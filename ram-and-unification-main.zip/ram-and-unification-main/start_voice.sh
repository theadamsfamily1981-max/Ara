#!/bin/bash
# Start the voice-controlled avatar

echo "🎤 Starting Voice Avatar..."
echo "Ara will talk to you!"
echo ""
echo "Press Ctrl+C to stop"
echo ""

cd /home/user/ram-and-unification/conversational-avatar
python main.py
