"""Media player modules for video and audio playback."""

from .media_player import MediaPlayer

__all__ = ["MediaPlayer"]
