"""TTS (Text-to-Speech) modules."""

from .coqui_tts import CoquiTTS

__all__ = ["CoquiTTS"]
