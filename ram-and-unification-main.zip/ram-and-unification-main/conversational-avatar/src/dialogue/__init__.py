"""Dialogue management modules."""

from .manager import DialogueManager

__all__ = ["DialogueManager"]
