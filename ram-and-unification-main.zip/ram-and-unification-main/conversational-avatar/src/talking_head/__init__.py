"""Talking head / avatar video generation modules."""

from .wav2lip_engine import Wav2LipTalkingHead

__all__ = ["Wav2LipTalkingHead"]
