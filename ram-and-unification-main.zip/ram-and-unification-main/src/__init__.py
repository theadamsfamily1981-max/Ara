"""
Talking Avatar API
A local AI-powered talking avatar system with API integration.
"""

__version__ = "1.0.0"
