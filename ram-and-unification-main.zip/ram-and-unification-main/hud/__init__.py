# hud/ - T-FAN Visualization Tools (GNOME HUD, etc.)
