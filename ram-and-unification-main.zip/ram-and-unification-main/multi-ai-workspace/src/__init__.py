"""Multi-AI Workspace - Intelligent multi-AI orchestration platform."""

__version__ = "0.1.0"
