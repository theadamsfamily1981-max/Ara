"""Web UI for Multi-AI Workspace."""

from .app import app

__all__ = ["app"]
