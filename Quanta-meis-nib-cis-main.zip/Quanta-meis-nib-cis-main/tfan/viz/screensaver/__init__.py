"""T-FAN Topology Screensaver - Living mathematics visualization."""
