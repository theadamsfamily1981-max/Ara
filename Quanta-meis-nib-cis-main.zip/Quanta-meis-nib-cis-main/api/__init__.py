"""T-FAN REST API package."""

from .main import app

__all__ = ["app"]
