#!/usr/bin/env python3
"""
Integrated Web GUI for Bug Bounty Automation System

Features:
- Real-time dashboard with all 10 AI analyzers
- Connection pooling, caching, and rate limiting
- Live metrics and statistics
- Analyzer controls (start/stop/pause)
- Finding display and export
- Configuration management
"""

from flask import Flask, render_template, jsonify, request, send_from_directory, Response
from flask_socketio import SocketIO, emit
from flask_cors import CORS
import os
import sys
import json
import logging
from datetime import datetime
from typing import Dict, Any
import threading

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Import new integrated components
from core.config import get_config, setup_logging
from core.web_integration import (
    WebIntegratedOrchestrator,
    create_orchestrator_routes,
    create_socket_handlers
)

# Import existing utilities
from src.utils.credentials_manager import CredentialsManager
from src.utils.db_migrations import run_all_migrations
from src.utils.audit_logger import audit_system_start, audit_system_stop

# Configure logging
config = get_config()
setup_logging(config)
logger = logging.getLogger(__name__)

# Flask app configuration
app = Flask(__name__,
            template_folder='web/templates',
            static_folder='web/static')

# Security configuration
app.config['SECRET_KEY'] = os.getenv('FLASK_SECRET_KEY', os.urandom(32).hex())
app.config['SESSION_COOKIE_SECURE'] = os.getenv('SESSION_COOKIE_SECURE', 'False').lower() == 'true'
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'

# CORS and SocketIO
CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

# Initialize components
credentials_manager = CredentialsManager()
orchestrator = None
start_time = datetime.now()

# Run database migrations
try:
    logger.info("Running database migrations...")
    run_all_migrations()
except Exception as e:
    logger.error(f"Error running migrations: {e}")


# ============================================================================
# Initialization
# ============================================================================

def initialize_orchestrator():
    """Initialize the web-integrated orchestrator"""
    global orchestrator

    try:
        logger.info("Initializing web-integrated orchestrator")
        orchestrator = WebIntegratedOrchestrator(socketio)
        orchestrator.initialize(config)

        # Start periodic updates
        orchestrator.emit_periodic_updates(interval=5)

        # Create API routes
        create_orchestrator_routes(app, orchestrator)

        # Create WebSocket handlers
        create_socket_handlers(socketio, orchestrator)

        audit_system_start()
        logger.info("Web-integrated orchestrator initialized successfully")

    except Exception as e:
        logger.error(f"Failed to initialize orchestrator: {e}", exc_info=True)
        raise


# ============================================================================
# Web Routes
# ============================================================================

@app.route('/')
def index():
    """Main dashboard page"""
    return render_template('dashboard.html')


@app.route('/analyzers')
def analyzers_page():
    """Analyzers management page"""
    return render_template('analyzers.html')


@app.route('/findings')
def findings_page():
    """Findings display page"""
    return render_template('findings.html')


@app.route('/config')
def config_page():
    """Configuration management page"""
    return render_template('config.html')


@app.route('/health')
def health_check():
    """Health check endpoint for monitoring"""
    health_status = {
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'uptime': (datetime.now() - start_time).total_seconds(),
        'components': {}
    }

    # Check orchestrator
    if orchestrator and orchestrator.running:
        health_status['components']['orchestrator'] = 'healthy'
    else:
        health_status['components']['orchestrator'] = 'initializing'
        health_status['status'] = 'starting'

    # Check credentials manager
    try:
        credentials_manager.list_platforms()
        health_status['components']['credentials'] = 'healthy'
    except Exception as e:
        logger.error(f"Credentials health check failed: {e}")
        health_status['components']['credentials'] = 'unhealthy'
        health_status['status'] = 'degraded'

    # Add analyzer status
    if orchestrator:
        status = orchestrator.get_status()
        health_status['analyzers'] = len([
            a for a in status.get('analyzers', {}).values()
            if a.get('status') == 'completed'
        ])

    status_code = 200 if health_status['status'] == 'healthy' else 503
    return jsonify(health_status), status_code


# Note: Orchestrator API routes are created by create_orchestrator_routes()
# Available routes:
# - /api/status - Get orchestrator status
# - /api/start_scan - Start scan (POST)
# - /api/pause - Pause scan
# - /api/resume - Resume scan
# - /api/findings - Get findings
# - /api/export/<format> - Export findings
# - /api/metrics - Get metrics
# - /api/analyzer/<name> - Get analyzer status


@app.route('/api/config')
def get_config_endpoint():
    """Get current configuration"""
    return jsonify(config.to_dict())


@app.route('/api/config', methods=['POST'])
def update_config_endpoint():
    """Update configuration"""
    try:
        data = request.get_json()

        # Validate and update config
        # (In production, this would update config file and reload)
        return jsonify({
            'success': True,
            'message': 'Configuration updated',
            'config': data
        })

    except Exception as e:
        logger.error(f"Config update error: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400


@app.route('/api/logs')
def get_logs():
    """Get recent logs"""
    try:
        log_file = config.log_file_path
        limit = int(request.args.get('limit', 100))

        if os.path.exists(log_file):
            with open(log_file, 'r') as f:
                lines = f.readlines()
                recent_lines = lines[-limit:]

                return jsonify({
                    'logs': [line.strip() for line in recent_lines],
                    'count': len(recent_lines)
                })
        else:
            return jsonify({'logs': [], 'count': 0})

    except Exception as e:
        logger.error(f"Error reading logs: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/stats/detailed')
def get_detailed_stats():
    """Get detailed system statistics"""
    if not orchestrator:
        return jsonify({'error': 'Orchestrator not initialized'}), 503

    metrics = orchestrator.get_metrics()

    # Add system info
    import psutil
    metrics['system'] = {
        'cpu_percent': psutil.cpu_percent(interval=1),
        'memory_percent': psutil.virtual_memory().percent,
        'disk_percent': psutil.disk_usage('/').percent
    }

    return jsonify(metrics)


@app.route('/api/targets', methods=['GET'])
def get_targets():
    """Get list of configured targets"""
    # Placeholder - would read from database/config
    targets = [
        {
            'id': 1,
            'name': 'Example Target',
            'url': 'https://example.com',
            'last_scan': '2025-11-24T10:00:00',
            'findings': 15
        }
    ]
    return jsonify({'targets': targets})


@app.route('/api/targets', methods=['POST'])
def add_target():
    """Add new target"""
    try:
        data = request.get_json()
        target_url = data.get('url')
        target_name = data.get('name')

        if not target_url:
            return jsonify({'error': 'URL required'}), 400

        # Validate URL
        from urllib.parse import urlparse
        parsed = urlparse(target_url)
        if not parsed.scheme or not parsed.netloc:
            return jsonify({'error': 'Invalid URL'}), 400

        # Save to database (placeholder)
        return jsonify({
            'success': True,
            'message': f'Target {target_name} added',
            'target': {
                'name': target_name,
                'url': target_url
            }
        })

    except Exception as e:
        logger.error(f"Error adding target: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/credentials', methods=['GET'])
def get_credentials():
    """Get stored credentials (without secrets)"""
    try:
        platforms = credentials_manager.list_platforms()
        return jsonify({'platforms': platforms})
    except Exception as e:
        logger.error(f"Error getting credentials: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/credentials', methods=['POST'])
def add_credential():
    """Add new credential"""
    try:
        data = request.get_json()
        platform = data.get('platform')
        username = data.get('username')
        api_token = data.get('api_token')

        if not all([platform, username, api_token]):
            return jsonify({'error': 'Missing required fields'}), 400

        credentials_manager.add_credential(platform, username, api_token)

        return jsonify({
            'success': True,
            'message': f'Credential added for {platform}'
        })

    except Exception as e:
        logger.error(f"Error adding credential: {e}")
        return jsonify({'error': str(e)}), 500


# ============================================================================
# WebSocket Events
# ============================================================================

# Socket handlers are created by create_socket_handlers()
# Available events:
# - connect - Client connected
# - disconnect - Client disconnected
# - request_status - Client requests status update
# - start_scan - Client starts scan


@socketio.on('subscribe_analyzer')
def handle_subscribe_analyzer(data):
    """Subscribe to specific analyzer updates"""
    analyzer_name = data.get('analyzer')
    logger.info(f"Client subscribed to {analyzer_name}")
    emit('subscribed', {'analyzer': analyzer_name})


# ============================================================================
# Startup and Shutdown
# ============================================================================

@app.before_first_request
def startup():
    """Run on first request"""
    initialize_orchestrator()


def shutdown_server():
    """Shutdown server gracefully"""
    logger.info("Shutting down server")

    if orchestrator:
        orchestrator.shutdown()

    audit_system_stop()


# ============================================================================
# Main Entry Point
# ============================================================================

def main():
    """Main entry point"""
    import argparse

    parser = argparse.ArgumentParser(description='Bug Bounty Automation Web GUI')
    parser.add_argument('--host', default='0.0.0.0', help='Host to bind to')
    parser.add_argument('--port', type=int, default=5000, help='Port to bind to')
    parser.add_argument('--debug', action='store_true', help='Enable debug mode')
    parser.add_argument('--env', default='production', help='Environment (development/production)')

    args = parser.parse_args()

    # Set environment
    os.environ['ANALYZER_ENV'] = args.env

    # Initialize orchestrator
    initialize_orchestrator()

    try:
        logger.info(f"Starting web GUI on {args.host}:{args.port}")
        logger.info(f"Environment: {args.env}")
        logger.info(f"Configuration:")
        logger.info(f"  - Connection pooling: {config.max_concurrent_connections} connections")
        logger.info(f"  - Caching: {'enabled' if config.cache_enabled else 'disabled'}")
        logger.info(f"  - Redis: {'enabled' if config.redis_enabled else 'disabled'}")
        logger.info(f"  - Rate limiting: {config.rate_limit_requests} req/hour")
        logger.info(f"  - SSL verification: {config.ssl_verify}")

        # Run server
        socketio.run(
            app,
            host=args.host,
            port=args.port,
            debug=args.debug,
            use_reloader=False  # Disable reloader to prevent double initialization
        )

    except KeyboardInterrupt:
        logger.info("Keyboard interrupt received")
    finally:
        shutdown_server()


if __name__ == '__main__':
    main()
