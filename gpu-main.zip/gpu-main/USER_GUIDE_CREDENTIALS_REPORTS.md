# User Guide: Credentials, Program Bounties & Report Submission

## Overview

The system now includes comprehensive features for:
1. 📋 **Viewing bug bounty programs with current bounty amounts**
2. 🔐 **Secure credential management for platform logins**
3. 📝 **Report review and submission with your credentials**

---

## 1. Bounty Program Dashboard 📋

### What You Can See

The system shows all discovered bug bounty programs with complete bounty information:

**Program Details**:
- Program name
- Platform (HackerOne, Bugcrowd, etc.)
- Program URL
- **Bounty amounts** for each severity level:
  - Critical: $X,XXX
  - High: $X,XXX
  - Medium: $XXX
  - Low: $XX

### How to Access

#### Via Web GUI:
```bash
# Start the GUI
python web_gui.py

# Open browser
http://localhost:5000

# Navigate to "Programs" tab
```

You'll see a table with:
```
╔══════════════╦══════════╦════════════╦══════════════════╗
║ Program Name ║ Platform ║ Critical   ║ High | Med | Low ║
╠══════════════╬══════════╬════════════╬══════════════════╣
║ Red Hat      ║ HackerOne║ $10,000    ║ $5,000 | $2,000...
║ Acme Corp    ║ Bugcrowd ║ $15,000    ║ $8,000 | $3,000...
╚══════════════╩══════════╩════════════╩══════════════════╝
```

#### Via API:
```bash
curl http://localhost:5000/api/programs/bounties
```

Returns JSON:
```json
{
  "programs": [
    {
      "id": 1,
      "name": "Red Hat",
      "platform": "hackerone",
      "url": "https://hackerone.com/redhat",
      "bounties": {
        "critical": 10000,
        "high": 5000,
        "medium": 2000,
        "low": 500
      },
      "last_scanned": "2024-01-15T10:30:00"
    }
  ]
}
```

### Understanding Bounty Ranges

**What the numbers mean**:
- **Critical** ($5,000-$50,000): RCE, Authentication Bypass, SQL Injection
- **High** ($2,000-$10,000): XSS, IDOR, SSRF
- **Medium** ($500-$3,000): CSRF, Info Disclosure
- **Low** ($100-$1,000): Open Redirect, Minor issues

**Your earnings potential**:
```
Example Week:
- 2 Critical findings  = $20,000
- 3 High findings      = $15,000
- 5 Medium findings    = $10,000
- 10 Low findings      = $5,000
────────────────────────────────
Total Weekly Earnings: $50,000
```

---

## 2. Credentials Manager 🔐

### Why You Need This

To submit reports automatically, the system needs your platform credentials. Your credentials are:
- ✅ **Encrypted** using Fernet (AES-256)
- ✅ **Stored locally** in `data/credentials.enc`
- ✅ **Never sent** anywhere except platform APIs
- ✅ **Protected** with file permissions (600)

### Supported Platforms

- **HackerOne** (username + API token)
- **Bugcrowd** (email + API token)
- **Intigriti** (API key)
- **YesWeHack** (API token)
- **Custom platforms** (add your own)

### How to Add Credentials

#### Method 1: Web GUI (Recommended)

```bash
# Start GUI
python web_gui.py
```

**Step-by-step**:
1. Open http://localhost:5000
2. Go to **"Credentials"** tab (new!)
3. Click **"Add Credential"**
4. Fill in the form:
   ```
   Platform:  [HackerOne ▼]
   Username:  your_username
   API Token: hc1_xxxxxxxxxxxxx
   ```
5. Click **"Save"**
6. See confirmation: ✅ "Credentials saved for HackerOne"

#### Method 2: API

```bash
curl -X POST http://localhost:5000/api/credentials/hackerone \
  -H "Content-Type: application/json" \
  -d '{
    "username": "your_username",
    "api_token": "hc1_your_token_here"
  }'
```

#### Method 3: Python Code

```python
from src.utils.credentials_manager import CredentialsManager

creds = CredentialsManager()

# Add HackerOne credentials
creds.add_credential(
    platform='hackerone',
    username='your_username',
    api_token='hc1_your_token_here'
)

# Add Bugcrowd credentials
creds.add_credential(
    platform='bugcrowd',
    username='your@email.com',
    api_token='bc_your_token_here'
)
```

### Where to Find Your API Tokens

#### HackerOne:
1. Go to https://hackerone.com/settings/api
2. Click "Create API Token"
3. Name it: "Bug Bounty Automation"
4. Copy the token: `hc1_xxxxxxxxxx`
5. **Important**: Save it now (can't view again!)

#### Bugcrowd:
1. Go to https://bugcrowd.com/user/api
2. Generate new API key
3. Copy both API Key and Secret
4. Use API Key as token in the system

### Viewing Your Credentials

**Via GUI**:
- Go to "Credentials" tab
- See all platforms with status
- Tokens are masked: `hc1_1234****5678`

**Via API**:
```bash
curl http://localhost:5000/api/credentials
```

Returns:
```json
{
  "credentials": {
    "hackerone": {
      "username": "your_username",
      "api_token": "hc1_1234****5678",
      "has_credentials": true
    },
    "bugcrowd": {
      "username": "your@email.com",
      "api_token": "bc_9876****4321",
      "has_credentials": true
    }
  },
  "platforms": ["hackerone", "bugcrowd"],
  "count": 2
}
```

### Removing Credentials

**Via GUI**:
- Go to "Credentials" tab
- Click **"Delete"** next to platform
- Confirm deletion

**Via API**:
```bash
curl -X DELETE http://localhost:5000/api/credentials/hackerone
```

### Security Notes

**Your credentials are safe because**:
1. **Encrypted at rest**: Using Fernet (AES-256-CBC)
2. **Key stored separately**: In `data/.key` with 600 permissions
3. **Never logged**: Credentials never appear in logs
4. **Local only**: Never transmitted except to official platform APIs
5. **No cloud storage**: Everything stays on your machine

**Best practices**:
- ✅ Use API tokens (not passwords)
- ✅ Create tokens with minimal permissions
- ✅ Rotate tokens every 90 days
- ✅ Use different tokens per application
- ❌ Never commit `.env` or `data/` folder to git

---

## 3. Report Review & Submission 📝

### The Workflow

```
1. System finds vulnerability
2. System generates professional report
3. Report appears in "Pending Reports"
4. YOU review the report
5. YOU approve or reject
6. If approved, YOU submit with your credentials
7. System tracks submission status
```

### Viewing Pending Reports

#### Via Web GUI:

```bash
# Start GUI
python web_gui.py

# Navigate to "Reports" tab → "Pending" subtab
```

You'll see:
```
╔═══╦══════════════════════╦══════════╦══════════╦════════════╗
║ # ║ Vulnerability        ║ Severity ║ Platform ║ Actions    ║
╠═══╬══════════════════════╬══════════╬══════════╬════════════╣
║ 1 ║ XSS in Profile Page  ║ High     ║ H1       ║ [Review]   ║
║ 2 ║ SQL Injection - API  ║ Critical ║ Bugcrowd ║ [Review]   ║
║ 3 ║ IDOR in User Data    ║ High     ║ H1       ║ [Review]   ║
╚═══╩══════════════════════╩══════════╩══════════╩════════════╝
```

#### Via API:

```bash
curl http://localhost:5000/api/reports/pending
```

Returns:
```json
{
  "reports": [
    {
      "id": 1,
      "vulnerability_name": "XSS in Profile Page",
      "severity": "high",
      "platform": "hackerone",
      "program_name": "Red Hat",
      "url": "https://redhat.com/profile",
      "report_content": "# XSS in Profile Page\n\n## Summary\n...",
      "generated_at": "2024-01-15T14:30:00"
    }
  ]
}
```

### Reviewing a Report

**Click "Review" to see**:

```markdown
# Cross-Site Scripting (XSS) in User Profile Page

## Summary
A high severity cross-site scripting vulnerability was discovered in
https://redhat.com/profile. This vulnerability allows an attacker to
execute arbitrary JavaScript...

## Steps to Reproduce
1. Navigate to https://redhat.com/profile
2. In the "name" field, enter: <script>alert(1)</script>
3. Save the profile
4. Observe the JavaScript execution

Expected: Input should be sanitized
Actual: JavaScript executes

## Impact
An attacker could steal session cookies, perform actions as the victim,
or redirect to phishing sites...

**Business Impact:**
- Data breach risk
- Reputation damage
- Compliance violations

## Proof of Concept
```html
<script>alert(document.cookie)</script>
```

## Remediation
1. Implement output encoding for all user input
2. Use Content Security Policy headers
3. Apply framework XSS protections

## References
- https://owasp.org/www-community/attacks/xss/
- https://cwe.mitre.org/data/definitions/79.html
```

**Your options**:
- ✅ **Approve**: Move to submission queue
- ✏️ **Edit**: Modify report before submission
- ❌ **Reject**: Delete report (false positive)

### Submitting Reports

#### Prerequisites:
1. ✅ Credentials added for the platform
2. ✅ Report reviewed and approved
3. ✅ Internet connection active

#### Via Web GUI:

**Step 1**: Review and approve report
**Step 2**: Click "Submit to [Platform]"
**Step 3**: System checks credentials
**Step 4**: Submits via platform API
**Step 5**: Shows confirmation

```
✅ Report Submitted Successfully!

Report ID: 123
Platform: HackerOne
Program: Red Hat
Severity: High
Submission Time: 2024-01-15 14:45:00

Report URL: https://hackerone.com/reports/123456

Next Steps:
- Monitor your email for triage updates
- System will track report status
- Check dashboard for acceptance notifications
```

#### Via API:

```bash
curl -X POST http://localhost:5000/api/reports/1/submit \
  -H "Content-Type: application/json" \
  -d '{"platform": "hackerone"}'
```

### Tracking Submitted Reports

The system tracks:
- ✅ Submission time
- ✅ Report ID from platform
- ✅ Current status (Pending, Triaged, Resolved)
- ✅ Bounty amount (if awarded)
- ✅ Response time

**View in GUI**: "Reports" tab → "Submitted" subtab

### Manual Submission (If Preferred)

**Don't want automatic submission?**

1. Generate reports as usual
2. Click "Download Report"
3. Copy/paste into platform manually
4. Mark as "Submitted Manually" in system

### Report Quality

**System ensures high quality**:
- ✅ All required sections included
- ✅ Professional formatting
- ✅ Clear reproduction steps
- ✅ Impact explanation
- ✅ Remediation advice
- ✅ References included
- ✅ Appropriate severity

**Quality Score**: Each report is scored 0-100
- **90-100**: Grade A (Very High Acceptance)
- **80-89**: Grade B (High Acceptance)
- **70-79**: Grade C (Medium Acceptance)
- **<70**: Auto-improved before review

---

## 4. Complete Workflow Example

### Scenario: Finding and Submitting XSS

**Day 1 - Setup** (One-time, 5 minutes):
```bash
1. Start GUI: python web_gui.py
2. Add HackerOne credentials:
   - Username: your_username
   - Token: hc1_xxxxxxxxxx
3. Add Bugcrowd credentials:
   - Email: your@email.com
   - Token: bc_yyyyyyyy
```

**Day 2 - Discovery** (Automatic):
```bash
1. System runs scan (continuous mode)
2. Finds XSS vulnerability in Red Hat program
3. Generates professional report
4. Report appears in "Pending Reports" ← YOU GET NOTIFIED
```

**Day 2 - Review** (5 minutes):
```bash
1. Open GUI → "Reports" tab
2. See: "XSS in Profile Page - High - Red Hat"
3. Click "Review"
4. Read through report
5. Looks good! Click "Approve"
```

**Day 2 - Submission** (30 seconds):
```bash
1. Click "Submit to HackerOne"
2. System uses your HackerOne credentials
3. Submits via API
4. Shows confirmation with Report ID
5. Done! ✅
```

**Day 3-7 - Tracking**:
```bash
1. Check email for triage updates
2. View status in GUI
3. Get notified when accepted
4. See bounty amount updated
```

**Result**: $5,000 bounty for High severity XSS! 💰

---

## 5. API Reference

### Credentials Management

```bash
# Get all credentials (masked)
GET /api/credentials

# Add/update credential
POST /api/credentials/{platform}
Body: {"username": "...", "api_token": "..."}

# Delete credential
DELETE /api/credentials/{platform}
```

### Programs & Bounties

```bash
# Get all programs with bounty info
GET /api/programs/bounties

# Get specific program
GET /api/programs/{id}
```

### Reports

```bash
# Get pending reports
GET /api/reports/pending

# Get specific report
GET /api/reports/{id}

# Approve report
POST /api/reports/{id}/approve

# Reject report
POST /api/reports/{id}/reject

# Submit report
POST /api/reports/{id}/submit
Body: {"platform": "hackerone"}
```

---

## 6. Troubleshooting

### "No credentials found for platform"

**Problem**: Trying to submit without credentials

**Solution**:
```bash
1. Go to "Credentials" tab
2. Add credentials for the platform
3. Try submission again
```

### "Invalid API token"

**Problem**: Credentials are incorrect or expired

**Solution**:
```bash
1. Go to platform website
2. Generate new API token
3. Update credentials in system
4. Try again
```

### "Report submission failed"

**Problem**: API error or network issue

**Solution**:
```bash
1. Check internet connection
2. Verify credentials are valid
3. Check platform API status
4. Try manual submission as fallback
5. Contact platform support if persists
```

### "Can't see bounty amounts"

**Problem**: Program hasn't been scanned yet or bounties not public

**Solution**:
```bash
# Bounties appear after first successful program discovery
1. Run a scan: python main.py --once
2. Wait for program discovery to complete
3. Refresh programs list
4. If still missing, program may not publish bounties publicly
```

---

## 7. Security Best Practices

### Credential Management

✅ **DO**:
- Use API tokens (never passwords)
- Create separate tokens per application
- Store tokens only in credential manager
- Rotate tokens every 90 days
- Use minimum required permissions

❌ **DON'T**:
- Share tokens with others
- Commit tokens to version control
- Use same token across multiple apps
- Store tokens in plain text files
- Use admin-level tokens if not needed

### Report Submission

✅ **DO**:
- Review every report before submission
- Verify vulnerability still exists
- Check report quality score
- Test PoC before submitting
- Follow responsible disclosure

❌ **DON'T**:
- Auto-submit without review
- Submit duplicate reports
- Submit to out-of-scope targets
- Include sensitive data in reports
- Spam programs with low-quality reports

### System Access

✅ **DO**:
- Run GUI on localhost only
- Use firewall to block external access
- Keep system updated
- Back up credentials regularly
- Use strong machine passwords

❌ **DON'T**:
- Expose GUI to internet
- Run as root/administrator
- Share credentials file
- Disable encryption
- Run on shared computers

---

## 8. FAQ

**Q: Are my credentials safe?**
A: Yes! They're encrypted with AES-256, stored locally, and never sent anywhere except official platform APIs.

**Q: Can I use the system without adding credentials?**
A: Yes! The system will generate reports, but you'll need to submit them manually.

**Q: Do I have to submit reports through the system?**
A: No. You can download reports and submit manually through platform websites.

**Q: Can I edit reports before submission?**
A: Yes! Click "Edit" in the report review screen.

**Q: What happens if submission fails?**
A: The report stays in "Pending" status. Fix the issue and retry, or submit manually.

**Q: Can I see my earnings?**
A: Yes! The dashboard shows total submitted, accepted, and earned amounts.

**Q: How do I update bounty amounts for programs?**
A: They update automatically during program discovery scans.

**Q: Can I add custom platforms?**
A: Yes! Use the credentials manager with your platform name and API details.

---

## 9. Next Steps

Now that you understand credentials and report submission:

1. **Add your credentials** (5 minutes):
   ```bash
   python web_gui.py
   # Go to Credentials tab → Add your platforms
   ```

2. **Run a scan** (automatic):
   ```bash
   python main.py --once
   # Or use GUI: click "Scan Once"
   ```

3. **Review reports** (as they appear):
   ```bash
   # Check "Reports" tab for pending reports
   # Review, approve, and submit!
   ```

4. **Track earnings** (ongoing):
   ```bash
   # Monitor dashboard for:
   # - Reports submitted
   # - Reports accepted
   # - Total bounties earned
   ```

---

## 10. Summary

✅ **You can now**:
- View all bug bounty programs with current bounty amounts
- Securely store your platform credentials
- Review generated reports before submission
- Submit reports with one click using your credentials
- Track submission status and earnings

✅ **The system handles**:
- Secure encryption of credentials
- Professional report generation
- Quality scoring and improvement
- Platform API integration
- Submission tracking

✅ **You control**:
- Which reports to submit
- When to submit them
- Which platforms to use
- Manual edits if needed

**Your credentials are safe, your reports are professional, and your earnings are maximized!** 🚀💰🔐

---

**Need help?** Check the logs:
```bash
tail -f logs/bounty_hunter.log
```

**Questions?** All APIs and functions are documented in the code!
