#!/bin/bash
# Setup script for Red Hat Bug Bounty Automation System

echo "=========================================="
echo "Red Hat Bug Bounty Automation Setup"
echo "=========================================="
echo ""

# Check if running as root (not recommended)
if [ "$EUID" -eq 0 ]; then
    echo "WARNING: Running as root is not recommended."
    read -p "Continue anyway? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Create virtual environment
echo "[1/8] Creating Python virtual environment..."
python3 -m venv venv
source venv/bin/activate

# Upgrade pip
echo "[2/8] Upgrading pip..."
pip install --upgrade pip

# Install Python dependencies
echo "[3/8] Installing Python dependencies..."
pip install -r requirements.txt

# Create directories
echo "[4/8] Creating required directories..."
mkdir -p data logs reports templates

# Install external tools (optional)
echo "[5/8] Installing external security tools..."
echo "Note: Some tools require sudo privileges. You may be prompted for your password."

# Check for and install common tools
command -v subfinder >/dev/null 2>&1 || {
    echo "Installing subfinder..."
    GO111MODULE=on go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest 2>/dev/null || echo "  Skipped (requires Go)"
}

command -v nuclei >/dev/null 2>&1 || {
    echo "Installing nuclei..."
    GO111MODULE=on go install -v github.com/projectdiscovery/nuclei/v2/cmd/nuclei@latest 2>/dev/null || echo "  Skipped (requires Go)"
}

command -v httpx >/dev/null 2>&1 || {
    echo "Installing httpx..."
    GO111MODULE=on go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest 2>/dev/null || echo "  Skipped (requires Go)"
}

# Update nuclei templates
echo "[6/8] Updating nuclei templates..."
nuclei -update-templates 2>/dev/null || echo "  Skipped (nuclei not installed)"

# Copy environment template
echo "[7/8] Setting up environment configuration..."
if [ ! -f .env ]; then
    cp .env.example .env
    echo "  Created .env file. Please edit it with your credentials."
else
    echo "  .env file already exists."
fi

# Set permissions
echo "[8/8] Setting permissions..."
chmod +x main.py

echo ""
echo "=========================================="
echo "Setup Complete!"
echo "=========================================="
echo ""
echo "Next steps:"
echo "1. Edit .env file with your API credentials:"
echo "   nano .env"
echo ""
echo "2. Review and customize config.yaml if needed:"
echo "   nano config.yaml"
echo ""
echo "3. Activate the virtual environment:"
echo "   source venv/bin/activate"
echo ""
echo "4. Run the system:"
echo "   python main.py --once        (single scan)"
echo "   python main.py --continuous  (continuous mode)"
echo ""
echo "=========================================="
