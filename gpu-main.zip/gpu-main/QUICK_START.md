# Quick Start Guide - Red Hat Bug Bounty Automation

## What Makes This System Competitive

### 🎯 Instant Value Features (Already Implemented)

1. **GitHub Secret Hunting** 🔥
   - Searches 40+ patterns for leaked credentials
   - Targets Red Hat repos specifically
   - Finds: API keys, passwords, tokens, private keys, DB creds
   - **Why it works**: Large orgs = more developers = more leaks
   - **Average payout**: $500-$5000 per secret

2. **Subdomain Takeover Detection** 🎯
   - Checks 6 major cloud platforms automatically
   - AWS S3, GitHub Pages, Heroku, Azure, Shopify, Fastly
   - **Why it works**: Fast-moving orgs abandon resources
   - **Average payout**: $1000-$3000 per takeover

3. **Full Automation Pipeline** 🤖
   - Runs 24/7 without manual intervention
   - Parallel scanning for speed
   - Smart prioritization (critical findings first)
   - Real-time Slack notifications

## Setup in 5 Minutes

### Step 1: Clone & Install
```bash
git clone <repo-url>
cd gpu
chmod +x setup.sh
./setup.sh
```

### Step 2: Configure Credentials
```bash
cp .env.example .env
nano .env
```

**Minimum Required**:
```bash
GITHUB_TOKEN=ghp_your_github_token_here
SLACK_WEBHOOK_URL=https://hooks.slack.com/your/webhook
```

**Optional (for platform submission)**:
```bash
HACKERONE_API_TOKEN=your_token
HACKERONE_USERNAME=your_username
BUGCROWD_API_TOKEN=your_token
```

### Step 3: Run
```bash
source venv/bin/activate

# Test run (single cycle):
python main.py --once

# Production mode (24/7):
python main.py --continuous
```

## What Happens When You Run It

```
Step 1: Discover Red Hat Programs (2-5 min)
├── HackerOne: redhat, openshift, ansible
└── Bugcrowd: rhel, jboss

Step 2: GitHub Secret Hunting (5-15 min) 🔥 HIGH VALUE
├── Search 40+ patterns across GitHub
├── Find leaked credentials, tokens, keys
└── Immediate Slack notification → Report → $$$

Step 3: Reconnaissance (30-60 min)
├── Subdomain enumeration (subfinder, amass, DNS, certs)
├── Port scanning (masscan/nmap)
└── Technology fingerprinting

Step 3.5: Subdomain Takeover Check (5-10 min) 🔥 HIGH VALUE
├── Check all subdomains for dangling CNAMEs
├── Validate against vulnerable services
└── Immediate Slack notification → Report → $$$

Step 4: Vulnerability Scanning (1-3 hours)
├── Nuclei templates (CVEs, misconfigs)
├── Custom scanners (XSS, SQLi, SSRF, RCE)
└── Parallel scanning for efficiency

Step 5: Exploit Development (10-30 min)
├── Generate PoC exploits
├── Create advanced payloads
└── Verify exploitability

Step 6: Report Generation (5-10 min)
├── Professional markdown reports
├── Optional auto-submission
└── Save to ./reports/

Step 7: Leaderboard Tracking (ongoing)
└── Monitor your ranking progress
```

## Expected Results - First 24 Hours

**Conservative Estimate**:
- GitHub Secrets Found: 2-5 (often critical severity)
- Subdomain Takeovers: 1-3 (high severity)
- XSS Vulnerabilities: 3-8 (medium-high)
- Other Findings: 5-15 (varies)

**Potential Earnings** (first week):
- Low estimate: $2,000-$5,000
- Medium estimate: $5,000-$15,000
- High estimate: $15,000-$30,000+

*(Depends on program generosity, finding severity, and report quality)*

## Pro Tips for Maximum Results

### 1. GitHub Token is Critical
Without it, you get 60 API requests/hour. With authentication: 5,000/hour.

Get one here: https://github.com/settings/tokens
Required scopes: `public_repo`, `read:org`

### 2. Let It Run Continuously
The system is designed for 24/7 operation:
- New subdomains appear daily
- Developers push secrets at all hours
- Early bird gets the bounty

### 3. Monitor Slack Notifications
Set up mobile notifications for:
- `critical_finding` - GitHub secrets, critical CVEs
- `high_finding` - Subdomain takeovers, high-severity bugs

### 4. Quick Wins First
The system prioritizes:
1. GitHub secrets (Step 2) - Usually fastest to report
2. Subdomain takeovers (Step 3.5) - Easy to verify
3. Then standard vulnerabilities

### 5. Manual Review Before Submission
```yaml
# In config.yaml
reporting:
  auto_submit: false  # Keep this false initially
  require_manual_review: true  # Review reports first
```

This ensures high-quality submissions and protects your reputation.

## Monitoring Your Success

### Real-time Logs
```bash
tail -f logs/bounty_hunter.log
```

### Database Query
```bash
sqlite3 data/bounty_hunter.db "SELECT severity, COUNT(*) FROM vulnerabilities GROUP BY severity;"
```

### Reports Directory
```bash
ls -lh reports/
```

## Troubleshooting

### No GitHub Secrets Found
- ✅ Check GITHUB_TOKEN is set correctly
- ✅ Verify token has correct scopes
- ✅ GitHub rate limit? Wait 1 hour or use authenticated token

### No Subdomains Discovered
- ✅ Install subfinder: `go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest`
- ✅ Install amass: `go install github.com/OWASP/Amass/v3/...@master`
- ✅ Check DNS resolution is working

### Scan is Slow
- ✅ Increase `max_concurrent_scans` in config.yaml (default: 5)
- ✅ Use faster network connection
- ✅ Consider cloud instance (AWS/GCP)

### Rate Limited
System has built-in rate limiting. If you see 429 errors:
- ✅ Decrease `max_concurrent_scans`
- ✅ Increase `request_delay_ms`

## Next Steps After First Results

1. **Review the IMPROVEMENTS.md file** - 50+ enhancements to implement
2. **Focus on Phase 1 quick wins** - More GitHub patterns, better detection
3. **Scale with cloud workers** - Distributed scanning for 10x speed
4. **Add ML prioritization** - Learn from successful findings

## Support

- Documentation: See README.md
- Improvements: See IMPROVEMENTS.md
- Issues: Check logs in ./logs/
- Configuration: Review config.yaml

---

## The Competitive Edge

Most bug bounty hunters:
- ❌ Manual reconnaissance
- ❌ Miss GitHub secrets entirely
- ❌ Don't check subdomain takeovers
- ❌ Scan 9-5 only
- ❌ Slow to report

This system:
- ✅ Fully automated 24/7
- ✅ GitHub dorking built-in
- ✅ Subdomain takeover detection
- ✅ Never sleeps
- ✅ Reports within minutes

**Result**: You're competing 24/7 while others sleep. 🚀

---

**Ready to start?**
```bash
python main.py --continuous
```

Watch the Slack notifications roll in! 💰
