#!/usr/bin/env python3
"""
Web-based GUI for Bug Bounty Automation System
Real-time dashboard with statistics, logs, and controls
"""

from flask import Flask, render_template, jsonify, request, send_from_directory
from flask_socketio import SocketIO, emit
from flask_cors import CORS
import asyncio
import threading
import os
import json
import yaml
from datetime import datetime
import sqlite3
import logging
from typing import Dict, List

# Import credentials manager
from src.utils.credentials_manager import CredentialsManager
from src.utils.db_migrations import run_all_migrations
from src.utils.input_validation import (
    validate_platform, validate_username, validate_api_token,
    validate_report_id, validate_limit_parameter, sanitize_string
)
from src.utils.audit_logger import (
    audit_credential_added, audit_credential_deleted,
    audit_report_submitted, audit_report_rejected,
    audit_failed_validation, audit_system_start, audit_system_stop
)
from contextlib import contextmanager

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__,
            template_folder='web/templates',
            static_folder='web/static')

# SECURITY: Use environment variable for SECRET_KEY or generate secure random key
app.config['SECRET_KEY'] = os.getenv('FLASK_SECRET_KEY', os.urandom(32).hex())
app.config['SESSION_COOKIE_SECURE'] = os.getenv('SESSION_COOKIE_SECURE', 'False').lower() == 'true'
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'

CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='eventlet')

# Global state
system_state = {
    'status': 'stopped',
    'current_cycle': None,
    'last_update': None,
    'statistics': {},
    'active_scans': []
}

orchestrator = None
credentials_manager = CredentialsManager()


# Database utilities
@contextmanager
def get_db_connection(db_path='data/bounty_hunter.db'):
    """Context manager for database connections to ensure proper cleanup."""
    conn = None
    try:
        conn = sqlite3.connect(db_path)
        yield conn
        conn.commit()  # Auto-commit on success
    except Exception as e:
        if conn:
            conn.rollback()
        logger.error(f"Database error: {e}")
        raise
    finally:
        if conn:
            conn.close()


# Run database migrations on startup
try:
    logger.info("Running database migrations...")
    run_all_migrations()
except Exception as e:
    logger.error(f"Error running migrations: {e}")


class GUIOrchestrator:
    """Wrapper for orchestrator with GUI callbacks."""

    def __init__(self):
        """Initialize GUI orchestrator."""
        from main import BugBountyOrchestrator
        self.orchestrator = BugBountyOrchestrator()
        self.running = False
        self.cycle_count = 0

    async def run_cycle_with_updates(self):
        """Run cycle with real-time GUI updates."""
        try:
            self.cycle_count += 1
            system_state['status'] = 'running'
            system_state['current_cycle'] = self.cycle_count

            socketio.emit('status_update', {
                'status': 'running',
                'cycle': self.cycle_count,
                'timestamp': datetime.now().isoformat()
            })

            # Run actual cycle
            result = await self.orchestrator.run_cycle()

            # Update statistics
            system_state['statistics'] = result
            system_state['last_update'] = datetime.now().isoformat()

            socketio.emit('cycle_complete', {
                'cycle': self.cycle_count,
                'statistics': result,
                'timestamp': datetime.now().isoformat()
            })

            return result

        except Exception as e:
            logger.error(f"Cycle error: {e}", exc_info=True)
            socketio.emit('error', {
                'message': str(e),
                'timestamp': datetime.now().isoformat()
            })
            raise


# ============================================================================
# Web Routes
# ============================================================================

@app.route('/')
def index():
    """Main dashboard page."""
    return render_template('dashboard.html')


@app.route('/health')
def health_check():
    """Health check endpoint for monitoring."""
    health_status = {
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'components': {}
    }

    # Check database connectivity
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT 1")
            health_status['components']['database'] = 'healthy'
    except Exception as e:
        logger.error(f"Database health check failed: {e}")
        health_status['components']['database'] = 'unhealthy'
        health_status['status'] = 'degraded'

    # Check credentials manager
    try:
        credentials_manager.list_platforms()
        health_status['components']['credentials'] = 'healthy'
    except Exception as e:
        logger.error(f"Credentials health check failed: {e}")
        health_status['components']['credentials'] = 'unhealthy'
        health_status['status'] = 'degraded'

    # Check orchestrator status
    health_status['components']['orchestrator'] = system_state['status']

    status_code = 200 if health_status['status'] == 'healthy' else 503
    return jsonify(health_status), status_code


@app.route('/api/status')
def get_status():
    """Get current system status."""
    return jsonify({
        'status': system_state['status'],
        'current_cycle': system_state['current_cycle'],
        'last_update': system_state['last_update'],
        'uptime': get_uptime()
    })


@app.route('/api/statistics')
def get_statistics():
    """Get current statistics."""
    db_stats = get_database_statistics()

    return jsonify({
        'current_cycle': system_state.get('statistics', {}),
        'database': db_stats,
        'timestamp': datetime.now().isoformat()
    })


@app.route('/api/config', methods=['GET', 'POST'])
def config():
    """Get or update configuration."""
    config_path = 'config.yaml'

    if request.method == 'GET':
        try:
            with open(config_path, 'r') as f:
                config_data = yaml.safe_load(f)
            return jsonify(config_data)
        except Exception as e:
            return jsonify({'error': str(e)}), 500

    elif request.method == 'POST':
        try:
            new_config = request.json
            with open(config_path, 'w') as f:
                yaml.dump(new_config, f, default_flow_style=False)

            socketio.emit('config_updated', {
                'timestamp': datetime.now().isoformat()
            })

            return jsonify({'success': True})
        except Exception as e:
            return jsonify({'error': str(e)}), 500


@app.route('/api/logs')
def get_logs():
    """Get recent log entries."""
    log_file = 'logs/bounty_hunter.log'
    lines = int(request.args.get('lines', 100))

    try:
        if os.path.exists(log_file):
            with open(log_file, 'r') as f:
                log_lines = f.readlines()
                recent_logs = log_lines[-lines:]
                return jsonify({
                    'logs': recent_logs,
                    'total_lines': len(log_lines)
                })
        else:
            return jsonify({'logs': [], 'total_lines': 0})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/reports')
def get_reports():
    """Get list of generated reports."""
    reports_dir = 'reports'

    try:
        if not os.path.exists(reports_dir):
            return jsonify({'reports': []})

        reports = []
        for filename in os.listdir(reports_dir):
            if filename.endswith('.html') or filename.endswith('.json'):
                filepath = os.path.join(reports_dir, filename)
                reports.append({
                    'filename': filename,
                    'size': os.path.getsize(filepath),
                    'modified': datetime.fromtimestamp(os.path.getmtime(filepath)).isoformat()
                })

        return jsonify({'reports': sorted(reports, key=lambda x: x['modified'], reverse=True)})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/reports/<filename>')
def get_report(filename):
    """Download a specific report."""
    return send_from_directory('reports', filename)


@app.route('/api/vulnerabilities')
def get_vulnerabilities():
    """Get recent vulnerabilities from database."""
    try:
        conn = sqlite3.connect('data/bounty_hunter.db')
        cursor = conn.cursor()

        limit = int(request.args.get('limit', 50))

        cursor.execute("""
            SELECT id, program_name, url, category, severity, name, created_at
            FROM vulnerabilities
            ORDER BY created_at DESC
            LIMIT ?
        """, (limit,))

        vulnerabilities = []
        for row in cursor.fetchall():
            vulnerabilities.append({
                'id': row[0],
                'program': row[1],
                'url': row[2],
                'category': row[3],
                'severity': row[4],
                'name': row[5],
                'created_at': row[6]
            })

        conn.close()

        return jsonify({'vulnerabilities': vulnerabilities})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/programs')
def get_programs():
    """Get tracked programs."""
    try:
        conn = sqlite3.connect('data/bounty_hunter.db')
        cursor = conn.cursor()

        cursor.execute("""
            SELECT id, name, platform, url, last_scanned
            FROM programs
            ORDER BY last_scanned DESC
        """)

        programs = []
        for row in cursor.fetchall():
            programs.append({
                'id': row[0],
                'name': row[1],
                'platform': row[2],
                'url': row[3],
                'last_scanned': row[4]
            })

        conn.close()

        return jsonify({'programs': programs})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ============================================================================
# Control Endpoints
# ============================================================================

@app.route('/api/control/start', methods=['POST'])
def start_system():
    """Start the automation system."""
    global orchestrator

    try:
        if system_state['status'] == 'running':
            return jsonify({'error': 'System already running'}), 400

        # Initialize orchestrator if needed
        if orchestrator is None:
            orchestrator = GUIOrchestrator()

        # Start in background thread
        def run_continuous():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

            orchestrator.running = True
            while orchestrator.running:
                try:
                    loop.run_until_complete(orchestrator.run_cycle_with_updates())
                    loop.run_until_complete(asyncio.sleep(3600))  # Wait 1 hour
                except Exception as e:
                    logger.error(f"Error in continuous mode: {e}")
                    break

        thread = threading.Thread(target=run_continuous, daemon=True)
        thread.start()

        system_state['status'] = 'running'

        return jsonify({'success': True, 'message': 'System started'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/control/stop', methods=['POST'])
def stop_system():
    """Stop the automation system."""
    global orchestrator

    try:
        if orchestrator:
            orchestrator.running = False

        system_state['status'] = 'stopped'

        socketio.emit('status_update', {
            'status': 'stopped',
            'timestamp': datetime.now().isoformat()
        })

        return jsonify({'success': True, 'message': 'System stopped'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/control/scan-once', methods=['POST'])
def scan_once():
    """Run a single scan cycle."""
    global orchestrator

    try:
        if system_state['status'] == 'running':
            return jsonify({'error': 'System already running'}), 400

        # Initialize orchestrator if needed
        if orchestrator is None:
            orchestrator = GUIOrchestrator()

        # Run single cycle in background
        def run_once():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

            try:
                loop.run_until_complete(orchestrator.run_cycle_with_updates())
                system_state['status'] = 'stopped'
            except Exception as e:
                logger.error(f"Error in single cycle: {e}")
                system_state['status'] = 'error'

        thread = threading.Thread(target=run_once, daemon=True)
        thread.start()

        return jsonify({'success': True, 'message': 'Single scan started'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ============================================================================
# Credentials Management Endpoints
# ============================================================================

@app.route('/api/credentials', methods=['GET'])
def get_credentials():
    """Get all stored credentials (masked)."""
    try:
        creds = credentials_manager.get_all_masked()
        platforms = credentials_manager.list_platforms()

        return jsonify({
            'credentials': creds,
            'platforms': platforms,
            'count': len(platforms)
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/credentials/<platform>', methods=['POST'])
def save_credential(platform):
    """Save credentials for a platform."""
    try:
        # Validate platform
        is_valid, error_msg = validate_platform(platform)
        if not is_valid:
            logger.warning(f"Invalid platform: {platform} - {error_msg}")
            return jsonify({'error': error_msg}), 400

        data = request.json
        if not data:
            return jsonify({'error': 'Request body is required'}), 400

        username = data.get('username', '').strip()
        api_token = data.get('api_token', '').strip()
        additional_info = data.get('additional_info', {})

        # Validate username
        is_valid, error_msg = validate_username(username)
        if not is_valid:
            logger.warning(f"Invalid username for {platform}: {error_msg}")
            return jsonify({'error': error_msg}), 400

        # Validate API token
        is_valid, error_msg = validate_api_token(api_token)
        if not is_valid:
            logger.warning(f"Invalid API token for {platform}: {error_msg}")
            return jsonify({'error': error_msg}), 400

        # Save credentials
        credentials_manager.add_credential(platform, username, api_token, additional_info)

        # Export to environment for immediate use
        credentials_manager.export_to_env()

        logger.info(f"Credentials saved for platform: {platform}, username: {username}")

        # Audit log
        audit_credential_added(platform, username, request.remote_addr)

        socketio.emit('credentials_updated', {
            'platform': platform,
            'timestamp': datetime.now().isoformat()
        })

        return jsonify({'success': True, 'message': f'Credentials saved for {platform}'})
    except Exception as e:
        logger.error(f"Error saving credentials for {platform}: {e}", exc_info=True)
        return jsonify({'error': 'Failed to save credentials. Please try again.'}), 500


@app.route('/api/credentials/<platform>', methods=['DELETE'])
def delete_credential(platform):
    """Delete credentials for a platform."""
    try:
        credentials_manager.remove_credential(platform)

        # Audit log
        audit_credential_deleted(platform, request.remote_addr)

        return jsonify({'success': True, 'message': f'Credentials removed for {platform}'})
    except Exception as e:
        logger.error(f"Error deleting credentials for {platform}: {e}", exc_info=True)
        return jsonify({'error': str(e)}), 500


# ============================================================================
# Program Bounties & Earnings
# ============================================================================

@app.route('/api/programs/bounties')
def get_program_bounties():
    """Get programs with bounty information."""
    try:
        conn = sqlite3.connect('data/bounty_hunter.db')
        cursor = conn.cursor()

        cursor.execute("""
            SELECT id, name, platform, url, rewards, last_scanned
            FROM programs
            ORDER BY last_scanned DESC
        """)

        programs = []
        for row in cursor.fetchall():
            rewards_json = row[4]
            rewards = {}

            if rewards_json:
                try:
                    rewards = json.loads(rewards_json)
                except:
                    pass

            programs.append({
                'id': row[0],
                'name': row[1],
                'platform': row[2],
                'url': row[3],
                'bounties': {
                    'critical': rewards.get('critical', 'N/A'),
                    'high': rewards.get('high', 'N/A'),
                    'medium': rewards.get('medium', 'N/A'),
                    'low': rewards.get('low', 'N/A')
                },
                'last_scanned': row[5]
            })

        conn.close()

        return jsonify({'programs': programs})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ============================================================================
# Report Review & Submission
# ============================================================================

@app.route('/api/reports/pending')
def get_pending_reports():
    """Get reports pending review/submission."""
    try:
        conn = sqlite3.connect('data/bounty_hunter.db')
        cursor = conn.cursor()

        cursor.execute("""
            SELECT r.id, r.vulnerability_id, r.report_content, r.platform,
                   r.program_name, r.generated_at, v.name, v.severity, v.url
            FROM reports r
            LEFT JOIN vulnerabilities v ON r.vulnerability_id = v.id
            WHERE r.submitted = 0
            ORDER BY r.generated_at DESC
        """)

        reports = []
        for row in cursor.fetchall():
            reports.append({
                'id': row[0],
                'vulnerability_id': row[1],
                'report_content': row[2],
                'platform': row[3],
                'program_name': row[4],
                'generated_at': row[5],
                'vulnerability_name': row[6],
                'severity': row[7],
                'url': row[8]
            })

        conn.close()

        return jsonify({'reports': reports})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/reports/<int:report_id>/submit', methods=['POST'])
def submit_report(report_id):
    """Submit a report to the platform."""
    try:
        # Validate report ID
        is_valid, error_msg = validate_report_id(report_id)
        if not is_valid:
            logger.warning(f"Invalid report ID: {report_id} - {error_msg}")
            return jsonify({'error': error_msg}), 400

        data = request.json
        if not data:
            return jsonify({'error': 'Request body is required'}), 400

        platform = data.get('platform', '').strip()

        # Validate platform
        is_valid, error_msg = validate_platform(platform)
        if not is_valid:
            logger.warning(f"Invalid platform for report submission: {platform}")
            return jsonify({'error': error_msg}), 400

        # Check if credentials exist
        if not credentials_manager.has_credentials(platform):
            logger.warning(f"No credentials found for platform: {platform}")
            return jsonify({'error': f'No credentials found for {platform}. Please add credentials first.'}), 400

        # Get report details using context manager
        with get_db_connection() as conn:
            cursor = conn.cursor()

            cursor.execute("""
                SELECT report_content, program_name
                FROM reports
                WHERE id = ?
            """, (report_id,))

            row = cursor.fetchone()
            if not row:
                logger.warning(f"Report not found: {report_id}")
                return jsonify({'error': 'Report not found'}), 404

            report_content = row[0]
            program_name = row[1]

            # TODO: Implement actual API submission based on platform
            # For now, just mark as submitted

            cursor.execute("""
                UPDATE reports
                SET submitted = 1, submission_result = ?
                WHERE id = ?
            """, (f'Submitted via GUI to {platform}', report_id))

            conn.commit()  # Commit within context manager

        logger.info(f"Report {report_id} submitted successfully to {platform}")

        # Audit log
        audit_report_submitted(report_id, platform, request.remote_addr)

        socketio.emit('report_submitted', {
            'report_id': report_id,
            'platform': platform,
            'timestamp': datetime.now().isoformat()
        })

        return jsonify({
            'success': True,
            'message': 'Report submitted successfully',
            'report_id': report_id
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/reports/<int:report_id>/approve', methods=['POST'])
def approve_report(report_id):
    """Approve a report for submission."""
    try:
        # Just mark as approved - actual submission done separately
        return jsonify({'success': True, 'message': 'Report approved'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/reports/<int:report_id>/reject', methods=['POST'])
def reject_report(report_id):
    """Reject a report (delete it)."""
    try:
        conn = sqlite3.connect('data/bounty_hunter.db')
        cursor = conn.cursor()

        cursor.execute("DELETE FROM reports WHERE id = ?", (report_id,))

        conn.commit()
        conn.close()

        return jsonify({'success': True, 'message': 'Report rejected and deleted'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ============================================================================
# Helper Functions
# ============================================================================

def get_database_statistics() -> Dict:
    """Get statistics from database."""
    try:
        conn = sqlite3.connect('data/bounty_hunter.db')
        cursor = conn.cursor()

        stats = {}

        # Count programs
        cursor.execute("SELECT COUNT(*) FROM programs")
        stats['total_programs'] = cursor.fetchone()[0]

        # Count assets
        cursor.execute("SELECT COUNT(*) FROM assets")
        stats['total_assets'] = cursor.fetchone()[0]

        # Count vulnerabilities
        cursor.execute("SELECT COUNT(*) FROM vulnerabilities")
        stats['total_vulnerabilities'] = cursor.fetchone()[0]

        # Count by severity
        cursor.execute("""
            SELECT severity, COUNT(*)
            FROM vulnerabilities
            GROUP BY severity
        """)
        stats['by_severity'] = dict(cursor.fetchall())

        # Count reports
        cursor.execute("SELECT COUNT(*) FROM reports")
        stats['total_reports'] = cursor.fetchone()[0]

        # Recent activity (last 7 days)
        cursor.execute("""
            SELECT COUNT(*)
            FROM vulnerabilities
            WHERE created_at >= datetime('now', '-7 days')
        """)
        stats['vulnerabilities_last_7_days'] = cursor.fetchone()[0]

        conn.close()

        return stats
    except Exception as e:
        logger.error(f"Error getting database stats: {e}")
        return {}


def get_uptime() -> str:
    """Get system uptime."""
    # This is a simplified version - in production, track actual start time
    return "Running"


# ============================================================================
# WebSocket Events
# ============================================================================

@socketio.on('connect')
def handle_connect():
    """Handle client connection."""
    logger.info('Client connected')
    emit('status_update', {
        'status': system_state['status'],
        'timestamp': datetime.now().isoformat()
    })


@socketio.on('disconnect')
def handle_disconnect():
    """Handle client disconnection."""
    logger.info('Client disconnected')


@socketio.on('request_update')
def handle_update_request():
    """Handle manual update request from client."""
    emit('status_update', {
        'status': system_state['status'],
        'current_cycle': system_state['current_cycle'],
        'statistics': system_state.get('statistics', {}),
        'timestamp': datetime.now().isoformat()
    })


# ============================================================================
# Main
# ============================================================================

def main():
    """Start the web GUI."""
    logger.info("Starting Bug Bounty Automation Web GUI...")
    logger.info("Dashboard will be available at: http://localhost:5000")

    # Create necessary directories
    os.makedirs('web/templates', exist_ok=True)
    os.makedirs('web/static', exist_ok=True)
    os.makedirs('logs', exist_ok=True)
    os.makedirs('reports', exist_ok=True)
    os.makedirs('data', exist_ok=True)

    # Run server
    socketio.run(app, host='0.0.0.0', port=5000, debug=False)


if __name__ == '__main__':
    main()
