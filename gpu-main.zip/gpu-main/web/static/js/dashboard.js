// Bug Bounty Automation Dashboard JavaScript

// Initialize Socket.IO
const socket = io();

// Charts
let severityChart = null;
let activityChart = null;

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    initializeCharts();
    loadInitialData();
    setupSocketListeners();
    setupAutoRefresh();
});

// ============================================================================
// Socket.IO Listeners
// ============================================================================

function setupSocketListeners() {
    socket.on('connect', () => {
        console.log('Connected to server');
        addActivity('info', 'Connected to server');
    });

    socket.on('disconnect', () => {
        console.log('Disconnected from server');
        addActivity('error', 'Disconnected from server');
    });

    socket.on('status_update', (data) => {
        updateStatus(data.status);
        if (data.cycle) {
            document.getElementById('current-cycle').textContent = data.cycle;
        }
        addActivity('info', `Status: ${data.status}`);
    });

    socket.on('cycle_complete', (data) => {
        showToast('success', `Cycle ${data.cycle} completed!`);
        updateStatistics(data.statistics);
        addActivity('success', `Cycle ${data.cycle} completed with ${data.statistics.vulnerabilities_found || 0} vulnerabilities found`);
        document.getElementById('last-update').textContent = new Date(data.timestamp).toLocaleString();
    });

    socket.on('error', (data) => {
        showToast('error', `Error: ${data.message}`);
        addActivity('error', data.message);
    });

    socket.on('config_updated', () => {
        showToast('info', 'Configuration updated');
        addActivity('info', 'Configuration reloaded');
    });
}

// ============================================================================
// Control Functions
// ============================================================================

async function startSystem() {
    try {
        const response = await fetch('/api/control/start', {
            method: 'POST'
        });
        const data = await response.json();

        if (data.success) {
            showToast('success', 'System started in continuous mode');
            updateStatus('running');
            document.getElementById('btn-start').disabled = true;
            document.getElementById('btn-stop').disabled = false;
            document.getElementById('btn-scan').disabled = true;
        } else {
            showToast('error', data.error || 'Failed to start system');
        }
    } catch (error) {
        showToast('error', 'Error starting system: ' + error.message);
    }
}

async function stopSystem() {
    try {
        const response = await fetch('/api/control/stop', {
            method: 'POST'
        });
        const data = await response.json();

        if (data.success) {
            showToast('success', 'System stopped');
            updateStatus('stopped');
            document.getElementById('btn-start').disabled = false;
            document.getElementById('btn-stop').disabled = true;
            document.getElementById('btn-scan').disabled = false;
        } else {
            showToast('error', data.error || 'Failed to stop system');
        }
    } catch (error) {
        showToast('error', 'Error stopping system: ' + error.message);
    }
}

async function scanOnce() {
    try {
        const response = await fetch('/api/control/scan-once', {
            method: 'POST'
        });
        const data = await response.json();

        if (data.success) {
            showToast('info', 'Single scan started');
            addActivity('info', 'Starting single scan cycle...');
        } else {
            showToast('error', data.error || 'Failed to start scan');
        }
    } catch (error) {
        showToast('error', 'Error starting scan: ' + error.message);
    }
}

function updateStatus(status) {
    const statusDot = document.getElementById('status-dot');
    const statusText = document.getElementById('status-text');

    statusDot.className = 'status-dot ' + status;
    statusText.textContent = status.charAt(0).toUpperCase() + status.slice(1);
}

// ============================================================================
// Data Loading Functions
// ============================================================================

async function loadInitialData() {
    await Promise.all([
        refreshStats(),
        loadVulnerabilities(),
        loadBounties(),
        loadPrograms(),
        loadPendingReports(),
        loadReports(),
        loadCredentials(),
        loadLogs(),
        loadConfig()
    ]);
}

async function refreshStats() {
    try {
        const response = await fetch('/api/statistics');
        const data = await response.json();

        updateStatistics(data.current_cycle);
        updateDatabaseStats(data.database);
    } catch (error) {
        console.error('Error loading statistics:', error);
    }
}

function updateStatistics(stats) {
    if (!stats) return;

    document.getElementById('stat-programs').textContent = stats.programs_found || 0;
    document.getElementById('stat-assets').textContent = stats.assets_discovered || 0;
    document.getElementById('stat-vulns').textContent = stats.vulnerabilities_found || 0;
    document.getElementById('stat-reports').textContent = stats.reports_generated || 0;
    document.getElementById('stat-chains').textContent = stats.exploit_chains_found || 0;
    document.getElementById('stat-duplicates').textContent = stats.duplicates_avoided || 0;
}

function updateDatabaseStats(dbStats) {
    if (!dbStats) return;

    // Update chart data
    if (severityChart && dbStats.by_severity) {
        const severities = ['critical', 'high', 'medium', 'low'];
        const counts = severities.map(s => dbStats.by_severity[s] || 0);

        severityChart.data.datasets[0].data = counts;
        severityChart.update();
    }

    // Update total stats in cards
    if (dbStats.total_programs !== undefined) {
        document.getElementById('stat-programs').textContent = dbStats.total_programs;
    }
    if (dbStats.total_vulnerabilities !== undefined) {
        document.getElementById('stat-vulns').textContent = dbStats.total_vulnerabilities;
    }
}

async function loadVulnerabilities() {
    try {
        const response = await fetch('/api/vulnerabilities?limit=50');
        const data = await response.json();

        const tbody = document.getElementById('vulns-tbody');
        tbody.innerHTML = '';

        if (data.vulnerabilities && data.vulnerabilities.length > 0) {
            data.vulnerabilities.forEach(vuln => {
                const row = tbody.insertRow();
                row.innerHTML = `
                    <td>${vuln.program || 'N/A'}</td>
                    <td>${vuln.category}</td>
                    <td class="severity-${vuln.severity}">${vuln.severity.toUpperCase()}</td>
                    <td>${vuln.name}</td>
                    <td style="max-width: 300px; overflow: hidden; text-overflow: ellipsis;">${vuln.url}</td>
                    <td>${new Date(vuln.created_at).toLocaleDateString()}</td>
                `;
            });
        } else {
            tbody.innerHTML = '<tr><td colspan="6" class="loading">No vulnerabilities found</td></tr>';
        }
    } catch (error) {
        console.error('Error loading vulnerabilities:', error);
        document.getElementById('vulns-tbody').innerHTML = '<tr><td colspan="6" class="loading">Error loading data</td></tr>';
    }
}

async function loadBounties() {
    try {
        const response = await fetch('/api/programs/bounties');
        const data = await response.json();

        const tbody = document.getElementById('bounties-tbody');
        tbody.innerHTML = '';

        if (data.programs && data.programs.length > 0) {
            data.programs.forEach(program => {
                const row = tbody.insertRow();
                row.innerHTML = `
                    <td>${program.name}</td>
                    <td>${program.platform}</td>
                    <td style="color: #ef4444; font-weight: bold;">${program.bounties.critical}</td>
                    <td style="color: #f59e0b; font-weight: bold;">${program.bounties.high}</td>
                    <td style="color: #3b82f6; font-weight: bold;">${program.bounties.medium}</td>
                    <td style="color: #9ca3af;">${program.bounties.low}</td>
                    <td>${program.last_scanned ? new Date(program.last_scanned).toLocaleString() : 'Never'}</td>
                `;
            });
        } else {
            tbody.innerHTML = '<tr><td colspan="7" class="loading">No bounty programs found</td></tr>';
        }
    } catch (error) {
        console.error('Error loading bounties:', error);
        document.getElementById('bounties-tbody').innerHTML = '<tr><td colspan="7" class="loading">Error loading data</td></tr>';
    }
}

async function loadPrograms() {
    try {
        const response = await fetch('/api/programs');
        const data = await response.json();

        const tbody = document.getElementById('programs-tbody');
        tbody.innerHTML = '';

        if (data.programs && data.programs.length > 0) {
            data.programs.forEach(program => {
                const row = tbody.insertRow();
                row.innerHTML = `
                    <td>${program.name}</td>
                    <td>${program.platform}</td>
                    <td style="max-width: 400px; overflow: hidden; text-overflow: ellipsis;">${program.url || 'N/A'}</td>
                    <td>${program.last_scanned ? new Date(program.last_scanned).toLocaleString() : 'Never'}</td>
                `;
            });
        } else {
            tbody.innerHTML = '<tr><td colspan="4" class="loading">No programs found</td></tr>';
        }
    } catch (error) {
        console.error('Error loading programs:', error);
        document.getElementById('programs-tbody').innerHTML = '<tr><td colspan="4" class="loading">Error loading data</td></tr>';
    }
}

async function loadPendingReports() {
    try {
        const response = await fetch('/api/reports/pending');
        const data = await response.json();

        const container = document.getElementById('pending-reports-container');
        container.innerHTML = '';

        if (data.reports && data.reports.length > 0) {
            data.reports.forEach(report => {
                const reportCard = document.createElement('div');
                reportCard.className = 'report-card';
                reportCard.innerHTML = `
                    <div class="report-header">
                        <h4>${report.vulnerability_name || 'Untitled'}</h4>
                        <span class="severity-badge severity-${report.severity}">${report.severity ? report.severity.toUpperCase() : 'N/A'}</span>
                    </div>
                    <div class="report-details">
                        <p><strong>Program:</strong> ${report.program_name || 'N/A'}</p>
                        <p><strong>Platform:</strong> ${report.platform || 'N/A'}</p>
                        <p><strong>URL:</strong> ${report.url || 'N/A'}</p>
                        <p><strong>Generated:</strong> ${report.generated_at ? new Date(report.generated_at).toLocaleString() : 'N/A'}</p>
                    </div>
                    <div class="report-content">
                        <h5>Report Preview:</h5>
                        <pre style="max-height: 300px; overflow-y: auto; background: #1f2937; padding: 15px; border-radius: 5px;">${report.report_content || 'No content'}</pre>
                    </div>
                    <div class="report-actions" style="margin-top: 15px; display: flex; gap: 10px;">
                        <button class="btn btn-success" onclick="submitReportPrompt(${report.id}, '${report.platform}')">✅ Approve & Submit</button>
                        <button class="btn btn-danger" onclick="rejectReport(${report.id})">❌ Reject</button>
                    </div>
                `;
                container.appendChild(reportCard);
            });
        } else {
            container.innerHTML = '<p class="loading">No pending reports. All reports have been submitted or rejected.</p>';
        }
    } catch (error) {
        console.error('Error loading pending reports:', error);
        document.getElementById('pending-reports-container').innerHTML = '<p class="loading">Error loading pending reports</p>';
    }
}

async function loadReports() {
    try {
        const response = await fetch('/api/reports');
        const data = await response.json();

        const tbody = document.getElementById('reports-tbody');
        tbody.innerHTML = '';

        if (data.reports && data.reports.length > 0) {
            data.reports.forEach(report => {
                const row = tbody.insertRow();
                row.innerHTML = `
                    <td>${report.filename}</td>
                    <td>${(report.size / 1024).toFixed(2)} KB</td>
                    <td>${new Date(report.modified).toLocaleString()}</td>
                    <td>
                        <a href="/api/reports/${report.filename}" target="_blank" class="btn btn-small btn-primary">📥 Download</a>
                    </td>
                `;
            });
        } else {
            tbody.innerHTML = '<tr><td colspan="4" class="loading">No reports generated yet</td></tr>';
        }
    } catch (error) {
        console.error('Error loading reports:', error);
        document.getElementById('reports-tbody').innerHTML = '<tr><td colspan="4" class="loading">Error loading data</td></tr>';
    }
}

async function loadCredentials() {
    try {
        const response = await fetch('/api/credentials');
        const data = await response.json();

        const tbody = document.getElementById('credentials-tbody');
        tbody.innerHTML = '';

        if (data.credentials && Object.keys(data.credentials).length > 0) {
            Object.entries(data.credentials).forEach(([platform, creds]) => {
                const row = tbody.insertRow();
                row.innerHTML = `
                    <td style="text-transform: capitalize;">${platform}</td>
                    <td>${creds.username || 'N/A'}</td>
                    <td><code>${creds.api_token || '***'}</code></td>
                    <td>
                        <button class="btn btn-small btn-danger" onclick="deleteCredential('${platform}')">🗑️ Delete</button>
                    </td>
                `;
            });
        } else {
            tbody.innerHTML = '<tr><td colspan="4" class="loading">No credentials saved yet</td></tr>';
        }
    } catch (error) {
        console.error('Error loading credentials:', error);
        document.getElementById('credentials-tbody').innerHTML = '<tr><td colspan="4" class="loading">Error loading credentials</td></tr>';
    }
}

async function addCredential(event) {
    event.preventDefault();

    const platform = document.getElementById('platform-select').value;
    const username = document.getElementById('username-input').value;
    const apiToken = document.getElementById('api-token-input').value;

    if (!platform || !username || !apiToken) {
        showToast('error', 'Please fill in all fields');
        return;
    }

    try {
        const response = await fetch(`/api/credentials/${platform}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username: username,
                api_token: apiToken
            })
        });

        const data = await response.json();

        if (data.success) {
            showToast('success', `Credentials saved for ${platform}`);

            // Reset form
            document.getElementById('add-credential-form').reset();

            // Reload credentials list
            await loadCredentials();
        } else {
            showToast('error', data.message || 'Failed to save credentials');
        }
    } catch (error) {
        showToast('error', 'Error saving credentials: ' + error.message);
    }
}

async function deleteCredential(platform) {
    if (!confirm(`Are you sure you want to delete credentials for ${platform}?`)) {
        return;
    }

    try {
        const response = await fetch(`/api/credentials/${platform}`, {
            method: 'DELETE'
        });

        const data = await response.json();

        if (data.success) {
            showToast('success', `Credentials deleted for ${platform}`);
            await loadCredentials();
        } else {
            showToast('error', data.message || 'Failed to delete credentials');
        }
    } catch (error) {
        showToast('error', 'Error deleting credentials: ' + error.message);
    }
}

async function submitReportPrompt(reportId, platform) {
    if (!confirm(`Submit this report to ${platform}?\n\nMake sure you have saved your credentials for this platform.`)) {
        return;
    }

    await submitReport(reportId, platform);
}

async function submitReport(reportId, platform) {
    try {
        const response = await fetch(`/api/reports/${reportId}/submit`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                platform: platform
            })
        });

        const data = await response.json();

        if (data.success) {
            showToast('success', 'Report submitted successfully!');
            await loadPendingReports();
        } else {
            showToast('error', data.error || 'Failed to submit report');
        }
    } catch (error) {
        showToast('error', 'Error submitting report: ' + error.message);
    }
}

async function rejectReport(reportId) {
    if (!confirm('Are you sure you want to reject this report?')) {
        return;
    }

    try {
        const response = await fetch(`/api/reports/${reportId}/reject`, {
            method: 'POST'
        });

        const data = await response.json();

        if (data.success) {
            showToast('info', 'Report rejected');
            await loadPendingReports();
        } else {
            showToast('error', data.error || 'Failed to reject report');
        }
    } catch (error) {
        showToast('error', 'Error rejecting report: ' + error.message);
    }
}

async function loadLogs() {
    try {
        const lines = document.getElementById('log-lines').value;
        const response = await fetch(`/api/logs?lines=${lines}`);
        const data = await response.json();

        const logContent = document.getElementById('log-content');

        if (data.logs && data.logs.length > 0) {
            logContent.textContent = data.logs.join('');
            // Scroll to bottom
            logContent.parentElement.scrollTop = logContent.parentElement.scrollHeight;
        } else {
            logContent.textContent = 'No logs available';
        }
    } catch (error) {
        console.error('Error loading logs:', error);
        document.getElementById('log-content').textContent = 'Error loading logs';
    }
}

async function loadConfig() {
    try {
        const response = await fetch('/api/config');
        const data = await response.json();

        if (data.error) {
            showToast('error', 'Error loading config: ' + data.error);
            return;
        }

        const editor = document.getElementById('config-editor');
        editor.value = JSON.stringify(data, null, 2);
    } catch (error) {
        console.error('Error loading config:', error);
        showToast('error', 'Error loading configuration');
    }
}

async function saveConfig() {
    try {
        const editor = document.getElementById('config-editor');
        const configData = JSON.parse(editor.value);

        const response = await fetch('/api/config', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(configData)
        });

        const data = await response.json();

        if (data.success) {
            showToast('success', 'Configuration saved successfully');
        } else {
            showToast('error', 'Error saving config: ' + data.error);
        }
    } catch (error) {
        showToast('error', 'Invalid JSON or save error: ' + error.message);
    }
}

// ============================================================================
// Chart Initialization
// ============================================================================

function initializeCharts() {
    // Severity Chart
    const severityCtx = document.getElementById('severity-chart');
    severityChart = new Chart(severityCtx, {
        type: 'doughnut',
        data: {
            labels: ['Critical', 'High', 'Medium', 'Low'],
            datasets: [{
                data: [0, 0, 0, 0],
                backgroundColor: [
                    '#ef4444',
                    '#f59e0b',
                    '#3b82f6',
                    '#9ca3af'
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: '#f9fafb'
                    }
                }
            }
        }
    });

    // Activity Chart
    const activityCtx = document.getElementById('activity-chart');
    activityChart = new Chart(activityCtx, {
        type: 'line',
        data: {
            labels: ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5', 'Day 6', 'Day 7'],
            datasets: [{
                label: 'Vulnerabilities Found',
                data: [0, 0, 0, 0, 0, 0, 0],
                borderColor: '#2563eb',
                backgroundColor: 'rgba(37, 99, 235, 0.1)',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    labels: {
                        color: '#f9fafb'
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#f9fafb'
                    },
                    grid: {
                        color: '#374151'
                    }
                },
                x: {
                    ticks: {
                        color: '#f9fafb'
                    },
                    grid: {
                        color: '#374151'
                    }
                }
            }
        }
    });
}

// ============================================================================
// UI Helper Functions
// ============================================================================

function showTab(tabName) {
    // Hide all tabs
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });

    // Remove active class from all buttons
    document.querySelectorAll('.tab-button').forEach(btn => {
        btn.classList.remove('active');
    });

    // Show selected tab
    document.getElementById(`tab-${tabName}`).classList.add('active');

    // Add active class to clicked button
    event.target.classList.add('active');

    // Load data for the tab if needed
    if (tabName === 'logs') {
        loadLogs();
    } else if (tabName === 'bounties') {
        loadBounties();
    } else if (tabName === 'pending-reports') {
        loadPendingReports();
    } else if (tabName === 'credentials') {
        loadCredentials();
    } else if (tabName === 'programs') {
        loadPrograms();
    } else if (tabName === 'reports') {
        loadReports();
    }
}

function showToast(type, message) {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;

    container.appendChild(toast);

    // Remove after 5 seconds
    setTimeout(() => {
        toast.style.animation = 'slideIn 0.3s reverse';
        setTimeout(() => toast.remove(), 300);
    }, 5000);
}

function addActivity(type, message) {
    const activityList = document.getElementById('activity-list');
    const now = new Date();
    const timeStr = now.toLocaleTimeString();

    const item = document.createElement('div');
    item.className = `activity-item activity-${type}`;
    item.innerHTML = `
        <span class="activity-time">${timeStr}</span>
        <span class="activity-message">${message}</span>
    `;

    // Add to top
    activityList.insertBefore(item, activityList.firstChild);

    // Keep only last 20 items
    while (activityList.children.length > 20) {
        activityList.removeChild(activityList.lastChild);
    }
}

function setupAutoRefresh() {
    // Refresh stats every 30 seconds
    setInterval(refreshStats, 30000);

    // Refresh vulnerabilities every minute
    setInterval(() => {
        if (document.getElementById('tab-vulnerabilities').classList.contains('active')) {
            loadVulnerabilities();
        }
    }, 60000);
}
