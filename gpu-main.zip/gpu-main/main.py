#!/usr/bin/env python3
"""
Red Hat Bug Bounty Automation System
Main orchestration and scheduling system.
"""

import asyncio
import logging
import yaml
import os
import sys
from datetime import datetime
from typing import Dict
from dotenv import load_dotenv

# Import all modules
from src.discovery.program_finder import ProgramDiscovery
from src.discovery.realtime_monitor import RealtimeMonitor, CertificateTransparencyMonitor
from src.recon.asset_discovery import AssetDiscovery
from src.recon.github_dorking import GitHubDorker, SubdomainTakeoverDetector
from src.recon.js_analysis import EnhancedRecon
from src.scanning.vulnerability_scanner import VulnerabilityScanner
from src.exploits.exploit_engine import ExploitEngine
from src.exploits.exploit_chainer import ExploitChainer
from src.reporting.report_generator import ReportingSystem
from src.leaderboard.tracker import LeaderboardTracker
from src.utils.database import Database
from src.utils.notifications import NotificationManager
from src.utils.duplicate_detector import DuplicateDetector

# Import intelligence modules
from src.intelligence.target_prioritizer import TargetPrioritizer
from src.intelligence.cve_monitor import CVEMonitor
from src.intelligence.report_optimizer import ReportOptimizer
from src.intelligence.cloud_hunter import CloudHunter

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/bounty_hunter.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)


class BugBountyOrchestrator:
    """Main orchestrator for the bug bounty automation system."""

    def __init__(self, config_path: str = 'config.yaml'):
        """Initialize the orchestrator."""
        # Load environment variables
        load_dotenv()

        # Load configuration
        self.config = self._load_config(config_path)

        # Substitute environment variables in config
        self.config = self._substitute_env_vars(self.config)

        # Initialize database
        db_path = self.config.get('database', {}).get('path', './data/bounty_hunter.db')
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self.db = Database(db_path)

        # Initialize modules
        self.program_discovery = ProgramDiscovery(self.config)
        self.asset_discovery = AssetDiscovery(self.config)
        self.github_dorker = GitHubDorker(os.getenv('GITHUB_TOKEN'))
        self.takeover_detector = SubdomainTakeoverDetector()
        self.enhanced_recon = EnhancedRecon()
        self.vulnerability_scanner = VulnerabilityScanner(self.config)
        self.exploit_engine = ExploitEngine(self.config)
        self.exploit_chainer = ExploitChainer()
        self.reporting_system = ReportingSystem(self.config)
        self.leaderboard_tracker = LeaderboardTracker(self.config)
        self.notifier = NotificationManager(self.config)
        self.duplicate_detector = DuplicateDetector(self.db)

        # Intelligence modules (NEW!)
        self.target_prioritizer = TargetPrioritizer(self.db)
        self.cve_monitor = CVEMonitor(self.db)
        self.report_optimizer = ReportOptimizer()
        self.cloud_hunter = CloudHunter()

        # Real-time monitoring (optional, can be started separately)
        self.realtime_monitor = RealtimeMonitor(self.config, self.notifier)
        self.ct_monitor = None  # Initialized after discovering targets

        logger.info("Bug Bounty Orchestrator initialized with Intelligence modules")

    def _load_config(self, config_path: str) -> Dict:
        """Load configuration from YAML file."""
        try:
            with open(config_path, 'r') as f:
                return yaml.safe_load(f)
        except FileNotFoundError:
            logger.error(f"Config file not found: {config_path}")
            sys.exit(1)
        except yaml.YAMLError as e:
            logger.error(f"Error parsing config: {e}")
            sys.exit(1)

    def _substitute_env_vars(self, config: Dict) -> Dict:
        """Substitute environment variables in config."""
        def substitute(obj):
            if isinstance(obj, dict):
                return {k: substitute(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [substitute(item) for item in obj]
            elif isinstance(obj, str) and obj.startswith('${') and obj.endswith('}'):
                var_name = obj[2:-1]
                return os.getenv(var_name, obj)
            return obj

        return substitute(config)

    async def run_full_cycle(self) -> Dict:
        """Run a complete bug bounty hunting cycle."""
        logger.info("="*60)
        logger.info("Starting Bug Bounty Hunting Cycle")
        logger.info("="*60)

        cycle_stats = {
            'start_time': datetime.now().isoformat(),
            'programs_found': 0,
            'assets_discovered': 0,
            'vulnerabilities_found': 0,
            'exploits_developed': 0,
            'reports_generated': 0,
            'reports_submitted': 0
        }

        try:
            # Step 1: Discover bug bounty programs
            logger.info("Step 1: Discovering Red Hat bug bounty programs...")
            programs = await self.program_discovery.discover_all_programs()
            cycle_stats['programs_found'] = len(programs)

            for program in programs:
                self.db.save_program(program.to_dict())

            if not programs:
                logger.warning("No programs found. Exiting cycle.")
                return cycle_stats

            # Step 1.5: Smart Target Prioritization 🎯 (Intelligence!)
            logger.info("Step 1.5: Prioritizing targets with ML-based scoring...")
            prioritized_programs = await self.target_prioritizer.prioritize_programs(
                [p.to_dict() for p in programs]
            )

            # Get best target suggestion
            best_target = await self.target_prioritizer.suggest_next_target(
                [p.to_dict() for p in programs]
            )

            if best_target:
                await self.notifier.notify(
                    'info',
                    f"🎯 Top Priority Target: {best_target['program'].get('name')}",
                    {
                        'Score': best_target['score'],
                        'Reason': best_target['reason']
                    }
                )

            # Use prioritized programs for rest of cycle
            programs = [p[0] for p in prioritized_programs[:5]]  # Top 5 targets
            cycle_stats['targets_prioritized'] = len(prioritized_programs)

            # Step 2: GitHub Dorking (Quick Win!)
            logger.info("Step 2: Searching GitHub for leaked secrets...")
            github_findings = await self.github_dorker.search_secrets(targets)

            for finding in github_findings:
                await self.notifier.notify(
                    'critical_finding',
                    f"GitHub Secret Found: {finding.get('repository')}",
                    {
                        'File': finding.get('file_path'),
                        'Secrets': len(finding.get('secrets_found', []))
                    }
                )

            cycle_stats['github_secrets_found'] = len(github_findings)

            # Step 3: Reconnaissance and asset discovery
            logger.info("Step 3: Performing reconnaissance and asset discovery...")
            targets = self.program_discovery.get_in_scope_targets()
            assets = await self.asset_discovery.discover_assets(targets)
            cycle_stats['assets_discovered'] = len(assets)

            if not assets:
                logger.warning("No assets discovered. Exiting cycle.")
                return cycle_stats

            # Step 3.5: Subdomain Takeover Detection
            logger.info("Step 3.5: Checking for subdomain takeovers...")
            subdomains = [asset.hostname for asset in assets]
            takeover_vulns = await self.takeover_detector.batch_check(subdomains)

            for vuln in takeover_vulns:
                await self.notifier.notify(
                    'high_finding',
                    f"Subdomain Takeover: {vuln.get('subdomain')}",
                    {
                        'Service': vuln.get('service'),
                        'CNAME': vuln.get('cname')
                    }
                )

            cycle_stats['subdomain_takeovers_found'] = len(takeover_vulns)

            # Step 3.7: Enhanced Reconnaissance (JS Analysis + Wayback)
            logger.info("Step 3.7: Enhanced reconnaissance (JavaScript + Wayback Machine)...")
            enhanced_targets = [asset.hostname for asset in assets[:10]]  # Limit to first 10 for speed
            enhanced_results = await self.enhanced_recon.perform_enhanced_recon(enhanced_targets)

            # Notify on JS secrets
            for secret in enhanced_results.get('secrets_from_js', []):
                await self.notifier.notify(
                    'critical_finding',
                    f"Secret in JavaScript: {secret.get('type')}",
                    {
                        'File': secret.get('file'),
                        'Type': secret.get('type')
                    }
                )

            cycle_stats['js_secrets_found'] = len(enhanced_results.get('secrets_from_js', []))
            cycle_stats['new_endpoints_found'] = enhanced_results.get('total_new_endpoints', 0)
            cycle_stats['wayback_endpoints'] = len(enhanced_results.get('wayback_endpoints', []))

            # Step 3.8: Cloud Asset Discovery ☁️ (Intelligence!)
            logger.info("Step 3.8: Hunting for cloud assets (AWS/GCP/Azure)...")
            cloud_assets = await self.cloud_hunter.discover_cloud_assets(
                targets[0] if targets else '',
                targets
            )

            # Check for misconfigurations
            cloud_issues = []
            for asset in cloud_assets:
                issues = await self.cloud_hunter.check_misconfigurations(asset)
                cloud_issues.extend(issues)

                # Notify on public cloud resources
                if asset.get('public'):
                    await self.notifier.notify(
                        'critical_finding',
                        f"🔴 Public {asset.get('type')}: {asset.get('name')}",
                        {
                            'Provider': asset.get('cloud_provider'),
                            'URL': asset.get('url'),
                            'Severity': asset.get('severity')
                        }
                    )

            cycle_stats['cloud_assets_found'] = len(cloud_assets)
            cycle_stats['cloud_issues_found'] = len(cloud_issues)

            # Step 3.9: CVE Monitoring & Auto-Exploitation 🚨 (Intelligence!)
            logger.info("Step 3.9: Checking for exploitable CVEs...")
            recent_cves = await self.cve_monitor.check_new_cves(days_back=7)

            # Match CVEs to discovered assets
            cve_matches = await self.cve_monitor.match_cves_to_targets(
                recent_cves,
                assets_dict if 'assets_dict' in locals() else []
            )

            # Attempt auto-exploitation
            cve_vulns = []
            for match in cve_matches[:10]:  # Limit to top 10 matches
                result = await self.cve_monitor.auto_exploit_cve(match)
                if result:
                    cve_vulns.append(result)

                    await self.notifier.notify(
                        'critical_finding',
                        f"🚨 CVE Exploited: {result.get('cve_id')}",
                        {
                            'URL': result.get('url'),
                            'CVSS': result.get('cvss_score'),
                            'Technology': result.get('technology')
                        }
                    )

            cycle_stats['cve_matches_found'] = len(cve_matches)
            cycle_stats['cve_vulns_exploited'] = len(cve_vulns)

            # Step 4: Vulnerability scanning
            logger.info("Step 4: Scanning for vulnerabilities...")
            assets_dict = [asset.to_dict() for asset in assets]
            vulnerabilities = await self.vulnerability_scanner.scan_targets(assets_dict)
            cycle_stats['vulnerabilities_found'] = len(vulnerabilities)

            # Save vulnerabilities and notify on critical/high findings
            for vuln in vulnerabilities:
                vuln_dict = vuln.to_dict()
                vuln_id = self.db.save_vulnerability(vuln_dict)

                if vuln.severity.value in ['critical', 'high']:
                    await self.notifier.notify(
                        f"{vuln.severity.value}_finding",
                        f"Found {vuln.severity.value} severity vulnerability: {vuln.name}",
                        {
                            'URL': vuln.url,
                            'Category': vuln.category
                        }
                    )

            if not vulnerabilities:
                logger.info("No vulnerabilities found in this cycle.")
                return cycle_stats

            # Add GitHub findings and takeover vulns to vulnerability list
            all_vulnerabilities = vulnerabilities + github_findings + takeover_vulns
            cycle_stats['vulnerabilities_found'] = len(all_vulnerabilities)

            # Step 5: Exploit development
            logger.info("Step 5: Developing exploits...")
            # Convert to dict format (some already are dicts from GitHub/takeover)
            vulnerabilities_dict = []
            for v in all_vulnerabilities:
                if hasattr(v, 'to_dict'):
                    vulnerabilities_dict.append(v.to_dict())
                else:
                    vulnerabilities_dict.append(v)

            exploits = await self.exploit_engine.batch_process_vulnerabilities(vulnerabilities_dict)
            cycle_stats['exploits_developed'] = len(exploits)

            # Step 5.5: Exploit Chaining 🔗 (Game Changer!)
            logger.info("Step 5.5: Analyzing exploit chains (combining bugs for higher impact)...")
            exploit_chains = await self.exploit_chainer.find_chains(vulnerabilities_dict)

            for chain in exploit_chains:
                bounty_info = self.exploit_chainer.calculate_bounty_increase(chain)

                await self.notifier.notify(
                    'critical_finding',
                    f"EXPLOIT CHAIN FOUND: {chain.chain_type}",
                    {
                        'Chain Type': chain.chain_type,
                        'Combined Severity': chain.combined_severity,
                        'Bounty Increase': f"+${bounty_info['increase']} ({bounty_info['percentage']}%)",
                        'Components': len(chain.vulnerabilities)
                    }
                )

            cycle_stats['exploit_chains_found'] = len(exploit_chains)
            cycle_stats['estimated_bounty_increase'] = sum(
                self.exploit_chainer.calculate_bounty_increase(c)['increase']
                for c in exploit_chains
            )

            # Step 5.7: Duplicate Detection 🔍 (Save Time!)
            logger.info("Step 5.7: Checking for duplicate vulnerabilities...")
            unique_vulnerabilities = []
            duplicates_found = 0

            for vuln in vulnerabilities_dict:
                dup_check = await self.duplicate_detector.is_duplicate(vuln)

                if dup_check['is_duplicate']:
                    duplicates_found += 1
                    logger.info(
                        f"DUPLICATE DETECTED: {vuln.get('name')} - {dup_check['reason']} "
                        f"(confidence: {dup_check['confidence']*100:.0f}%)"
                    )

                    # Notify about high-confidence duplicates
                    if dup_check['confidence'] >= 0.9:
                        # Get alternative suggestions
                        alternatives = await self.duplicate_detector.suggest_alternatives(vuln)

                        await self.notifier.notify(
                            'duplicate_avoided',
                            f"Avoided duplicate: {vuln.get('name')}",
                            {
                                'Reason': dup_check['reason'],
                                'Confidence': f"{dup_check['confidence']*100:.0f}%",
                                'Suggestion': alternatives[0] if alternatives else 'Try different endpoint'
                            }
                        )
                else:
                    unique_vulnerabilities.append(vuln)

                    # Log similar patterns for awareness
                    if dup_check.get('similar_reports'):
                        logger.info(
                            f"Similar reports found for {vuln.get('name')}: "
                            f"{len(dup_check['similar_reports'])} - review recommended"
                        )

            cycle_stats['duplicates_avoided'] = duplicates_found
            cycle_stats['unique_vulnerabilities'] = len(unique_vulnerabilities)

            logger.info(
                f"Duplicate detection complete: {duplicates_found} duplicates avoided, "
                f"{len(unique_vulnerabilities)} unique findings to report"
            )

            # Step 5.9: Report Quality Optimization 📝 (Intelligence!)
            logger.info("Step 5.9: Optimizing report quality with AI...")
            optimized_reports = []

            for vuln in unique_vulnerabilities:
                # Analyze report quality
                quality_analysis = self.report_optimizer.analyze_report(vuln)

                logger.info(
                    f"Report quality for {vuln.get('name')}: {quality_analysis['grade']} "
                    f"(Score: {quality_analysis['score']}/100)"
                )

                # If score is low, improve automatically
                if quality_analysis['score'] < 70:
                    logger.info(f"Improving report quality for {vuln.get('name')}...")
                    improved_vuln = self.report_optimizer.improve_report(vuln)
                    optimized_reports.append(improved_vuln)

                    # Re-analyze
                    new_quality = self.report_optimizer.analyze_report(improved_vuln)
                    logger.info(
                        f"Improved report quality: {new_quality['grade']} "
                        f"(+{new_quality['score'] - quality_analysis['score']} points)"
                    )
                else:
                    optimized_reports.append(vuln)

            # Use optimized reports
            unique_vulnerabilities = optimized_reports
            cycle_stats['reports_optimized'] = len(optimized_reports)

            # Step 6: Generate reports
            logger.info("Step 6: Generating high-quality reports...")
            for program in programs:
                # Use only unique (non-duplicate) vulnerabilities
                program_vulns = [v for v in unique_vulnerabilities if any(
                    scope in v.get('url', '') for scope in program.scope
                )]

                if program_vulns:
                    reports = await self.reporting_system.process_findings(
                        program_vulns,
                        exploits,
                        program.to_dict()
                    )

                    cycle_stats['reports_generated'] += len(reports)
                    cycle_stats['reports_submitted'] += sum(1 for r in reports if r.get('submitted'))

                    # Save reports to disk
                    self.reporting_system.save_reports(reports)

            # Step 7: Update leaderboard statistics
            logger.info("Step 7: Updating leaderboard statistics...")
            leaderboard_stats = await self.leaderboard_tracker.update_all_stats()

            cycle_stats['end_time'] = datetime.now().isoformat()

            # Print summary
            self._print_summary(cycle_stats)

        except Exception as e:
            logger.error(f"Error during cycle: {e}", exc_info=True)
            cycle_stats['error'] = str(e)

        return cycle_stats

    def _print_summary(self, stats: Dict):
        """Print cycle summary."""
        logger.info("="*60)
        logger.info("CYCLE SUMMARY")
        logger.info("="*60)
        logger.info(f"Programs Found: {stats['programs_found']}")
        logger.info(f"GitHub Secrets Found: {stats.get('github_secrets_found', 0)}")
        logger.info(f"Subdomain Takeovers: {stats.get('subdomain_takeovers_found', 0)}")
        logger.info(f"Assets Discovered: {stats['assets_discovered']}")
        logger.info(f"JS Secrets Found: {stats.get('js_secrets_found', 0)}")
        logger.info(f"New Endpoints Discovered: {stats.get('new_endpoints_found', 0)}")
        logger.info(f"Wayback Endpoints Found: {stats.get('wayback_endpoints', 0)}")
        logger.info(f"Vulnerabilities Found: {stats['vulnerabilities_found']}")
        logger.info(f"Exploits Developed: {stats['exploits_developed']}")
        logger.info(f"🔗 Exploit Chains Found: {stats.get('exploit_chains_found', 0)}")
        logger.info(f"💰 Estimated Bounty Increase from Chains: ${stats.get('estimated_bounty_increase', 0)}")
        logger.info(f"🔍 Duplicates Avoided: {stats.get('duplicates_avoided', 0)}")
        logger.info(f"✅ Unique Vulnerabilities: {stats.get('unique_vulnerabilities', 0)}")
        logger.info(f"Reports Generated: {stats['reports_generated']}")
        logger.info(f"Reports Submitted: {stats['reports_submitted']}")
        logger.info("="*60)

        # Database statistics
        db_stats = self.db.get_statistics()
        logger.info("DATABASE STATISTICS")
        logger.info("="*60)
        logger.info(f"Total Programs: {db_stats.get('total_programs', 0)}")
        logger.info(f"Total Assets: {db_stats.get('total_assets', 0)}")
        logger.info(f"Total Vulnerabilities: {db_stats.get('total_vulnerabilities', 0)}")
        logger.info(f"Submitted Reports: {db_stats.get('submitted_reports', 0)}")
        logger.info("="*60)

    async def run_continuous(self):
        """Run in continuous mode with scheduling."""
        interval_hours = self.config.get('scheduling', {}).get('scan_interval_hours', 24)

        logger.info(f"Starting continuous mode (scanning every {interval_hours} hours)")

        while True:
            try:
                await self.run_full_cycle()

                # Wait before next cycle
                logger.info(f"Waiting {interval_hours} hours before next cycle...")
                await asyncio.sleep(interval_hours * 3600)

            except KeyboardInterrupt:
                logger.info("Shutting down...")
                break
            except Exception as e:
                logger.error(f"Error in continuous mode: {e}")
                await asyncio.sleep(60)  # Wait 1 minute before retrying

    def cleanup(self):
        """Cleanup resources."""
        self.db.close()
        logger.info("Cleanup completed")


async def main():
    """Main entry point."""
    import argparse

    parser = argparse.ArgumentParser(
        description='Red Hat Bug Bounty Automation System'
    )
    parser.add_argument(
        '--config',
        default='config.yaml',
        help='Path to configuration file'
    )
    parser.add_argument(
        '--continuous',
        action='store_true',
        help='Run in continuous mode'
    )
    parser.add_argument(
        '--once',
        action='store_true',
        help='Run a single cycle'
    )

    args = parser.parse_args()

    # Create orchestrator
    orchestrator = BugBountyOrchestrator(config_path=args.config)

    try:
        if args.continuous:
            await orchestrator.run_continuous()
        else:
            await orchestrator.run_full_cycle()

    finally:
        orchestrator.cleanup()


if __name__ == '__main__':
    # Ensure required directories exist
    os.makedirs('logs', exist_ok=True)
    os.makedirs('data', exist_ok=True)
    os.makedirs('reports', exist_ok=True)

    # Run main
    asyncio.run(main())
