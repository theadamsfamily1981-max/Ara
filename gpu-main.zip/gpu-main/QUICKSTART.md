# Quick Start Guide

Get the Bug Bounty Automation System running in 5 minutes!

---

## Option 1: One-Command Install (Recommended)

```bash
# Clone and install
git clone https://github.com/yourusername/bounty-hunter.git
cd bounty-hunter
bash install.sh

# Configure credentials (required)
vi .env  # Add your API tokens

# Start hunting!
make run
```

Access at: **http://localhost:5000**

---

## Option 2: Docker (Fastest)

```bash
# Clone
git clone https://github.com/yourusername/bounty-hunter.git
cd bounty-hunter

# Configure
cp .env.template .env
vi .env  # Add API tokens

# Start
make docker-up
```

Access at: **http://localhost:5000**

---

## Required Configuration

Edit `.env` and add your platform tokens:

```env
HACKERONE_API_TOKEN=your-token-here
BUGCROWD_API_TOKEN=your-token-here
YESWEHACK_API_TOKEN=your-token-here
INTIGRITI_API_TOKEN=your-token-here
```

### How to Get API Tokens:

**HackerOne:**
1. Go to Settings → API Tokens
2. Click "Create API Token"
3. Copy token to `.env`

**Bugcrowd:**
1. Go to Settings → API
2. Generate new token
3. Copy to `.env`

**YesWeHack:**
1. Go to Profile → API Keys
2. Create new key
3. Copy to `.env`

**Intigriti:**
1. Contact support for API access
2. Copy token to `.env`

---

## Essential Commands

| Command | What It Does |
|---------|--------------|
| `make run` | Start web interface |
| `make hunt` | Start continuous hunting |
| `make status` | Check if everything is working |
| `make logs` | View recent activity |
| `make help` | See all commands |

---

## First Time Setup

### 1. Start the Web GUI

```bash
make run
```

### 2. Add Platform Credentials

Open **http://localhost:5000** and go to:
- **Credentials** tab
- Add each platform (HackerOne, Bugcrowd, etc.)
- Enter username + API token

### 3. Start Your First Hunt

Two ways to hunt:

**Via Web GUI:**
- Click "Start Hunting" button
- Watch live progress in dashboard

**Via Command Line:**
```bash
make hunt
```

### 4. View Results

- **Dashboard**: Real-time statistics
- **Vulnerabilities Tab**: All findings
- **Reports Tab**: Generated reports
- **Logs**: `make logs-follow`

---

## What Happens During a Hunt?

1. **🔍 Discovery**
   - Fetches active programs from all platforms
   - Prioritizes high-paying targets
   - Discovers subdomains and endpoints

2. **🎯 Scanning**
   - Tests for 50+ vulnerability types
   - Uses advanced scanners (GraphQL, JWT, NoSQL)
   - OSINT credential checking
   - Cloud bucket enumeration

3. **📝 Reporting**
   - Generates detailed reports
   - Includes proof of concept
   - Adds remediation steps
   - Submits automatically (if configured)

4. **💰 Profit**
   - Tracks bounty payments
   - Shows ROI statistics
   - Displays leaderboard position

---

## Troubleshooting

### "Virtual environment not found"
```bash
# The installer creates it, but if missing:
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### "Database not found"
```bash
# Run migrations:
make migrate
```

### "401 Unauthorized"
```bash
# Check your API tokens in .env file
vi .env

# Restart the system
make restart
```

### "Port 5000 already in use"
```bash
# Find and kill the process
lsof -i :5000
kill -9 <PID>

# Or use different port
FLASK_PORT=8080 make run
```

### Need More Help?
```bash
make help          # See all commands
make status        # Check what's working
cat INSTALL.md     # Full installation guide
```

---

## System Requirements

- **OS**: Ubuntu 20.04+, Debian 11+, CentOS 8+, macOS 12+
- **Python**: 3.8+
- **RAM**: 4GB minimum
- **Disk**: 10GB free
- **Network**: Internet connection

---

## Security Best Practices

1. ✅ **Never commit `.env` file** - Contains secrets
2. ✅ **Use strong passwords** - Auto-generated secret keys
3. ✅ **Keep updated** - Run `git pull` regularly
4. ✅ **Review reports** - Before auto-submission
5. ✅ **Monitor logs** - Check `logs/audit.log`

---

## Advanced Usage

### Continuous Hunting (24/7)
```bash
# Run in background
nohup make hunt > hunt.log 2>&1 &

# Or use Docker
make docker-up  # Automatically runs 24/7
```

### Custom Scans
```bash
# Activate virtual environment
source venv/bin/activate

# Run specific scanner
python -c "from src.scanning.graphql_scanner import scan_graphql; import asyncio; asyncio.run(scan_graphql('https://target.com/graphql', {}))"
```

### Export Results
```bash
# Generate CSV report
sqlite3 data/bounty_hunter.db "SELECT * FROM vulnerabilities" -csv > results.csv

# Or use the web GUI: Reports → Export
```

---

## Performance Tips

### Faster Scans
```bash
# Reduce concurrent operations in src/config.py:
MAX_CONCURRENT_SCANS = 5  # Lower = less RAM usage
MAX_WORKERS = 2            # Lower = less CPU usage
```

### More Aggressive Scanning
```bash
# Increase in src/config.py:
MAX_CONCURRENT_SCANS = 20
MAX_WORKERS = 8
SCAN_TIMEOUT = 300  # 5 minutes per target
```

---

## Next Steps

1. 📖 **Read the full guide**: `cat USER_GUIDE_CREDENTIALS_REPORTS.md`
2. 🧪 **Run tests**: `make test`
3. 🐳 **Try Docker**: `make docker-up`
4. 📊 **Check effectiveness**: `cat EFFECTIVENESS_ANALYSIS.md`
5. 🎯 **Start earning**: Focus on high-value targets

---

## Support & Community

- **Documentation**: See `INSTALL.md` for detailed setup
- **Issues**: Report bugs on GitHub
- **Updates**: `git pull` to get latest features

---

## Expected Results

Based on our analysis (see `EFFECTIVENESS_ANALYSIS.md`):

| Category | Monthly Findings | Expected Earnings |
|----------|------------------|-------------------|
| GraphQL Vulns | 5-10 | $7.5K - $15K |
| JWT Issues | 3-5 | $30K - $50K |
| NoSQL Injection | 4-8 | $20K - $40K |
| OSINT/Credentials | 8-15 | $40K - $75K |
| **TOTAL** | **20-38** | **$97.5K - $180K** |

*Results vary based on platform, targets, and competition.*

---

## Pro Tips

1. 🎯 **Focus on New Programs**: Less competition
2. ⚡ **Run 24/7**: Catch vulnerabilities first
3. 📝 **Review Before Submitting**: Quality over quantity
4. 🔄 **Update Daily**: `make update-tools`
5. 📊 **Monitor ROI**: Use dashboard analytics

---

**Ready to start? Run:**
```bash
make run
```

**Happy Hunting! 🎯💰**
