# Red Hat Bug Bounty Automation System

A comprehensive, self-running automated security research platform designed to dominate Red Hat bug bounty program leaderboards. This system discovers programs, performs reconnaissance, scans for vulnerabilities, develops exploits, generates professional reports, and tracks leaderboard performance.

## 🎯 Features

### Core Capabilities
- **🔍 Automated Program Discovery**: Finds Red Hat bug bounty programs across HackerOne, Bugcrowd, and other platforms
- **🌐 Advanced Reconnaissance**: Multi-tool subdomain enumeration, port scanning, and technology detection
- **🛡️ Comprehensive Vulnerability Scanning**:
  - XSS (Cross-Site Scripting)
  - SQL Injection
  - SSRF (Server-Side Request Forgery)
  - RCE (Remote Code Execution)
  - Open Redirects
  - IDOR, XXE, CSRF, and more
- **💣 Exploit Development**: Automatically develops proof-of-concept exploits
- **📝 Professional Reporting**: Generates detailed, professional security reports
- **📊 Leaderboard Tracking**: Monitors rankings and provides performance analytics
- **🔄 Continuous Operation**: Runs 24/7 with intelligent scheduling
- **🔔 Smart Notifications**: Real-time alerts for critical findings

### Technical Features
- Parallel scanning for maximum efficiency
- Rate limiting and scope respect
- SQLite database for all findings
- Jinja2 templating for reports
- Async/await for performance
- Modular, extensible architecture

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Main Orchestrator                         │
│                     (main.py)                                │
└────────────┬────────────────────────────────────────────────┘
             │
    ┌────────┴──────────┬──────────────┬──────────────┬────────┐
    │                   │              │              │        │
┌───▼────┐  ┌──────────▼───┐  ┌───────▼──────┐  ┌───▼────┐  │
│Program │  │Reconnaissance│  │Vulnerability │  │Exploit │  │
│Discovery│  │   & Assets   │  │   Scanner    │  │Engine  │  │
└────────┘  └──────────────┘  └──────────────┘  └────────┘  │
                                                              │
    ┌─────────────────────────────────────────────────────────┘
    │                           │
┌───▼────────┐  ┌──────────────▼─────┐  ┌──────────────┐
│  Reporting │  │Leaderboard Tracking│  │  Database    │
│   System   │  │   & Analytics      │  │              │
└────────────┘  └────────────────────┘  └──────────────┘
```

## 🚀 Quick Start

### Prerequisites
- Python 3.8+
- Linux/Unix environment (recommended)
- Go (for optional tools like subfinder, nuclei)

### Installation

1. **Clone the repository**
```bash
git clone <repository-url>
cd gpu
```

2. **Run setup script**
```bash
chmod +x setup.sh
./setup.sh
```

3. **Configure credentials**
```bash
cp .env.example .env
nano .env  # Add your API tokens and credentials
```

4. **Customize configuration** (optional)
```bash
nano config.yaml  # Adjust settings as needed
```

### Running the System

**Single Scan Mode** (run once):
```bash
source venv/bin/activate
python main.py --once
```

**Continuous Mode** (24/7 operation):
```bash
source venv/bin/activate
python main.py --continuous
```

## 📋 Configuration

### Environment Variables (.env)
```bash
# Bug Bounty Platform Credentials
HACKERONE_API_TOKEN=your_token
HACKERONE_USERNAME=your_username
BUGCROWD_API_TOKEN=your_token

# Notifications
SLACK_WEBHOOK_URL=your_webhook_url
```

### Main Configuration (config.yaml)

Key settings to customize:
- **Target Programs**: Add/remove Red Hat-related programs
- **Scanning Types**: Enable/disable specific vulnerability types
- **Rate Limiting**: Adjust concurrent scans and delays
- **Reporting**: Configure auto-submission and review requirements
- **Scheduling**: Set scan intervals and priority hours

## 🎯 Workflow

1. **Program Discovery** (5-10 min)
   - Searches HackerOne and Bugcrowd for Red Hat programs
   - Extracts scope, rules, and reward information

2. **Reconnaissance** (30-60 min)
   - Enumerates subdomains using multiple tools
   - Scans for open ports
   - Probes web services for technologies

3. **Vulnerability Scanning** (1-3 hours)
   - Runs Nuclei with custom templates
   - Tests for XSS, SQLi, SSRF, and more
   - Validates findings

4. **Exploit Development** (10-30 min)
   - Creates proof-of-concept exploits
   - Assesses impact
   - Verifies exploitability

5. **Report Generation** (5-10 min)
   - Generates professional security reports
   - Optionally submits to platforms
   - Saves to local storage

6. **Leaderboard Tracking** (ongoing)
   - Updates ranking statistics
   - Provides performance analytics
   - Sends notifications on changes

## 📊 Output

### Reports
Professional markdown reports saved to `./reports/`:
- Detailed vulnerability descriptions
- Step-by-step reproduction
- Impact assessment
- Remediation recommendations
- Proof-of-concept code

### Database
SQLite database (`./data/bounty_hunter.db`) containing:
- All discovered programs
- Scanned assets
- Found vulnerabilities
- Generated exploits
- Submission history
- Leaderboard snapshots

### Logs
Comprehensive logs in `./logs/bounty_hunter.log`

## 🛡️ Safety and Ethics

This system is designed for **authorized security testing only**. It includes:

- ✅ Scope validation
- ✅ Rate limiting
- ✅ No destructive testing
- ✅ No DoS attacks
- ✅ Respect for program rules
- ✅ Responsible disclosure

**IMPORTANT**: Only use this system on bug bounty programs that explicitly authorize security testing. Always follow the program's rules and scope.

## 📈 Performance Tips

1. **API Credentials**: Configure all platform API tokens for best results
2. **Parallel Scanning**: Adjust `max_concurrent_scans` for your bandwidth
3. **Custom Templates**: Add custom Nuclei templates for specific technologies
4. **Continuous Mode**: Run 24/7 to catch new programs and assets quickly
5. **Notifications**: Enable Slack notifications for immediate awareness

## 🔧 Troubleshooting

### Common Issues

**No vulnerabilities found**:
- Check if assets were discovered
- Verify targets are in scope
- Review nuclei template updates

**API errors**:
- Verify credentials in .env
- Check API rate limits
- Ensure network connectivity

**Tool not found**:
- Install missing tools (subfinder, nuclei, etc.)
- Check PATH configuration
- Run setup.sh again

## 📚 Project Structure

```
gpu/
├── main.py                 # Main orchestrator
├── config.yaml            # Configuration
├── requirements.txt       # Python dependencies
├── setup.sh              # Setup script
├── .env.example          # Environment template
├── src/
│   ├── discovery/        # Program discovery
│   ├── recon/            # Reconnaissance
│   ├── scanning/         # Vulnerability scanning
│   ├── exploits/         # Exploit development
│   ├── reporting/        # Report generation
│   ├── leaderboard/      # Leaderboard tracking
│   └── utils/            # Utilities
├── templates/            # Report templates
├── data/                 # Database
├── logs/                 # Log files
└── reports/              # Generated reports
```

## 🤝 Contributing

This is a specialized tool for Red Hat bug bounty hunting. Contributions welcome:
- New vulnerability detection modules
- Enhanced exploit techniques
- Better reporting templates
- Performance improvements

## ⚖️ Legal Disclaimer

This tool is provided for **educational and authorized security testing purposes only**. Users are solely responsible for:
- Obtaining proper authorization
- Following bug bounty program rules
- Complying with all applicable laws
- Using the tool ethically and responsibly

The authors assume no liability for misuse of this tool.

## 🎓 Learning Resources

- [HackerOne Platform](https://hackerone.com)
- [Bugcrowd Platform](https://bugcrowd.com)
- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [Web Security Academy](https://portswigger.net/web-security)

## 📝 License

MIT License - See LICENSE file for details

## 🚀 Ready to Dominate?

```bash
python main.py --continuous
```

Happy hunting! 🎯

---

**commit**
*Red Hat Bug Bounty Automation System - Climb the leaderboards automatically*
