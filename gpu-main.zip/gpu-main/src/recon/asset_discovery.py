"""
Asset Discovery and Reconnaissance Module
Discovers subdomains, ports, and technologies for target assets.
"""

import asyncio
import subprocess
import json
import logging
from typing import List, Dict, Set, Optional
from dataclasses import dataclass, field
from datetime import datetime
import aiohttp
import dns.resolver

logger = logging.getLogger(__name__)


@dataclass
class Asset:
    """Represents a discovered asset."""
    hostname: str
    ip_addresses: List[str] = field(default_factory=list)
    ports: List[int] = field(default_factory=list)
    technologies: List[str] = field(default_factory=list)
    web_servers: List[str] = field(default_factory=list)
    status_code: Optional[int] = None
    title: Optional[str] = None
    screenshot_path: Optional[str] = None
    discovered_at: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> Dict:
        """Convert to dictionary."""
        return {
            'hostname': self.hostname,
            'ip_addresses': self.ip_addresses,
            'ports': self.ports,
            'technologies': self.technologies,
            'web_servers': self.web_servers,
            'status_code': self.status_code,
            'title': self.title,
            'screenshot_path': self.screenshot_path,
            'discovered_at': self.discovered_at.isoformat()
        }


class SubdomainEnumerator:
    """Enumerates subdomains using multiple tools."""

    def __init__(self, domain: str, config: Dict):
        self.domain = domain
        self.config = config
        self.subdomains: Set[str] = set()

    async def enumerate(self) -> Set[str]:
        """Run all subdomain enumeration methods."""
        tasks = [
            self._run_subfinder(),
            self._run_amass(),
            self._dns_bruteforce(),
            self._certificate_transparency(),
        ]

        results = await asyncio.gather(*tasks, return_exceptions=True)

        for result in results:
            if isinstance(result, set):
                self.subdomains.update(result)
            elif isinstance(result, Exception):
                logger.error(f"Enumeration error: {result}")

        logger.info(f"Found {len(self.subdomains)} subdomains for {self.domain}")
        return self.subdomains

    async def _run_subfinder(self) -> Set[str]:
        """Run subfinder for subdomain enumeration."""
        subdomains = set()

        try:
            cmd = [
                'subfinder',
                '-d', self.domain,
                '-silent',
                '-json'
            ]

            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )

            stdout, stderr = await process.communicate()

            if process.returncode == 0:
                for line in stdout.decode().strip().split('\n'):
                    if line:
                        try:
                            data = json.loads(line)
                            subdomains.add(data.get('host', ''))
                        except json.JSONDecodeError:
                            subdomains.add(line.strip())

            logger.info(f"Subfinder found {len(subdomains)} subdomains")

        except FileNotFoundError:
            logger.warning("subfinder not installed")
        except Exception as e:
            logger.error(f"Subfinder error: {e}")

        return subdomains

    async def _run_amass(self) -> Set[str]:
        """Run amass for subdomain enumeration."""
        subdomains = set()

        try:
            cmd = [
                'amass', 'enum',
                '-passive',
                '-d', self.domain,
                '-json', '/dev/stdout'
            ]

            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )

            stdout, stderr = await process.communicate()

            if process.returncode == 0:
                for line in stdout.decode().strip().split('\n'):
                    if line:
                        try:
                            data = json.loads(line)
                            subdomains.add(data.get('name', ''))
                        except json.JSONDecodeError:
                            pass

            logger.info(f"Amass found {len(subdomains)} subdomains")

        except FileNotFoundError:
            logger.warning("amass not installed")
        except Exception as e:
            logger.error(f"Amass error: {e}")

        return subdomains

    async def _dns_bruteforce(self) -> Set[str]:
        """Perform DNS bruteforce with common names."""
        subdomains = set()

        # Common subdomain names
        common_names = [
            'www', 'mail', 'ftp', 'localhost', 'webmail', 'smtp', 'pop', 'ns1', 'webdisk',
            'ns2', 'cpanel', 'whm', 'autodiscover', 'autoconfig', 'm', 'imap', 'test',
            'ns', 'blog', 'pop3', 'dev', 'www2', 'admin', 'forum', 'news', 'vpn', 'ns3',
            'mail2', 'new', 'mysql', 'old', 'lists', 'support', 'mobile', 'mx', 'static',
            'docs', 'beta', 'shop', 'sql', 'secure', 'demo', 'cp', 'calendar', 'wiki',
            'web', 'media', 'email', 'images', 'img', 'www1', 'intranet', 'portal', 'video',
            'sip', 'dns2', 'api', 'cdn', 'stats', 'dns1', 'ns4', 'www3', 'dns', 'search',
            'staging', 'server', 'mx1', 'chat', 'wap', 'my', 'svn', 'mail1', 'sites',
            'proxy', 'ads', 'host', 'crm', 'cms', 'backup', 'mx2', 'lyncdiscover', 'info',
            'apps', 'download', 'remote', 'db', 'forums', 'store', 'relay', 'files',
            'newsletter', 'app', 'live', 'owa', 'en', 'start', 'sms', 'office', 'exchange',
            'ipv4', 'prod', 'stage', 'uat', 'preprod'
        ]

        resolver = dns.resolver.Resolver()
        resolver.timeout = 2
        resolver.lifetime = 2

        tasks = []
        for name in common_names:
            subdomain = f"{name}.{self.domain}"
            tasks.append(self._resolve_domain(subdomain, resolver))

        results = await asyncio.gather(*tasks, return_exceptions=True)

        for result in results:
            if result and not isinstance(result, Exception):
                subdomains.add(result)

        logger.info(f"DNS bruteforce found {len(subdomains)} subdomains")
        return subdomains

    async def _resolve_domain(self, domain: str, resolver: dns.resolver.Resolver) -> Optional[str]:
        """Resolve a domain asynchronously."""
        try:
            # Run DNS resolution in executor to avoid blocking
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, resolver.resolve, domain, 'A')
            return domain
        except Exception:
            return None

    async def _certificate_transparency(self) -> Set[str]:
        """Query certificate transparency logs."""
        subdomains = set()

        try:
            url = f"https://crt.sh/?q=%.{self.domain}&output=json"

            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=30)) as response:
                    if response.status == 200:
                        data = await response.json()

                        for entry in data:
                            name_value = entry.get('name_value', '')
                            # Split by newlines as crt.sh returns multiple names
                            for subdomain in name_value.split('\n'):
                                subdomain = subdomain.strip()
                                if subdomain and not subdomain.startswith('*'):
                                    subdomains.add(subdomain)

            logger.info(f"Certificate transparency found {len(subdomains)} subdomains")

        except Exception as e:
            logger.error(f"Certificate transparency error: {e}")

        return subdomains


class PortScanner:
    """Scans for open ports on targets."""

    def __init__(self, config: Dict):
        self.config = config
        self.common_ports = [
            21, 22, 23, 25, 53, 80, 110, 111, 135, 139, 143, 443, 445, 993, 995,
            1723, 3306, 3389, 5900, 8080, 8443, 8888, 9090
        ]

    async def scan_host(self, hostname: str) -> List[int]:
        """Scan a host for open ports."""
        open_ports = []

        try:
            # Use masscan for fast scanning if available
            open_ports = await self._masscan(hostname)

            if not open_ports:
                # Fallback to nmap
                open_ports = await self._nmap_scan(hostname)

        except Exception as e:
            logger.error(f"Port scanning error for {hostname}: {e}")

        return open_ports

    async def _masscan(self, hostname: str) -> List[int]:
        """Use masscan for fast port scanning."""
        open_ports = []

        try:
            ports_str = ','.join(map(str, self.common_ports))

            cmd = [
                'masscan',
                hostname,
                '-p', ports_str,
                '--rate', '1000',
                '--output-format', 'json',
                '--output-filename', '/dev/stdout'
            ]

            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )

            stdout, stderr = await process.communicate()

            if process.returncode == 0:
                for line in stdout.decode().strip().split('\n'):
                    if line:
                        try:
                            data = json.loads(line)
                            if 'ports' in data:
                                for port_info in data['ports']:
                                    open_ports.append(port_info['port'])
                        except json.JSONDecodeError:
                            pass

        except FileNotFoundError:
            logger.debug("masscan not installed")
        except Exception as e:
            logger.error(f"Masscan error: {e}")

        return open_ports

    async def _nmap_scan(self, hostname: str) -> List[int]:
        """Use nmap for port scanning."""
        open_ports = []

        try:
            ports_str = ','.join(map(str, self.common_ports))

            cmd = [
                'nmap',
                '-p', ports_str,
                '-T4',
                '--open',
                '-oX', '-',
                hostname
            ]

            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )

            stdout, stderr = await process.communicate()

            if process.returncode == 0:
                # Parse XML output
                import xml.etree.ElementTree as ET
                root = ET.fromstring(stdout.decode())

                for port in root.findall('.//port'):
                    state = port.find('state')
                    if state is not None and state.get('state') == 'open':
                        port_id = port.get('portid')
                        if port_id:
                            open_ports.append(int(port_id))

        except FileNotFoundError:
            logger.warning("nmap not installed")
        except Exception as e:
            logger.error(f"Nmap error: {e}")

        return open_ports


class WebProber:
    """Probes web services for information."""

    def __init__(self, config: Dict):
        self.config = config

    async def probe(self, hostname: str, ports: List[int]) -> Dict:
        """Probe web services on a host."""
        results = {
            'status_code': None,
            'title': None,
            'web_servers': [],
            'technologies': []
        }

        # Try common web ports
        web_ports = [p for p in ports if p in [80, 443, 8080, 8443]]

        if not web_ports:
            web_ports = [80, 443]

        for port in web_ports:
            scheme = 'https' if port in [443, 8443] else 'http'
            url = f"{scheme}://{hostname}:{port}" if port not in [80, 443] else f"{scheme}://{hostname}"

            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(
                        url,
                        timeout=aiohttp.ClientTimeout(total=10),
                        allow_redirects=True,
                        ssl=False
                    ) as response:
                        results['status_code'] = response.status
                        results['web_servers'].append(url)

                        # Get title
                        html = await response.text()
                        if '<title>' in html:
                            start = html.find('<title>') + 7
                            end = html.find('</title>', start)
                            results['title'] = html[start:end].strip()

                        # Detect technologies from headers
                        server = response.headers.get('Server')
                        if server:
                            results['technologies'].append(server)

                        powered_by = response.headers.get('X-Powered-By')
                        if powered_by:
                            results['technologies'].append(powered_by)

                        break  # Found working web server

            except Exception as e:
                logger.debug(f"Web probe error for {url}: {e}")
                continue

        return results


class AssetDiscovery:
    """Main asset discovery coordinator."""

    def __init__(self, config: Dict):
        self.config = config
        self.assets: List[Asset] = []

    async def discover_assets(self, targets: List[str]) -> List[Asset]:
        """Discover all assets for given targets."""
        all_subdomains = set()

        # Enumerate subdomains for each target
        for target in targets:
            logger.info(f"Enumerating subdomains for {target}")

            enumerator = SubdomainEnumerator(target, self.config)
            subdomains = await enumerator.enumerate()
            all_subdomains.update(subdomains)

        logger.info(f"Total unique subdomains: {len(all_subdomains)}")

        # Scan each subdomain
        scanner = PortScanner(self.config)
        prober = WebProber(self.config)

        tasks = []
        for subdomain in all_subdomains:
            tasks.append(self._scan_asset(subdomain, scanner, prober))

        # Process in batches to avoid overwhelming the target
        batch_size = self.config.get('reconnaissance', {}).get('max_concurrent_scans', 5)

        for i in range(0, len(tasks), batch_size):
            batch = tasks[i:i + batch_size]
            results = await asyncio.gather(*batch, return_exceptions=True)

            for result in results:
                if isinstance(result, Asset):
                    self.assets.append(result)

            # Rate limiting
            delay = self.config.get('reconnaissance', {}).get('request_delay_ms', 100) / 1000
            await asyncio.sleep(delay)

        logger.info(f"Discovered {len(self.assets)} assets")
        return self.assets

    async def _scan_asset(self, hostname: str, scanner: PortScanner, prober: WebProber) -> Asset:
        """Scan a single asset."""
        asset = Asset(hostname=hostname)

        try:
            # Resolve IP addresses
            try:
                resolver = dns.resolver.Resolver()
                answers = resolver.resolve(hostname, 'A')
                asset.ip_addresses = [str(rdata) for rdata in answers]
            except Exception as e:
                logger.debug(f"DNS resolution failed for {hostname}: {e}")

            # Scan ports
            if self.config.get('reconnaissance', {}).get('port_scanning'):
                asset.ports = await scanner.scan_host(hostname)

            # Probe web services
            if self.config.get('reconnaissance', {}).get('technology_detection'):
                probe_results = await prober.probe(hostname, asset.ports)
                asset.status_code = probe_results['status_code']
                asset.title = probe_results['title']
                asset.web_servers = probe_results['web_servers']
                asset.technologies = probe_results['technologies']

        except Exception as e:
            logger.error(f"Asset scanning error for {hostname}: {e}")

        return asset
