"""
GitHub Dorking Module
Searches GitHub for leaked secrets, credentials, and internal URLs related to Red Hat.
"""

import asyncio
import aiohttp
import logging
from typing import List, Dict, Optional
from datetime import datetime
import re
import base64

logger = logging.getLogger(__name__)


class GitHubDorker:
    """Searches GitHub for security-sensitive information."""

    def __init__(self, github_token: Optional[str] = None):
        self.github_token = github_token
        self.base_url = "https://api.github.com/search/code"
        self.results = []

    async def search_secrets(self, target_domains: List[str]) -> List[Dict]:
        """Search for leaked secrets related to target domains."""
        all_findings = []

        for domain in target_domains:
            logger.info(f"GitHub dorking for: {domain}")

            # Generate search queries
            queries = self._generate_dork_queries(domain)

            for query in queries:
                findings = await self._execute_search(query)
                all_findings.extend(findings)

                # Rate limiting - GitHub allows 30 requests/minute
                await asyncio.sleep(2)

        # Deduplicate
        unique_findings = {f['url']: f for f in all_findings}
        return list(unique_findings.values())

    def _generate_dork_queries(self, domain: str) -> List[str]:
        """Generate GitHub dork queries."""
        base_domain = domain.replace('www.', '')

        queries = [
            # API Keys and Tokens
            f'"{base_domain}" api_key',
            f'"{base_domain}" apikey',
            f'"{base_domain}" api-key',
            f'"{base_domain}" password',
            f'"{base_domain}" passwd',
            f'"{base_domain}" pwd',
            f'"{base_domain}" token',
            f'"{base_domain}" secret',
            f'"{base_domain}" aws_access_key_id',
            f'"{base_domain}" aws_secret_access_key',

            # Database Credentials
            f'"{base_domain}" db_password',
            f'"{base_domain}" database_password',
            f'"{base_domain}" mysql_password',
            f'"{base_domain}" postgres_password',
            f'"{base_domain}" mongodb_password',

            # Configuration Files
            f'"{base_domain}" extension:env',
            f'"{base_domain}" extension:config',
            f'"{base_domain}" extension:conf',
            f'"{base_domain}" extension:ini',
            f'"{base_domain}" extension:yaml',
            f'"{base_domain}" extension:yml',

            # Private Keys
            f'"{base_domain}" extension:pem',
            f'"{base_domain}" extension:key',
            f'"{base_domain}" extension:ppk',
            f'"{base_domain}" "BEGIN RSA PRIVATE KEY"',
            f'"{base_domain}" "BEGIN DSA PRIVATE KEY"',
            f'"{base_domain}" "BEGIN EC PRIVATE KEY"',

            # OAuth & JWT
            f'"{base_domain}" client_secret',
            f'"{base_domain}" client_id',
            f'"{base_domain}" oauth_token',
            f'"{base_domain}" refresh_token',

            # Cloud Credentials
            f'"{base_domain}" credentials',
            f'"{base_domain}" HEROKU_API_KEY',
            f'"{base_domain}" DOCKER_PASSWORD',

            # Internal URLs
            f'"{base_domain}" staging',
            f'"{base_domain}" internal',
            f'"{base_domain}" dev',
            f'"{base_domain}" test',
            f'"{base_domain}" admin',

            # Common Patterns
            f'"{base_domain}" extension:json password',
            f'"{base_domain}" extension:xml password',
            f'"{base_domain}" extension:sql',
            f'"{base_domain}" extension:log',

            # Red Hat Specific
            f'"redhat.com" api_key',
            f'"access.redhat.com" credentials',
            f'"openshift" api_token',
        ]

        return queries

    async def _execute_search(self, query: str) -> List[Dict]:
        """Execute a GitHub code search."""
        findings = []

        try:
            headers = {
                'Accept': 'application/vnd.github.v3+json'
            }

            if self.github_token:
                headers['Authorization'] = f'token {self.github_token}'

            params = {
                'q': query,
                'per_page': 100
            }

            async with aiohttp.ClientSession() as session:
                async with session.get(
                    self.base_url,
                    params=params,
                    headers=headers
                ) as response:
                    if response.status == 200:
                        data = await response.json()

                        for item in data.get('items', []):
                            finding = await self._analyze_result(item, query)
                            if finding:
                                findings.append(finding)

                    elif response.status == 403:
                        logger.warning("GitHub rate limit exceeded")
                    elif response.status == 422:
                        logger.debug(f"Invalid query: {query}")
                    else:
                        logger.error(f"GitHub search failed: {response.status}")

        except Exception as e:
            logger.error(f"GitHub search error: {e}")

        return findings

    async def _analyze_result(self, item: Dict, query: str) -> Optional[Dict]:
        """Analyze a search result for sensitive data."""
        try:
            repo = item.get('repository', {})
            file_path = item.get('path', '')
            html_url = item.get('html_url', '')

            # Download file content
            content_url = item.get('url', '')
            content = await self._get_file_content(content_url)

            if not content:
                return None

            # Analyze content for secrets
            secrets = self._extract_secrets(content)

            if secrets:
                return {
                    'type': 'github_secret',
                    'severity': 'critical',
                    'repository': repo.get('full_name'),
                    'file_path': file_path,
                    'url': html_url,
                    'query': query,
                    'secrets_found': secrets,
                    'discovered_at': datetime.now().isoformat(),
                    'description': f"Potential secrets found in {file_path}",
                    'remediation': 'Rotate all exposed credentials immediately. Remove from git history.'
                }

        except Exception as e:
            logger.error(f"Error analyzing result: {e}")

        return None

    async def _get_file_content(self, content_url: str) -> Optional[str]:
        """Get file content from GitHub."""
        try:
            headers = {
                'Accept': 'application/vnd.github.v3+json'
            }

            if self.github_token:
                headers['Authorization'] = f'token {self.github_token}'

            async with aiohttp.ClientSession() as session:
                async with session.get(content_url, headers=headers) as response:
                    if response.status == 200:
                        data = await response.json()
                        encoding = data.get('encoding')

                        if encoding == 'base64':
                            content_b64 = data.get('content', '')
                            content = base64.b64decode(content_b64).decode('utf-8', errors='ignore')
                            return content

        except Exception as e:
            logger.debug(f"Error getting file content: {e}")

        return None

    def _extract_secrets(self, content: str) -> List[Dict]:
        """Extract potential secrets from content."""
        secrets = []

        # Regex patterns for common secrets
        patterns = {
            'AWS Access Key': r'AKIA[0-9A-Z]{16}',
            'AWS Secret Key': r'[0-9a-zA-Z/+=]{40}',
            'GitHub Token': r'ghp_[0-9a-zA-Z]{36}',
            'Generic API Key': r'api[_-]?key[\'"\s]*[:=][\'"\s]*[0-9a-zA-Z]{32,}',
            'Generic Secret': r'secret[\'"\s]*[:=][\'"\s]*[0-9a-zA-Z]{16,}',
            'Password': r'password[\'"\s]*[:=][\'"\s]*[\S]{8,}',
            'Private Key': r'-----BEGIN (?:RSA|DSA|EC|OPENSSH) PRIVATE KEY-----',
            'JWT Token': r'eyJ[A-Za-z0-9-_=]+\.eyJ[A-Za-z0-9-_=]+\.[A-Za-z0-9-_.+/=]*',
            'Database URL': r'(?:mysql|postgres|mongodb)://[^\s]+',
            'Bearer Token': r'Bearer\s+[A-Za-z0-9\-._~+/]+=*',
        }

        for secret_type, pattern in patterns.items():
            matches = re.finditer(pattern, content, re.IGNORECASE)
            for match in matches:
                # Skip common false positives
                matched_text = match.group(0)
                if self._is_likely_real_secret(matched_text):
                    secrets.append({
                        'type': secret_type,
                        'value': matched_text[:50] + '...' if len(matched_text) > 50 else matched_text,
                        'position': match.start()
                    })

        return secrets

    def _is_likely_real_secret(self, text: str) -> bool:
        """Filter out common false positives."""
        false_positives = [
            'example', 'sample', 'test', 'dummy', 'fake', 'placeholder',
            'your_api_key', 'your_password', 'xxx', '***', '...', 'null',
            'undefined', 'none', 'password123', '12345'
        ]

        text_lower = text.lower()
        return not any(fp in text_lower for fp in false_positives)


class SubdomainTakeoverDetector:
    """Detects subdomain takeover vulnerabilities."""

    def __init__(self):
        self.vulnerable_patterns = {
            'AWS S3': {
                'patterns': [
                    r'NoSuchBucket',
                    r'The specified bucket does not exist'
                ],
                'cname_patterns': ['.s3.amazonaws.com', '.s3-website']
            },
            'GitHub Pages': {
                'patterns': [
                    r'There isn\'t a GitHub Pages site here',
                    r'For root URLs.*you can provide an index.html file'
                ],
                'cname_patterns': ['.github.io']
            },
            'Heroku': {
                'patterns': [
                    r'No such app',
                    r'There\'s nothing here, yet'
                ],
                'cname_patterns': ['.herokuapp.com', '.herokussl.com']
            },
            'Azure': {
                'patterns': [
                    r'404 Web Site not found',
                    r'Error 404.*cloudapp.net'
                ],
                'cname_patterns': ['.azurewebsites.net', '.cloudapp.net']
            },
            'Shopify': {
                'patterns': [
                    r'Sorry, this shop is currently unavailable',
                    r'Only one step left'
                ],
                'cname_patterns': ['.myshopify.com']
            },
            'Fastly': {
                'patterns': [
                    r'Fastly error: unknown domain'
                ],
                'cname_patterns': ['.fastly.net']
            },
        }

    async def check_subdomain(self, subdomain: str, cname: Optional[str] = None) -> Optional[Dict]:
        """Check if a subdomain is vulnerable to takeover."""
        try:
            # Get CNAME if not provided
            if not cname:
                cname = await self._get_cname(subdomain)

            if not cname:
                return None

            # Check if CNAME matches vulnerable services
            for service, patterns in self.vulnerable_patterns.items():
                if any(pattern in cname for pattern in patterns['cname_patterns']):
                    # Try to fetch the page
                    vulnerable = await self._check_takeover_patterns(
                        subdomain,
                        patterns['patterns']
                    )

                    if vulnerable:
                        return {
                            'type': 'subdomain_takeover',
                            'severity': 'high',
                            'subdomain': subdomain,
                            'cname': cname,
                            'service': service,
                            'description': f'Subdomain {subdomain} points to unclaimed {service} resource',
                            'proof_of_concept': f'CNAME: {subdomain} -> {cname}',
                            'remediation': f'Remove DNS record or claim the {service} resource',
                            'discovered_at': datetime.now().isoformat()
                        }

        except Exception as e:
            logger.debug(f"Takeover check error for {subdomain}: {e}")

        return None

    async def _get_cname(self, subdomain: str) -> Optional[str]:
        """Get CNAME record for subdomain."""
        try:
            import dns.resolver
            resolver = dns.resolver.Resolver()
            answers = resolver.resolve(subdomain, 'CNAME')
            return str(answers[0].target).rstrip('.')
        except Exception:
            return None

    async def _check_takeover_patterns(self, subdomain: str, patterns: List[str]) -> bool:
        """Check if subdomain shows takeover vulnerability patterns."""
        try:
            for scheme in ['http', 'https']:
                url = f'{scheme}://{subdomain}'

                async with aiohttp.ClientSession() as session:
                    async with session.get(
                        url,
                        timeout=aiohttp.ClientTimeout(total=10),
                        allow_redirects=True,
                        ssl=False
                    ) as response:
                        html = await response.text()

                        for pattern in patterns:
                            if re.search(pattern, html, re.IGNORECASE):
                                return True

        except Exception:
            pass

        return False

    async def batch_check(self, subdomains: List[str]) -> List[Dict]:
        """Check multiple subdomains in parallel."""
        tasks = [self.check_subdomain(subdomain) for subdomain in subdomains]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        vulnerabilities = []
        for result in results:
            if isinstance(result, dict):
                vulnerabilities.append(result)

        return vulnerabilities
