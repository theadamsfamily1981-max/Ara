"""
JavaScript Analysis Module
Extracts API endpoints, secrets, and vulnerabilities from JavaScript files.
"""

import asyncio
import aiohttp
import logging
import re
from typing import List, Dict, Set, Optional
from urllib.parse import urljoin, urlparse
from datetime import datetime
import base64

logger = logging.getLogger(__name__)


class JavaScriptAnalyzer:
    """Analyzes JavaScript files for security-sensitive information."""

    def __init__(self):
        self.endpoints = set()
        self.secrets = []
        self.interesting_files = []

    async def analyze_url(self, base_url: str) -> Dict:
        """Analyze all JavaScript files for a given URL."""
        results = {
            'base_url': base_url,
            'js_files_found': 0,
            'api_endpoints': [],
            'secrets_found': [],
            'source_maps': [],
            'interesting_comments': [],
            'vulnerabilities': []
        }

        try:
            # Fetch the main page
            js_files = await self._find_js_files(base_url)
            results['js_files_found'] = len(js_files)

            logger.info(f"Found {len(js_files)} JavaScript files for {base_url}")

            # Analyze each JS file
            for js_url in js_files:
                analysis = await self._analyze_js_file(js_url, base_url)

                results['api_endpoints'].extend(analysis.get('endpoints', []))
                results['secrets_found'].extend(analysis.get('secrets', []))
                results['source_maps'].extend(analysis.get('source_maps', []))
                results['interesting_comments'].extend(analysis.get('comments', []))
                results['vulnerabilities'].extend(analysis.get('vulnerabilities', []))

            # Deduplicate
            results['api_endpoints'] = list(set(results['api_endpoints']))

            logger.info(f"JavaScript analysis complete: {len(results['api_endpoints'])} endpoints, "
                       f"{len(results['secrets_found'])} secrets")

        except Exception as e:
            logger.error(f"JavaScript analysis error for {base_url}: {e}")

        return results

    async def _find_js_files(self, url: str) -> List[str]:
        """Find all JavaScript files referenced in a page."""
        js_files = set()

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url,
                    timeout=aiohttp.ClientTimeout(total=15),
                    ssl=False
                ) as response:
                    if response.status == 200:
                        html = await response.text()

                        # Find <script src="...">
                        script_pattern = r'<script[^>]+src=["\']([^"\']+)["\']'
                        matches = re.findall(script_pattern, html, re.IGNORECASE)

                        for match in matches:
                            js_url = urljoin(url, match)
                            if js_url.endswith('.js') or 'javascript' in js_url.lower():
                                js_files.add(js_url)

                        # Also look for inline webpack/bundle references
                        webpack_pattern = r'["\']([^"\']*(?:chunk|bundle|vendor|app|main)[^"\']*\.js)["\']'
                        webpack_matches = re.findall(webpack_pattern, html, re.IGNORECASE)

                        for match in webpack_matches:
                            js_url = urljoin(url, match)
                            js_files.add(js_url)

        except Exception as e:
            logger.debug(f"Error finding JS files: {e}")

        return list(js_files)

    async def _analyze_js_file(self, js_url: str, base_url: str) -> Dict:
        """Analyze a single JavaScript file."""
        analysis = {
            'endpoints': [],
            'secrets': [],
            'source_maps': [],
            'comments': [],
            'vulnerabilities': []
        }

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    js_url,
                    timeout=aiohttp.ClientTimeout(total=15),
                    ssl=False
                ) as response:
                    if response.status == 200:
                        js_content = await response.text()

                        # Extract API endpoints
                        analysis['endpoints'] = self._extract_endpoints(js_content, base_url)

                        # Find secrets/credentials
                        analysis['secrets'] = self._find_secrets(js_content, js_url)

                        # Check for source maps
                        if '//# sourceMappingURL=' in js_content:
                            source_map_match = re.search(r'//# sourceMappingURL=(.+)', js_content)
                            if source_map_match:
                                map_url = urljoin(js_url, source_map_match.group(1))
                                analysis['source_maps'].append(map_url)

                        # Extract interesting comments
                        analysis['comments'] = self._extract_comments(js_content)

                        # Look for client-side vulnerabilities
                        analysis['vulnerabilities'] = self._find_js_vulnerabilities(js_content, js_url)

        except Exception as e:
            logger.debug(f"Error analyzing JS file {js_url}: {e}")

        return analysis

    def _extract_endpoints(self, js_content: str, base_url: str) -> List[str]:
        """Extract API endpoints from JavaScript."""
        endpoints = set()

        # Common API endpoint patterns
        patterns = [
            # Fetch/Axios calls
            r'fetch\(["\']([^"\']+)["\']',
            r'axios\.[a-z]+\(["\']([^"\']+)["\']',
            r'\.get\(["\']([^"\']+)["\']',
            r'\.post\(["\']([^"\']+)["\']',
            r'\.put\(["\']([^"\']+)["\']',
            r'\.delete\(["\']([^"\']+)["\']',

            # URL strings
            r'["\']/(api|v1|v2|v3|rest|graphql)/[^"\']+["\']',

            # GraphQL
            r'query[:\s]+["\']([^"\']+)["\']',
            r'mutation[:\s]+["\']([^"\']+)["\']',

            # Endpoints in objects
            r'endpoint["\']?\s*:\s*["\']([^"\']+)["\']',
            r'url["\']?\s*:\s*["\']([^"\']+)["\']',
            r'path["\']?\s*:\s*["\']([^"\']+)["\']',
        ]

        for pattern in patterns:
            matches = re.findall(pattern, js_content, re.IGNORECASE)
            for match in matches:
                # Clean up and validate
                if isinstance(match, tuple):
                    match = match[0]

                # Skip obvious non-endpoints
                if any(skip in match.lower() for skip in ['http', 'www', 'cdn', '.js', '.css', '.png', '.jpg']):
                    continue

                # Make absolute URL
                if match.startswith('/'):
                    endpoint = urljoin(base_url, match)
                    endpoints.add(endpoint)
                elif match.startswith('api') or match.startswith('v1'):
                    endpoint = urljoin(base_url, '/' + match)
                    endpoints.add(endpoint)

        return list(endpoints)

    def _find_secrets(self, js_content: str, js_url: str) -> List[Dict]:
        """Find secrets and credentials in JavaScript."""
        secrets = []

        secret_patterns = {
            'API Key': [
                r'api[_-]?key["\']?\s*[:=]\s*["\']([a-zA-Z0-9_\-]{20,})["\']',
                r'apikey["\']?\s*[:=]\s*["\']([a-zA-Z0-9_\-]{20,})["\']',
            ],
            'AWS Access Key': [
                r'(AKIA[0-9A-Z]{16})',
            ],
            'AWS Secret Key': [
                r'aws[_-]?secret["\']?\s*[:=]\s*["\']([a-zA-Z0-9/+=]{40})["\']',
            ],
            'Private Key': [
                r'(-----BEGIN (?:RSA|DSA|EC) PRIVATE KEY-----)',
            ],
            'JWT Token': [
                r'(eyJ[A-Za-z0-9-_=]+\.eyJ[A-Za-z0-9-_=]+\.[A-Za-z0-9-_.+/=]*)',
            ],
            'Firebase URL': [
                r'([a-z0-9-]+\.firebaseio\.com)',
            ],
            'Google API Key': [
                r'AIza[0-9A-Za-z\-_]{35}',
            ],
            'Slack Token': [
                r'xox[baprs]-[0-9a-zA-Z]{10,48}',
            ],
            'Authorization Header': [
                r'authorization["\']?\s*:\s*["\']Bearer\s+([^"\']+)["\']',
            ],
            'Database Connection': [
                r'(mongodb(?:\+srv)?://[^\s"\']+)',
                r'(postgres://[^\s"\']+)',
                r'(mysql://[^\s"\']+)',
            ],
            'Access Token': [
                r'access[_-]?token["\']?\s*[:=]\s*["\']([a-zA-Z0-9_\-\.]{20,})["\']',
            ],
            'Client Secret': [
                r'client[_-]?secret["\']?\s*[:=]\s*["\']([a-zA-Z0-9_\-]{20,})["\']',
            ]
        }

        for secret_type, patterns in secret_patterns.items():
            for pattern in patterns:
                matches = re.finditer(pattern, js_content, re.IGNORECASE)
                for match in matches:
                    secret_value = match.group(1) if match.groups() else match.group(0)

                    # Filter false positives
                    if self._is_likely_real_secret(secret_value):
                        secrets.append({
                            'type': secret_type,
                            'value': secret_value[:50] + '...' if len(secret_value) > 50 else secret_value,
                            'file': js_url,
                            'severity': 'critical'
                        })

        return secrets

    def _is_likely_real_secret(self, value: str) -> bool:
        """Filter out obvious false positives."""
        false_positives = [
            'example', 'sample', 'test', 'demo', 'dummy', 'placeholder',
            'your_api_key', 'insert', 'replace', 'xxx', '...', 'null',
            'undefined', 'none', '12345', 'abcdef', 'secret_here',
            'api_key_here', 'enter_your', 'paste_your', '<your', 'your_',
            'my_secret', 'client_secret_here', 'xxxxxxxx'
        ]

        value_lower = value.lower()

        # Too short
        if len(value) < 10:
            return False

        # Common false positive patterns
        if any(fp in value_lower for fp in false_positives):
            return False

        # All same character
        if len(set(value)) < 5:
            return False

        return True

    def _extract_comments(self, js_content: str) -> List[str]:
        """Extract interesting comments from JavaScript."""
        interesting = []

        # Single-line comments
        single_line_pattern = r'//\s*(.+)'
        for match in re.finditer(single_line_pattern, js_content):
            comment = match.group(1).strip()
            if self._is_interesting_comment(comment):
                interesting.append(comment)

        # Multi-line comments
        multi_line_pattern = r'/\*\s*(.+?)\s*\*/'
        for match in re.finditer(multi_line_pattern, js_content, re.DOTALL):
            comment = match.group(1).strip()
            if self._is_interesting_comment(comment):
                interesting.append(comment[:200])  # Limit length

        return interesting[:20]  # Limit total comments

    def _is_interesting_comment(self, comment: str) -> bool:
        """Check if comment contains interesting information."""
        keywords = [
            'todo', 'fixme', 'hack', 'bug', 'broken', 'temp', 'temporary',
            'debug', 'password', 'secret', 'api', 'key', 'token', 'admin',
            'internal', 'deprecated', 'vulnerability', 'security', 'unsafe'
        ]

        comment_lower = comment.lower()
        return any(keyword in comment_lower for keyword in keywords) and len(comment) > 10

    def _find_js_vulnerabilities(self, js_content: str, js_url: str) -> List[Dict]:
        """Find potential vulnerabilities in JavaScript code."""
        vulnerabilities = []

        # Dangerous functions (XSS)
        if re.search(r'innerHTML\s*=', js_content):
            vulnerabilities.append({
                'type': 'potential_xss',
                'severity': 'medium',
                'description': 'Uses innerHTML which may be vulnerable to XSS',
                'file': js_url,
                'line': 'See file'
            })

        # eval() usage
        if re.search(r'\beval\s*\(', js_content):
            vulnerabilities.append({
                'type': 'dangerous_function',
                'severity': 'high',
                'description': 'Uses eval() which is dangerous',
                'file': js_url,
                'line': 'See file'
            })

        # document.write
        if re.search(r'document\.write\s*\(', js_content):
            vulnerabilities.append({
                'type': 'potential_xss',
                'severity': 'medium',
                'description': 'Uses document.write which may be vulnerable',
                'file': js_url,
                'line': 'See file'
            })

        # Hardcoded credentials
        if re.search(r'password\s*[:=]\s*["\'][^"\']{5,}["\']', js_content, re.IGNORECASE):
            vulnerabilities.append({
                'type': 'hardcoded_credential',
                'severity': 'high',
                'description': 'Potential hardcoded password found',
                'file': js_url,
                'line': 'See file'
            })

        # Debug mode enabled
        if re.search(r'debug\s*[:=]\s*true', js_content, re.IGNORECASE):
            vulnerabilities.append({
                'type': 'debug_enabled',
                'severity': 'low',
                'description': 'Debug mode appears to be enabled',
                'file': js_url,
                'line': 'See file'
            })

        return vulnerabilities


class WaybackMachine:
    """Queries Wayback Machine for historical URLs and endpoints."""

    BASE_URL = "http://web.archive.org"

    async def find_urls(self, domain: str) -> List[str]:
        """Find all archived URLs for a domain."""
        urls = set()

        try:
            # CDX API - gets all archived URLs
            cdx_url = f"{self.BASE_URL}/cdx/search/cdx"
            params = {
                'url': f'*.{domain}/*',
                'matchType': 'domain',
                'output': 'json',
                'fl': 'original',
                'collapse': 'urlkey',
                'limit': 10000
            }

            async with aiohttp.ClientSession() as session:
                async with session.get(
                    cdx_url,
                    params=params,
                    timeout=aiohttp.ClientTimeout(total=30)
                ) as response:
                    if response.status == 200:
                        data = await response.json()

                        # Skip header row
                        for row in data[1:]:
                            if row and isinstance(row, list):
                                url = row[0]
                                urls.add(url)

            logger.info(f"Wayback Machine found {len(urls)} historical URLs for {domain}")

        except Exception as e:
            logger.error(f"Wayback Machine error: {e}")

        return list(urls)

    async def find_interesting_endpoints(self, domain: str) -> List[Dict]:
        """Find interesting historical endpoints that might still exist."""
        interesting = []

        try:
            all_urls = await self.find_urls(domain)

            # Keywords that indicate interesting endpoints
            keywords = [
                'admin', 'panel', 'dashboard', 'api', 'v1', 'v2', 'v3',
                'dev', 'test', 'staging', 'debug', 'console', 'upload',
                'login', 'auth', 'user', 'account', 'profile', 'config',
                'settings', 'manage', 'internal', 'private', 'backup',
                'old', 'legacy', 'deprecated', 'temp', 'tmp'
            ]

            for url in all_urls:
                url_lower = url.lower()

                # Check for interesting keywords
                if any(keyword in url_lower for keyword in keywords):
                    # Check if it's an actual endpoint (not just image/css/js)
                    if not any(ext in url_lower for ext in ['.jpg', '.png', '.gif', '.css', '.js', '.svg', '.ico']):
                        interesting.append({
                            'url': url,
                            'type': 'historical_endpoint',
                            'severity': 'info',
                            'description': f'Historical endpoint found in Wayback Machine',
                            'discovered_at': datetime.now().isoformat()
                        })

            logger.info(f"Found {len(interesting)} interesting historical endpoints")

        except Exception as e:
            logger.error(f"Error finding interesting endpoints: {e}")

        return interesting[:100]  # Limit results

    async def check_if_still_exists(self, url: str) -> bool:
        """Check if a historical URL still exists."""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.head(
                    url,
                    timeout=aiohttp.ClientTimeout(total=10),
                    allow_redirects=True,
                    ssl=False
                ) as response:
                    return response.status in [200, 301, 302, 403]  # 403 means exists but forbidden

        except Exception:
            return False


class EnhancedRecon:
    """Combined JavaScript analysis and Wayback Machine reconnaissance."""

    def __init__(self):
        self.js_analyzer = JavaScriptAnalyzer()
        self.wayback = WaybackMachine()

    async def perform_enhanced_recon(self, targets: List[str]) -> Dict:
        """Perform enhanced reconnaissance with JS analysis and Wayback."""
        results = {
            'js_analysis': [],
            'wayback_endpoints': [],
            'total_new_endpoints': 0,
            'secrets_from_js': []
        }

        for target in targets:
            logger.info(f"Enhanced recon for: {target}")

            # JavaScript analysis
            js_results = await self.js_analyzer.analyze_url(f"https://{target}")
            results['js_analysis'].append(js_results)
            results['secrets_from_js'].extend(js_results.get('secrets_found', []))
            results['total_new_endpoints'] += len(js_results.get('api_endpoints', []))

            # Wayback Machine
            domain = target.replace('www.', '')
            wayback_results = await self.wayback.find_interesting_endpoints(domain)
            results['wayback_endpoints'].extend(wayback_results)

            # Rate limiting
            await asyncio.sleep(2)

        logger.info(f"Enhanced recon complete: {results['total_new_endpoints']} new endpoints, "
                   f"{len(results['secrets_from_js'])} secrets from JS")

        return results
