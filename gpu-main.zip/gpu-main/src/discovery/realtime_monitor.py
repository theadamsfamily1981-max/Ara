"""
Real-Time Program Monitor
Monitors for new bug bounty programs every 5 minutes and alerts immediately.
"""

import asyncio
import aiohttp
import logging
from typing import List, Dict, Set, Optional
from datetime import datetime, timedelta
import json
from hashlib import md5

logger = logging.getLogger(__name__)


class ProgramChange:
    """Represents a change in a bug bounty program."""

    def __init__(self, change_type: str, program_name: str, details: Dict):
        self.change_type = change_type  # 'new_program', 'scope_expansion', 'bounty_increase'
        self.program_name = program_name
        self.details = details
        self.detected_at = datetime.now()

    def to_dict(self) -> Dict:
        return {
            'change_type': self.change_type,
            'program_name': self.program_name,
            'details': self.details,
            'detected_at': self.detected_at.isoformat(),
            'urgency': self._calculate_urgency()
        }

    def _calculate_urgency(self) -> str:
        """Calculate urgency level."""
        if self.change_type == 'new_program':
            return 'CRITICAL'  # Act within minutes!
        elif self.change_type == 'scope_expansion':
            return 'HIGH'  # Act within hours
        elif self.change_type == 'bounty_increase':
            return 'MEDIUM'  # Good to know
        return 'LOW'


class RealtimeMonitor:
    """Monitors bug bounty platforms for changes in real-time."""

    def __init__(self, config: Dict, notification_manager):
        self.config = config
        self.notifier = notification_manager

        # Cache of known programs (hash of program data)
        self.known_programs: Set[str] = set()
        self.program_snapshots: Dict[str, Dict] = {}

        # Monitoring interval (default: 5 minutes)
        self.check_interval = 300  # seconds

        self.running = False

    async def start_monitoring(self):
        """Start continuous monitoring loop."""
        logger.info("Starting real-time program monitoring...")
        self.running = True

        # Initial load
        await self._load_initial_state()

        while self.running:
            try:
                changes = await self._check_for_changes()

                if changes:
                    await self._process_changes(changes)

                # Wait before next check
                await asyncio.sleep(self.check_interval)

            except Exception as e:
                logger.error(f"Monitor error: {e}")
                await asyncio.sleep(60)  # Wait 1 min before retry

    def stop_monitoring(self):
        """Stop monitoring."""
        self.running = False
        logger.info("Stopped real-time monitoring")

    async def _load_initial_state(self):
        """Load initial state of all programs."""
        logger.info("Loading initial program state...")

        # Get all current programs
        programs = await self._fetch_all_programs()

        for program in programs:
            program_hash = self._hash_program(program)
            self.known_programs.add(program_hash)
            self.program_snapshots[program_hash] = {
                'name': program.get('name'),
                'snapshot': program,
                'last_seen': datetime.now()
            }

        logger.info(f"Loaded {len(self.known_programs)} programs")

    async def _check_for_changes(self) -> List[ProgramChange]:
        """Check for any changes in programs."""
        changes = []

        # Fetch current state
        current_programs = await self._fetch_all_programs()

        # Create set of current program hashes
        current_hashes = {self._hash_program(p) for p in current_programs}

        # Check for NEW programs
        new_hashes = current_hashes - self.known_programs
        for prog_hash in new_hashes:
            program = next(p for p in current_programs if self._hash_program(p) == prog_hash)

            change = ProgramChange(
                change_type='new_program',
                program_name=program.get('name'),
                details={
                    'url': program.get('url'),
                    'platform': program.get('platform'),
                    'scope': program.get('scope', []),
                    'max_bounty': program.get('rewards', {}).get('max_bounty'),
                    'detected_within': '5 minutes'
                }
            )
            changes.append(change)

            # Add to known programs
            self.known_programs.add(prog_hash)
            self.program_snapshots[prog_hash] = {
                'name': program.get('name'),
                'snapshot': program,
                'last_seen': datetime.now()
            }

        # Check for SCOPE CHANGES in existing programs
        for program in current_programs:
            scope_changes = self._detect_scope_changes(program)
            if scope_changes:
                changes.extend(scope_changes)

        # Check for BOUNTY INCREASES
        for program in current_programs:
            bounty_changes = self._detect_bounty_changes(program)
            if bounty_changes:
                changes.append(bounty_changes)

        return changes

    async def _fetch_all_programs(self) -> List[Dict]:
        """Fetch all current programs from platforms."""
        all_programs = []

        # HackerOne
        if self.config.get('platforms', {}).get('hackerone', {}).get('enabled'):
            h1_programs = await self._fetch_hackerone_programs()
            all_programs.extend(h1_programs)

        # Bugcrowd
        if self.config.get('platforms', {}).get('bugcrowd', {}).get('enabled'):
            bc_programs = await self._fetch_bugcrowd_programs()
            all_programs.extend(bc_programs)

        return all_programs

    async def _fetch_hackerone_programs(self) -> List[Dict]:
        """Fetch HackerOne programs."""
        programs = []

        try:
            # HackerOne directory API
            url = "https://hackerone.com/programs/search"

            params = {
                'query': 'Red Hat OR RedHat OR OpenShift OR Ansible OR JBoss',
                'sort': 'launched_at',
                'page': 1
            }

            async with aiohttp.ClientSession() as session:
                async with session.get(url, params=params) as response:
                    if response.status == 200:
                        data = await response.json()

                        for item in data.get('results', []):
                            programs.append({
                                'name': item.get('name'),
                                'platform': 'HackerOne',
                                'url': f"https://hackerone.com/{item.get('handle')}",
                                'handle': item.get('handle'),
                                'scope': item.get('targets', {}).get('in_scope', []),
                                'rewards': {
                                    'min_bounty': item.get('min_bounty'),
                                    'max_bounty': item.get('max_bounty'),
                                    'currency': item.get('currency')
                                },
                                'launched_at': item.get('launched_at')
                            })

        except Exception as e:
            logger.error(f"Error fetching HackerOne programs: {e}")

        return programs

    async def _fetch_bugcrowd_programs(self) -> List[Dict]:
        """Fetch Bugcrowd programs."""
        programs = []

        try:
            url = "https://bugcrowd.com/programs.json"

            params = {
                'q': 'Red Hat',
                'sort': 'created_at'
            }

            async with aiohttp.ClientSession() as session:
                async with session.get(url, params=params) as response:
                    if response.status == 200:
                        data = await response.json()

                        for item in data.get('programs', []):
                            programs.append({
                                'name': item.get('name'),
                                'platform': 'Bugcrowd',
                                'url': item.get('program_url'),
                                'code': item.get('code'),
                                'scope': item.get('targets', []),
                                'rewards': item.get('rewards', {}),
                                'created_at': item.get('created_at')
                            })

        except Exception as e:
            logger.error(f"Error fetching Bugcrowd programs: {e}")

        return programs

    def _hash_program(self, program: Dict) -> str:
        """Create hash of program for comparison."""
        # Hash based on name and platform (unique identifier)
        identifier = f"{program.get('name')}_{program.get('platform')}"
        return md5(identifier.encode()).hexdigest()

    def _detect_scope_changes(self, program: Dict) -> List[ProgramChange]:
        """Detect if program scope has expanded."""
        changes = []
        program_hash = self._hash_program(program)

        if program_hash in self.program_snapshots:
            old_snapshot = self.program_snapshots[program_hash]['snapshot']
            old_scope = set(old_snapshot.get('scope', []))
            new_scope = set(program.get('scope', []))

            # New domains added to scope
            added_domains = new_scope - old_scope

            if added_domains:
                change = ProgramChange(
                    change_type='scope_expansion',
                    program_name=program.get('name'),
                    details={
                        'new_domains': list(added_domains),
                        'total_new': len(added_domains),
                        'platform': program.get('platform'),
                        'url': program.get('url')
                    }
                )
                changes.append(change)

                # Update snapshot
                self.program_snapshots[program_hash]['snapshot'] = program

        return changes

    def _detect_bounty_changes(self, program: Dict) -> Optional[ProgramChange]:
        """Detect if program bounty has increased."""
        program_hash = self._hash_program(program)

        if program_hash in self.program_snapshots:
            old_snapshot = self.program_snapshots[program_hash]['snapshot']
            old_max = old_snapshot.get('rewards', {}).get('max_bounty', 0)
            new_max = program.get('rewards', {}).get('max_bounty', 0)

            if new_max and old_max and new_max > old_max:
                return ProgramChange(
                    change_type='bounty_increase',
                    program_name=program.get('name'),
                    details={
                        'old_max_bounty': old_max,
                        'new_max_bounty': new_max,
                        'increase': new_max - old_max,
                        'percentage': round((new_max - old_max) / old_max * 100, 1),
                        'platform': program.get('platform'),
                        'url': program.get('url')
                    }
                )

                # Update snapshot
                self.program_snapshots[program_hash]['snapshot'] = program

        return None

    async def _process_changes(self, changes: List[ProgramChange]):
        """Process detected changes."""
        for change in changes:
            logger.info(f"CHANGE DETECTED: {change.change_type} - {change.program_name}")

            # Send notifications
            await self._notify_change(change)

            # For new programs, trigger immediate scan
            if change.change_type == 'new_program':
                await self._trigger_immediate_scan(change)

    async def _notify_change(self, change: ProgramChange):
        """Send notification about change."""
        if change.change_type == 'new_program':
            message = f"""
🚨 **NEW BUG BOUNTY PROGRAM DETECTED!** 🚨

Program: {change.program_name}
Platform: {change.details.get('platform')}
URL: {change.details.get('url')}

Scope: {len(change.details.get('scope', []))} domains
Max Bounty: ${change.details.get('max_bounty', 'Unknown')}

⚡ **ACTION REQUIRED: Scan immediately to be FIRST to report!** ⚡

Detected within: {change.details.get('detected_within')}
"""

            await self.notifier.notify(
                'critical_finding',
                message,
                {
                    'Program': change.program_name,
                    'Platform': change.details.get('platform'),
                    'Urgency': 'CRITICAL - Act Now!'
                }
            )

        elif change.change_type == 'scope_expansion':
            message = f"""
📈 **SCOPE EXPANSION DETECTED!**

Program: {change.program_name}
Platform: {change.details.get('platform')}

New Domains Added: {change.details.get('total_new')}
Domains: {', '.join(change.details.get('new_domains', [])[:5])}

⚡ **Scan new domains immediately!** ⚡
"""

            await self.notifier.notify(
                'high_finding',
                message,
                {
                    'Program': change.program_name,
                    'New Domains': change.details.get('total_new')
                }
            )

        elif change.change_type == 'bounty_increase':
            message = f"""
💰 **BOUNTY INCREASE DETECTED!**

Program: {change.program_name}
Old Max: ${change.details.get('old_max_bounty')}
New Max: ${change.details.get('new_max_bounty')}
Increase: +${change.details.get('increase')} (+{change.details.get('percentage')}%)

Consider prioritizing this program!
"""

            await self.notifier.notify(
                'high_finding',
                message,
                {
                    'Program': change.program_name,
                    'Increase': f"+${change.details.get('increase')}"
                }
            )

    async def _trigger_immediate_scan(self, change: ProgramChange):
        """Trigger immediate scan of new program."""
        logger.info(f"Triggering immediate scan of {change.program_name}")

        # Save to file for orchestrator to pick up
        scan_request = {
            'program_name': change.program_name,
            'platform': change.details.get('platform'),
            'url': change.details.get('url'),
            'scope': change.details.get('scope', []),
            'priority': 'CRITICAL',
            'reason': 'new_program_detected',
            'detected_at': datetime.now().isoformat()
        }

        # Write to priority queue file
        with open('./data/priority_scan_queue.json', 'a') as f:
            f.write(json.dumps(scan_request) + '\n')

        logger.info(f"Scan request queued for {change.program_name}")


class CertificateTransparencyMonitor:
    """Monitors Certificate Transparency logs for new subdomains in real-time."""

    def __init__(self, domains: List[str], notification_manager):
        self.domains = domains
        self.notifier = notification_manager
        self.known_subdomains: Set[str] = set()
        self.running = False

    async def start_monitoring(self):
        """Start monitoring CT logs."""
        logger.info(f"Starting CT log monitoring for {len(self.domains)} domains...")
        self.running = True

        # Load initial subdomains
        await self._load_initial_subdomains()

        while self.running:
            try:
                new_subdomains = await self._check_ct_logs()

                if new_subdomains:
                    await self._process_new_subdomains(new_subdomains)

                await asyncio.sleep(300)  # Check every 5 minutes

            except Exception as e:
                logger.error(f"CT monitor error: {e}")
                await asyncio.sleep(60)

    def stop_monitoring(self):
        """Stop monitoring."""
        self.running = False

    async def _load_initial_subdomains(self):
        """Load currently known subdomains."""
        for domain in self.domains:
            subdomains = await self._query_crtsh(domain)
            self.known_subdomains.update(subdomains)

        logger.info(f"Loaded {len(self.known_subdomains)} known subdomains")

    async def _check_ct_logs(self) -> List[str]:
        """Check CT logs for new certificates."""
        new_subdomains = []

        for domain in self.domains:
            current_subdomains = await self._query_crtsh(domain)

            # Find new ones
            new = current_subdomains - self.known_subdomains

            if new:
                new_subdomains.extend(new)
                self.known_subdomains.update(new)
                logger.info(f"Found {len(new)} new subdomains for {domain}")

        return new_subdomains

    async def _query_crtsh(self, domain: str) -> Set[str]:
        """Query crt.sh for certificates."""
        subdomains = set()

        try:
            url = f"https://crt.sh/?q=%.{domain}&output=json"

            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=30)) as response:
                    if response.status == 200:
                        data = await response.json()

                        for entry in data:
                            name_value = entry.get('name_value', '')
                            for subdomain in name_value.split('\n'):
                                subdomain = subdomain.strip()
                                if subdomain and not subdomain.startswith('*'):
                                    subdomains.add(subdomain)

        except Exception as e:
            logger.debug(f"CT query error for {domain}: {e}")

        return subdomains

    async def _process_new_subdomains(self, subdomains: List[str]):
        """Process newly discovered subdomains."""
        logger.info(f"Processing {len(subdomains)} new subdomains...")

        # Notify
        message = f"""
🆕 **NEW SUBDOMAINS DETECTED!**

Found {len(subdomains)} new subdomains from Certificate Transparency logs:

{chr(10).join(subdomains[:10])}
{"... and more" if len(subdomains) > 10 else ""}

⚡ **Scanning immediately!** ⚡
"""

        await self.notifier.notify(
            'high_finding',
            message,
            {
                'New Subdomains': len(subdomains),
                'Source': 'Certificate Transparency'
            }
        )

        # Queue for immediate scanning
        scan_request = {
            'subdomains': subdomains,
            'priority': 'HIGH',
            'reason': 'new_subdomain_from_ct',
            'detected_at': datetime.now().isoformat()
        }

        with open('./data/priority_scan_queue.json', 'a') as f:
            f.write(json.dumps(scan_request) + '\n')
