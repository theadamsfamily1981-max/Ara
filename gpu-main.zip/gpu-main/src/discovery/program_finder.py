"""
Bug Bounty Program Discovery Module
Finds and monitors Red Hat bug bounty programs across multiple platforms.
"""

import asyncio
import aiohttp
from typing import List, Dict, Optional
from datetime import datetime
import logging
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)


class BugBountyProgram:
    """Represents a bug bounty program."""

    def __init__(self, name: str, platform: str, url: str, scope: List[str],
                 out_of_scope: List[str], rewards: Dict, rules: str):
        self.name = name
        self.platform = platform
        self.url = url
        self.scope = scope
        self.out_of_scope = out_of_scope
        self.rewards = rewards
        self.rules = rules
        self.discovered_at = datetime.now()
        self.last_updated = datetime.now()

    def to_dict(self) -> Dict:
        """Convert to dictionary."""
        return {
            'name': self.name,
            'platform': self.platform,
            'url': self.url,
            'scope': self.scope,
            'out_of_scope': self.out_of_scope,
            'rewards': self.rewards,
            'rules': self.rules,
            'discovered_at': self.discovered_at.isoformat(),
            'last_updated': self.last_updated.isoformat()
        }


class HackerOneDiscovery:
    """Discovers Red Hat programs on HackerOne."""

    BASE_URL = "https://hackerone.com"

    def __init__(self, api_token: Optional[str] = None, username: Optional[str] = None):
        self.api_token = api_token
        self.username = username
        self.session = None

    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()

    async def find_red_hat_programs(self) -> List[BugBountyProgram]:
        """Find all Red Hat related programs on HackerOne."""
        programs = []

        try:
            # Search for Red Hat programs
            search_queries = [
                "Red Hat",
                "RedHat",
                "OpenShift",
                "Ansible",
                "JBoss",
                "RHEL"
            ]

            for query in search_queries:
                logger.info(f"Searching HackerOne for: {query}")
                found_programs = await self._search_programs(query)
                programs.extend(found_programs)

            # Remove duplicates
            unique_programs = {p.url: p for p in programs}
            return list(unique_programs.values())

        except Exception as e:
            logger.error(f"Error finding HackerOne programs: {e}")
            return []

    async def _search_programs(self, query: str) -> List[BugBountyProgram]:
        """Search for programs matching query."""
        programs = []

        try:
            # Use GraphQL API if authenticated
            if self.api_token and self.username:
                programs = await self._search_with_api(query)
            else:
                # Fallback to web scraping
                programs = await self._search_with_scraping(query)

        except Exception as e:
            logger.error(f"Error searching for '{query}': {e}")

        return programs

    async def _search_with_api(self, query: str) -> List[BugBountyProgram]:
        """Search using HackerOne GraphQL API."""
        graphql_query = """
        query ProgramSearch($query: String!) {
          teams(first: 50, query: $query, where: {_and: [{state: {_eq: soft_launched}}, {submission_state: {_eq: open}}]}) {
            edges {
              node {
                id
                handle
                name
                url
                offers_bounties
                currency
                base_bounty
                structured_scopes(archived: false) {
                  edges {
                    node {
                      asset_identifier
                      asset_type
                      eligible_for_bounty
                      eligible_for_submission
                      instruction
                    }
                  }
                }
              }
            }
          }
        }
        """

        headers = {
            "Content-Type": "application/json",
        }

        if self.api_token:
            headers["Authorization"] = f"Bearer {self.api_token}"

        data = {
            "query": graphql_query,
            "variables": {"query": query}
        }

        programs = []

        try:
            async with self.session.post(
                f"{self.BASE_URL}/graphql",
                json=data,
                headers=headers
            ) as response:
                if response.status == 200:
                    result = await response.json()
                    teams = result.get('data', {}).get('teams', {}).get('edges', [])

                    for edge in teams:
                        node = edge.get('node', {})
                        program = await self._parse_program_from_api(node)
                        if program:
                            programs.append(program)

        except Exception as e:
            logger.error(f"API search error: {e}")

        return programs

    async def _parse_program_from_api(self, node: Dict) -> Optional[BugBountyProgram]:
        """Parse program data from API response."""
        try:
            handle = node.get('handle')
            if not handle:
                return None

            # Extract scope
            scope = []
            out_of_scope = []

            scopes = node.get('structured_scopes', {}).get('edges', [])
            for scope_edge in scopes:
                scope_node = scope_edge.get('node', {})
                asset = scope_node.get('asset_identifier')

                if scope_node.get('eligible_for_submission'):
                    scope.append(asset)
                else:
                    out_of_scope.append(asset)

            # Rewards info
            rewards = {
                'offers_bounties': node.get('offers_bounties', False),
                'currency': node.get('currency'),
                'base_bounty': node.get('base_bounty')
            }

            return BugBountyProgram(
                name=node.get('name', handle),
                platform='HackerOne',
                url=f"{self.BASE_URL}/{handle}",
                scope=scope,
                out_of_scope=out_of_scope,
                rewards=rewards,
                rules=node.get('policy', '')
            )

        except Exception as e:
            logger.error(f"Error parsing program: {e}")
            return None

    async def _search_with_scraping(self, query: str) -> List[BugBountyProgram]:
        """Search using web scraping (fallback)."""
        programs = []

        try:
            # Search directory page
            search_url = f"{self.BASE_URL}/directory/programs"

            async with self.session.get(search_url) as response:
                if response.status == 200:
                    html = await response.text()
                    soup = BeautifulSoup(html, 'lxml')

                    # This is a simplified scraping - actual implementation
                    # would need to handle pagination and dynamic content
                    logger.info("Web scraping fallback - limited results")

        except Exception as e:
            logger.error(f"Scraping error: {e}")

        return programs


class BugcrowdDiscovery:
    """Discovers Red Hat programs on Bugcrowd."""

    BASE_URL = "https://bugcrowd.com"

    def __init__(self, api_token: Optional[str] = None):
        self.api_token = api_token
        self.session = None

    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()

    async def find_red_hat_programs(self) -> List[BugBountyProgram]:
        """Find all Red Hat related programs on Bugcrowd."""
        programs = []

        try:
            # Bugcrowd API endpoint
            api_url = f"{self.BASE_URL}/api/programs"

            headers = {}
            if self.api_token:
                headers["Authorization"] = f"Bearer {self.api_token}"

            async with self.session.get(api_url, headers=headers) as response:
                if response.status == 200:
                    data = await response.json()

                    # Filter for Red Hat programs
                    for program_data in data.get('programs', []):
                        if self._is_red_hat_program(program_data):
                            program = self._parse_bugcrowd_program(program_data)
                            if program:
                                programs.append(program)

        except Exception as e:
            logger.error(f"Error finding Bugcrowd programs: {e}")

        return programs

    def _is_red_hat_program(self, program_data: Dict) -> bool:
        """Check if program is related to Red Hat."""
        name = program_data.get('name', '').lower()
        keywords = ['red hat', 'redhat', 'openshift', 'ansible', 'jboss', 'rhel']
        return any(keyword in name for keyword in keywords)

    def _parse_bugcrowd_program(self, data: Dict) -> Optional[BugBountyProgram]:
        """Parse Bugcrowd program data."""
        try:
            return BugBountyProgram(
                name=data.get('name'),
                platform='Bugcrowd',
                url=data.get('program_url'),
                scope=data.get('targets', {}).get('in_scope', []),
                out_of_scope=data.get('targets', {}).get('out_of_scope', []),
                rewards=data.get('rewards', {}),
                rules=data.get('safe_harbor', '')
            )
        except Exception as e:
            logger.error(f"Error parsing Bugcrowd program: {e}")
            return None


class ProgramDiscovery:
    """Main program discovery coordinator."""

    def __init__(self, config: Dict):
        self.config = config
        self.programs = []

    async def discover_all_programs(self) -> List[BugBountyProgram]:
        """Discover programs across all platforms."""
        all_programs = []

        tasks = []

        # HackerOne
        if self.config.get('platforms', {}).get('hackerone', {}).get('enabled'):
            tasks.append(self._discover_hackerone())

        # Bugcrowd
        if self.config.get('platforms', {}).get('bugcrowd', {}).get('enabled'):
            tasks.append(self._discover_bugcrowd())

        # Run all discoveries in parallel
        results = await asyncio.gather(*tasks, return_exceptions=True)

        for result in results:
            if isinstance(result, list):
                all_programs.extend(result)
            elif isinstance(result, Exception):
                logger.error(f"Discovery error: {result}")

        self.programs = all_programs
        logger.info(f"Discovered {len(all_programs)} Red Hat bug bounty programs")

        return all_programs

    async def _discover_hackerone(self) -> List[BugBountyProgram]:
        """Discover HackerOne programs."""
        h1_config = self.config.get('platforms', {}).get('hackerone', {})

        async with HackerOneDiscovery(
            api_token=h1_config.get('api_token'),
            username=h1_config.get('username')
        ) as discovery:
            return await discovery.find_red_hat_programs()

    async def _discover_bugcrowd(self) -> List[BugBountyProgram]:
        """Discover Bugcrowd programs."""
        bc_config = self.config.get('platforms', {}).get('bugcrowd', {})

        async with BugcrowdDiscovery(
            api_token=bc_config.get('api_token')
        ) as discovery:
            return await discovery.find_red_hat_programs()

    def get_in_scope_targets(self) -> List[str]:
        """Get all in-scope targets from discovered programs."""
        targets = []
        for program in self.programs:
            targets.extend(program.scope)
        return list(set(targets))  # Remove duplicates

    def get_program_rules(self) -> Dict[str, str]:
        """Get rules for all programs."""
        return {program.name: program.rules for program in self.programs}
