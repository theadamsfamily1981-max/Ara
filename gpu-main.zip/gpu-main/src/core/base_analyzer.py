"""
Base Analyzer Class with Connection Pooling and Best Practices

This base class provides:
- Connection pooling for efficient resource usage
- Rate limiting to avoid IP bans
- Configurable SSL verification
- Standardized error handling
- Metrics collection
- Async context manager support

All intelligence analyzers should inherit from this class.
"""

import asyncio
import time
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field
from datetime import datetime
import aiohttp
from aiohttp import ClientSession, TCPConnector, ClientTimeout
import logging
from contextlib import asynccontextmanager

from .config import AnalyzerConfig
from .rate_limiter import RateLimiter
from .cache_manager import CacheManager


@dataclass
class RequestMetrics:
    """Metrics for monitoring request performance"""
    analyzer_name: str
    endpoint: str
    method: str
    status_code: int
    duration_ms: float
    timestamp: datetime
    cached: bool = False
    rate_limited: bool = False
    error: Optional[str] = None


@dataclass
class AnalyzerStats:
    """Statistics for an analyzer instance"""
    total_requests: int = 0
    successful_requests: int = 0
    failed_requests: int = 0
    cached_requests: int = 0
    rate_limited_requests: int = 0
    total_duration_ms: float = 0.0
    errors: List[str] = field(default_factory=list)

    @property
    def success_rate(self) -> float:
        """Calculate success rate"""
        if self.total_requests == 0:
            return 0.0
        return (self.successful_requests / self.total_requests) * 100

    @property
    def average_duration_ms(self) -> float:
        """Calculate average request duration"""
        if self.successful_requests == 0:
            return 0.0
        return self.total_duration_ms / self.successful_requests

    @property
    def cache_hit_rate(self) -> float:
        """Calculate cache hit rate"""
        if self.total_requests == 0:
            return 0.0
        return (self.cached_requests / self.total_requests) * 100


class BaseAnalyzer:
    """
    Base class for all intelligence analyzers

    Features:
    - Connection pooling with configurable limits
    - Rate limiting to prevent IP bans
    - SSL verification control
    - Request/response caching
    - Automatic retries with exponential backoff
    - Comprehensive metrics collection
    - Async context manager for proper cleanup

    Usage:
        async with MyAnalyzer(config) as analyzer:
            results = await analyzer.analyze(target_url)
    """

    def __init__(
        self,
        name: str,
        config: Optional[AnalyzerConfig] = None,
        cache_manager: Optional[CacheManager] = None
    ):
        """
        Initialize base analyzer

        Args:
            name: Analyzer name for logging and metrics
            config: Configuration object (uses default if None)
            cache_manager: Cache manager instance (creates new if None)
        """
        self.name = name
        self.config = config or AnalyzerConfig()
        self.cache_manager = cache_manager

        # Connection pooling
        self.session: Optional[ClientSession] = None
        self._session_lock = asyncio.Lock()

        # Rate limiting
        self.rate_limiter = RateLimiter(
            max_requests=self.config.rate_limit_requests,
            time_window=self.config.rate_limit_window_seconds
        )

        # Metrics
        self.stats = AnalyzerStats()
        self.metrics: List[RequestMetrics] = []

        # Logging
        self.logger = logging.getLogger(f"analyzer.{name}")
        self.logger.setLevel(logging.INFO)

    async def __aenter__(self):
        """Async context manager entry"""
        await self._ensure_session()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit with cleanup"""
        await self.close()

    async def _ensure_session(self):
        """Ensure session is created (thread-safe)"""
        if self.session is None:
            async with self._session_lock:
                if self.session is None:
                    # Create connector with connection pooling
                    connector = TCPConnector(
                        limit=self.config.max_concurrent_connections,
                        limit_per_host=self.config.max_connections_per_host,
                        ttl_dns_cache=self.config.dns_cache_ttl_seconds,
                        ssl=self.config.ssl_verify
                    )

                    # Create timeout configuration
                    timeout = ClientTimeout(
                        total=self.config.request_timeout_seconds,
                        connect=self.config.connect_timeout_seconds,
                        sock_read=self.config.read_timeout_seconds
                    )

                    # Create session with pooling
                    self.session = ClientSession(
                        connector=connector,
                        timeout=timeout,
                        headers=self._get_default_headers()
                    )

                    self.logger.info(
                        f"Session created for {self.name}: "
                        f"pool_size={self.config.max_concurrent_connections}, "
                        f"ssl_verify={self.config.ssl_verify}"
                    )

    def _get_default_headers(self) -> Dict[str, str]:
        """Get default headers for requests"""
        return {
            'User-Agent': self.config.user_agent,
            'Accept': 'application/json, text/html, */*',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive'
        }

    async def request(
        self,
        method: str,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        data: Optional[Any] = None,
        json: Optional[Dict] = None,
        params: Optional[Dict] = None,
        allow_redirects: bool = True,
        use_cache: bool = True,
        cache_ttl: int = 300,
        retry_count: int = 3
    ) -> Dict[str, Any]:
        """
        Make HTTP request with connection pooling, caching, and rate limiting

        Args:
            method: HTTP method (GET, POST, etc.)
            url: Target URL
            headers: Additional headers
            data: Request body (form data)
            json: Request body (JSON)
            params: URL parameters
            allow_redirects: Follow redirects
            use_cache: Use caching for GET requests
            cache_ttl: Cache time-to-live in seconds
            retry_count: Number of retries on failure

        Returns:
            Dict with response data:
                - status: HTTP status code
                - headers: Response headers
                - body: Response body (text)
                - json: Parsed JSON (if applicable)
                - cached: Whether response was cached
                - duration_ms: Request duration
        """
        await self._ensure_session()

        # Check cache for GET requests
        if use_cache and method.upper() == 'GET' and self.cache_manager:
            cache_key = self.cache_manager.make_cache_key(url, params)
            cached_response = await self.cache_manager.get(cache_key)

            if cached_response:
                self.stats.cached_requests += 1
                self.stats.total_requests += 1

                self.logger.debug(f"Cache hit for {url}")

                return {
                    **cached_response,
                    'cached': True
                }

        # Rate limiting
        await self.rate_limiter.acquire()

        # Merge headers
        request_headers = self._get_default_headers()
        if headers:
            request_headers.update(headers)

        # Retry logic with exponential backoff
        last_error = None
        for attempt in range(retry_count):
            start_time = time.time()

            try:
                async with self.session.request(
                    method=method,
                    url=url,
                    headers=request_headers,
                    data=data,
                    json=json,
                    params=params,
                    allow_redirects=allow_redirects,
                    ssl=self.config.ssl_verify
                ) as response:
                    # Read response
                    body = await response.text()
                    duration_ms = (time.time() - start_time) * 1000

                    # Try to parse JSON
                    response_json = None
                    if 'application/json' in response.headers.get('Content-Type', ''):
                        try:
                            response_json = await response.json()
                        except Exception:
                            pass

                    # Build response dict
                    result = {
                        'status': response.status,
                        'headers': dict(response.headers),
                        'body': body,
                        'json': response_json,
                        'cached': False,
                        'duration_ms': duration_ms,
                        'url': str(response.url)
                    }

                    # Update statistics
                    self.stats.total_requests += 1
                    self.stats.total_duration_ms += duration_ms

                    if 200 <= response.status < 300:
                        self.stats.successful_requests += 1
                    else:
                        self.stats.failed_requests += 1

                    # Record metrics
                    metric = RequestMetrics(
                        analyzer_name=self.name,
                        endpoint=url,
                        method=method,
                        status_code=response.status,
                        duration_ms=duration_ms,
                        timestamp=datetime.now(),
                        cached=False
                    )
                    self.metrics.append(metric)

                    # Cache successful GET requests
                    if (use_cache and method.upper() == 'GET' and
                        200 <= response.status < 300 and self.cache_manager):
                        cache_key = self.cache_manager.make_cache_key(url, params)
                        await self.cache_manager.set(cache_key, result, ttl=cache_ttl)

                    self.logger.debug(
                        f"{method} {url} - {response.status} - {duration_ms:.2f}ms"
                    )

                    return result

            except asyncio.TimeoutError as e:
                last_error = f"Timeout after {self.config.request_timeout_seconds}s"
                self.logger.warning(f"Attempt {attempt + 1}/{retry_count}: {last_error}")

            except aiohttp.ClientError as e:
                last_error = f"Client error: {str(e)}"
                self.logger.warning(f"Attempt {attempt + 1}/{retry_count}: {last_error}")

            except Exception as e:
                last_error = f"Unexpected error: {str(e)}"
                self.logger.error(f"Attempt {attempt + 1}/{retry_count}: {last_error}")

            # Exponential backoff before retry
            if attempt < retry_count - 1:
                backoff_time = min(2 ** attempt, 10)  # Max 10 seconds
                await asyncio.sleep(backoff_time)

        # All retries failed
        self.stats.total_requests += 1
        self.stats.failed_requests += 1
        self.stats.errors.append(last_error)

        self.logger.error(f"All retries failed for {method} {url}: {last_error}")

        raise Exception(f"Request failed after {retry_count} attempts: {last_error}")

    async def close(self):
        """Close session and cleanup resources"""
        if self.session:
            await self.session.close()
            self.session = None
            self.logger.info(f"Session closed for {self.name}")

    def get_stats(self) -> Dict[str, Any]:
        """Get analyzer statistics"""
        return {
            'analyzer': self.name,
            'total_requests': self.stats.total_requests,
            'successful_requests': self.stats.successful_requests,
            'failed_requests': self.stats.failed_requests,
            'cached_requests': self.stats.cached_requests,
            'success_rate': f"{self.stats.success_rate:.2f}%",
            'cache_hit_rate': f"{self.stats.cache_hit_rate:.2f}%",
            'average_duration_ms': f"{self.stats.average_duration_ms:.2f}",
            'errors': self.stats.errors[-10:]  # Last 10 errors
        }

    def get_metrics(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get recent metrics"""
        recent_metrics = self.metrics[-limit:]
        return [
            {
                'endpoint': m.endpoint,
                'method': m.method,
                'status': m.status_code,
                'duration_ms': m.duration_ms,
                'timestamp': m.timestamp.isoformat(),
                'cached': m.cached
            }
            for m in recent_metrics
        ]


class AnalyzerPool:
    """
    Pool of analyzer instances for parallel execution

    Manages multiple analyzer instances with:
    - Shared connection pool
    - Shared cache
    - Aggregated metrics
    - Load balancing
    """

    def __init__(
        self,
        analyzer_class: type,
        pool_size: int = 5,
        config: Optional[AnalyzerConfig] = None,
        cache_manager: Optional[CacheManager] = None
    ):
        """
        Initialize analyzer pool

        Args:
            analyzer_class: Analyzer class to instantiate
            pool_size: Number of analyzer instances
            config: Shared configuration
            cache_manager: Shared cache manager
        """
        self.analyzer_class = analyzer_class
        self.pool_size = pool_size
        self.config = config or AnalyzerConfig()
        self.cache_manager = cache_manager

        self.analyzers: List[BaseAnalyzer] = []
        self.current_index = 0
        self.lock = asyncio.Lock()

    async def __aenter__(self):
        """Initialize pool"""
        for i in range(self.pool_size):
            analyzer = self.analyzer_class(
                config=self.config,
                cache_manager=self.cache_manager
            )
            await analyzer.__aenter__()
            self.analyzers.append(analyzer)
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Cleanup pool"""
        for analyzer in self.analyzers:
            await analyzer.close()
        self.analyzers.clear()

    async def get_analyzer(self) -> BaseAnalyzer:
        """Get next analyzer (round-robin)"""
        async with self.lock:
            analyzer = self.analyzers[self.current_index]
            self.current_index = (self.current_index + 1) % self.pool_size
            return analyzer

    def get_aggregated_stats(self) -> Dict[str, Any]:
        """Get aggregated statistics from all analyzers"""
        total_requests = sum(a.stats.total_requests for a in self.analyzers)
        successful_requests = sum(a.stats.successful_requests for a in self.analyzers)
        failed_requests = sum(a.stats.failed_requests for a in self.analyzers)
        cached_requests = sum(a.stats.cached_requests for a in self.analyzers)
        total_duration = sum(a.stats.total_duration_ms for a in self.analyzers)

        return {
            'pool_size': self.pool_size,
            'total_requests': total_requests,
            'successful_requests': successful_requests,
            'failed_requests': failed_requests,
            'cached_requests': cached_requests,
            'success_rate': f"{(successful_requests / total_requests * 100):.2f}%" if total_requests > 0 else "0%",
            'cache_hit_rate': f"{(cached_requests / total_requests * 100):.2f}%" if total_requests > 0 else "0%",
            'average_duration_ms': f"{(total_duration / successful_requests):.2f}" if successful_requests > 0 else "0"
        }
