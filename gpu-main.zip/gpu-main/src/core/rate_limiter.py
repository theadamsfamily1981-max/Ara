"""
Rate Limiting System

Implements token bucket and sliding window algorithms to prevent:
- IP bans from target servers
- Overwhelming target systems
- Detection as automated scanner

Supports:
- Per-host rate limiting
- Global rate limiting
- Burst allowances
- Async/await patterns
"""

import asyncio
import time
from typing import Dict, Optional
from collections import deque
from dataclasses import dataclass
import logging


@dataclass
class RateLimitConfig:
    """Configuration for rate limiter"""
    max_requests: int
    time_window: int  # seconds
    burst_size: Optional[int] = None  # Allow bursts

    def __post_init__(self):
        if self.burst_size is None:
            self.burst_size = max(10, self.max_requests // 10)


class TokenBucketRateLimiter:
    """
    Token bucket algorithm for rate limiting

    Allows burst traffic up to bucket capacity while
    maintaining average rate over time.
    """

    def __init__(
        self,
        rate: float,  # tokens per second
        capacity: int,  # max tokens
        name: str = "default"
    ):
        """
        Initialize token bucket

        Args:
            rate: Tokens added per second
            capacity: Maximum tokens in bucket
            name: Limiter name for logging
        """
        self.rate = rate
        self.capacity = capacity
        self.name = name

        self.tokens = float(capacity)
        self.last_update = time.time()
        self.lock = asyncio.Lock()

        self.logger = logging.getLogger(f"rate_limiter.{name}")

    async def acquire(self, tokens: int = 1) -> bool:
        """
        Acquire tokens from bucket

        Args:
            tokens: Number of tokens to acquire

        Returns:
            True if tokens acquired, False if would exceed rate
        """
        async with self.lock:
            now = time.time()
            time_passed = now - self.last_update

            # Refill tokens based on time passed
            self.tokens = min(
                self.capacity,
                self.tokens + time_passed * self.rate
            )
            self.last_update = now

            # Check if enough tokens
            if self.tokens >= tokens:
                self.tokens -= tokens
                return True

            # Calculate wait time for next token
            wait_time = (tokens - self.tokens) / self.rate

            self.logger.debug(
                f"Rate limit reached, need to wait {wait_time:.2f}s"
            )

            return False

    async def wait_for_token(self, tokens: int = 1):
        """
        Wait until tokens are available

        Args:
            tokens: Number of tokens needed
        """
        while True:
            if await self.acquire(tokens):
                return

            # Calculate wait time
            async with self.lock:
                wait_time = (tokens - self.tokens) / self.rate
                wait_time = max(0.1, min(wait_time, 10.0))  # Clamp between 0.1-10s

            await asyncio.sleep(wait_time)


class SlidingWindowRateLimiter:
    """
    Sliding window algorithm for rate limiting

    Tracks exact timestamps of requests to enforce
    precise rate limits over rolling time windows.
    """

    def __init__(
        self,
        max_requests: int,
        time_window: int,  # seconds
        name: str = "default"
    ):
        """
        Initialize sliding window limiter

        Args:
            max_requests: Maximum requests in time window
            time_window: Time window in seconds
            name: Limiter name for logging
        """
        self.max_requests = max_requests
        self.time_window = time_window
        self.name = name

        self.requests: deque = deque()
        self.lock = asyncio.Lock()

        self.logger = logging.getLogger(f"rate_limiter.{name}")

    async def acquire(self) -> bool:
        """
        Check if request is allowed

        Returns:
            True if request allowed, False if would exceed rate
        """
        async with self.lock:
            now = time.time()

            # Remove old requests outside window
            while self.requests and self.requests[0] <= now - self.time_window:
                self.requests.popleft()

            # Check if under limit
            if len(self.requests) < self.max_requests:
                self.requests.append(now)
                return True

            return False

    async def wait_for_slot(self):
        """Wait until a slot is available"""
        while True:
            if await self.acquire():
                return

            async with self.lock:
                if self.requests:
                    # Calculate wait time until oldest request expires
                    oldest = self.requests[0]
                    wait_time = max(0.1, oldest + self.time_window - time.time())
                else:
                    wait_time = 0.1

            await asyncio.sleep(wait_time)

    def get_current_rate(self) -> float:
        """Get current requests per second"""
        if not self.requests:
            return 0.0

        now = time.time()
        recent = [r for r in self.requests if r > now - self.time_window]

        if not recent or len(recent) < 2:
            return 0.0

        time_span = recent[-1] - recent[0]
        if time_span == 0:
            return 0.0

        return len(recent) / time_span


class RateLimiter:
    """
    Comprehensive rate limiter with multiple strategies

    Features:
    - Global rate limiting
    - Per-host rate limiting
    - Burst allowances
    - Automatic backoff
    - Statistics tracking
    """

    def __init__(
        self,
        max_requests: int = 1000,
        time_window: int = 3600,  # 1 hour
        burst_size: Optional[int] = None,
        per_host_limit: Optional[int] = None
    ):
        """
        Initialize rate limiter

        Args:
            max_requests: Global max requests per time window
            time_window: Time window in seconds
            burst_size: Maximum burst size (None = auto)
            per_host_limit: Per-host request limit (None = no per-host limit)
        """
        self.config = RateLimitConfig(
            max_requests=max_requests,
            time_window=time_window,
            burst_size=burst_size
        )

        # Global limiter (token bucket for bursts)
        rate = max_requests / time_window
        self.global_limiter = TokenBucketRateLimiter(
            rate=rate,
            capacity=self.config.burst_size,
            name="global"
        )

        # Per-host limiters (sliding window for precision)
        self.per_host_limit = per_host_limit
        self.host_limiters: Dict[str, SlidingWindowRateLimiter] = {}
        self.host_lock = asyncio.Lock()

        # Statistics
        self.total_requests = 0
        self.blocked_requests = 0
        self.total_wait_time = 0.0

        self.logger = logging.getLogger("rate_limiter")

    async def _get_host_limiter(self, host: str) -> Optional[SlidingWindowRateLimiter]:
        """Get or create per-host limiter"""
        if not self.per_host_limit:
            return None

        async with self.host_lock:
            if host not in self.host_limiters:
                self.host_limiters[host] = SlidingWindowRateLimiter(
                    max_requests=self.per_host_limit,
                    time_window=self.config.time_window,
                    name=f"host_{host}"
                )

            return self.host_limiters[host]

    async def acquire(self, host: Optional[str] = None) -> None:
        """
        Acquire permission to make request

        Blocks until request is allowed by rate limiter.

        Args:
            host: Target host for per-host limiting
        """
        start_time = time.time()
        self.total_requests += 1

        # Wait for global rate limit
        await self.global_limiter.wait_for_token()

        # Wait for per-host rate limit
        if host:
            host_limiter = await self._get_host_limiter(host)
            if host_limiter:
                await host_limiter.wait_for_slot()

        wait_time = time.time() - start_time
        self.total_wait_time += wait_time

        if wait_time > 0.1:
            self.logger.debug(f"Rate limit wait: {wait_time:.2f}s")

    async def try_acquire(self, host: Optional[str] = None) -> bool:
        """
        Try to acquire without blocking

        Args:
            host: Target host for per-host limiting

        Returns:
            True if acquired, False if rate limited
        """
        self.total_requests += 1

        # Check global rate limit
        if not await self.global_limiter.acquire():
            self.blocked_requests += 1
            return False

        # Check per-host rate limit
        if host:
            host_limiter = await self._get_host_limiter(host)
            if host_limiter and not await host_limiter.acquire():
                self.blocked_requests += 1
                return False

        return True

    def get_stats(self) -> Dict[str, any]:
        """Get rate limiter statistics"""
        avg_wait_time = (
            self.total_wait_time / self.total_requests
            if self.total_requests > 0
            else 0.0
        )

        return {
            'total_requests': self.total_requests,
            'blocked_requests': self.blocked_requests,
            'block_rate': f"{(self.blocked_requests / max(self.total_requests, 1) * 100):.2f}%",
            'average_wait_time_ms': f"{avg_wait_time * 1000:.2f}",
            'max_requests_per_window': self.config.max_requests,
            'time_window_seconds': self.config.time_window,
            'burst_size': self.config.burst_size,
            'per_host_limit': self.per_host_limit,
            'active_hosts': len(self.host_limiters)
        }

    async def reset(self):
        """Reset all rate limiters"""
        self.host_limiters.clear()
        self.total_requests = 0
        self.blocked_requests = 0
        self.total_wait_time = 0.0

        # Reset global limiter
        self.global_limiter.tokens = float(self.global_limiter.capacity)
        self.global_limiter.last_update = time.time()

        self.logger.info("Rate limiters reset")


class AdaptiveRateLimiter(RateLimiter):
    """
    Adaptive rate limiter that adjusts based on server responses

    Features:
    - Automatic backoff on 429 (Too Many Requests)
    - Gradual rate increase when successful
    - Circuit breaker on repeated failures
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.success_count = 0
        self.failure_count = 0
        self.current_multiplier = 1.0
        self.min_multiplier = 0.1
        self.max_multiplier = 2.0

        self.circuit_breaker_threshold = 10
        self.circuit_breaker_active = False
        self.circuit_breaker_reset_time = None

    async def record_response(self, status_code: int):
        """
        Record response and adjust rate accordingly

        Args:
            status_code: HTTP status code
        """
        if status_code == 429:  # Too Many Requests
            self.failure_count += 1
            self.success_count = 0

            # Aggressive backoff
            self.current_multiplier *= 0.5
            self.current_multiplier = max(self.min_multiplier, self.current_multiplier)

            self.logger.warning(
                f"Rate limit detected (429), backing off to {self.current_multiplier:.2f}x"
            )

            # Activate circuit breaker if too many failures
            if self.failure_count >= self.circuit_breaker_threshold:
                self.circuit_breaker_active = True
                self.circuit_breaker_reset_time = time.time() + 300  # 5 minutes
                self.logger.error("Circuit breaker activated, pausing for 5 minutes")

        elif 200 <= status_code < 300:  # Success
            self.success_count += 1

            # Gradually increase rate after 10 consecutive successes
            if self.success_count >= 10:
                self.current_multiplier *= 1.1
                self.current_multiplier = min(self.max_multiplier, self.current_multiplier)
                self.success_count = 0

                self.logger.info(f"Rate increased to {self.current_multiplier:.2f}x")

    async def acquire(self, host: Optional[str] = None):
        """Acquire with circuit breaker check"""
        # Check circuit breaker
        if self.circuit_breaker_active:
            if time.time() < self.circuit_breaker_reset_time:
                wait_time = self.circuit_breaker_reset_time - time.time()
                self.logger.warning(f"Circuit breaker active, waiting {wait_time:.0f}s")
                await asyncio.sleep(wait_time)

            # Reset circuit breaker
            self.circuit_breaker_active = False
            self.failure_count = 0
            self.current_multiplier = 0.5  # Start at half speed
            self.logger.info("Circuit breaker reset")

        # Apply rate multiplier
        await super().acquire(host)

        # Additional delay based on multiplier
        if self.current_multiplier < 1.0:
            additional_delay = (1.0 - self.current_multiplier) * 2.0
            await asyncio.sleep(additional_delay)
