"""
Autonomous Orchestrator - Coordinates all 10 AI-powered analyzers

This module manages the autonomous operation of all analyzers:
- Initializes all analyzers with proper configuration
- Manages analyzer lifecycle (start, stop, restart)
- Coordinates analyzer execution based on findings
- Aggregates results from all analyzers
- Provides real-time status and metrics
- Handles analyzer failures and retries
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import json

from core.base_analyzer import BaseAnalyzer, AnalyzerPool
from core.config import AnalyzerConfig, get_config
from core.cache_manager import CacheManager, create_cache_manager
from core.rate_limiter import AdaptiveRateLimiter


class AnalyzerStatus(Enum):
    """Analyzer status"""
    IDLE = "idle"
    RUNNING = "running"
    PAUSED = "paused"
    ERROR = "error"
    COMPLETED = "completed"


@dataclass
class AnalyzerState:
    """State of an individual analyzer"""
    name: str
    status: AnalyzerStatus
    findings_count: int = 0
    last_run: Optional[datetime] = None
    last_error: Optional[str] = None
    total_runtime_seconds: float = 0.0
    total_requests: int = 0
    success_rate: float = 0.0


@dataclass
class Finding:
    """Unified finding structure"""
    analyzer: str
    severity: str  # critical, high, medium, low, info
    title: str
    description: str
    evidence: Dict[str, Any]
    remediation: str
    timestamp: datetime
    target_url: str
    confidence: float  # 0.0 - 1.0


class AutonomousOrchestrator:
    """
    Orchestrates all 10 AI-powered analyzers autonomously

    Features:
    - Automatic analyzer initialization
    - Parallel analyzer execution
    - Intelligent finding correlation
    - Real-time progress tracking
    - Automatic error recovery
    - Resource management
    """

    def __init__(self, config: Optional[AnalyzerConfig] = None):
        """
        Initialize orchestrator

        Args:
            config: Configuration (uses default if None)
        """
        self.config = config or get_config()
        self.cache_manager: Optional[CacheManager] = None
        self.rate_limiter = AdaptiveRateLimiter(
            max_requests=self.config.rate_limit_requests,
            time_window=self.config.rate_limit_window_seconds
        )

        # Analyzer states
        self.analyzer_states: Dict[str, AnalyzerState] = {}
        self.initialize_analyzer_states()

        # Results
        self.findings: List[Finding] = []
        self.total_findings_by_severity = {
            'critical': 0,
            'high': 0,
            'medium': 0,
            'low': 0,
            'info': 0
        }

        # Execution control
        self.running = False
        self.paused = False
        self.tasks: List[asyncio.Task] = []

        # Logging
        self.logger = logging.getLogger("orchestrator")
        self.logger.setLevel(logging.INFO)

    def initialize_analyzer_states(self):
        """Initialize states for all 10 analyzers"""
        analyzers = [
            "Deep Correlation Analyzer",
            "Business Logic Mapper",
            "Chain Discovery Engine",
            "Race Condition Detector",
            "Semantic Analyzer",
            "Transformation Tracker",
            "Permission Inferencer",
            "Temporal Detector",
            "Crypto Analyzer",
            "Pattern Learner"
        ]

        for analyzer in analyzers:
            self.analyzer_states[analyzer] = AnalyzerState(
                name=analyzer,
                status=AnalyzerStatus.IDLE
            )

    async def initialize(self):
        """Initialize orchestrator and all subsystems"""
        self.logger.info("Initializing Autonomous Orchestrator")

        # Initialize cache manager
        self.cache_manager = await create_cache_manager(self.config)

        self.logger.info(
            f"Orchestrator initialized: "
            f"cache={'enabled' if self.config.cache_enabled else 'disabled'}, "
            f"redis={'enabled' if self.config.redis_enabled else 'disabled'}"
        )

    async def shutdown(self):
        """Shutdown orchestrator gracefully"""
        self.logger.info("Shutting down orchestrator")

        # Stop all running tasks
        self.running = False
        for task in self.tasks:
            task.cancel()

        # Wait for tasks to complete
        if self.tasks:
            await asyncio.gather(*self.tasks, return_exceptions=True)

        # Disconnect cache
        if self.cache_manager:
            await self.cache_manager.disconnect()

        self.logger.info("Orchestrator shutdown complete")

    async def run_analyzer(
        self,
        analyzer_name: str,
        analyzer_module,
        target_url: str,
        **kwargs
    ) -> List[Finding]:
        """
        Run a single analyzer

        Args:
            analyzer_name: Name of the analyzer
            analyzer_module: Analyzer module/class
            target_url: Target URL to analyze
            **kwargs: Additional arguments for analyzer

        Returns:
            List of findings from the analyzer
        """
        state = self.analyzer_states[analyzer_name]
        state.status = AnalyzerStatus.RUNNING
        state.last_run = datetime.now()

        start_time = asyncio.get_event_loop().time()
        findings = []

        try:
            self.logger.info(f"Starting {analyzer_name} on {target_url}")

            # Create analyzer instance with our config and cache
            analyzer = analyzer_module(
                config=self.config,
                cache_manager=self.cache_manager
            )

            # Run analyzer
            if hasattr(analyzer, '__aenter__'):
                async with analyzer:
                    results = await analyzer.analyze(target_url, **kwargs)
            else:
                results = await analyzer.analyze(target_url, **kwargs)

            # Convert results to findings
            findings = self._convert_to_findings(analyzer_name, target_url, results)

            # Update state
            state.findings_count += len(findings)
            state.status = AnalyzerStatus.COMPLETED

            # Update statistics if analyzer extends BaseAnalyzer
            if isinstance(analyzer, BaseAnalyzer):
                stats = analyzer.get_stats()
                state.total_requests += stats['total_requests']
                success_rate = float(stats['success_rate'].rstrip('%'))
                state.success_rate = success_rate

            self.logger.info(
                f"{analyzer_name} completed: {len(findings)} findings"
            )

        except Exception as e:
            state.status = AnalyzerStatus.ERROR
            state.last_error = str(e)
            self.logger.error(f"{analyzer_name} failed: {e}", exc_info=True)

        finally:
            elapsed = asyncio.get_event_loop().time() - start_time
            state.total_runtime_seconds += elapsed

        return findings

    def _convert_to_findings(
        self,
        analyzer_name: str,
        target_url: str,
        results: Any
    ) -> List[Finding]:
        """
        Convert analyzer-specific results to unified Finding format

        Args:
            analyzer_name: Name of analyzer
            target_url: Target URL
            results: Analyzer-specific results

        Returns:
            List of Finding objects
        """
        findings = []

        # Handle different result formats
        if isinstance(results, list):
            for result in results:
                finding = self._parse_result_to_finding(
                    analyzer_name, target_url, result
                )
                if finding:
                    findings.append(finding)
                    self.total_findings_by_severity[finding.severity] += 1

        elif isinstance(results, dict):
            # Single finding
            finding = self._parse_result_to_finding(
                analyzer_name, target_url, results
            )
            if finding:
                findings.append(finding)
                self.total_findings_by_severity[finding.severity] += 1

        return findings

    def _parse_result_to_finding(
        self,
        analyzer_name: str,
        target_url: str,
        result: Dict[str, Any]
    ) -> Optional[Finding]:
        """Parse a single result into a Finding"""
        try:
            return Finding(
                analyzer=analyzer_name,
                severity=result.get('severity', 'info'),
                title=result.get('title', 'Untitled Finding'),
                description=result.get('description', ''),
                evidence=result.get('evidence', {}),
                remediation=result.get('remediation', 'No remediation provided'),
                timestamp=datetime.now(),
                target_url=target_url,
                confidence=result.get('confidence', 0.8)
            )
        except Exception as e:
            self.logger.error(f"Failed to parse result: {e}")
            return None

    async def run_all_analyzers(
        self,
        target_url: str,
        parallel: bool = True
    ) -> List[Finding]:
        """
        Run all enabled analyzers on target

        Args:
            target_url: Target URL to analyze
            parallel: Run analyzers in parallel if True

        Returns:
            Combined findings from all analyzers
        """
        self.logger.info(f"Starting all analyzers on {target_url}")
        self.running = True

        # Import analyzer modules
        analyzer_modules = self._get_analyzer_modules()

        if parallel:
            # Run all analyzers in parallel
            tasks = []
            for name, module in analyzer_modules.items():
                if self._is_analyzer_enabled(name):
                    task = self.run_analyzer(name, module, target_url)
                    tasks.append(task)

            results = await asyncio.gather(*tasks, return_exceptions=True)

            # Flatten results
            all_findings = []
            for result in results:
                if isinstance(result, list):
                    all_findings.extend(result)
                elif isinstance(result, Exception):
                    self.logger.error(f"Analyzer failed: {result}")

        else:
            # Run analyzers sequentially
            all_findings = []
            for name, module in analyzer_modules.items():
                if self._is_analyzer_enabled(name):
                    if not self.running or self.paused:
                        break

                    findings = await self.run_analyzer(name, module, target_url)
                    all_findings.extend(findings)

        self.findings.extend(all_findings)
        self.running = False

        self.logger.info(
            f"All analyzers completed: {len(all_findings)} total findings"
        )

        return all_findings

    def _get_analyzer_modules(self) -> Dict[str, Any]:
        """Get all analyzer modules"""
        # In a real implementation, these would be actual imports
        # For now, return a dict structure that can be filled in
        return {
            "Deep Correlation Analyzer": None,  # Will be populated with actual module
            "Business Logic Mapper": None,
            "Chain Discovery Engine": None,
            "Race Condition Detector": None,
            "Semantic Analyzer": None,
            "Transformation Tracker": None,
            "Permission Inferencer": None,
            "Temporal Detector": None,
            "Crypto Analyzer": None,
            "Pattern Learner": None,
        }

    def _is_analyzer_enabled(self, analyzer_name: str) -> bool:
        """Check if analyzer is enabled in config"""
        # Map analyzer names to config flags
        enabled_flags = {
            "Deep Correlation Analyzer": self.config.enable_deep_correlation,
            "Business Logic Mapper": self.config.enable_business_logic_mapping,
            "Chain Discovery Engine": self.config.enable_chain_discovery,
            "Race Condition Detector": self.config.enable_race_detection,
            "Semantic Analyzer": self.config.enable_semantic_analysis,
            "Transformation Tracker": self.config.enable_transformation_tracking,
            "Permission Inferencer": self.config.enable_permission_inference,
            "Temporal Detector": self.config.enable_temporal_detection,
            "Crypto Analyzer": self.config.enable_crypto_analysis,
            "Pattern Learner": self.config.enable_pattern_learning,
        }

        return enabled_flags.get(analyzer_name, True)

    def pause(self):
        """Pause execution"""
        self.paused = True
        self.logger.info("Orchestrator paused")

    def resume(self):
        """Resume execution"""
        self.paused = False
        self.logger.info("Orchestrator resumed")

    def get_status(self) -> Dict[str, Any]:
        """Get orchestrator status"""
        return {
            'running': self.running,
            'paused': self.paused,
            'analyzers': {
                name: {
                    'status': state.status.value,
                    'findings': state.findings_count,
                    'last_run': state.last_run.isoformat() if state.last_run else None,
                    'last_error': state.last_error,
                    'runtime_seconds': state.total_runtime_seconds,
                    'total_requests': state.total_requests,
                    'success_rate': f"{state.success_rate:.2f}%"
                }
                for name, state in self.analyzer_states.items()
            },
            'findings_summary': {
                'total': len(self.findings),
                'by_severity': self.total_findings_by_severity,
                'critical': self.total_findings_by_severity['critical'],
                'high': self.total_findings_by_severity['high'],
                'medium': self.total_findings_by_severity['medium'],
                'low': self.total_findings_by_severity['low'],
                'info': self.total_findings_by_severity['info']
            },
            'rate_limiter': self.rate_limiter.get_stats() if self.rate_limiter else {},
            'cache': self.cache_manager.get_stats() if self.cache_manager else {}
        }

    def get_findings(
        self,
        severity: Optional[str] = None,
        analyzer: Optional[str] = None,
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """
        Get findings with optional filtering

        Args:
            severity: Filter by severity
            analyzer: Filter by analyzer name
            limit: Maximum findings to return

        Returns:
            List of findings as dictionaries
        """
        filtered = self.findings

        if severity:
            filtered = [f for f in filtered if f.severity == severity]

        if analyzer:
            filtered = [f for f in filtered if f.analyzer == analyzer]

        # Sort by severity and timestamp
        severity_order = {'critical': 0, 'high': 1, 'medium': 2, 'low': 3, 'info': 4}
        filtered.sort(
            key=lambda f: (severity_order.get(f.severity, 5), -f.timestamp.timestamp())
        )

        # Limit results
        filtered = filtered[:limit]

        # Convert to dict
        return [
            {
                'analyzer': f.analyzer,
                'severity': f.severity,
                'title': f.title,
                'description': f.description,
                'evidence': f.evidence,
                'remediation': f.remediation,
                'timestamp': f.timestamp.isoformat(),
                'target_url': f.target_url,
                'confidence': f.confidence
            }
            for f in filtered
        ]

    def export_findings(self, format: str = 'json') -> str:
        """
        Export findings in various formats

        Args:
            format: Export format (json, csv, markdown)

        Returns:
            Formatted findings
        """
        findings_dict = self.get_findings(limit=10000)

        if format == 'json':
            return json.dumps(findings_dict, indent=2, default=str)

        elif format == 'csv':
            import csv
            import io

            output = io.StringIO()
            if findings_dict:
                writer = csv.DictWriter(
                    output,
                    fieldnames=['analyzer', 'severity', 'title', 'timestamp', 'target_url']
                )
                writer.writeheader()
                for finding in findings_dict:
                    writer.writerow({
                        'analyzer': finding['analyzer'],
                        'severity': finding['severity'],
                        'title': finding['title'],
                        'timestamp': finding['timestamp'],
                        'target_url': finding['target_url']
                    })

            return output.getvalue()

        elif format == 'markdown':
            md = "# Bug Bounty Findings\n\n"
            md += f"**Total Findings**: {len(findings_dict)}\n\n"

            for severity in ['critical', 'high', 'medium', 'low', 'info']:
                severity_findings = [f for f in findings_dict if f['severity'] == severity]
                if severity_findings:
                    md += f"## {severity.upper()} ({len(severity_findings)})\n\n"
                    for finding in severity_findings:
                        md += f"### {finding['title']}\n"
                        md += f"- **Analyzer**: {finding['analyzer']}\n"
                        md += f"- **Target**: {finding['target_url']}\n"
                        md += f"- **Confidence**: {finding['confidence']:.0%}\n"
                        md += f"- **Description**: {finding['description']}\n"
                        md += f"- **Remediation**: {finding['remediation']}\n\n"

            return md

        else:
            raise ValueError(f"Unsupported format: {format}")


async def create_orchestrator(config: Optional[AnalyzerConfig] = None) -> AutonomousOrchestrator:
    """
    Factory function to create and initialize orchestrator

    Args:
        config: Configuration (uses default if None)

    Returns:
        Initialized orchestrator
    """
    orchestrator = AutonomousOrchestrator(config)
    await orchestrator.initialize()
    return orchestrator
