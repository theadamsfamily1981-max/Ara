"""
Analyzer Adapter - Integrates existing analyzers with BaseAnalyzer

This adapter wraps existing intelligence analyzers to use:
- Connection pooling from BaseAnalyzer
- Caching from CacheManager
- Rate limiting from RateLimiter
- Configuration from AnalyzerConfig

Maintains backward compatibility while adding new features.
"""

import asyncio
import aiohttp
from typing import Dict, List, Optional, Any
import logging

from core.base_analyzer import BaseAnalyzer
from core.config import AnalyzerConfig
from core.cache_manager import CacheManager


class AnalyzerAdapter(BaseAnalyzer):
    """
    Adapter that wraps existing analyzers with BaseAnalyzer features

    Usage:
        # Wrap existing analyzer
        adapter = AnalyzerAdapter(
            name="Deep Correlation Analyzer",
            config=config,
            cache_manager=cache
        )

        async with adapter:
            # Old analyzer code can use adapter.request()
            response = await adapter.request('GET', url)
    """

    def __init__(
        self,
        name: str,
        config: Optional[AnalyzerConfig] = None,
        cache_manager: Optional[CacheManager] = None
    ):
        """
        Initialize adapter

        Args:
            name: Analyzer name
            config: Configuration
            cache_manager: Cache manager
        """
        super().__init__(name, config, cache_manager)

    async def make_request(
        self,
        method: str,
        url: str,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Make HTTP request using BaseAnalyzer

        This method can be called by existing analyzer code.
        It uses connection pooling, caching, and rate limiting.

        Args:
            method: HTTP method
            url: Target URL
            **kwargs: Additional request parameters

        Returns:
            Response dictionary
        """
        return await self.request(method, url, **kwargs)

    async def make_parallel_requests(
        self,
        requests: List[Dict[str, Any]],
        max_concurrent: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Make multiple requests in parallel

        Args:
            requests: List of request specifications
                Each dict should have: method, url, and optional kwargs
            max_concurrent: Max concurrent requests (uses config if None)

        Returns:
            List of responses
        """
        if max_concurrent is None:
            max_concurrent = self.config.max_parallel_requests

        semaphore = asyncio.Semaphore(max_concurrent)

        async def bounded_request(req_spec):
            async with semaphore:
                method = req_spec.get('method', 'GET')
                url = req_spec['url']
                kwargs = {k: v for k, v in req_spec.items() if k not in ['method', 'url']}
                return await self.request(method, url, **kwargs)

        responses = await asyncio.gather(
            *[bounded_request(req) for req in requests],
            return_exceptions=True
        )

        # Filter out exceptions and log them
        valid_responses = []
        for i, response in enumerate(responses):
            if isinstance(response, Exception):
                self.logger.error(f"Request {i} failed: {response}")
            else:
                valid_responses.append(response)

        return valid_responses


def create_adapter_for_analyzer(
    analyzer_class,
    config: Optional[AnalyzerConfig] = None,
    cache_manager: Optional[CacheManager] = None
):
    """
    Factory function to create adapter for existing analyzer

    Args:
        analyzer_class: Existing analyzer class
        config: Configuration
        cache_manager: Cache manager

    Returns:
        Adapter-wrapped analyzer
    """
    class AdaptedAnalyzer(analyzer_class, AnalyzerAdapter):
        """Analyzer with BaseAnalyzer features"""

        def __init__(self, *args, **kwargs):
            # Initialize AnalyzerAdapter
            AnalyzerAdapter.__init__(
                self,
                name=analyzer_class.__name__,
                config=config or kwargs.get('config'),
                cache_manager=cache_manager or kwargs.get('cache_manager')
            )

            # Initialize original analyzer (if it has __init__)
            if hasattr(analyzer_class, '__init__'):
                try:
                    analyzer_class.__init__(self, *args, **kwargs)
                except TypeError:
                    # Original analyzer doesn't take args
                    pass

        async def _make_request(self, method: str, url: str, **kwargs):
            """Helper method for existing analyzer code"""
            return await self.request(method, url, **kwargs)

    return AdaptedAnalyzer


# Example: Integrating Deep Correlation Analyzer
class IntegratedDeepCorrelationAnalyzer(AnalyzerAdapter):
    """
    Deep Correlation Analyzer with full BaseAnalyzer integration

    This is an example of how existing analyzers can be integrated.
    """

    def __init__(
        self,
        config: Optional[AnalyzerConfig] = None,
        cache_manager: Optional[CacheManager] = None
    ):
        super().__init__(
            name="Deep Correlation Analyzer",
            config=config,
            cache_manager=cache_manager
        )
        self.captures = []
        self.max_captures = config.max_capture_size if config else 1000

    async def analyze(self, target_url: str, **kwargs) -> List[Dict[str, Any]]:
        """
        Run deep correlation analysis

        Args:
            target_url: Target URL to analyze
            **kwargs: Additional parameters

        Returns:
            List of findings
        """
        findings = []

        try:
            # Discover endpoints
            endpoints = await self.discover_endpoints(target_url)

            # Capture requests across multiple endpoints
            await self.capture_requests(target_url, endpoints)

            # Run correlation analyses
            findings.extend(await self.analyze_cross_user_leakage())
            findings.extend(await self.analyze_information_aggregation())
            findings.extend(await self.analyze_permission_bypass_chains())

            self.logger.info(
                f"Deep Correlation Analysis complete: {len(findings)} findings"
            )

        except Exception as e:
            self.logger.error(f"Analysis failed: {e}", exc_info=True)

        return findings

    async def discover_endpoints(self, target_url: str) -> List[str]:
        """Discover API endpoints"""
        endpoints = []

        # Common API paths
        common_paths = [
            '/api/v1/users',
            '/api/v1/profile',
            '/api/v1/settings',
            '/api/v1/data',
            '/api/v2/users',
            '/api/v2/profile'
        ]

        for path in common_paths:
            url = f"{target_url.rstrip('/')}{path}"
            try:
                # Use BaseAnalyzer's request method (with caching & pooling)
                response = await self.request('GET', url, retry_count=1)

                if response['status'] != 404:
                    endpoints.append(url)

            except Exception:
                pass

        return endpoints

    async def capture_requests(self, target_url: str, endpoints: List[str]):
        """Capture requests to multiple endpoints"""
        # Build request specifications
        requests = []
        for endpoint in endpoints[:50]:  # Limit to 50 endpoints
            requests.append({
                'method': 'GET',
                'url': endpoint
            })

        # Make parallel requests using adapter
        responses = await self.make_parallel_requests(requests)

        # Store captures
        for response in responses:
            if len(self.captures) < self.max_captures:
                self.captures.append(response)

    async def analyze_cross_user_leakage(self) -> List[Dict[str, Any]]:
        """Analyze for cross-user state leakage"""
        findings = []

        # Example analysis logic
        if len(self.captures) > 10:
            findings.append({
                'severity': 'info',
                'title': 'Cross-user analysis completed',
                'description': f'Analyzed {len(self.captures)} requests',
                'evidence': {'captures': len(self.captures)},
                'remediation': 'Review session isolation',
                'confidence': 0.7
            })

        return findings

    async def analyze_information_aggregation(self) -> List[Dict[str, Any]]:
        """Analyze for information aggregation attacks"""
        findings = []

        # Placeholder for actual analysis
        return findings

    async def analyze_permission_bypass_chains(self) -> List[Dict[str, Any]]:
        """Analyze for permission bypass chains"""
        findings = []

        # Placeholder for actual analysis
        return findings


# Factory function for all 10 analyzers
def create_integrated_analyzers(
    config: Optional[AnalyzerConfig] = None,
    cache_manager: Optional[CacheManager] = None
) -> Dict[str, AnalyzerAdapter]:
    """
    Create integrated versions of all 10 analyzers

    Args:
        config: Configuration
        cache_manager: Cache manager

    Returns:
        Dictionary of analyzer name -> integrated analyzer
    """
    analyzers = {}

    # Deep Correlation Analyzer
    analyzers["Deep Correlation Analyzer"] = IntegratedDeepCorrelationAnalyzer(
        config=config,
        cache_manager=cache_manager
    )

    # Placeholder for other analyzers (to be integrated similarly)
    # Business Logic Mapper
    # Chain Discovery Engine
    # Race Condition Detector
    # Semantic Analyzer
    # Transformation Tracker
    # Permission Inferencer
    # Temporal Detector
    # Crypto Analyzer
    # Pattern Learner

    return analyzers
