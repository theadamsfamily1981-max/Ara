"""
Caching System with Redis Support

Provides multi-tier caching:
- In-memory LRU cache for hot data
- Redis for distributed caching
- Configurable TTLs
- Cache invalidation strategies
"""

import asyncio
import hashlib
import json
import time
from typing import Optional, Any, Dict
from collections import OrderedDict
from dataclasses import dataclass
import logging

try:
    import redis.asyncio as redis
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False
    logging.warning("Redis not available, using in-memory cache only")


@dataclass
class CacheEntry:
    """Cache entry with metadata"""
    key: str
    value: Any
    timestamp: float
    ttl: int
    hits: int = 0

    def is_expired(self) -> bool:
        """Check if entry is expired"""
        if self.ttl <= 0:
            return False
        return time.time() > self.timestamp + self.ttl


class LRUCache:
    """
    Thread-safe LRU cache with TTL support

    Features:
    - Least Recently Used eviction
    - Per-entry TTL
    - Size limits
    - Hit rate tracking
    """

    def __init__(self, max_size: int = 1000):
        """
        Initialize LRU cache

        Args:
            max_size: Maximum number of entries
        """
        self.max_size = max_size
        self.cache: OrderedDict[str, CacheEntry] = OrderedDict()
        self.lock = asyncio.Lock()

        self.hits = 0
        self.misses = 0
        self.evictions = 0

        self.logger = logging.getLogger("cache.lru")

    async def get(self, key: str) -> Optional[Any]:
        """
        Get value from cache

        Args:
            key: Cache key

        Returns:
            Cached value or None if not found/expired
        """
        async with self.lock:
            if key not in self.cache:
                self.misses += 1
                return None

            entry = self.cache[key]

            # Check expiration
            if entry.is_expired():
                del self.cache[key]
                self.misses += 1
                return None

            # Update access order (LRU)
            self.cache.move_to_end(key)
            entry.hits += 1
            self.hits += 1

            return entry.value

    async def set(self, key: str, value: Any, ttl: int = 300):
        """
        Set value in cache

        Args:
            key: Cache key
            value: Value to cache
            ttl: Time to live in seconds (0 = no expiration)
        """
        async with self.lock:
            # Create entry
            entry = CacheEntry(
                key=key,
                value=value,
                timestamp=time.time(),
                ttl=ttl
            )

            # Add to cache
            self.cache[key] = entry
            self.cache.move_to_end(key)

            # Evict if over size limit
            while len(self.cache) > self.max_size:
                oldest_key = next(iter(self.cache))
                del self.cache[oldest_key]
                self.evictions += 1

    async def delete(self, key: str):
        """Delete key from cache"""
        async with self.lock:
            if key in self.cache:
                del self.cache[key]

    async def clear(self):
        """Clear all cache entries"""
        async with self.lock:
            self.cache.clear()
            self.logger.info("Cache cleared")

    async def cleanup_expired(self):
        """Remove expired entries"""
        async with self.lock:
            expired_keys = [
                key for key, entry in self.cache.items()
                if entry.is_expired()
            ]

            for key in expired_keys:
                del self.cache[key]

            if expired_keys:
                self.logger.debug(f"Cleaned up {len(expired_keys)} expired entries")

    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        total_requests = self.hits + self.misses
        hit_rate = (self.hits / total_requests * 100) if total_requests > 0 else 0

        return {
            'size': len(self.cache),
            'max_size': self.max_size,
            'hits': self.hits,
            'misses': self.misses,
            'hit_rate': f"{hit_rate:.2f}%",
            'evictions': self.evictions
        }


class RedisCache:
    """
    Redis-based distributed cache

    Features:
    - Distributed caching across instances
    - Automatic serialization
    - Connection pooling
    - Retry logic
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 6379,
        db: int = 0,
        password: Optional[str] = None,
        ssl: bool = False,
        prefix: str = "bounty:"
    ):
        """
        Initialize Redis cache

        Args:
            host: Redis host
            port: Redis port
            db: Redis database number
            password: Redis password
            ssl: Use SSL connection
            prefix: Key prefix for namespacing
        """
        if not REDIS_AVAILABLE:
            raise ImportError("redis package not installed")

        self.host = host
        self.port = port
        self.db = db
        self.password = password
        self.ssl = ssl
        self.prefix = prefix

        self.client: Optional[redis.Redis] = None
        self.connected = False

        self.hits = 0
        self.misses = 0

        self.logger = logging.getLogger("cache.redis")

    async def connect(self):
        """Connect to Redis"""
        if self.connected:
            return

        try:
            self.client = redis.Redis(
                host=self.host,
                port=self.port,
                db=self.db,
                password=self.password,
                ssl=self.ssl,
                decode_responses=False,
                socket_connect_timeout=5,
                socket_timeout=5
            )

            # Test connection
            await self.client.ping()
            self.connected = True

            self.logger.info(f"Connected to Redis at {self.host}:{self.port}")

        except Exception as e:
            self.logger.error(f"Failed to connect to Redis: {e}")
            self.connected = False
            raise

    async def disconnect(self):
        """Disconnect from Redis"""
        if self.client:
            await self.client.close()
            self.connected = False
            self.logger.info("Disconnected from Redis")

    def _make_key(self, key: str) -> str:
        """Add prefix to key"""
        return f"{self.prefix}{key}"

    async def get(self, key: str) -> Optional[Any]:
        """
        Get value from Redis

        Args:
            key: Cache key

        Returns:
            Cached value or None if not found
        """
        if not self.connected:
            return None

        try:
            redis_key = self._make_key(key)
            value = await self.client.get(redis_key)

            if value is None:
                self.misses += 1
                return None

            # Deserialize
            result = json.loads(value)
            self.hits += 1

            return result

        except Exception as e:
            self.logger.error(f"Redis get error for key {key}: {e}")
            return None

    async def set(self, key: str, value: Any, ttl: int = 300):
        """
        Set value in Redis

        Args:
            key: Cache key
            value: Value to cache
            ttl: Time to live in seconds
        """
        if not self.connected:
            return

        try:
            redis_key = self._make_key(key)

            # Serialize
            serialized = json.dumps(value)

            # Set with TTL
            if ttl > 0:
                await self.client.setex(redis_key, ttl, serialized)
            else:
                await self.client.set(redis_key, serialized)

        except Exception as e:
            self.logger.error(f"Redis set error for key {key}: {e}")

    async def delete(self, key: str):
        """Delete key from Redis"""
        if not self.connected:
            return

        try:
            redis_key = self._make_key(key)
            await self.client.delete(redis_key)

        except Exception as e:
            self.logger.error(f"Redis delete error for key {key}: {e}")

    async def clear(self, pattern: str = "*"):
        """
        Clear keys matching pattern

        Args:
            pattern: Key pattern (default: all keys with prefix)
        """
        if not self.connected:
            return

        try:
            redis_pattern = self._make_key(pattern)
            keys = await self.client.keys(redis_pattern)

            if keys:
                await self.client.delete(*keys)
                self.logger.info(f"Cleared {len(keys)} keys")

        except Exception as e:
            self.logger.error(f"Redis clear error: {e}")

    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        total_requests = self.hits + self.misses
        hit_rate = (self.hits / total_requests * 100) if total_requests > 0 else 0

        return {
            'connected': self.connected,
            'host': self.host,
            'port': self.port,
            'hits': self.hits,
            'misses': self.misses,
            'hit_rate': f"{hit_rate:.2f}%"
        }


class CacheManager:
    """
    Multi-tier cache manager

    Features:
    - L1: In-memory LRU cache (fast, per-instance)
    - L2: Redis cache (distributed, persistent)
    - Automatic failover
    - Cache warming
    - Invalidation strategies
    """

    def __init__(
        self,
        enable_memory_cache: bool = True,
        enable_redis_cache: bool = False,
        memory_cache_size: int = 1000,
        redis_host: str = "localhost",
        redis_port: int = 6379,
        redis_password: Optional[str] = None
    ):
        """
        Initialize cache manager

        Args:
            enable_memory_cache: Enable in-memory L1 cache
            enable_redis_cache: Enable Redis L2 cache
            memory_cache_size: Max size of L1 cache
            redis_host: Redis server host
            redis_port: Redis server port
            redis_password: Redis password
        """
        self.enable_memory_cache = enable_memory_cache
        self.enable_redis_cache = enable_redis_cache

        # L1 Cache
        self.memory_cache = LRUCache(max_size=memory_cache_size) if enable_memory_cache else None

        # L2 Cache
        self.redis_cache = None
        if enable_redis_cache and REDIS_AVAILABLE:
            self.redis_cache = RedisCache(
                host=redis_host,
                port=redis_port,
                password=redis_password
            )

        self.logger = logging.getLogger("cache.manager")

        # Cleanup task
        self.cleanup_task: Optional[asyncio.Task] = None

    async def connect(self):
        """Connect to cache backends"""
        if self.redis_cache:
            try:
                await self.redis_cache.connect()
            except Exception as e:
                self.logger.warning(f"Redis connection failed, continuing without: {e}")
                self.redis_cache = None

        # Start cleanup task
        self.cleanup_task = asyncio.create_task(self._periodic_cleanup())

        self.logger.info(
            f"Cache manager initialized: "
            f"memory={self.enable_memory_cache}, "
            f"redis={self.redis_cache is not None}"
        )

    async def disconnect(self):
        """Disconnect from cache backends"""
        if self.cleanup_task:
            self.cleanup_task.cancel()

        if self.redis_cache:
            await self.redis_cache.disconnect()

    async def get(self, key: str) -> Optional[Any]:
        """
        Get value from cache (L1 -> L2)

        Args:
            key: Cache key

        Returns:
            Cached value or None
        """
        # Try L1 cache
        if self.memory_cache:
            value = await self.memory_cache.get(key)
            if value is not None:
                return value

        # Try L2 cache
        if self.redis_cache:
            value = await self.redis_cache.get(key)
            if value is not None:
                # Warm L1 cache
                if self.memory_cache:
                    await self.memory_cache.set(key, value, ttl=60)
                return value

        return None

    async def set(self, key: str, value: Any, ttl: int = 300):
        """
        Set value in cache (both L1 and L2)

        Args:
            key: Cache key
            value: Value to cache
            ttl: Time to live in seconds
        """
        # Set in L1
        if self.memory_cache:
            await self.memory_cache.set(key, value, ttl=ttl)

        # Set in L2
        if self.redis_cache:
            await self.redis_cache.set(key, value, ttl=ttl)

    async def delete(self, key: str):
        """Delete key from all cache tiers"""
        if self.memory_cache:
            await self.memory_cache.delete(key)

        if self.redis_cache:
            await self.redis_cache.delete(key)

    async def clear(self):
        """Clear all caches"""
        if self.memory_cache:
            await self.memory_cache.clear()

        if self.redis_cache:
            await self.redis_cache.clear()

        self.logger.info("All caches cleared")

    async def _periodic_cleanup(self):
        """Periodic cleanup of expired entries"""
        while True:
            try:
                await asyncio.sleep(300)  # Every 5 minutes

                if self.memory_cache:
                    await self.memory_cache.cleanup_expired()

            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Cleanup error: {e}")

    def make_cache_key(self, *args, **kwargs) -> str:
        """
        Generate cache key from arguments

        Args:
            *args: Positional arguments
            **kwargs: Keyword arguments

        Returns:
            Hashed cache key
        """
        # Create deterministic string representation
        key_parts = []

        for arg in args:
            if isinstance(arg, (dict, list)):
                key_parts.append(json.dumps(arg, sort_keys=True))
            else:
                key_parts.append(str(arg))

        for k, v in sorted(kwargs.items()):
            if isinstance(v, (dict, list)):
                key_parts.append(f"{k}={json.dumps(v, sort_keys=True)}")
            else:
                key_parts.append(f"{k}={v}")

        key_string = ":".join(key_parts)

        # Hash for consistent length
        return hashlib.sha256(key_string.encode()).hexdigest()[:32]

    def get_stats(self) -> Dict[str, Any]:
        """Get aggregated cache statistics"""
        stats = {
            'memory_cache_enabled': self.enable_memory_cache,
            'redis_cache_enabled': self.enable_redis_cache
        }

        if self.memory_cache:
            stats['memory_cache'] = self.memory_cache.get_stats()

        if self.redis_cache:
            stats['redis_cache'] = self.redis_cache.get_stats()

        return stats


async def create_cache_manager(config) -> CacheManager:
    """
    Factory function to create and initialize cache manager

    Args:
        config: AnalyzerConfig instance

    Returns:
        Initialized CacheManager
    """
    manager = CacheManager(
        enable_memory_cache=config.cache_enabled,
        enable_redis_cache=config.redis_enabled,
        memory_cache_size=config.cache_max_size,
        redis_host=config.redis_host,
        redis_port=config.redis_port,
        redis_password=config.redis_password
    )

    await manager.connect()

    return manager
