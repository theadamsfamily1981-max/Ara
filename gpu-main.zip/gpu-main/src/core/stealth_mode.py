"""
Stealth Mode & Evasion Techniques

Advanced techniques to evade detection by WAFs, IDS, and rate limiters.

⚠️ ETHICAL USE ONLY ⚠️
- Authorized bug bounty programs
- Penetration testing with permission
- Security research
- Educational purposes

Features:
- User-agent rotation
- Request timing randomization
- Header obfuscation
- Proxy rotation
- Session simulation
- Fingerprint randomization
"""

import random
import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
import hashlib
import time


@dataclass
class StealthConfig:
    """Configuration for stealth mode"""
    user_agent_rotation: bool = True
    timing_randomization: bool = True
    header_randomization: bool = True
    proxy_rotation: bool = False
    session_simulation: bool = True
    min_delay_seconds: float = 1.0
    max_delay_seconds: float = 3.0
    proxy_list: List[str] = None


class StealthMode:
    """
    Stealth mode for evasion

    Implements techniques to appear more human-like and evade detection.

    ⚠️ WARNING: Use only for authorized security testing!
    """

    def __init__(self, config: Optional[StealthConfig] = None):
        """
        Initialize stealth mode

        Args:
            config: Stealth configuration
        """
        self.config = config or StealthConfig()
        self.logger = logging.getLogger("stealth")

        # User agents (realistic, recent)
        self.user_agents = [
            # Chrome on Windows
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',

            # Chrome on macOS
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',

            # Firefox on Windows
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0',

            # Firefox on macOS
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:121.0) Gecko/20100101 Firefox/121.0',

            # Safari on macOS
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15',

            # Edge on Windows
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0',

            # Chrome on Linux
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',

            # Mobile Chrome
            'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',

            # Mobile Safari
            'Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Mobile/15E148 Safari/604.1'
        ]

        # Accept-Language variations
        self.accept_languages = [
            'en-US,en;q=0.9',
            'en-GB,en;q=0.9',
            'en-US,en;q=0.9,es;q=0.8',
            'en-US,en;q=0.9,fr;q=0.8',
            'en-US,en;q=0.9,de;q=0.8',
        ]

        # Accept variations
        self.accepts = [
            'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        ]

        # Accept-Encoding
        self.accept_encodings = [
            'gzip, deflate, br',
            'gzip, deflate',
        ]

        # DNT (Do Not Track)
        self.dnts = ['1', None]  # None means don't send header

        # Current session fingerprint
        self.current_fingerprint = self._generate_fingerprint()

        # Request counter for session simulation
        self.request_count = 0

    def _generate_fingerprint(self) -> Dict[str, Any]:
        """Generate a consistent fingerprint for this session"""
        return {
            'user_agent': random.choice(self.user_agents),
            'accept_language': random.choice(self.accept_languages),
            'accept': random.choice(self.accepts),
            'accept_encoding': random.choice(self.accept_encodings),
            'dnt': random.choice(self.dnts),
            'session_start': time.time()
        }

    def rotate_fingerprint(self):
        """Rotate to a new fingerprint"""
        self.current_fingerprint = self._generate_fingerprint()
        self.request_count = 0
        self.logger.debug("Rotated fingerprint")

    def get_headers(self, additional_headers: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        """
        Get stealth headers for request

        Args:
            additional_headers: Additional headers to include

        Returns:
            Headers dictionary
        """
        headers = {}

        if self.config.user_agent_rotation:
            headers['User-Agent'] = self.current_fingerprint['user_agent']

        if self.config.header_randomization:
            headers['Accept-Language'] = self.current_fingerprint['accept_language']
            headers['Accept'] = self.current_fingerprint['accept']
            headers['Accept-Encoding'] = self.current_fingerprint['accept_encoding']

            if self.current_fingerprint['dnt']:
                headers['DNT'] = self.current_fingerprint['dnt']

            # Add common headers
            headers['Cache-Control'] = random.choice(['no-cache', 'max-age=0'])
            headers['Upgrade-Insecure-Requests'] = '1'

            # Vary Sec-Fetch headers (realistic browser behavior)
            if random.random() > 0.5:
                headers['Sec-Fetch-Dest'] = random.choice(['document', 'empty'])
                headers['Sec-Fetch-Mode'] = random.choice(['navigate', 'cors'])
                headers['Sec-Fetch-Site'] = random.choice(['none', 'same-origin', 'cross-site'])

        # Merge with additional headers
        if additional_headers:
            headers.update(additional_headers)

        # Increment request count
        self.request_count += 1

        # Rotate fingerprint periodically (every 20-50 requests)
        if self.config.session_simulation and self.request_count > random.randint(20, 50):
            self.rotate_fingerprint()

        return headers

    async def get_delay(self) -> float:
        """
        Get randomized delay for next request

        Returns:
            Delay in seconds
        """
        if not self.config.timing_randomization:
            return 0.0

        # Exponential distribution (more realistic than uniform)
        delay = random.expovariate(1.0 / self.config.min_delay_seconds)

        # Clamp to max
        delay = min(delay, self.config.max_delay_seconds)

        return delay

    async def wait_before_request(self):
        """Wait with randomized timing before making request"""
        delay = await self.get_delay()

        if delay > 0:
            await asyncio.sleep(delay)

    def get_proxy(self) -> Optional[str]:
        """
        Get proxy for request

        Returns:
            Proxy URL or None
        """
        if not self.config.proxy_rotation or not self.config.proxy_list:
            return None

        return random.choice(self.config.proxy_list)

    def simulate_human_behavior(self) -> Dict[str, Any]:
        """
        Simulate realistic human browsing patterns

        Returns:
            Behavior parameters
        """
        behavior = {
            'read_time': random.uniform(2.0, 10.0),  # Time "reading" response
            'mouse_movements': random.randint(5, 20),  # Simulated mouse movements
            'scroll_depth': random.uniform(0.3, 1.0),  # How far they "scrolled"
            'should_follow_link': random.random() > 0.7  # Probability of following a link
        }

        return behavior

    async def simulate_read_time(self, content_length: int):
        """
        Simulate time spent reading content

        Args:
            content_length: Length of content in bytes
        """
        if not self.config.session_simulation:
            return

        # Estimate reading time (avg 200 words/min, ~5 chars/word)
        words = content_length / 5
        reading_time = (words / 200) * 60  # seconds

        # Add randomness
        actual_time = reading_time * random.uniform(0.5, 1.5)

        # Clamp to reasonable range
        actual_time = max(1.0, min(actual_time, 10.0))

        await asyncio.sleep(actual_time)

    def get_referrer(self, current_url: str, previous_url: Optional[str] = None) -> Optional[str]:
        """
        Get realistic Referer header

        Args:
            current_url: Current URL being requested
            previous_url: Previous URL in session

        Returns:
            Referer header value or None
        """
        if not self.config.session_simulation:
            return None

        if previous_url:
            return previous_url

        # First request in session - no referer or search engine
        if random.random() > 0.5:
            return None
        else:
            # Came from search engine
            search_engines = [
                'https://www.google.com/',
                'https://www.bing.com/',
                'https://duckduckgo.com/'
            ]
            return random.choice(search_engines)

    def obfuscate_payload(self, payload: str) -> str:
        """
        Obfuscate payload to evade WAF signature detection

        Args:
            payload: Original payload

        Returns:
            Obfuscated payload
        """
        # Simple obfuscation techniques
        # Note: Real WAF bypass requires target-specific techniques

        # Case variation
        if random.random() > 0.5:
            payload = self._random_case(payload)

        # Comment injection (SQL)
        if 'SELECT' in payload.upper() or 'UNION' in payload.upper():
            payload = self._inject_sql_comments(payload)

        # URL encoding
        if random.random() > 0.5:
            payload = self._partial_url_encode(payload)

        return payload

    def _random_case(self, text: str) -> str:
        """Randomize case of text"""
        return ''.join(
            c.upper() if random.random() > 0.5 else c.lower()
            for c in text
        )

    def _inject_sql_comments(self, payload: str) -> str:
        """Inject SQL comments into payload"""
        # Add comments between keywords
        payload = payload.replace(' ', '/**/ ')
        payload = payload.replace('SELECT', 'SeLeCt/**/')
        payload = payload.replace('UNION', '/**/UnIoN/**/')
        return payload

    def _partial_url_encode(self, payload: str) -> str:
        """Partially URL encode payload"""
        import urllib.parse

        # Only encode some characters
        encoded = []
        for c in payload:
            if random.random() > 0.7 and c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789':
                encoded.append(urllib.parse.quote(c))
            else:
                encoded.append(c)

        return ''.join(encoded)

    def get_stealth_stats(self) -> Dict[str, Any]:
        """Get stealth mode statistics"""
        return {
            'user_agent_rotation': self.config.user_agent_rotation,
            'timing_randomization': self.config.timing_randomization,
            'header_randomization': self.config.header_randomization,
            'proxy_rotation': self.config.proxy_rotation,
            'session_simulation': self.config.session_simulation,
            'current_user_agent': self.current_fingerprint['user_agent'],
            'request_count': self.request_count,
            'session_age': time.time() - self.current_fingerprint['session_start']
        }


def create_stealth_mode(
    enable_user_agent: bool = True,
    enable_timing: bool = True,
    enable_headers: bool = True,
    min_delay: float = 1.0,
    max_delay: float = 3.0
) -> StealthMode:
    """
    Factory function to create stealth mode

    Args:
        enable_user_agent: Enable user-agent rotation
        enable_timing: Enable timing randomization
        enable_headers: Enable header randomization
        min_delay: Minimum delay between requests
        max_delay: Maximum delay between requests

    Returns:
        Configured StealthMode
    """
    config = StealthConfig(
        user_agent_rotation=enable_user_agent,
        timing_randomization=enable_timing,
        header_randomization=enable_headers,
        min_delay_seconds=min_delay,
        max_delay_seconds=max_delay
    )

    return StealthMode(config)
