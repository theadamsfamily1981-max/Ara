"""
Plugin System for Custom Analyzers

Allows users to create and load custom analyzers without modifying core code.

Features:
- Hot-reload plugins
- Automatic discovery
- Dependency management
- Sandboxed execution
- Plugin marketplace integration (future)
"""

import os
import sys
import importlib
import importlib.util
import inspect
import logging
from typing import Dict, List, Any, Optional, Type
from dataclasses import dataclass
from pathlib import Path
import ast
import hashlib


@dataclass
class PluginMetadata:
    """Plugin metadata"""
    name: str
    version: str
    author: str
    description: str
    dependencies: List[str]
    enabled: bool = True


class PluginInterface:
    """
    Base interface that all plugins must implement

    Custom analyzers should inherit from this class.
    """

    def __init__(self, config=None, cache_manager=None):
        """
        Initialize plugin

        Args:
            config: Configuration object
            cache_manager: Cache manager instance
        """
        self.config = config
        self.cache_manager = cache_manager
        self.logger = logging.getLogger(f"plugin.{self.__class__.__name__}")

    def get_metadata(self) -> PluginMetadata:
        """
        Get plugin metadata

        Returns:
            PluginMetadata
        """
        raise NotImplementedError("Plugins must implement get_metadata()")

    async def analyze(self, target_url: str, **kwargs) -> List[Dict[str, Any]]:
        """
        Run analysis on target

        Args:
            target_url: Target URL
            **kwargs: Additional parameters

        Returns:
            List of findings
        """
        raise NotImplementedError("Plugins must implement analyze()")

    async def initialize(self):
        """Optional initialization method"""
        pass

    async def cleanup(self):
        """Optional cleanup method"""
        pass


class PluginManager:
    """
    Plugin manager for loading and managing custom analyzers

    Discovers, validates, and loads plugins from the plugins directory.
    """

    def __init__(self, plugins_dir: str = "plugins"):
        """
        Initialize plugin manager

        Args:
            plugins_dir: Directory containing plugins
        """
        self.plugins_dir = Path(plugins_dir)
        self.plugins: Dict[str, Type[PluginInterface]] = {}
        self.plugin_instances: Dict[str, PluginInterface] = {}
        self.plugin_metadata: Dict[str, PluginMetadata] = {}

        self.logger = logging.getLogger("plugin_manager")

        # Create plugins directory if it doesn't exist
        self.plugins_dir.mkdir(parents=True, exist_ok=True)

        # Create example plugin
        self._create_example_plugin()

    def _create_example_plugin(self):
        """Create an example plugin for users to reference"""
        example_plugin = '''"""
Example Custom Analyzer Plugin

This is a template for creating custom analyzers.
Copy this file and modify it to create your own analyzer.
"""

from src.core.plugin_system import PluginInterface, PluginMetadata
from typing import Dict, List, Any


class ExampleAnalyzer(PluginInterface):
    """
    Example custom analyzer

    This analyzer demonstrates how to create a plugin.
    """

    def get_metadata(self) -> PluginMetadata:
        """Get plugin metadata"""
        return PluginMetadata(
            name="Example Analyzer",
            version="1.0.0",
            author="Your Name",
            description="An example custom analyzer",
            dependencies=[],  # List any required packages
            enabled=False  # Set to True to enable
        )

    async def analyze(self, target_url: str, **kwargs) -> List[Dict[str, Any]]:
        """
        Analyze target URL

        Args:
            target_url: Target URL to analyze
            **kwargs: Additional parameters

        Returns:
            List of findings
        """
        findings = []

        try:
            self.logger.info(f"Running Example Analyzer on {target_url}")

            # Your analysis logic here
            # Example: Check for a specific header

            # Simulated finding
            finding = {
                'severity': 'info',
                'title': 'Example Finding',
                'description': 'This is an example finding from the custom analyzer',
                'evidence': {
                    'target': target_url,
                    'custom_data': 'your_data_here'
                },
                'remediation': 'This is how to fix it',
                'confidence': 0.8
            }

            findings.append(finding)

        except Exception as e:
            self.logger.error(f"Error in Example Analyzer: {e}")

        return findings
'''

        example_path = self.plugins_dir / "example_analyzer.py"
        if not example_path.exists():
            example_path.write_text(example_plugin)
            self.logger.info(f"Created example plugin at {example_path}")

    def discover_plugins(self) -> List[Path]:
        """
        Discover all plugin files in plugins directory

        Returns:
            List of plugin file paths
        """
        if not self.plugins_dir.exists():
            self.logger.warning(f"Plugins directory not found: {self.plugins_dir}")
            return []

        plugin_files = []

        for path in self.plugins_dir.glob("*.py"):
            if path.name.startswith("_"):
                continue  # Skip private files

            plugin_files.append(path)

        self.logger.info(f"Discovered {len(plugin_files)} plugin files")

        return plugin_files

    def _validate_plugin_class(self, plugin_class: Type) -> bool:
        """
        Validate that a class is a valid plugin

        Args:
            plugin_class: Class to validate

        Returns:
            True if valid
        """
        # Must inherit from PluginInterface
        if not issubclass(plugin_class, PluginInterface):
            return False

        # Must not be the base class itself
        if plugin_class == PluginInterface:
            return False

        # Must implement required methods
        required_methods = ['get_metadata', 'analyze']
        for method in required_methods:
            if not hasattr(plugin_class, method):
                return False

        return True

    def load_plugin(self, plugin_path: Path) -> Optional[Type[PluginInterface]]:
        """
        Load a plugin from file

        Args:
            plugin_path: Path to plugin file

        Returns:
            Plugin class or None if failed
        """
        try:
            # Load module
            spec = importlib.util.spec_from_file_location(
                plugin_path.stem,
                plugin_path
            )

            if spec is None or spec.loader is None:
                self.logger.error(f"Failed to load spec for {plugin_path}")
                return None

            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

            # Find plugin classes in module
            for name, obj in inspect.getmembers(module, inspect.isclass):
                if self._validate_plugin_class(obj):
                    # Get metadata to check if enabled
                    try:
                        temp_instance = obj()
                        metadata = temp_instance.get_metadata()

                        if not metadata.enabled:
                            self.logger.info(f"Plugin {metadata.name} is disabled")
                            continue

                        self.plugins[metadata.name] = obj
                        self.plugin_metadata[metadata.name] = metadata

                        self.logger.info(
                            f"Loaded plugin: {metadata.name} v{metadata.version} by {metadata.author}"
                        )

                        return obj

                    except Exception as e:
                        self.logger.error(f"Error getting metadata for {name}: {e}")

        except Exception as e:
            self.logger.error(f"Error loading plugin {plugin_path}: {e}", exc_info=True)

        return None

    def load_all_plugins(self) -> int:
        """
        Load all plugins from plugins directory

        Returns:
            Number of plugins loaded
        """
        self.logger.info("Loading plugins...")

        plugin_files = self.discover_plugins()

        loaded_count = 0
        for plugin_path in plugin_files:
            if self.load_plugin(plugin_path):
                loaded_count += 1

        self.logger.info(f"Loaded {loaded_count}/{len(plugin_files)} plugins")

        return loaded_count

    def get_plugin(self, name: str) -> Optional[Type[PluginInterface]]:
        """
        Get plugin class by name

        Args:
            name: Plugin name

        Returns:
            Plugin class or None
        """
        return self.plugins.get(name)

    def create_plugin_instance(
        self,
        name: str,
        config=None,
        cache_manager=None
    ) -> Optional[PluginInterface]:
        """
        Create plugin instance

        Args:
            name: Plugin name
            config: Configuration
            cache_manager: Cache manager

        Returns:
            Plugin instance or None
        """
        plugin_class = self.get_plugin(name)

        if plugin_class is None:
            self.logger.error(f"Plugin not found: {name}")
            return None

        try:
            instance = plugin_class(config=config, cache_manager=cache_manager)
            self.plugin_instances[name] = instance

            return instance

        except Exception as e:
            self.logger.error(f"Error creating plugin instance {name}: {e}")
            return None

    def get_all_plugins(self) -> Dict[str, PluginMetadata]:
        """Get metadata for all loaded plugins"""
        return self.plugin_metadata.copy()

    def reload_plugin(self, name: str) -> bool:
        """
        Reload a plugin (useful for development)

        Args:
            name: Plugin name

        Returns:
            True if reloaded successfully
        """
        # Find plugin file
        for plugin_path in self.discover_plugins():
            # Try to load and check if it matches the name
            plugin_class = self.load_plugin(plugin_path)

            if plugin_class:
                temp_instance = plugin_class()
                metadata = temp_instance.get_metadata()

                if metadata.name == name:
                    self.logger.info(f"Reloaded plugin: {name}")
                    return True

        self.logger.error(f"Failed to reload plugin: {name}")
        return False

    def unload_plugin(self, name: str):
        """
        Unload a plugin

        Args:
            name: Plugin name
        """
        if name in self.plugins:
            del self.plugins[name]

        if name in self.plugin_instances:
            del self.plugin_instances[name]

        if name in self.plugin_metadata:
            del self.plugin_metadata[name]

        self.logger.info(f"Unloaded plugin: {name}")

    def get_plugin_stats(self) -> Dict[str, Any]:
        """Get plugin system statistics"""
        return {
            'total_plugins': len(self.plugins),
            'loaded_plugins': list(self.plugins.keys()),
            'plugin_instances': list(self.plugin_instances.keys()),
            'plugins_dir': str(self.plugins_dir)
        }


# Global plugin manager instance
_plugin_manager: Optional[PluginManager] = None


def get_plugin_manager() -> PluginManager:
    """
    Get global plugin manager instance

    Returns:
        PluginManager
    """
    global _plugin_manager

    if _plugin_manager is None:
        _plugin_manager = PluginManager()
        _plugin_manager.load_all_plugins()

    return _plugin_manager


def create_plugin_template(
    name: str,
    author: str,
    description: str,
    output_path: Optional[str] = None
) -> Path:
    """
    Create a new plugin template

    Args:
        name: Plugin name
        author: Author name
        description: Plugin description
        output_path: Output file path (auto-generated if None)

    Returns:
        Path to created plugin file
    """
    template = f'''"""
{name}

{description}

Author: {author}
"""

from src.core.plugin_system import PluginInterface, PluginMetadata
from typing import Dict, List, Any


class {name.replace(" ", "")}(PluginInterface):
    """
    {description}
    """

    def get_metadata(self) -> PluginMetadata:
        """Get plugin metadata"""
        return PluginMetadata(
            name="{name}",
            version="1.0.0",
            author="{author}",
            description="{description}",
            dependencies=[],  # Add any required packages here
            enabled=True
        )

    async def initialize(self):
        """Initialize plugin (optional)"""
        self.logger.info("Initializing {name}")
        # Add initialization logic here

    async def analyze(self, target_url: str, **kwargs) -> List[Dict[str, Any]]:
        """
        Analyze target URL

        Args:
            target_url: Target URL to analyze
            **kwargs: Additional parameters

        Returns:
            List of findings
        """
        findings = []

        try:
            self.logger.info(f"Running {name} on {{target_url}}")

            # TODO: Implement your analysis logic here

            # Example finding structure:
            # finding = {{
            #     'severity': 'medium',  # critical, high, medium, low, info
            #     'title': 'Finding Title',
            #     'description': 'Detailed description',
            #     'evidence': {{
            #         'key': 'value'
            #     }},
            #     'remediation': 'How to fix it',
            #     'confidence': 0.8  # 0.0 - 1.0
            # }}
            # findings.append(finding)

        except Exception as e:
            self.logger.error(f"Error in {name}: {{e}}")

        return findings

    async def cleanup(self):
        """Cleanup plugin (optional)"""
        self.logger.info("Cleaning up {name}")
        # Add cleanup logic here
'''

    if output_path is None:
        plugin_manager = get_plugin_manager()
        filename = name.lower().replace(" ", "_") + ".py"
        output_path = plugin_manager.plugins_dir / filename

    output_path = Path(output_path)
    output_path.write_text(template)

    logging.info(f"Created plugin template: {output_path}")

    return output_path
