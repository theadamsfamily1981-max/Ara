"""
Web GUI Integration Module

Integrates the autonomous orchestrator with the Flask web GUI:
- Real-time status updates via WebSockets
- Analyzer controls (start/stop/pause)
- Live metrics and statistics
- Finding display and export
- Configuration management
"""

import asyncio
import threading
import logging
from typing import Dict, Any, Optional
from datetime import datetime
import json

from core.orchestrator import AutonomousOrchestrator, create_orchestrator
from core.config import AnalyzerConfig, get_config


class WebIntegratedOrchestrator:
    """
    Orchestrator wrapper for web GUI integration

    Features:
    - Async/sync bridge for Flask compatibility
    - WebSocket notifications for real-time updates
    - Thread-safe operations
    - Background task management
    """

    def __init__(self, socketio=None):
        """
        Initialize web-integrated orchestrator

        Args:
            socketio: Flask-SocketIO instance for real-time updates
        """
        self.socketio = socketio
        self.orchestrator: Optional[AutonomousOrchestrator] = None
        self.loop: Optional[asyncio.AbstractEventLoop] = None
        self.thread: Optional[threading.Thread] = None
        self.running = False

        self.logger = logging.getLogger("web_orchestrator")

    def initialize(self, config: Optional[AnalyzerConfig] = None):
        """
        Initialize orchestrator in background thread

        Args:
            config: Configuration (uses default if None)
        """
        if self.running:
            self.logger.warning("Orchestrator already running")
            return

        self.logger.info("Initializing web-integrated orchestrator")

        # Start event loop in background thread
        self.thread = threading.Thread(target=self._run_event_loop, daemon=True)
        self.thread.start()

        # Wait for initialization
        import time
        max_wait = 5
        start = time.time()
        while not self.loop and time.time() - start < max_wait:
            time.sleep(0.1)

        if not self.loop:
            raise RuntimeError("Failed to initialize event loop")

        # Create orchestrator
        config = config or get_config()
        future = asyncio.run_coroutine_threadsafe(
            create_orchestrator(config),
            self.loop
        )
        self.orchestrator = future.result(timeout=10)

        self.running = True
        self.logger.info("Web-integrated orchestrator initialized")

    def _run_event_loop(self):
        """Run event loop in background thread"""
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

    def shutdown(self):
        """Shutdown orchestrator and event loop"""
        if not self.running:
            return

        self.logger.info("Shutting down web-integrated orchestrator")
        self.running = False

        if self.orchestrator and self.loop:
            future = asyncio.run_coroutine_threadsafe(
                self.orchestrator.shutdown(),
                self.loop
            )
            future.result(timeout=10)

        if self.loop:
            self.loop.call_soon_threadsafe(self.loop.stop)

        if self.thread:
            self.thread.join(timeout=5)

        self.logger.info("Web-integrated orchestrator shutdown complete")

    def start_scan(self, target_url: str, parallel: bool = True) -> Dict[str, Any]:
        """
        Start scan on target

        Args:
            target_url: Target URL to scan
            parallel: Run analyzers in parallel

        Returns:
            Status dictionary
        """
        if not self.orchestrator or not self.loop:
            return {'success': False, 'error': 'Orchestrator not initialized'}

        self.logger.info(f"Starting scan on {target_url}")

        # Emit start event
        if self.socketio:
            self.socketio.emit('scan_started', {
                'target': target_url,
                'timestamp': datetime.now().isoformat()
            })

        # Run scan in background
        def scan_complete_callback(future):
            try:
                findings = future.result()
                if self.socketio:
                    self.socketio.emit('scan_completed', {
                        'target': target_url,
                        'findings_count': len(findings),
                        'timestamp': datetime.now().isoformat()
                    })
            except Exception as e:
                self.logger.error(f"Scan failed: {e}")
                if self.socketio:
                    self.socketio.emit('scan_failed', {
                        'target': target_url,
                        'error': str(e),
                        'timestamp': datetime.now().isoformat()
                    })

        future = asyncio.run_coroutine_threadsafe(
            self.orchestrator.run_all_analyzers(target_url, parallel),
            self.loop
        )
        future.add_done_callback(scan_complete_callback)

        return {
            'success': True,
            'message': f'Scan started on {target_url}',
            'target': target_url
        }

    def pause_scan(self) -> Dict[str, Any]:
        """Pause current scan"""
        if not self.orchestrator:
            return {'success': False, 'error': 'Orchestrator not initialized'}

        self.orchestrator.pause()

        if self.socketio:
            self.socketio.emit('scan_paused', {
                'timestamp': datetime.now().isoformat()
            })

        return {'success': True, 'message': 'Scan paused'}

    def resume_scan(self) -> Dict[str, Any]:
        """Resume paused scan"""
        if not self.orchestrator:
            return {'success': False, 'error': 'Orchestrator not initialized'}

        self.orchestrator.resume()

        if self.socketio:
            self.socketio.emit('scan_resumed', {
                'timestamp': datetime.now().isoformat()
            })

        return {'success': True, 'message': 'Scan resumed'}

    def get_status(self) -> Dict[str, Any]:
        """Get orchestrator status"""
        if not self.orchestrator:
            return {
                'initialized': False,
                'running': False,
                'error': 'Orchestrator not initialized'
            }

        status = self.orchestrator.get_status()
        status['initialized'] = True

        return status

    def get_findings(
        self,
        severity: Optional[str] = None,
        analyzer: Optional[str] = None,
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """Get findings with optional filtering"""
        if not self.orchestrator:
            return []

        return self.orchestrator.get_findings(severity, analyzer, limit)

    def export_findings(self, format: str = 'json') -> str:
        """Export findings in specified format"""
        if not self.orchestrator:
            return json.dumps({'error': 'Orchestrator not initialized'})

        return self.orchestrator.export_findings(format)

    def get_analyzer_status(self, analyzer_name: str) -> Dict[str, Any]:
        """Get status of specific analyzer"""
        status = self.get_status()

        if 'analyzers' in status and analyzer_name in status['analyzers']:
            return status['analyzers'][analyzer_name]

        return {'error': 'Analyzer not found'}

    def get_metrics(self) -> Dict[str, Any]:
        """Get comprehensive metrics"""
        status = self.get_status()

        return {
            'orchestrator': {
                'running': status.get('running', False),
                'paused': status.get('paused', False)
            },
            'findings': status.get('findings_summary', {}),
            'analyzers': status.get('analyzers', {}),
            'rate_limiter': status.get('rate_limiter', {}),
            'cache': status.get('cache', {}),
            'timestamp': datetime.now().isoformat()
        }

    def emit_periodic_updates(self, interval: int = 5):
        """
        Emit periodic status updates via WebSocket

        Args:
            interval: Update interval in seconds
        """
        if not self.socketio or not self.loop:
            return

        async def periodic_update():
            while self.running:
                try:
                    metrics = self.get_metrics()

                    if self.socketio:
                        self.socketio.emit('metrics_update', metrics)

                    await asyncio.sleep(interval)

                except Exception as e:
                    self.logger.error(f"Error emitting update: {e}")
                    await asyncio.sleep(interval)

        # Schedule periodic updates
        asyncio.run_coroutine_threadsafe(periodic_update(), self.loop)

    def configure_analyzer(
        self,
        analyzer_name: str,
        config: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Configure specific analyzer

        Args:
            analyzer_name: Name of analyzer
            config: Configuration dictionary

        Returns:
            Status dictionary
        """
        # Placeholder for analyzer-specific configuration
        return {
            'success': True,
            'message': f'Configuration updated for {analyzer_name}',
            'config': config
        }


def create_web_orchestrator(socketio=None) -> WebIntegratedOrchestrator:
    """
    Factory function to create web-integrated orchestrator

    Args:
        socketio: Flask-SocketIO instance

    Returns:
        WebIntegratedOrchestrator instance
    """
    orchestrator = WebIntegratedOrchestrator(socketio)
    orchestrator.initialize()
    return orchestrator


# Flask route helpers
def create_orchestrator_routes(app, orchestrator: WebIntegratedOrchestrator):
    """
    Create Flask routes for orchestrator control

    Args:
        app: Flask application
        orchestrator: WebIntegratedOrchestrator instance
    """
    from flask import jsonify, request

    @app.route('/api/status')
    def api_status():
        """Get orchestrator status"""
        return jsonify(orchestrator.get_status())

    @app.route('/api/start_scan', methods=['POST'])
    def api_start_scan():
        """Start scan on target"""
        data = request.get_json()
        target_url = data.get('target_url')

        if not target_url:
            return jsonify({'success': False, 'error': 'Missing target_url'}), 400

        parallel = data.get('parallel', True)
        result = orchestrator.start_scan(target_url, parallel)

        return jsonify(result)

    @app.route('/api/pause')
    def api_pause():
        """Pause current scan"""
        return jsonify(orchestrator.pause_scan())

    @app.route('/api/resume')
    def api_resume():
        """Resume paused scan"""
        return jsonify(orchestrator.resume_scan())

    @app.route('/api/findings')
    def api_findings():
        """Get findings"""
        severity = request.args.get('severity')
        analyzer = request.args.get('analyzer')
        limit = int(request.args.get('limit', 100))

        findings = orchestrator.get_findings(severity, analyzer, limit)
        return jsonify({'findings': findings})

    @app.route('/api/export/<format>')
    def api_export(format):
        """Export findings"""
        data = orchestrator.export_findings(format)

        if format == 'json':
            return jsonify(json.loads(data))
        elif format == 'csv':
            from flask import Response
            return Response(data, mimetype='text/csv')
        elif format == 'markdown':
            from flask import Response
            return Response(data, mimetype='text/markdown')
        else:
            return jsonify({'error': 'Unsupported format'}), 400

    @app.route('/api/metrics')
    def api_metrics():
        """Get comprehensive metrics"""
        return jsonify(orchestrator.get_metrics())

    @app.route('/api/analyzer/<analyzer_name>')
    def api_analyzer_status(analyzer_name):
        """Get status of specific analyzer"""
        return jsonify(orchestrator.get_analyzer_status(analyzer_name))

    return app


# WebSocket event handlers
def create_socket_handlers(socketio, orchestrator: WebIntegratedOrchestrator):
    """
    Create SocketIO event handlers

    Args:
        socketio: Flask-SocketIO instance
        orchestrator: WebIntegratedOrchestrator instance
    """

    @socketio.on('connect')
    def handle_connect():
        """Client connected"""
        logging.info('Client connected')
        socketio.emit('connected', {'message': 'Connected to orchestrator'})

        # Send initial status
        status = orchestrator.get_status()
        socketio.emit('status_update', status)

    @socketio.on('disconnect')
    def handle_disconnect():
        """Client disconnected"""
        logging.info('Client disconnected')

    @socketio.on('request_status')
    def handle_status_request():
        """Client requested status update"""
        status = orchestrator.get_status()
        socketio.emit('status_update', status)

    @socketio.on('start_scan')
    def handle_start_scan(data):
        """Client requested scan start"""
        target_url = data.get('target_url')
        parallel = data.get('parallel', True)

        result = orchestrator.start_scan(target_url, parallel)
        socketio.emit('scan_response', result)

    return socketio
