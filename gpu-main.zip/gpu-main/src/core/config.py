"""
Central Configuration Management System

Provides centralized configuration for all analyzers with:
- Environment-based settings (dev, staging, production)
- Security defaults
- Performance tuning
- Feature flags
"""

import os
from dataclasses import dataclass, field
from typing import Optional, Dict, Any
from pathlib import Path
import yaml
import logging


@dataclass
class AnalyzerConfig:
    """
    Configuration for intelligence analyzers

    All settings have secure defaults and can be overridden
    via environment variables or config files.
    """

    # Connection Pooling
    max_concurrent_connections: int = 100
    max_connections_per_host: int = 30
    dns_cache_ttl_seconds: int = 300

    # Timeouts (in seconds)
    request_timeout_seconds: int = 30
    connect_timeout_seconds: int = 10
    read_timeout_seconds: int = 30

    # Rate Limiting
    rate_limit_requests: int = 1000
    rate_limit_window_seconds: int = 3600  # 1 hour

    # SSL/TLS
    ssl_verify: bool = True  # Always verify SSL in production

    # Retries
    max_retries: int = 3
    retry_backoff_factor: float = 2.0
    retry_max_backoff: int = 10

    # Caching
    cache_enabled: bool = True
    cache_default_ttl: int = 300  # 5 minutes
    cache_max_size: int = 10000

    # Redis (for distributed caching)
    redis_enabled: bool = False
    redis_host: str = "localhost"
    redis_port: int = 6379
    redis_db: int = 0
    redis_password: Optional[str] = None
    redis_ssl: bool = False

    # Headers
    user_agent: str = "Bug-Bounty-Hunter/1.0 (Security Research)"

    # Logging
    log_level: str = "INFO"
    log_to_file: bool = True
    log_file_path: str = "logs/analyzer.log"
    log_max_bytes: int = 10_000_000  # 10MB
    log_backup_count: int = 5

    # Performance
    use_uvloop: bool = True  # Use uvloop for better performance
    use_orjson: bool = True  # Use orjson for faster JSON parsing

    # Analysis Settings
    max_capture_size: int = 1000  # Max requests to capture
    max_chain_length: int = 5  # Max attack chain length
    max_parallel_requests: int = 100  # For race condition testing
    monitoring_duration_hours: int = 24  # For temporal detection

    # Security
    sanitize_logs: bool = True  # Remove sensitive data from logs
    encrypt_storage: bool = True  # Encrypt stored data
    audit_log_enabled: bool = True

    # Feature Flags
    enable_deep_correlation: bool = True
    enable_business_logic_mapping: bool = True
    enable_chain_discovery: bool = True
    enable_race_detection: bool = True
    enable_semantic_analysis: bool = True
    enable_transformation_tracking: bool = True
    enable_permission_inference: bool = True
    enable_temporal_detection: bool = True
    enable_crypto_analysis: bool = True
    enable_pattern_learning: bool = True

    @classmethod
    def from_env(cls) -> 'AnalyzerConfig':
        """Load configuration from environment variables"""
        config = cls()

        # Connection pooling
        config.max_concurrent_connections = int(
            os.getenv('MAX_CONCURRENT_CONNECTIONS', config.max_concurrent_connections)
        )
        config.max_connections_per_host = int(
            os.getenv('MAX_CONNECTIONS_PER_HOST', config.max_connections_per_host)
        )

        # Timeouts
        config.request_timeout_seconds = int(
            os.getenv('REQUEST_TIMEOUT_SECONDS', config.request_timeout_seconds)
        )
        config.connect_timeout_seconds = int(
            os.getenv('CONNECT_TIMEOUT_SECONDS', config.connect_timeout_seconds)
        )

        # Rate limiting
        config.rate_limit_requests = int(
            os.getenv('RATE_LIMIT_REQUESTS', config.rate_limit_requests)
        )
        config.rate_limit_window_seconds = int(
            os.getenv('RATE_LIMIT_WINDOW_SECONDS', config.rate_limit_window_seconds)
        )

        # SSL
        config.ssl_verify = os.getenv('SSL_VERIFY', 'true').lower() == 'true'

        # Redis
        config.redis_enabled = os.getenv('REDIS_ENABLED', 'false').lower() == 'true'
        config.redis_host = os.getenv('REDIS_HOST', config.redis_host)
        config.redis_port = int(os.getenv('REDIS_PORT', config.redis_port))
        config.redis_password = os.getenv('REDIS_PASSWORD')

        # Logging
        config.log_level = os.getenv('LOG_LEVEL', config.log_level)
        config.log_to_file = os.getenv('LOG_TO_FILE', 'true').lower() == 'true'

        return config

    @classmethod
    def from_file(cls, config_path: str) -> 'AnalyzerConfig':
        """Load configuration from YAML file"""
        config = cls()

        if not os.path.exists(config_path):
            logging.warning(f"Config file not found: {config_path}, using defaults")
            return config

        try:
            with open(config_path, 'r') as f:
                data = yaml.safe_load(f)

            if not data:
                return config

            # Update config from file
            for key, value in data.items():
                if hasattr(config, key):
                    setattr(config, key, value)

            logging.info(f"Configuration loaded from {config_path}")

        except Exception as e:
            logging.error(f"Error loading config from {config_path}: {e}")

        return config

    @classmethod
    def for_environment(cls, env: str = "production") -> 'AnalyzerConfig':
        """
        Get configuration for specific environment

        Args:
            env: Environment name (development, staging, production)

        Returns:
            Configured AnalyzerConfig instance
        """
        config = cls()

        if env == "development":
            config.ssl_verify = False  # Allow self-signed certs in dev
            config.log_level = "DEBUG"
            config.rate_limit_requests = 10000  # Higher limits in dev
            config.cache_enabled = False  # Disable cache in dev
            config.max_retries = 1  # Fail fast in dev

        elif env == "staging":
            config.ssl_verify = True
            config.log_level = "INFO"
            config.rate_limit_requests = 2000
            config.cache_enabled = True
            config.max_retries = 2

        elif env == "production":
            config.ssl_verify = True  # Always verify in production
            config.log_level = "WARNING"
            config.rate_limit_requests = 1000  # Conservative in production
            config.cache_enabled = True
            config.max_retries = 3
            config.redis_enabled = True  # Use Redis in production
            config.sanitize_logs = True
            config.encrypt_storage = True
            config.audit_log_enabled = True

        return config

    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary"""
        return {
            'connection_pooling': {
                'max_concurrent_connections': self.max_concurrent_connections,
                'max_connections_per_host': self.max_connections_per_host,
                'dns_cache_ttl_seconds': self.dns_cache_ttl_seconds,
            },
            'timeouts': {
                'request_timeout_seconds': self.request_timeout_seconds,
                'connect_timeout_seconds': self.connect_timeout_seconds,
                'read_timeout_seconds': self.read_timeout_seconds,
            },
            'rate_limiting': {
                'rate_limit_requests': self.rate_limit_requests,
                'rate_limit_window_seconds': self.rate_limit_window_seconds,
            },
            'ssl': {
                'ssl_verify': self.ssl_verify,
            },
            'caching': {
                'cache_enabled': self.cache_enabled,
                'cache_default_ttl': self.cache_default_ttl,
                'cache_max_size': self.cache_max_size,
            },
            'redis': {
                'redis_enabled': self.redis_enabled,
                'redis_host': self.redis_host,
                'redis_port': self.redis_port,
            },
            'logging': {
                'log_level': self.log_level,
                'log_to_file': self.log_to_file,
                'log_file_path': self.log_file_path,
            },
            'security': {
                'sanitize_logs': self.sanitize_logs,
                'encrypt_storage': self.encrypt_storage,
                'audit_log_enabled': self.audit_log_enabled,
            }
        }

    def save(self, config_path: str):
        """Save configuration to YAML file"""
        os.makedirs(os.path.dirname(config_path), exist_ok=True)

        with open(config_path, 'w') as f:
            yaml.dump(self.to_dict(), f, default_flow_style=False)

        logging.info(f"Configuration saved to {config_path}")


def setup_logging(config: AnalyzerConfig):
    """Setup logging based on configuration"""
    log_level = getattr(logging, config.log_level.upper(), logging.INFO)

    # Create formatters
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    # Setup root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(log_level)

    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(log_level)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)

    # File handler
    if config.log_to_file:
        from logging.handlers import RotatingFileHandler

        # Create log directory
        log_dir = os.path.dirname(config.log_file_path)
        if log_dir:
            os.makedirs(log_dir, exist_ok=True)

        file_handler = RotatingFileHandler(
            config.log_file_path,
            maxBytes=config.log_max_bytes,
            backupCount=config.log_backup_count
        )
        file_handler.setLevel(log_level)
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)

    logging.info(f"Logging configured: level={config.log_level}")


def get_config() -> AnalyzerConfig:
    """
    Get configuration based on environment

    Priority:
    1. Environment variable ANALYZER_ENV (development/staging/production)
    2. Config file at ./config/analyzer_config.yaml
    3. Environment variables
    4. Default values
    """
    env = os.getenv('ANALYZER_ENV', 'production')

    # Start with environment-specific defaults
    config = AnalyzerConfig.for_environment(env)

    # Override with config file if exists
    config_file = os.getenv('ANALYZER_CONFIG_FILE', 'config/analyzer_config.yaml')
    if os.path.exists(config_file):
        file_config = AnalyzerConfig.from_file(config_file)
        # Merge file config into env config
        for key, value in file_config.__dict__.items():
            if value != AnalyzerConfig().__dict__[key]:  # If not default
                setattr(config, key, value)

    # Override with environment variables
    env_config = AnalyzerConfig.from_env()
    for key, value in env_config.__dict__.items():
        if value != AnalyzerConfig().__dict__[key]:  # If not default
            setattr(config, key, value)

    # Setup logging
    setup_logging(config)

    logging.info(f"Configuration loaded for environment: {env}")

    return config


# Example configuration files
EXAMPLE_DEV_CONFIG = """
# Development Configuration
max_concurrent_connections: 50
ssl_verify: false
log_level: DEBUG
cache_enabled: false
redis_enabled: false
rate_limit_requests: 10000
"""

EXAMPLE_PROD_CONFIG = """
# Production Configuration
max_concurrent_connections: 100
max_connections_per_host: 30
ssl_verify: true
log_level: WARNING
cache_enabled: true
redis_enabled: true
redis_host: redis.example.com
redis_port: 6379
rate_limit_requests: 1000
rate_limit_window_seconds: 3600
sanitize_logs: true
encrypt_storage: true
audit_log_enabled: true
"""
