"""
Intelligent Finding Prioritization System

Automatically prioritizes findings based on multiple factors:
- CVSS scoring
- Exploitability assessment
- Business impact
- Attack surface exposure
- Historical data
- Trend analysis

Helps focus on the most valuable findings first.
"""

import logging
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from datetime import datetime
import math


@dataclass
class PriorityScore:
    """Priority scoring breakdown"""
    total_score: float  # 0-100
    severity_score: float
    exploitability_score: float
    impact_score: float
    confidence_score: float
    urgency_score: float
    trend_score: float
    priority_level: str  # critical, high, medium, low


class IntelligentPrioritizer:
    """
    Intelligent finding prioritization

    Combines multiple factors to generate actionable priority scores,
    helping security teams focus on the most important findings first.
    """

    def __init__(self):
        """Initialize prioritizer"""
        self.logger = logging.getLogger("ml.prioritizer")

        # Historical data for trend analysis
        self.finding_history: List[Dict[str, Any]] = []

        # Custom weights (can be tuned)
        self.weights = {
            'severity': 0.30,
            'exploitability': 0.25,
            'impact': 0.20,
            'confidence': 0.15,
            'urgency': 0.05,
            'trend': 0.05
        }

    def calculate_cvss_score(self, finding: Dict[str, Any]) -> float:
        """
        Calculate CVSS-like score for finding

        Based on Common Vulnerability Scoring System (CVSS) v3.1

        Args:
            finding: Finding dictionary

        Returns:
            CVSS score (0-10)
        """
        # Base severity
        severity_scores = {
            'critical': 9.0,
            'high': 7.0,
            'medium': 5.0,
            'low': 3.0,
            'info': 1.0
        }

        base_score = severity_scores.get(finding.get('severity', 'info'), 1.0)

        # Attack Vector (how is it exploited?)
        evidence = finding.get('evidence', {})
        title_lower = finding.get('title', '').lower()
        desc_lower = finding.get('description', '').lower()

        # Network-based (remotely exploitable)
        if any(kw in title_lower or kw in desc_lower for kw in ['remote', 'rce', 'ssrf', 'xss', 'injection']):
            av_score = 1.0
        # Adjacent network
        elif any(kw in title_lower or kw in desc_lower for kw in ['csrf', 'cors']):
            av_score = 0.9
        # Local
        elif any(kw in title_lower or kw in desc_lower for kw in ['local', 'file']):
            av_score = 0.7
        # Physical
        else:
            av_score = 0.5

        # Attack Complexity
        if 'authentication' in title_lower or 'auth' in title_lower:
            ac_score = 0.6  # High complexity (requires auth)
        else:
            ac_score = 1.0  # Low complexity

        # Privileges Required
        if 'authenticated' in desc_lower or 'logged in' in desc_lower:
            pr_score = 0.7  # Requires privileges
        elif 'admin' in desc_lower:
            pr_score = 0.5  # Requires high privileges
        else:
            pr_score = 1.0  # No privileges required

        # User Interaction
        if 'user' in title_lower or 'click' in desc_lower:
            ui_score = 0.85  # Requires user interaction
        else:
            ui_score = 1.0  # No interaction

        # Calculate final score
        cvss_score = base_score * av_score * ac_score * pr_score * ui_score

        return min(cvss_score, 10.0)

    def assess_exploitability(self, finding: Dict[str, Any]) -> float:
        """
        Assess how easily the finding can be exploited

        Args:
            finding: Finding dictionary

        Returns:
            Exploitability score (0-1)
        """
        score = 0.5  # Default

        title_lower = finding.get('title', '').lower()
        desc_lower = finding.get('description', '').lower()
        evidence = finding.get('evidence', {})

        # High exploitability indicators
        if any(kw in title_lower for kw in ['rce', 'injection', 'deserialization']):
            score += 0.3

        # Has working exploit/PoC
        if any(kw in desc_lower for kw in ['exploit', 'poc', 'proof of concept', 'payload']):
            score += 0.2

        # Public exploit available
        if 'public' in desc_lower or 'cve-' in desc_lower:
            score += 0.15

        # No authentication required
        if 'unauthenticated' in desc_lower or 'no auth' in desc_lower:
            score += 0.15

        # Has reproduction steps
        if len(evidence) > 3:
            score += 0.1

        # Widely exploitable
        if any(kw in desc_lower for kw in ['all users', 'any user', 'anonymous']):
            score += 0.1

        return min(score, 1.0)

    def assess_business_impact(self, finding: Dict[str, Any]) -> float:
        """
        Assess business impact of the finding

        Args:
            finding: Finding dictionary

        Returns:
            Impact score (0-1)
        """
        score = 0.5  # Default

        title_lower = finding.get('title', '').lower()
        desc_lower = finding.get('description', '').lower()
        severity = finding.get('severity', 'info')

        # Data breach potential
        if any(kw in title_lower or kw in desc_lower for kw in ['data', 'leak', 'exposure', 'disclosure']):
            score += 0.2

        # Financial impact
        if any(kw in title_lower or kw in desc_lower for kw in ['payment', 'credit card', 'transaction', 'money']):
            score += 0.25

        # PII exposure
        if any(kw in title_lower or kw in desc_lower for kw in ['pii', 'personal', 'email', 'ssn', 'password']):
            score += 0.2

        # Account takeover
        if any(kw in title_lower or kw in desc_lower for kw in ['takeover', 'hijack', 'session']):
            score += 0.2

        # System compromise
        if any(kw in title_lower or kw in desc_lower for kw in ['compromise', 'control', 'admin']):
            score += 0.25

        # Compliance issues
        if any(kw in title_lower or kw in desc_lower for kw in ['gdpr', 'hipaa', 'pci', 'compliance']):
            score += 0.15

        # Reputational damage
        if severity == 'critical':
            score += 0.1

        return min(score, 1.0)

    def calculate_urgency(self, finding: Dict[str, Any]) -> float:
        """
        Calculate urgency based on external factors

        Args:
            finding: Finding dictionary

        Returns:
            Urgency score (0-1)
        """
        score = 0.5  # Default

        desc_lower = finding.get('description', '').lower()

        # Active exploitation in the wild
        if 'active' in desc_lower or 'in the wild' in desc_lower:
            score += 0.3

        # Has CVE with high CVSS
        if 'cve-' in desc_lower:
            score += 0.2

        # Zero-day
        if 'zero' in desc_lower or '0day' in desc_lower:
            score += 0.25

        # Public disclosure
        if 'public' in desc_lower or 'disclosed' in desc_lower:
            score += 0.15

        # Recent discovery (assume recent if timestamp is available)
        timestamp = finding.get('timestamp')
        if timestamp:
            try:
                if isinstance(timestamp, str):
                    ts = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
                else:
                    ts = timestamp

                age_hours = (datetime.now() - ts.replace(tzinfo=None)).total_seconds() / 3600
                if age_hours < 24:
                    score += 0.1

            except:
                pass

        return min(score, 1.0)

    def analyze_trend(self, finding: Dict[str, Any]) -> float:
        """
        Analyze if this type of finding is trending (appearing more frequently)

        Args:
            finding: Finding dictionary

        Returns:
            Trend score (0-1)
        """
        if not self.finding_history:
            return 0.5

        # Look for similar findings in history
        similar_count = 0
        recent_count = 0

        title_lower = finding.get('title', '').lower()
        analyzer = finding.get('analyzer', '')

        for historical in self.finding_history[-100:]:  # Last 100 findings
            h_title = historical.get('title', '').lower()
            h_analyzer = historical.get('analyzer', '')

            # Similar title or same analyzer
            if analyzer == h_analyzer or any(word in h_title for word in title_lower.split() if len(word) > 4):
                similar_count += 1

                # Recent similar finding
                h_timestamp = historical.get('timestamp')
                if h_timestamp:
                    try:
                        if isinstance(h_timestamp, str):
                            ts = datetime.fromisoformat(h_timestamp.replace('Z', '+00:00'))
                        else:
                            ts = h_timestamp

                        age_days = (datetime.now() - ts.replace(tzinfo=None)).total_seconds() / 86400
                        if age_days < 7:
                            recent_count += 1
                    except:
                        pass

        # Calculate trend score
        if similar_count == 0:
            return 0.5  # New finding type

        trend_score = 0.5 + (recent_count / similar_count) * 0.5

        return min(trend_score, 1.0)

    def prioritize(self, finding: Dict[str, Any]) -> PriorityScore:
        """
        Calculate comprehensive priority score for a finding

        Args:
            finding: Finding dictionary

        Returns:
            PriorityScore with breakdown
        """
        # Calculate individual scores
        cvss = self.calculate_cvss_score(finding)
        severity_score = (cvss / 10.0) * 100  # Convert to 0-100

        exploitability_score = self.assess_exploitability(finding) * 100
        impact_score = self.assess_business_impact(finding) * 100
        confidence_score = finding.get('confidence', 0.8) * 100
        urgency_score = self.calculate_urgency(finding) * 100
        trend_score = self.analyze_trend(finding) * 100

        # Weighted total score
        total_score = (
            severity_score * self.weights['severity'] +
            exploitability_score * self.weights['exploitability'] +
            impact_score * self.weights['impact'] +
            confidence_score * self.weights['confidence'] +
            urgency_score * self.weights['urgency'] +
            trend_score * self.weights['trend']
        )

        # Determine priority level
        if total_score >= 85:
            priority_level = 'critical'
        elif total_score >= 70:
            priority_level = 'high'
        elif total_score >= 50:
            priority_level = 'medium'
        else:
            priority_level = 'low'

        priority = PriorityScore(
            total_score=total_score,
            severity_score=severity_score,
            exploitability_score=exploitability_score,
            impact_score=impact_score,
            confidence_score=confidence_score,
            urgency_score=urgency_score,
            trend_score=trend_score,
            priority_level=priority_level
        )

        return priority

    def prioritize_findings(
        self,
        findings: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        Prioritize a list of findings

        Args:
            findings: List of findings

        Returns:
            Sorted list with priority scores added
        """
        prioritized = []

        for finding in findings:
            priority = self.prioritize(finding)

            # Add priority info to finding
            finding['priority'] = {
                'total_score': priority.total_score,
                'priority_level': priority.priority_level,
                'breakdown': {
                    'severity': priority.severity_score,
                    'exploitability': priority.exploitability_score,
                    'impact': priority.impact_score,
                    'confidence': priority.confidence_score,
                    'urgency': priority.urgency_score,
                    'trend': priority.trend_score
                },
                'cvss_score': self.calculate_cvss_score(finding)
            }

            prioritized.append(finding)

        # Sort by priority score (highest first)
        prioritized.sort(key=lambda x: x['priority']['total_score'], reverse=True)

        # Add to history for trend analysis
        self.finding_history.extend(findings)

        self.logger.info(
            f"Prioritized {len(findings)} findings: "
            f"{sum(1 for f in prioritized if f['priority']['priority_level'] == 'critical')} critical, "
            f"{sum(1 for f in prioritized if f['priority']['priority_level'] == 'high')} high"
        )

        return prioritized

    def get_top_findings(
        self,
        findings: List[Dict[str, Any]],
        limit: int = 10
    ) -> List[Dict[str, Any]]:
        """
        Get top N findings by priority

        Args:
            findings: List of findings
            limit: Number of top findings to return

        Returns:
            Top findings
        """
        prioritized = self.prioritize_findings(findings)
        return prioritized[:limit]

    def set_weights(self, weights: Dict[str, float]):
        """
        Set custom weights for prioritization factors

        Args:
            weights: Dictionary of factor weights (must sum to 1.0)
        """
        total = sum(weights.values())
        if abs(total - 1.0) > 0.01:
            raise ValueError(f"Weights must sum to 1.0, got {total}")

        self.weights = weights
        self.logger.info(f"Updated prioritization weights: {weights}")

    def get_stats(self) -> Dict[str, Any]:
        """Get prioritizer statistics"""
        return {
            'historical_findings': len(self.finding_history),
            'weights': self.weights
        }
