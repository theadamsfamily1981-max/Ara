"""
Smart Learning & Adaptation System

Learns from scan results and adapts strategy automatically:
- Endpoint effectiveness tracking
- Parameter optimization
- Pattern recognition
- Adaptive scan depth
- Resource allocation

Makes the system smarter over time.
"""

import logging
from typing import Dict, List, Any, Optional, Set
from dataclasses import dataclass, field
from datetime import datetime
from collections import defaultdict, deque
import json
import os


@dataclass
class EndpointStats:
    """Statistics for an endpoint"""
    url: str
    total_scans: int = 0
    findings_count: int = 0
    avg_findings_per_scan: float = 0.0
    last_scan: Optional[datetime] = None
    effectiveness_score: float = 0.5  # 0-1
    scan_duration_avg: float = 0.0
    recommended_depth: str = "normal"  # shallow, normal, deep


@dataclass
class PatternEffectiveness:
    """Effectiveness of a vulnerability pattern"""
    pattern_type: str
    occurrences: int = 0
    true_positives: int = 0
    false_positives: int = 0
    success_rate: float = 0.0
    avg_priority_score: float = 0.0


class AdaptiveLearner:
    """
    Smart learning system that adapts scanning strategy

    Learns from results to optimize:
    - Which endpoints to scan deeply
    - Which patterns to focus on
    - How to allocate resources
    - Optimal parameters for each target
    """

    def __init__(self, data_path: str = "data/adaptive_learning"):
        """
        Initialize adaptive learner

        Args:
            data_path: Path to store learning data
        """
        self.data_path = data_path
        self.logger = logging.getLogger("ml.adaptive_learner")

        # Endpoint tracking
        self.endpoint_stats: Dict[str, EndpointStats] = {}

        # Pattern tracking
        self.pattern_effectiveness: Dict[str, PatternEffectiveness] = {}

        # Analyzer performance
        self.analyzer_success_rates: Dict[str, float] = {}

        # Parameter history
        self.parameter_history: deque = deque(maxlen=1000)

        # Resource allocation
        self.resource_allocation: Dict[str, float] = {
            'deep_correlation': 1.0,
            'business_logic': 1.0,
            'chain_discovery': 1.0,
            'race_condition': 1.0,
            'semantic_analysis': 1.0,
            'transformation': 1.0,
            'permission': 1.0,
            'temporal': 1.0,
            'crypto': 1.0,
            'pattern_learning': 1.0
        }

        # Load existing data
        self.load_data()

    def track_endpoint(
        self,
        url: str,
        findings: List[Dict[str, Any]],
        duration_seconds: float
    ):
        """
        Track endpoint scan results

        Args:
            url: Endpoint URL
            findings: Findings from scan
            duration_seconds: Scan duration
        """
        if url not in self.endpoint_stats:
            self.endpoint_stats[url] = EndpointStats(url=url)

        stats = self.endpoint_stats[url]
        stats.total_scans += 1
        stats.findings_count += len(findings)
        stats.last_scan = datetime.now()

        # Update averages
        stats.avg_findings_per_scan = stats.findings_count / stats.total_scans

        if stats.scan_duration_avg == 0:
            stats.scan_duration_avg = duration_seconds
        else:
            # Running average
            stats.scan_duration_avg = (
                stats.scan_duration_avg * 0.7 + duration_seconds * 0.3
            )

        # Calculate effectiveness score
        # High findings + low duration = high effectiveness
        if duration_seconds > 0:
            findings_per_minute = (len(findings) / duration_seconds) * 60
            stats.effectiveness_score = min(findings_per_minute / 10.0, 1.0)

        # Recommend scan depth based on effectiveness
        if stats.effectiveness_score > 0.7:
            stats.recommended_depth = "deep"
        elif stats.effectiveness_score > 0.3:
            stats.recommended_depth = "normal"
        else:
            stats.recommended_depth = "shallow"

        self.logger.info(
            f"Tracked {url}: {len(findings)} findings, "
            f"effectiveness={stats.effectiveness_score:.2f}, "
            f"depth={stats.recommended_depth}"
        )

    def track_pattern(
        self,
        pattern_type: str,
        is_true_positive: bool,
        priority_score: float
    ):
        """
        Track pattern effectiveness

        Args:
            pattern_type: Type of vulnerability pattern
            is_true_positive: Whether it was a true positive
            priority_score: Priority score of finding
        """
        if pattern_type not in self.pattern_effectiveness:
            self.pattern_effectiveness[pattern_type] = PatternEffectiveness(
                pattern_type=pattern_type
            )

        pattern = self.pattern_effectiveness[pattern_type]
        pattern.occurrences += 1

        if is_true_positive:
            pattern.true_positives += 1
        else:
            pattern.false_positives += 1

        # Calculate success rate
        pattern.success_rate = (
            pattern.true_positives / pattern.occurrences
            if pattern.occurrences > 0 else 0.0
        )

        # Update average priority
        if pattern.avg_priority_score == 0:
            pattern.avg_priority_score = priority_score
        else:
            pattern.avg_priority_score = (
                pattern.avg_priority_score * 0.7 + priority_score * 0.3
            )

    def track_analyzer_performance(
        self,
        analyzer_name: str,
        findings: List[Dict[str, Any]],
        true_positive_rate: Optional[float] = None
    ):
        """
        Track analyzer performance

        Args:
            analyzer_name: Name of analyzer
            findings: Findings from analyzer
            true_positive_rate: TP rate if available
        """
        if true_positive_rate is not None:
            # Direct TP rate provided
            self.analyzer_success_rates[analyzer_name] = true_positive_rate
        else:
            # Estimate based on confidence and priority
            if findings:
                avg_confidence = sum(f.get('confidence', 0.5) for f in findings) / len(findings)
                self.analyzer_success_rates[analyzer_name] = avg_confidence

    def get_optimal_scan_depth(self, url: str) -> str:
        """
        Get recommended scan depth for URL

        Args:
            url: Target URL

        Returns:
            Depth recommendation (shallow/normal/deep)
        """
        if url in self.endpoint_stats:
            return self.endpoint_stats[url].recommended_depth

        return "normal"  # Default

    def get_high_value_endpoints(self, limit: int = 10) -> List[EndpointStats]:
        """
        Get highest value endpoints to focus on

        Args:
            limit: Max number of endpoints

        Returns:
            List of high-value endpoint stats
        """
        sorted_endpoints = sorted(
            self.endpoint_stats.values(),
            key=lambda x: x.effectiveness_score,
            reverse=True
        )

        return sorted_endpoints[:limit]

    def get_low_value_endpoints(self, limit: int = 10) -> List[EndpointStats]:
        """
        Get lowest value endpoints to skip/deprioritize

        Args:
            limit: Max number of endpoints

        Returns:
            List of low-value endpoint stats
        """
        sorted_endpoints = sorted(
            self.endpoint_stats.values(),
            key=lambda x: x.effectiveness_score
        )

        return sorted_endpoints[:limit]

    def get_effective_patterns(self, min_success_rate: float = 0.7) -> List[PatternEffectiveness]:
        """
        Get most effective vulnerability patterns

        Args:
            min_success_rate: Minimum success rate

        Returns:
            List of effective patterns
        """
        return [
            pattern for pattern in self.pattern_effectiveness.values()
            if pattern.success_rate >= min_success_rate and pattern.occurrences >= 5
        ]

    def get_ineffective_patterns(self, max_success_rate: float = 0.3) -> List[PatternEffectiveness]:
        """
        Get least effective patterns (skip these)

        Args:
            max_success_rate: Maximum success rate

        Returns:
            List of ineffective patterns
        """
        return [
            pattern for pattern in self.pattern_effectiveness.values()
            if pattern.success_rate <= max_success_rate and pattern.occurrences >= 5
        ]

    def optimize_analyzer_allocation(self) -> Dict[str, float]:
        """
        Optimize resource allocation across analyzers

        Returns:
            Dictionary of analyzer -> priority multiplier
        """
        # Allocate more resources to successful analyzers
        total_success = sum(self.analyzer_success_rates.values())

        if total_success == 0:
            return self.resource_allocation

        allocation = {}
        for analyzer, success_rate in self.analyzer_success_rates.items():
            # Normalize to 0.5-1.5 range
            allocation[analyzer] = 0.5 + (success_rate * 1.0)

        return allocation

    def should_scan_endpoint(self, url: str, threshold: float = 0.2) -> bool:
        """
        Decide if endpoint is worth scanning

        Args:
            url: Endpoint URL
            threshold: Minimum effectiveness threshold

        Returns:
            True if worth scanning
        """
        if url not in self.endpoint_stats:
            return True  # Unknown, give it a try

        stats = self.endpoint_stats[url]

        # Don't scan if consistently unproductive
        if stats.total_scans >= 3 and stats.effectiveness_score < threshold:
            return False

        return True

    def get_scan_recommendations(self, target_url: str) -> Dict[str, Any]:
        """
        Get comprehensive scan recommendations

        Args:
            target_url: Target URL

        Returns:
            Recommendations dictionary
        """
        recommendations = {
            'scan_depth': self.get_optimal_scan_depth(target_url),
            'high_value_endpoints': [
                e.url for e in self.get_high_value_endpoints(limit=5)
            ],
            'skip_endpoints': [
                e.url for e in self.get_low_value_endpoints(limit=5)
            ],
            'focus_patterns': [
                p.pattern_type for p in self.get_effective_patterns()
            ],
            'skip_patterns': [
                p.pattern_type for p in self.get_ineffective_patterns()
            ],
            'analyzer_allocation': self.optimize_analyzer_allocation(),
            'estimated_duration': self._estimate_scan_duration(target_url)
        }

        return recommendations

    def _estimate_scan_duration(self, target_url: str) -> float:
        """Estimate scan duration based on history"""
        if target_url in self.endpoint_stats:
            return self.endpoint_stats[target_url].scan_duration_avg

        # Average across all endpoints
        if self.endpoint_stats:
            avg = sum(e.scan_duration_avg for e in self.endpoint_stats.values()) / len(self.endpoint_stats)
            return avg

        return 300.0  # Default 5 minutes

    def save_data(self):
        """Save learning data to disk"""
        os.makedirs(self.data_path, exist_ok=True)

        data = {
            'endpoint_stats': {
                url: {
                    'total_scans': stats.total_scans,
                    'findings_count': stats.findings_count,
                    'avg_findings_per_scan': stats.avg_findings_per_scan,
                    'effectiveness_score': stats.effectiveness_score,
                    'scan_duration_avg': stats.scan_duration_avg,
                    'recommended_depth': stats.recommended_depth,
                    'last_scan': stats.last_scan.isoformat() if stats.last_scan else None
                }
                for url, stats in self.endpoint_stats.items()
            },
            'pattern_effectiveness': {
                pattern_type: {
                    'occurrences': pattern.occurrences,
                    'true_positives': pattern.true_positives,
                    'false_positives': pattern.false_positives,
                    'success_rate': pattern.success_rate,
                    'avg_priority_score': pattern.avg_priority_score
                }
                for pattern_type, pattern in self.pattern_effectiveness.items()
            },
            'analyzer_success_rates': self.analyzer_success_rates,
            'resource_allocation': self.resource_allocation
        }

        with open(os.path.join(self.data_path, 'learning_data.json'), 'w') as f:
            json.dump(data, f, indent=2)

        self.logger.info(f"Saved learning data to {self.data_path}")

    def load_data(self):
        """Load learning data from disk"""
        data_file = os.path.join(self.data_path, 'learning_data.json')

        if not os.path.exists(data_file):
            self.logger.info("No existing learning data found")
            return

        try:
            with open(data_file, 'r') as f:
                data = json.load(f)

            # Load endpoint stats
            for url, stats_data in data.get('endpoint_stats', {}).items():
                self.endpoint_stats[url] = EndpointStats(
                    url=url,
                    total_scans=stats_data['total_scans'],
                    findings_count=stats_data['findings_count'],
                    avg_findings_per_scan=stats_data['avg_findings_per_scan'],
                    effectiveness_score=stats_data['effectiveness_score'],
                    scan_duration_avg=stats_data['scan_duration_avg'],
                    recommended_depth=stats_data['recommended_depth'],
                    last_scan=datetime.fromisoformat(stats_data['last_scan']) if stats_data.get('last_scan') else None
                )

            # Load pattern effectiveness
            for pattern_type, pattern_data in data.get('pattern_effectiveness', {}).items():
                self.pattern_effectiveness[pattern_type] = PatternEffectiveness(
                    pattern_type=pattern_type,
                    occurrences=pattern_data['occurrences'],
                    true_positives=pattern_data['true_positives'],
                    false_positives=pattern_data['false_positives'],
                    success_rate=pattern_data['success_rate'],
                    avg_priority_score=pattern_data['avg_priority_score']
                )

            # Load analyzer success rates
            self.analyzer_success_rates = data.get('analyzer_success_rates', {})

            # Load resource allocation
            self.resource_allocation = data.get('resource_allocation', self.resource_allocation)

            self.logger.info(
                f"Loaded learning data: "
                f"{len(self.endpoint_stats)} endpoints, "
                f"{len(self.pattern_effectiveness)} patterns tracked"
            )

        except Exception as e:
            self.logger.error(f"Error loading learning data: {e}")

    def get_stats(self) -> Dict[str, Any]:
        """Get learning system statistics"""
        return {
            'endpoints_tracked': len(self.endpoint_stats),
            'patterns_tracked': len(self.pattern_effectiveness),
            'analyzers_tracked': len(self.analyzer_success_rates),
            'high_value_endpoints': len([
                e for e in self.endpoint_stats.values()
                if e.effectiveness_score > 0.7
            ]),
            'low_value_endpoints': len([
                e for e in self.endpoint_stats.values()
                if e.effectiveness_score < 0.3
            ]),
            'effective_patterns': len(self.get_effective_patterns()),
            'ineffective_patterns': len(self.get_ineffective_patterns())
        }
