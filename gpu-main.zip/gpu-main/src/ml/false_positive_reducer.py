"""
ML-Powered False Positive Reduction System

Uses machine learning to learn from validated findings and automatically
filter out false positives, improving signal-to-noise ratio over time.

Features:
- Supervised learning from user feedback
- Feature extraction from findings
- Random Forest classifier for high accuracy
- Confidence scoring
- Continuous learning
- Model persistence
"""

import os
import pickle
import logging
from typing import List, Dict, Any, Tuple, Optional
from dataclasses import dataclass
from datetime import datetime
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
import joblib


@dataclass
class ValidatedFinding:
    """A finding that has been validated by a human"""
    finding_id: str
    analyzer: str
    severity: str
    title: str
    description: str
    evidence: Dict[str, Any]
    is_true_positive: bool  # Human validation
    validation_timestamp: datetime
    validator: str


class FalsePositiveReducer:
    """
    ML-powered false positive reduction

    Learns from validated findings to automatically identify
    and filter false positives, improving over time.
    """

    def __init__(self, model_path: str = "data/ml_models/fp_reducer.pkl"):
        """
        Initialize false positive reducer

        Args:
            model_path: Path to save/load trained model
        """
        self.model_path = model_path
        self.model: Optional[RandomForestClassifier] = None
        self.text_vectorizer: Optional[TfidfVectorizer] = None
        self.scaler: Optional[StandardScaler] = None
        self.feature_names: List[str] = []

        self.logger = logging.getLogger("ml.fp_reducer")

        # Training data
        self.validated_findings: List[ValidatedFinding] = []

        # Load existing model if available
        self.load_model()

    def extract_features(self, finding: Dict[str, Any]) -> np.ndarray:
        """
        Extract features from a finding

        Features include:
        - Text features (title, description)
        - Severity score
        - Analyzer reliability
        - Confidence score
        - Evidence complexity
        - Pattern features

        Args:
            finding: Finding dictionary

        Returns:
            Feature vector
        """
        features = []

        # Severity score
        severity_scores = {'critical': 4, 'high': 3, 'medium': 2, 'low': 1, 'info': 0}
        features.append(severity_scores.get(finding.get('severity', 'info'), 0))

        # Confidence score
        features.append(finding.get('confidence', 0.5))

        # Title length (longer titles often indicate more detail)
        features.append(len(finding.get('title', '')))

        # Description length
        features.append(len(finding.get('description', '')))

        # Evidence complexity (number of evidence items)
        evidence = finding.get('evidence', {})
        features.append(len(evidence))

        # Evidence has URLs
        features.append(1 if any('url' in str(v).lower() for v in evidence.values()) else 0)

        # Evidence has status codes
        features.append(1 if any('status' in str(k).lower() for k, v in evidence.items()) else 0)

        # Evidence has request/response
        features.append(1 if any(k in evidence for k in ['request', 'response', 'payload']) else 0)

        # Title contains specific keywords (often indicators)
        title_lower = finding.get('title', '').lower()
        keywords = ['injection', 'xss', 'csrf', 'sqli', 'rce', 'ssrf', 'idor', 'lfi', 'rfi']
        features.append(sum(1 for kw in keywords if kw in title_lower))

        # Has CVE reference
        features.append(1 if 'cve-' in finding.get('description', '').lower() else 0)

        # Has remediation
        features.append(1 if finding.get('remediation') and len(finding.get('remediation', '')) > 50 else 0)

        # Analyzer-specific features (some analyzers are more accurate)
        analyzer_reliability = {
            'Deep Correlation Analyzer': 0.9,
            'Business Logic Mapper': 0.85,
            'Chain Discovery Engine': 0.95,
            'Race Condition Detector': 0.8,
            'Semantic Analyzer': 0.85,
            'Transformation Tracker': 0.9,
            'Permission Inferencer': 0.95,
            'Temporal Detector': 0.8,
            'Crypto Analyzer': 0.9,
            'Pattern Learner': 0.85
        }
        features.append(analyzer_reliability.get(finding.get('analyzer', ''), 0.7))

        return np.array(features)

    def extract_text_features(self, finding: Dict[str, Any]) -> str:
        """
        Extract text for TF-IDF vectorization

        Args:
            finding: Finding dictionary

        Returns:
            Combined text
        """
        text_parts = [
            finding.get('title', ''),
            finding.get('description', ''),
            finding.get('analyzer', ''),
            ' '.join(str(v) for v in finding.get('evidence', {}).values())
        ]

        return ' '.join(text_parts)

    def train(self, validated_findings: List[ValidatedFinding]) -> Dict[str, Any]:
        """
        Train the model on validated findings

        Args:
            validated_findings: List of validated findings

        Returns:
            Training metrics
        """
        if len(validated_findings) < 20:
            self.logger.warning(f"Not enough training data: {len(validated_findings)} samples. Need at least 20.")
            return {'error': 'Not enough training data', 'samples': len(validated_findings)}

        self.logger.info(f"Training false positive reducer on {len(validated_findings)} samples")

        # Convert to feature vectors
        X_numeric = []
        X_text = []
        y = []

        for vf in validated_findings:
            finding_dict = {
                'analyzer': vf.analyzer,
                'severity': vf.severity,
                'title': vf.title,
                'description': vf.description,
                'evidence': vf.evidence,
                'confidence': 0.8
            }

            X_numeric.append(self.extract_features(finding_dict))
            X_text.append(self.extract_text_features(finding_dict))
            y.append(1 if vf.is_true_positive else 0)

        X_numeric = np.array(X_numeric)
        y = np.array(y)

        # Text vectorization
        if self.text_vectorizer is None:
            self.text_vectorizer = TfidfVectorizer(
                max_features=100,
                min_df=2,
                stop_words='english'
            )

        X_text_vec = self.text_vectorizer.fit_transform(X_text).toarray()

        # Combine features
        X = np.hstack([X_numeric, X_text_vec])

        # Scale features
        if self.scaler is None:
            self.scaler = StandardScaler()

        X_scaled = self.scaler.fit_transform(X)

        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X_scaled, y, test_size=0.2, random_state=42, stratify=y
        )

        # Train Random Forest
        self.model = RandomForestClassifier(
            n_estimators=100,
            max_depth=10,
            min_samples_split=5,
            class_weight='balanced',
            random_state=42,
            n_jobs=-1
        )

        self.model.fit(X_train, y_train)

        # Evaluate
        y_pred = self.model.predict(X_test)
        y_pred_proba = self.model.predict_proba(X_test)

        # Metrics
        from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

        metrics = {
            'accuracy': accuracy_score(y_test, y_pred),
            'precision': precision_score(y_test, y_pred),
            'recall': recall_score(y_test, y_pred),
            'f1_score': f1_score(y_test, y_pred),
            'training_samples': len(X_train),
            'test_samples': len(X_test),
            'true_positives': int(sum(y)),
            'false_positives': int(len(y) - sum(y))
        }

        self.logger.info(f"Model trained: Accuracy={metrics['accuracy']:.2%}, F1={metrics['f1_score']:.2%}")

        # Save model
        self.save_model()

        # Store validated findings
        self.validated_findings = validated_findings

        return metrics

    def predict(self, finding: Dict[str, Any]) -> Tuple[bool, float]:
        """
        Predict if finding is a true positive

        Args:
            finding: Finding dictionary

        Returns:
            (is_true_positive, confidence)
        """
        if self.model is None:
            # No model trained yet, assume true positive
            return True, finding.get('confidence', 0.8)

        # Extract features
        X_numeric = self.extract_features(finding).reshape(1, -1)
        X_text = self.text_vectorizer.transform([self.extract_text_features(finding)]).toarray()
        X = np.hstack([X_numeric, X_text])
        X_scaled = self.scaler.transform(X)

        # Predict
        prediction = self.model.predict(X_scaled)[0]
        probabilities = self.model.predict_proba(X_scaled)[0]

        is_true_positive = bool(prediction)
        confidence = probabilities[1] if is_true_positive else probabilities[0]

        return is_true_positive, float(confidence)

    def filter_findings(
        self,
        findings: List[Dict[str, Any]],
        confidence_threshold: float = 0.7
    ) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
        """
        Filter findings, separating likely true positives from false positives

        Args:
            findings: List of findings
            confidence_threshold: Minimum confidence for true positive

        Returns:
            (likely_true_positives, likely_false_positives)
        """
        if self.model is None:
            # No model, return all as true positives
            return findings, []

        true_positives = []
        false_positives = []

        for finding in findings:
            is_tp, confidence = self.predict(finding)

            # Add ML prediction to finding
            finding['ml_prediction'] = {
                'is_true_positive': is_tp,
                'confidence': confidence,
                'filtered': not is_tp or confidence < confidence_threshold
            }

            if is_tp and confidence >= confidence_threshold:
                true_positives.append(finding)
            else:
                false_positives.append(finding)

        self.logger.info(
            f"Filtered {len(findings)} findings: "
            f"{len(true_positives)} likely true positives, "
            f"{len(false_positives)} likely false positives"
        )

        return true_positives, false_positives

    def add_validation(
        self,
        finding: Dict[str, Any],
        is_true_positive: bool,
        validator: str = "analyst"
    ):
        """
        Add a validated finding for continuous learning

        Args:
            finding: Finding dictionary
            is_true_positive: Whether it's a true positive
            validator: Who validated it
        """
        validated = ValidatedFinding(
            finding_id=finding.get('id', str(hash(str(finding)))),
            analyzer=finding.get('analyzer', 'Unknown'),
            severity=finding.get('severity', 'info'),
            title=finding.get('title', ''),
            description=finding.get('description', ''),
            evidence=finding.get('evidence', {}),
            is_true_positive=is_true_positive,
            validation_timestamp=datetime.now(),
            validator=validator
        )

        self.validated_findings.append(validated)

        # Retrain if we have enough new validations
        if len(self.validated_findings) % 10 == 0:
            self.logger.info(f"Retraining model with {len(self.validated_findings)} samples")
            self.train(self.validated_findings)

    def save_model(self):
        """Save trained model to disk"""
        if self.model is None:
            return

        os.makedirs(os.path.dirname(self.model_path), exist_ok=True)

        model_data = {
            'model': self.model,
            'text_vectorizer': self.text_vectorizer,
            'scaler': self.scaler,
            'validated_findings': self.validated_findings,
            'feature_names': self.feature_names,
            'timestamp': datetime.now()
        }

        joblib.dump(model_data, self.model_path)
        self.logger.info(f"Model saved to {self.model_path}")

    def load_model(self):
        """Load trained model from disk"""
        if not os.path.exists(self.model_path):
            self.logger.info("No existing model found, will train when data available")
            return

        try:
            model_data = joblib.load(self.model_path)

            self.model = model_data['model']
            self.text_vectorizer = model_data['text_vectorizer']
            self.scaler = model_data['scaler']
            self.validated_findings = model_data.get('validated_findings', [])
            self.feature_names = model_data.get('feature_names', [])

            self.logger.info(
                f"Model loaded from {self.model_path}: "
                f"{len(self.validated_findings)} training samples"
            )

        except Exception as e:
            self.logger.error(f"Error loading model: {e}")

    def get_feature_importance(self) -> Dict[str, float]:
        """Get feature importance scores"""
        if self.model is None:
            return {}

        feature_importance = self.model.feature_importances_

        # Top features
        indices = np.argsort(feature_importance)[-10:][::-1]

        return {
            f'feature_{i}': float(feature_importance[i])
            for i in indices
        }

    def get_stats(self) -> Dict[str, Any]:
        """Get reducer statistics"""
        if self.model is None:
            return {
                'trained': False,
                'training_samples': 0
            }

        tp_count = sum(1 for vf in self.validated_findings if vf.is_true_positive)
        fp_count = len(self.validated_findings) - tp_count

        return {
            'trained': True,
            'training_samples': len(self.validated_findings),
            'true_positives': tp_count,
            'false_positives': fp_count,
            'tp_ratio': tp_count / len(self.validated_findings) if self.validated_findings else 0,
            'feature_importance': self.get_feature_importance()
        }
