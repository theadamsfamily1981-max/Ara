"""
Leaderboard Tracking and Analytics
Monitors bug bounty leaderboards and tracks performance metrics.
"""

import asyncio
import logging
from typing import List, Dict, Optional
from datetime import datetime, timedelta
import aiohttp
from bs4 import BeautifulSoup
import json

logger = logging.getLogger(__name__)


class LeaderboardEntry:
    """Represents a leaderboard entry."""

    def __init__(self, rank: int, username: str, points: int, bounties_earned: float,
                 bugs_found: int, platform: str):
        self.rank = rank
        self.username = username
        self.points = points
        self.bounties_earned = bounties_earned
        self.bugs_found = bugs_found
        self.platform = platform
        self.timestamp = datetime.now()

    def to_dict(self) -> Dict:
        """Convert to dictionary."""
        return {
            'rank': self.rank,
            'username': self.username,
            'points': self.points,
            'bounties_earned': self.bounties_earned,
            'bugs_found': self.bugs_found,
            'platform': self.platform,
            'timestamp': self.timestamp.isoformat()
        }


class HackerOneLeaderboard:
    """Tracks HackerOne leaderboards."""

    BASE_URL = "https://hackerone.com"

    def __init__(self, username: Optional[str] = None):
        self.username = username

    async def get_global_leaderboard(self, limit: int = 100) -> List[LeaderboardEntry]:
        """Get global leaderboard."""
        entries = []

        try:
            url = f"{self.BASE_URL}/leaderboard"

            async with aiohttp.ClientSession() as session:
                async with session.get(url) as response:
                    if response.status == 200:
                        html = await response.text()
                        entries = self._parse_leaderboard(html)

        except Exception as e:
            logger.error(f"Error fetching HackerOne leaderboard: {e}")

        return entries[:limit]

    async def get_program_leaderboard(self, program_handle: str, limit: int = 50) -> List[LeaderboardEntry]:
        """Get program-specific leaderboard."""
        entries = []

        try:
            url = f"{self.BASE_URL}/{program_handle}/thanks"

            async with aiohttp.ClientSession() as session:
                async with session.get(url) as response:
                    if response.status == 200:
                        html = await response.text()
                        entries = self._parse_leaderboard(html)

        except Exception as e:
            logger.error(f"Error fetching program leaderboard: {e}")

        return entries[:limit]

    def _parse_leaderboard(self, html: str) -> List[LeaderboardEntry]:
        """Parse leaderboard HTML."""
        entries = []

        try:
            soup = BeautifulSoup(html, 'lxml')

            # This is a simplified parser - actual implementation would need
            # to handle the specific HTML structure of HackerOne leaderboards
            # which may require JavaScript rendering

            logger.info("Leaderboard parsing - simplified implementation")

        except Exception as e:
            logger.error(f"Leaderboard parsing error: {e}")

        return entries

    async def get_user_stats(self, username: Optional[str] = None) -> Dict:
        """Get user statistics."""
        username = username or self.username

        if not username:
            return {}

        stats = {
            'username': username,
            'rank': None,
            'reputation': None,
            'signal': None,
            'impact': None,
            'total_bounties': None,
            'total_reports': None,
            'platform': 'HackerOne'
        }

        try:
            url = f"{self.BASE_URL}/{username}"

            async with aiohttp.ClientSession() as session:
                async with session.get(url) as response:
                    if response.status == 200:
                        html = await response.text()
                        stats.update(self._parse_user_profile(html))

        except Exception as e:
            logger.error(f"Error fetching user stats: {e}")

        return stats

    def _parse_user_profile(self, html: str) -> Dict:
        """Parse user profile page."""
        data = {}

        try:
            soup = BeautifulSoup(html, 'lxml')

            # Parse reputation, signal, impact, etc.
            # This would need to be implemented based on actual HTML structure

        except Exception as e:
            logger.error(f"Profile parsing error: {e}")

        return data


class BugcrowdLeaderboard:
    """Tracks Bugcrowd leaderboards."""

    BASE_URL = "https://bugcrowd.com"

    def __init__(self, username: Optional[str] = None):
        self.username = username

    async def get_global_leaderboard(self, limit: int = 100) -> List[LeaderboardEntry]:
        """Get global leaderboard."""
        entries = []

        try:
            url = f"{self.BASE_URL}/leaderboard"

            async with aiohttp.ClientSession() as session:
                async with session.get(url) as response:
                    if response.status == 200:
                        html = await response.text()
                        entries = self._parse_leaderboard(html)

        except Exception as e:
            logger.error(f"Error fetching Bugcrowd leaderboard: {e}")

        return entries[:limit]

    def _parse_leaderboard(self, html: str) -> List[LeaderboardEntry]:
        """Parse leaderboard HTML."""
        entries = []

        try:
            soup = BeautifulSoup(html, 'lxml')
            # Parse leaderboard entries

        except Exception as e:
            logger.error(f"Leaderboard parsing error: {e}")

        return entries

    async def get_user_stats(self, username: Optional[str] = None) -> Dict:
        """Get user statistics."""
        username = username or self.username

        if not username:
            return {}

        stats = {
            'username': username,
            'rank': None,
            'points': None,
            'total_bounties': None,
            'submissions': None,
            'platform': 'Bugcrowd'
        }

        try:
            url = f"{self.BASE_URL}/researchers/{username}"

            async with aiohttp.ClientSession() as session:
                async with session.get(url) as response:
                    if response.status == 200:
                        html = await response.text()
                        stats.update(self._parse_user_profile(html))

        except Exception as e:
            logger.error(f"Error fetching user stats: {e}")

        return stats

    def _parse_user_profile(self, html: str) -> Dict:
        """Parse user profile page."""
        data = {}

        try:
            soup = BeautifulSoup(html, 'lxml')
            # Parse profile data

        except Exception as e:
            logger.error(f"Profile parsing error: {e}")

        return data


class PerformanceAnalytics:
    """Analyzes performance and provides insights."""

    def __init__(self, config: Dict):
        self.config = config
        self.history = []

    def add_snapshot(self, stats: Dict):
        """Add performance snapshot."""
        self.history.append({
            'timestamp': datetime.now().isoformat(),
            'stats': stats
        })

    def get_trends(self, days: int = 30) -> Dict:
        """Get performance trends."""
        cutoff = datetime.now() - timedelta(days=days)

        recent_snapshots = [
            s for s in self.history
            if datetime.fromisoformat(s['timestamp']) > cutoff
        ]

        if len(recent_snapshots) < 2:
            return {'insufficient_data': True}

        # Calculate trends
        first = recent_snapshots[0]['stats']
        last = recent_snapshots[-1]['stats']

        trends = {
            'period_days': days,
            'snapshots': len(recent_snapshots),
            'rank_change': self._calculate_change(first.get('rank'), last.get('rank'), inverse=True),
            'points_change': self._calculate_change(first.get('points'), last.get('points')),
            'bounties_change': self._calculate_change(first.get('total_bounties'), last.get('total_bounties')),
            'bugs_change': self._calculate_change(first.get('total_reports'), last.get('total_reports')),
        }

        return trends

    def _calculate_change(self, old_value: Optional[float], new_value: Optional[float], inverse: bool = False) -> Dict:
        """Calculate change between two values."""
        if old_value is None or new_value is None:
            return {'change': 0, 'percentage': 0}

        if inverse:
            # For rank, lower is better
            change = old_value - new_value
        else:
            change = new_value - old_value

        percentage = (change / old_value * 100) if old_value != 0 else 0

        return {
            'change': change,
            'percentage': round(percentage, 2)
        }

    def compare_with_competitors(self, my_stats: Dict, leaderboard: List[LeaderboardEntry]) -> Dict:
        """Compare performance with top researchers."""
        my_rank = my_stats.get('rank')

        if not my_rank:
            return {'error': 'No rank available'}

        # Find position in leaderboard
        top_10 = [e for e in leaderboard if e.rank <= 10]
        top_100 = [e for e in leaderboard if e.rank <= 100]

        analysis = {
            'my_rank': my_rank,
            'top_10_threshold': top_10[-1].points if top_10 else None,
            'top_100_threshold': top_100[-1].points if top_100 else None,
            'my_points': my_stats.get('points'),
            'gap_to_top_10': None,
            'gap_to_top_100': None,
        }

        my_points = my_stats.get('points', 0)

        if top_10:
            analysis['gap_to_top_10'] = top_10[-1].points - my_points

        if top_100:
            analysis['gap_to_top_100'] = top_100[-1].points - my_points

        return analysis


class LeaderboardTracker:
    """Main leaderboard tracking coordinator."""

    def __init__(self, config: Dict):
        self.config = config
        self.h1_tracker = HackerOneLeaderboard(
            username=config.get('platforms', {}).get('hackerone', {}).get('username')
        )
        self.bc_tracker = BugcrowdLeaderboard(
            username=config.get('platforms', {}).get('bugcrowd', {}).get('username')
        )
        self.analytics = PerformanceAnalytics(config)

    async def update_all_stats(self) -> Dict:
        """Update all leaderboard statistics."""
        stats = {
            'timestamp': datetime.now().isoformat(),
            'platforms': {}
        }

        # HackerOne stats
        if self.config.get('platforms', {}).get('hackerone', {}).get('enabled'):
            h1_stats = await self.h1_tracker.get_user_stats()
            h1_leaderboard = await self.h1_tracker.get_global_leaderboard()

            stats['platforms']['hackerone'] = {
                'user_stats': h1_stats,
                'leaderboard_snapshot': [e.to_dict() for e in h1_leaderboard[:10]]
            }

        # Bugcrowd stats
        if self.config.get('platforms', {}).get('bugcrowd', {}).get('enabled'):
            bc_stats = await self.bc_tracker.get_user_stats()
            bc_leaderboard = await self.bc_tracker.get_global_leaderboard()

            stats['platforms']['bugcrowd'] = {
                'user_stats': bc_stats,
                'leaderboard_snapshot': [e.to_dict() for e in bc_leaderboard[:10]]
            }

        # Add to analytics
        self.analytics.add_snapshot(stats)

        logger.info("Updated leaderboard statistics")
        return stats

    def generate_report(self) -> str:
        """Generate performance report."""
        trends = self.analytics.get_trends(days=30)

        report = f"""
# Bug Bounty Performance Report
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## 30-Day Trends
- Rank Change: {trends.get('rank_change', {}).get('change', 'N/A')}
- Points Change: {trends.get('points_change', {}).get('change', 'N/A')} ({trends.get('points_change', {}).get('percentage', 'N/A')}%)
- Bounties Change: ${trends.get('bounties_change', {}).get('change', 'N/A')}
- Bugs Found: {trends.get('bugs_change', {}).get('change', 'N/A')}

## Goals
- Current Rank: [Current Rank]
- Target: Top 100
- Gap: [Points needed]

## Recommendations
1. Focus on high-severity vulnerabilities (Critical/High)
2. Target programs with higher payouts
3. Improve response time to new programs
4. Diversify vulnerability types

---
*Automated Performance Analytics*
"""

        return report
