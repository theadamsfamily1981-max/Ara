"""
JWT (JSON Web Token) Security Analyzer
Detects JWT-related vulnerabilities and misconfigurations.
"""

import asyncio
import aiohttp
import json
import logging
import base64
import hmac
import hashlib
from typing import List, Dict, Optional, Tuple
from datetime import datetime
import re

logger = logging.getLogger(__name__)


class JWTAnalyzer:
    """Analyzer for JWT security vulnerabilities."""

    def __init__(self, config: Dict):
        self.config = config
        # Common weak secrets for brute force
        self.weak_secrets = [
            'secret', 'secret123', 'password', 'password123', '123456', '12345678',
            'admin', 'root', 'test', 'demo', 'jwt_secret', 'your-256-bit-secret',
            '', 'null', 'undefined', 'key', 'secretkey', 'mysecret', 'jwtsecret',
            'HS256', 'HS384', 'HS512'
        ]

    async def analyze(self, url: str, jwt_token: str) -> List[Dict]:
        """
        Comprehensive JWT security analysis.

        Tests for:
        - Algorithm confusion (alg: none, RS256 to HS256)
        - Weak secret brute force
        - Claims injection
        - Expired/invalid signature
        - Kid (Key ID) manipulation
        - JKU/X5U header injection
        - SQL injection in claims
        """
        vulnerabilities = []

        # Decode JWT
        header, payload, signature = self._decode_jwt(jwt_token)

        if not header or not payload:
            logger.warning(f"Invalid JWT format: {jwt_token[:50]}...")
            return vulnerabilities

        logger.info(f"Analyzing JWT: alg={header.get('alg')}, claims={list(payload.keys())}")

        # Run all JWT tests
        tests = [
            self._test_none_algorithm(url, jwt_token, header, payload),
            self._test_algorithm_confusion(url, jwt_token, header, payload),
            self._test_weak_secret(jwt_token, header, payload),
            self._test_claims_injection(url, jwt_token, header, payload),
            self._test_kid_manipulation(url, jwt_token, header, payload),
            self._test_jku_injection(url, jwt_token, header, payload),
            self._test_expired_token(url, jwt_token, payload),
            self._test_blank_signature(url, jwt_token, header, payload)
        ]

        results = await asyncio.gather(*tests, return_exceptions=True)

        for result in results:
            if isinstance(result, dict) and result:
                vulnerabilities.append(result)
            elif isinstance(result, list):
                vulnerabilities.extend(result)

        logger.info(f"JWT analysis complete: {len(vulnerabilities)} issues found")
        return vulnerabilities

    def _decode_jwt(self, token: str) -> Tuple[Optional[Dict], Optional[Dict], str]:
        """Decode JWT token into header, payload, and signature."""
        try:
            parts = token.split('.')
            if len(parts) != 3:
                return None, None, ''

            # Decode header
            header_b64 = parts[0] + '=' * (4 - len(parts[0]) % 4)  # Add padding
            header = json.loads(base64.urlsafe_b64decode(header_b64))

            # Decode payload
            payload_b64 = parts[1] + '=' * (4 - len(parts[1]) % 4)
            payload = json.loads(base64.urlsafe_b64decode(payload_b64))

            signature = parts[2]

            return header, payload, signature

        except Exception as e:
            logger.debug(f"JWT decode error: {e}")
            return None, None, ''

    def _encode_jwt_part(self, data: Dict) -> str:
        """Encode dictionary to JWT base64url format."""
        json_str = json.dumps(data, separators=(',', ':'))
        encoded = base64.urlsafe_b64encode(json_str.encode()).decode()
        return encoded.rstrip('=')  # Remove padding

    async def _test_none_algorithm(self, url: str, original_token: str, header: Dict, payload: Dict) -> Optional[Dict]:
        """Test for 'none' algorithm acceptance."""
        try:
            # Create token with alg: none
            modified_header = header.copy()
            modified_header['alg'] = 'none'

            new_token = f"{self._encode_jwt_part(modified_header)}.{self._encode_jwt_part(payload)}."

            # Try to use the token
            if await self._test_token(url, new_token):
                return {
                    'name': 'JWT Algorithm None Acceptance',
                    'severity': 'critical',
                    'category': 'jwt',
                    'url': url,
                    'description': 'The application accepts JWT tokens with "alg": "none", allowing '
                                  'unsigned tokens to be accepted. This means anyone can forge valid tokens.',
                    'proof_of_concept': f'Modified token: {new_token}',
                    'remediation': 'Reject tokens with "alg": "none". Explicitly whitelist allowed algorithms. '
                                 'Use libraries that reject none algorithm by default.',
                    'discovered_at': datetime.now().isoformat()
                }

        except Exception as e:
            logger.debug(f"None algorithm test error: {e}")

        return None

    async def _test_algorithm_confusion(self, url: str, original_token: str, header: Dict, payload: Dict) -> Optional[Dict]:
        """Test for RS256 to HS256 algorithm confusion."""
        try:
            if header.get('alg', '').startswith('RS'):
                # Try changing RS256 to HS256
                modified_header = header.copy()
                modified_header['alg'] = 'HS256'

                # Create new token (signature will be wrong, but that's the point)
                new_token_base = f"{self._encode_jwt_part(modified_header)}.{self._encode_jwt_part(payload)}"

                # Try with common public key as secret
                for secret in ['public', 'public.pem', 'cert', 'certificate']:
                    signature = hmac.new(
                        secret.encode(),
                        new_token_base.encode(),
                        hashlib.sha256
                    ).digest()
                    sig_b64 = base64.urlsafe_b64encode(signature).decode().rstrip('=')

                    new_token = f"{new_token_base}.{sig_b64}"

                    if await self._test_token(url, new_token):
                        return {
                            'name': 'JWT Algorithm Confusion (RS256 to HS256)',
                            'severity': 'critical',
                            'category': 'jwt',
                            'url': url,
                            'description': 'The application is vulnerable to algorithm confusion attack. '
                                          'It accepts tokens signed with HS256 using the public key as secret. '
                                          'This allows attackers to forge valid tokens if they can obtain the public key.',
                            'proof_of_concept': f'Changed alg from {header.get("alg")} to HS256, signed with public key',
                            'remediation': 'Explicitly verify the algorithm matches expected type. '
                                         'Do not use the same key for multiple algorithms. '
                                         'Use algorithm-specific verification functions.',
                            'discovered_at': datetime.now().isoformat()
                        }

        except Exception as e:
            logger.debug(f"Algorithm confusion test error: {e}")

        return None

    async def _test_weak_secret(self, token: str, header: Dict, payload: Dict) -> Optional[Dict]:
        """Test for weak JWT secret."""
        if not header.get('alg', '').startswith('HS'):
            return None  # Only applies to HMAC algorithms

        try:
            token_base = '.'.join(token.split('.')[:2])

            for secret in self.weak_secrets:
                # Calculate signature with test secret
                if header['alg'] == 'HS256':
                    hash_func = hashlib.sha256
                elif header['alg'] == 'HS384':
                    hash_func = hashlib.sha384
                elif header['alg'] == 'HS512':
                    hash_func = hashlib.sha512
                else:
                    continue

                signature = hmac.new(
                    secret.encode(),
                    token_base.encode(),
                    hash_func
                ).digest()

                sig_b64 = base64.urlsafe_b64encode(signature).decode().rstrip('=')

                # Check if matches
                if sig_b64 == token.split('.')[2]:
                    return {
                        'name': 'JWT Weak Secret',
                        'severity': 'critical',
                        'category': 'jwt',
                        'url': 'N/A',
                        'description': f'The JWT is signed with a weak secret: "{secret}". '
                                      f'This allows anyone to forge valid tokens and impersonate any user.',
                        'proof_of_concept': f'JWT secret brute-forced: {secret}',
                        'remediation': 'Use a strong, randomly generated secret (minimum 256 bits). '
                                     'Store secrets securely in environment variables or key management systems. '
                                     'Rotate secrets regularly.',
                        'discovered_at': datetime.now().isoformat()
                    }

        except Exception as e:
            logger.debug(f"Weak secret test error: {e}")

        return None

    async def _test_claims_injection(self, url: str, original_token: str, header: Dict, payload: Dict) -> List[Dict]:
        """Test for claims injection vulnerabilities."""
        vulnerabilities = []

        try:
            # Test 1: Add admin claim
            modified_payload = payload.copy()
            modified_payload['admin'] = True
            modified_payload['role'] = 'admin'

            new_token = f"{self._encode_jwt_part(header)}.{self._encode_jwt_part(modified_payload)}."

            if await self._test_token(url, new_token):
                vulnerabilities.append({
                    'name': 'JWT Claims Injection - Admin Privilege Escalation',
                    'severity': 'critical',
                    'category': 'jwt',
                    'url': url,
                    'description': 'The application accepts JWT tokens with injected admin claims. '
                                  'An attacker can add "admin": true or "role": "admin" to gain admin privileges.',
                    'proof_of_concept': json.dumps(modified_payload, indent=2),
                    'remediation': 'Always verify JWT signature before trusting claims. '
                                 'Never accept unsigned tokens. Validate critical claims server-side.',
                    'discovered_at': datetime.now().isoformat()
                })

            # Test 2: Modify user ID
            if 'user_id' in payload or 'sub' in payload:
                modified_payload = payload.copy()
                id_field = 'user_id' if 'user_id' in payload else 'sub'
                modified_payload[id_field] = '1'  # Try admin/root user ID

                new_token = f"{self._encode_jwt_part(header)}.{self._encode_jwt_part(modified_payload)}."

                if await self._test_token(url, new_token):
                    vulnerabilities.append({
                        'name': 'JWT Claims Injection - User ID Manipulation',
                        'severity': 'critical',
                        'category': 'jwt',
                        'url': url,
                        'description': f'The application accepts JWT tokens with modified {id_field} claim. '
                                      f'An attacker can change their user ID to access other users\' accounts.',
                        'proof_of_concept': f'Changed {id_field} to: 1',
                        'remediation': 'Always verify JWT signature. Never trust unsigned tokens. '
                                     'Validate user identity server-side.',
                        'discovered_at': datetime.now().isoformat()
                    })

        except Exception as e:
            logger.debug(f"Claims injection test error: {e}")

        return vulnerabilities

    async def _test_kid_manipulation(self, url: str, original_token: str, header: Dict, payload: Dict) -> Optional[Dict]:
        """Test for Key ID (kid) header manipulation."""
        if 'kid' not in header:
            return None

        try:
            # Test path traversal in kid
            modified_header = header.copy()
            modified_header['kid'] = '../../../dev/null'

            new_token = f"{self._encode_jwt_part(modified_header)}.{self._encode_jwt_part(payload)}."

            # Note: Can't fully test without actually verifying, but flag it for manual review
            return {
                'name': 'JWT Key ID (kid) Present - Potential Manipulation Vector',
                'severity': 'medium',
                'category': 'jwt',
                'url': url,
                'description': 'The JWT uses the "kid" (Key ID) header parameter. '
                              'If not properly validated, this can be exploited for: '
                              '1) Path traversal to use arbitrary files as signing key '
                              '2) SQL injection if kid is used in database query '
                              '3) Command injection if kid is used in system commands',
                'proof_of_concept': f'Original kid: {header["kid"]}',
                'remediation': 'Validate kid parameter strictly. Use whitelist of allowed key IDs. '
                             'Never use kid value directly in file paths, SQL queries, or system commands.',
                'discovered_at': datetime.now().isoformat()
            }

        except Exception as e:
            logger.debug(f"Kid manipulation test error: {e}")

        return None

    async def _test_jku_injection(self, url: str, original_token: str, header: Dict, payload: Dict) -> Optional[Dict]:
        """Test for JKU (JSON Web Key URL) injection."""
        if 'jku' in header or 'x5u' in header:
            return {
                'name': 'JWT JKU/X5U Header Present - SSRF Risk',
                'severity': 'high',
                'category': 'jwt',
                'url': url,
                'description': 'The JWT uses "jku" or "x5u" header which references external URL for keys. '
                              'If not validated, attackers can host their own keys and sign arbitrary tokens. '
                              'This may also be exploitable for SSRF attacks.',
                'proof_of_concept': f'Header contains: {header.get("jku") or header.get("x5u")}',
                'remediation': 'Never trust jku/x5u headers. Use hardcoded key locations. '
                             'If external keys are required, strictly validate URLs against whitelist.',
                'discovered_at': datetime.now().isoformat()
            }

        return None

    async def _test_expired_token(self, url: str, token: str, payload: Dict) -> Optional[Dict]:
        """Test if expired tokens are accepted."""
        if 'exp' in payload:
            try:
                import time
                exp_time = payload['exp']
                current_time = int(time.time())

                if exp_time < current_time:
                    # Token is expired, test if still accepted
                    if await self._test_token(url, token):
                        return {
                            'name': 'Expired JWT Token Accepted',
                            'severity': 'high',
                            'category': 'jwt',
                            'url': url,
                            'description': 'The application accepts expired JWT tokens. '
                                          'This allows attackers to use stolen tokens indefinitely.',
                            'proof_of_concept': f'Token expired at: {datetime.fromtimestamp(exp_time).isoformat()}, '
                                              f'but still accepted',
                            'remediation': 'Always validate token expiration (exp claim). '
                                         'Reject tokens past their expiration time. '
                                         'Implement short expiration times (15-60 minutes).',
                            'discovered_at': datetime.now().isoformat()
                        }

            except Exception as e:
                logger.debug(f"Expired token test error: {e}")

        return None

    async def _test_blank_signature(self, url: str, original_token: str, header: Dict, payload: Dict) -> Optional[Dict]:
        """Test if blank signature is accepted."""
        try:
            new_token = f"{self._encode_jwt_part(header)}.{self._encode_jwt_part(payload)}."

            if await self._test_token(url, new_token):
                return {
                    'name': 'JWT Blank Signature Accepted',
                    'severity': 'critical',
                    'category': 'jwt',
                    'url': url,
                    'description': 'The application accepts JWT tokens with blank/empty signatures. '
                                  'This allows anyone to forge valid tokens.',
                    'proof_of_concept': 'Token with empty signature was accepted',
                    'remediation': 'Always verify JWT signature. Reject tokens with missing or empty signatures. '
                                 'Use well-tested JWT libraries that enforce signature verification.',
                    'discovered_at': datetime.now().isoformat()
                }

        except Exception as e:
            logger.debug(f"Blank signature test error: {e}")

        return None

    async def _test_token(self, url: str, token: str) -> bool:
        """Test if a JWT token is accepted by the application."""
        try:
            headers = {
                'Authorization': f'Bearer {token}',
                'Cookie': f'token={token}'
            }

            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url,
                    headers=headers,
                    timeout=aiohttp.ClientTimeout(total=10),
                    ssl=False
                ) as response:
                    # If not 401/403, token might be accepted
                    return response.status not in [401, 403]

        except Exception as e:
            logger.debug(f"Token test error: {e}")
            return False


def extract_jwt_from_response(response_text: str) -> List[str]:
    """Extract JWT tokens from HTTP response."""
    # JWT pattern: header.payload.signature
    jwt_pattern = r'eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+'
    return re.findall(jwt_pattern, response_text)


async def analyze_jwt_token(token: str, url: str, config: Dict) -> List[Dict]:
    """Convenience function to analyze a JWT token."""
    analyzer = JWTAnalyzer(config)
    return await analyzer.analyze(url, token)
