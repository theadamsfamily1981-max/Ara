"""
GraphQL Security Scanner
Detects GraphQL-specific vulnerabilities including introspection, injection, and DoS.
"""

import asyncio
import aiohttp
import json
import logging
from typing import List, Dict, Optional
from datetime import datetime

logger = logging.getLogger(__name__)


class GraphQLScanner:
    """Scanner for GraphQL-specific vulnerabilities."""

    def __init__(self, config: Dict):
        self.config = config
        self.vulnerabilities = []

    async def scan(self, url: str) -> List[Dict]:
        """
        Comprehensive GraphQL security scan.

        Tests for:
        - Introspection enabled
        - Query depth/complexity limits
        - GraphQL injection
        - Batch query attacks
        - Field suggestions
        - Alias-based DoS
        """
        vulnerabilities = []

        # Test for GraphQL endpoint
        if not await self._is_graphql_endpoint(url):
            logger.debug(f"{url} is not a GraphQL endpoint")
            return vulnerabilities

        logger.info(f"GraphQL endpoint detected: {url}")

        # Run all GraphQL tests
        tests = [
            self._test_introspection(url),
            self._test_query_depth_limit(url),
            self._test_batch_queries(url),
            self._test_graphql_injection(url),
            self._test_field_suggestions(url),
            self._test_alias_dos(url),
            self._test_directive_overloading(url)
        ]

        results = await asyncio.gather(*tests, return_exceptions=True)

        for result in results:
            if isinstance(result, dict) and result:
                vulnerabilities.append(result)
            elif isinstance(result, list):
                vulnerabilities.extend(result)

        logger.info(f"GraphQL scan complete: {len(vulnerabilities)} issues found")
        return vulnerabilities

    async def _is_graphql_endpoint(self, url: str) -> bool:
        """Check if URL is a GraphQL endpoint."""
        try:
            query = {"query": "{__typename}"}

            async with aiohttp.ClientSession() as session:
                async with session.post(
                    url,
                    json=query,
                    timeout=aiohttp.ClientTimeout(total=10),
                    ssl=False
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        if 'data' in data or 'errors' in data:
                            return True

        except Exception as e:
            logger.debug(f"GraphQL endpoint check error: {e}")

        return False

    async def _test_introspection(self, url: str) -> Optional[Dict]:
        """Test if GraphQL introspection is enabled."""
        introspection_query = {
            "query": """
                query IntrospectionQuery {
                    __schema {
                        queryType { name }
                        mutationType { name }
                        subscriptionType { name }
                        types {
                            ...FullType
                        }
                        directives {
                            name
                            description
                            locations
                            args {
                                ...InputValue
                            }
                        }
                    }
                }

                fragment FullType on __Type {
                    kind
                    name
                    description
                    fields(includeDeprecated: true) {
                        name
                        description
                        args {
                            ...InputValue
                        }
                        type {
                            ...TypeRef
                        }
                        isDeprecated
                        deprecationReason
                    }
                    inputFields {
                        ...InputValue
                    }
                    interfaces {
                        ...TypeRef
                    }
                    enumValues(includeDeprecated: true) {
                        name
                        description
                        isDeprecated
                        deprecationReason
                    }
                    possibleTypes {
                        ...TypeRef
                    }
                }

                fragment InputValue on __InputValue {
                    name
                    description
                    type { ...TypeRef }
                    defaultValue
                }

                fragment TypeRef on __Type {
                    kind
                    name
                    ofType {
                        kind
                        name
                        ofType {
                            kind
                            name
                            ofType {
                                kind
                                name
                                ofType {
                                    kind
                                    name
                                    ofType {
                                        kind
                                        name
                                        ofType {
                                            kind
                                            name
                                            ofType {
                                                kind
                                                name
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            """
        }

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    url,
                    json=introspection_query,
                    timeout=aiohttp.ClientTimeout(total=15),
                    ssl=False
                ) as response:
                    if response.status == 200:
                        data = await response.json()

                        if 'data' in data and data['data'] and '__schema' in data['data']:
                            schema = data['data']['__schema']
                            types_count = len(schema.get('types', []))

                            return {
                                'name': 'GraphQL Introspection Enabled',
                                'severity': 'medium',
                                'category': 'graphql',
                                'url': url,
                                'description': f'GraphQL introspection is enabled, exposing the entire API schema. '
                                              f'Found {types_count} types defined. This allows attackers to map the entire '
                                              f'API structure including hidden queries, mutations, and data types.',
                                'proof_of_concept': json.dumps(introspection_query, indent=2),
                                'remediation': 'Disable introspection in production environments. In Apollo Server, set '
                                             'introspection: false in the configuration.',
                                'discovered_at': datetime.now().isoformat()
                            }

        except Exception as e:
            logger.debug(f"Introspection test error: {e}")

        return None

    async def _test_query_depth_limit(self, url: str) -> Optional[Dict]:
        """Test for missing query depth limits."""
        # Create deeply nested query
        deep_query = "query { "
        field_name = "user"
        depth = 50  # Try 50 levels of nesting

        for i in range(depth):
            deep_query += f"{field_name} {{ "

        deep_query += "id "

        for i in range(depth):
            deep_query += "} "

        deep_query += "}"

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    url,
                    json={"query": deep_query},
                    timeout=aiohttp.ClientTimeout(total=30),
                    ssl=False
                ) as response:
                    # If server accepts or tries to process deeply nested query
                    if response.status in [200, 500]:
                        data = await response.text()

                        # Check if server processed it (even if errored)
                        if 'Cannot' not in data and 'depth' not in data.lower():
                            return {
                                'name': 'GraphQL Query Depth Limit Missing',
                                'severity': 'high',
                                'category': 'graphql',
                                'url': url,
                                'description': 'The GraphQL endpoint does not enforce query depth limits. '
                                              'An attacker can craft deeply nested queries to cause resource exhaustion and DoS.',
                                'proof_of_concept': f'Depth {depth} query accepted: {deep_query[:200]}...',
                                'remediation': 'Implement query depth limiting. In Apollo Server, use graphql-depth-limit. '
                                             'Recommended max depth: 7-10 levels.',
                                'discovered_at': datetime.now().isoformat()
                            }

        except asyncio.TimeoutError:
            # Timeout might indicate processing is happening
            return {
                'name': 'GraphQL Query Depth Limit - Potential DoS',
                'severity': 'high',
                'category': 'graphql',
                'url': url,
                'description': 'Deeply nested query caused timeout, indicating potential DoS vulnerability.',
                'proof_of_concept': f'Query depth: {depth} levels',
                'remediation': 'Implement strict query depth limits and timeouts.',
                'discovered_at': datetime.now().isoformat()
            }
        except Exception as e:
            logger.debug(f"Query depth test error: {e}")

        return None

    async def _test_batch_queries(self, url: str) -> Optional[Dict]:
        """Test for batch query attacks."""
        # Send 100 queries at once
        batch_queries = [
            {"query": "{__typename}"} for _ in range(100)
        ]

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    url,
                    json=batch_queries,
                    timeout=aiohttp.ClientTimeout(total=30),
                    ssl=False
                ) as response:
                    if response.status == 200:
                        data = await response.json()

                        # If server processes all queries
                        if isinstance(data, list) and len(data) >= 50:
                            return {
                                'name': 'GraphQL Batch Query Attack - No Limit',
                                'severity': 'medium',
                                'category': 'graphql',
                                'url': url,
                                'description': f'The GraphQL endpoint processes batch queries without limits. '
                                              f'Successfully processed {len(data)} queries in a single request. '
                                              f'This can be abused for DoS or rate limit bypass.',
                                'proof_of_concept': f'Sent {len(batch_queries)} queries, received {len(data)} responses',
                                'remediation': 'Limit the number of queries per request (recommended: 5-10 max). '
                                             'Implement query cost analysis.',
                                'discovered_at': datetime.now().isoformat()
                            }

        except Exception as e:
            logger.debug(f"Batch query test error: {e}")

        return None

    async def _test_graphql_injection(self, url: str) -> List[Dict]:
        """Test for GraphQL injection vulnerabilities."""
        vulnerabilities = []

        injection_payloads = [
            # String injection
            {'query': '{ user(id: "1\\"") { name } }'},
            # Number injection
            {'query': '{ user(id: 1 OR 1=1) { name } }'},
            # Comment injection
            {'query': '{ user(id: "1#") { name } }'},
            # Escaped injection
            {'query': '{ user(id: "1\\u0022) { name } }'}
        ]

        for payload in injection_payloads:
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.post(
                        url,
                        json=payload,
                        timeout=aiohttp.ClientTimeout(total=10),
                        ssl=False
                    ) as response:
                        if response.status == 200:
                            data = await response.json()

                            # Check for successful injection or interesting errors
                            data_str = json.dumps(data)
                            if any(keyword in data_str for keyword in ['syntax', 'parse', 'unexpected', 'invalid']):
                                continue  # Normal error, not a vuln

                            # If data returned without proper error, might be injectable
                            if 'data' in data and data['data']:
                                vulnerabilities.append({
                                    'name': 'Potential GraphQL Injection',
                                    'severity': 'high',
                                    'category': 'graphql',
                                    'url': url,
                                    'description': 'GraphQL endpoint may be vulnerable to injection attacks. '
                                                  'Malformed input was processed without proper validation.',
                                    'proof_of_concept': json.dumps(payload),
                                    'remediation': 'Implement strict input validation and use parameterized queries. '
                                                 'Never concatenate user input into GraphQL queries.',
                                    'discovered_at': datetime.now().isoformat()
                                })
                                break  # Found one, move on

            except Exception as e:
                logger.debug(f"Injection test error: {e}")

        return vulnerabilities

    async def _test_field_suggestions(self, url: str) -> Optional[Dict]:
        """Test if field suggestions leak information."""
        # Query with typo to trigger suggestions
        query = {"query": "{ usr { id } }"}  # 'usr' instead of 'user'

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    url,
                    json=query,
                    timeout=aiohttp.ClientTimeout(total=10),
                    ssl=False
                ) as response:
                    if response.status == 200:
                        data = await response.json()

                        if 'errors' in data:
                            error_msg = json.dumps(data['errors'])
                            # Check if error message suggests fields
                            if 'Did you mean' in error_msg or 'suggest' in error_msg.lower():
                                return {
                                    'name': 'GraphQL Field Suggestions Enabled',
                                    'severity': 'low',
                                    'category': 'graphql',
                                    'url': url,
                                    'description': 'GraphQL endpoint provides field suggestions in error messages, '
                                                  'which can help attackers discover hidden fields and API structure.',
                                    'proof_of_concept': error_msg[:500],
                                    'remediation': 'Disable field suggestions in production. Provide generic error messages.',
                                    'discovered_at': datetime.now().isoformat()
                                }

        except Exception as e:
            logger.debug(f"Field suggestions test error: {e}")

        return None

    async def _test_alias_dos(self, url: str) -> Optional[Dict]:
        """Test for alias-based DoS attacks."""
        # Create query with many aliases
        aliases = '\n'.join([f'alias{i}: __typename' for i in range(1000)])
        query = {"query": f"{{ {aliases} }}"}

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    url,
                    json=query,
                    timeout=aiohttp.ClientTimeout(total=10),
                    ssl=False
                ) as response:
                    if response.status == 200:
                        return {
                            'name': 'GraphQL Alias-Based DoS',
                            'severity': 'medium',
                            'category': 'graphql',
                            'url': url,
                            'description': 'The GraphQL endpoint accepts queries with excessive aliases, '
                                          'which can be used for DoS attacks by requesting the same field '
                                          'thousands of times with different aliases.',
                            'proof_of_concept': f'Query with 1000 aliases was accepted',
                            'remediation': 'Limit the number of aliases per query (recommended: 10-50 max).',
                            'discovered_at': datetime.now().isoformat()
                        }

        except asyncio.TimeoutError:
            return {
                'name': 'GraphQL Alias-Based DoS (Confirmed)',
                'severity': 'high',
                'category': 'graphql',
                'url': url,
                'description': 'Alias attack caused timeout, confirming DoS vulnerability.',
                'proof_of_concept': 'Query with 1000 aliases caused timeout',
                'remediation': 'Implement strict alias limits and query complexity analysis.',
                'discovered_at': datetime.now().isoformat()
            }
        except Exception as e:
            logger.debug(f"Alias DoS test error: {e}")

        return None

    async def _test_directive_overloading(self, url: str) -> Optional[Dict]:
        """Test for directive overloading attacks."""
        # Query with many directives
        query = {
            "query": "{ __typename " + "@skip(if: false) " * 1000 + "}"
        }

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    url,
                    json=query,
                    timeout=aiohttp.ClientTimeout(total=10),
                    ssl=False
                ) as response:
                    if response.status == 200:
                        return {
                            'name': 'GraphQL Directive Overloading',
                            'severity': 'medium',
                            'category': 'graphql',
                            'url': url,
                            'description': 'The GraphQL endpoint accepts queries with excessive directives, '
                                          'which can cause parsing overhead and DoS.',
                            'proof_of_concept': 'Query with 1000 @skip directives was accepted',
                            'remediation': 'Limit the number of directives per query.',
                            'discovered_at': datetime.now().isoformat()
                        }

        except Exception as e:
            logger.debug(f"Directive overloading test error: {e}")

        return None


async def scan_graphql(url: str, config: Dict) -> List[Dict]:
    """Convenience function to scan a GraphQL endpoint."""
    scanner = GraphQLScanner(config)
    return await scanner.scan(url)
