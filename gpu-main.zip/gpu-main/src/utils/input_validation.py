"""
Input validation utilities for web GUI.
"""

import re
from typing import Tuple


def validate_platform(platform: str) -> Tuple[bool, str]:
    """
    Validate platform name.

    Returns: (is_valid, error_message)
    """
    if not platform:
        return False, "Platform is required"

    if len(platform) > 50:
        return False, "Platform name too long (max 50 characters)"

    # Only allow alphanumeric, hyphens, and underscores
    if not re.match(r'^[a-zA-Z0-9_-]+$', platform):
        return False, "Platform name can only contain letters, numbers, hyphens, and underscores"

    valid_platforms = ['hackerone', 'bugcrowd', 'intigriti', 'yeswehack', 'synack']
    if platform.lower() not in valid_platforms:
        return False, f"Invalid platform. Supported platforms: {', '.join(valid_platforms)}"

    return True, ""


def validate_username(username: str) -> Tuple[bool, str]:
    """
    Validate username.

    Returns: (is_valid, error_message)
    """
    if not username:
        return False, "Username is required"

    if len(username) < 3:
        return False, "Username must be at least 3 characters"

    if len(username) > 100:
        return False, "Username too long (max 100 characters)"

    # Basic sanitization - allow alphanumeric, dots, hyphens, underscores, @
    if not re.match(r'^[a-zA-Z0-9._@-]+$', username):
        return False, "Username contains invalid characters"

    return True, ""


def validate_api_token(api_token: str) -> Tuple[bool, str]:
    """
    Validate API token.

    Returns: (is_valid, error_message)
    """
    if not api_token:
        return False, "API token is required"

    if len(api_token) < 10:
        return False, "API token too short (minimum 10 characters)"

    if len(api_token) > 500:
        return False, "API token too long (max 500 characters)"

    # Check for suspicious patterns (SQL injection, XSS, etc.)
    suspicious_patterns = [
        r'<script',
        r'javascript:',
        r'onerror=',
        r'onclick=',
        r'SELECT.*FROM',
        r'DROP\s+TABLE',
        r'INSERT\s+INTO',
        r'DELETE\s+FROM'
    ]

    for pattern in suspicious_patterns:
        if re.search(pattern, api_token, re.IGNORECASE):
            return False, "API token contains suspicious patterns"

    return True, ""


def validate_report_id(report_id: any) -> Tuple[bool, str]:
    """
    Validate report ID.

    Returns: (is_valid, error_message)
    """
    try:
        report_id_int = int(report_id)
        if report_id_int <= 0:
            return False, "Report ID must be a positive integer"
        return True, ""
    except (ValueError, TypeError):
        return False, "Report ID must be a valid integer"


def sanitize_string(input_str: str, max_length: int = 1000) -> str:
    """
    Sanitize string input by removing potentially dangerous characters.

    Args:
        input_str: The string to sanitize
        max_length: Maximum allowed length

    Returns:
        Sanitized string
    """
    if not input_str:
        return ""

    # Truncate to max length
    sanitized = input_str[:max_length]

    # Remove null bytes
    sanitized = sanitized.replace('\x00', '')

    # Remove control characters except newlines and tabs
    sanitized = ''.join(char for char in sanitized
                       if char >= ' ' or char in '\n\t\r')

    return sanitized.strip()


def validate_limit_parameter(limit: any, max_limit: int = 1000) -> Tuple[bool, int, str]:
    """
    Validate and sanitize limit parameter for database queries.

    Returns: (is_valid, sanitized_limit, error_message)
    """
    try:
        limit_int = int(limit)

        if limit_int <= 0:
            return False, 0, "Limit must be a positive integer"

        if limit_int > max_limit:
            # Clamp to max instead of rejecting
            return True, max_limit, ""

        return True, limit_int, ""

    except (ValueError, TypeError):
        return False, 0, "Limit must be a valid integer"
