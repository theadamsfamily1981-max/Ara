"""
Audit logging for security-sensitive operations.
"""

import logging
import json
from datetime import datetime
from typing import Optional, Dict, Any
from pathlib import Path

# Create dedicated audit logger
audit_logger = logging.getLogger('audit')
audit_logger.setLevel(logging.INFO)

# Create audit log file handler
audit_log_path = Path('logs/audit.log')
audit_log_path.parent.mkdir(parents=True, exist_ok=True)

file_handler = logging.FileHandler(audit_log_path)
file_handler.setLevel(logging.INFO)

# Audit log format: JSON for easy parsing
formatter = logging.Formatter('%(message)s')
file_handler.setFormatter(formatter)

audit_logger.addHandler(file_handler)


def audit_log(
    action: str,
    resource: str,
    user: str = 'system',
    status: str = 'success',
    details: Optional[Dict[str, Any]] = None,
    ip_address: Optional[str] = None
):
    """
    Log an audit event.

    Args:
        action: Action performed (e.g., 'credential_added', 'report_submitted')
        resource: Resource affected (e.g., 'hackerone', 'report_123')
        user: User who performed the action (default: 'system')
        status: 'success' or 'failure'
        details: Additional details about the action
        ip_address: IP address of the requester
    """
    audit_entry = {
        'timestamp': datetime.now().isoformat(),
        'action': action,
        'resource': resource,
        'user': user,
        'status': status,
        'ip_address': ip_address,
        'details': details or {}
    }

    # Log as JSON for easy parsing and analysis
    audit_logger.info(json.dumps(audit_entry))


# Convenience functions for common audit events

def audit_credential_added(platform: str, username: str, ip_address: Optional[str] = None):
    """Audit log for credential addition."""
    audit_log(
        action='credential_added',
        resource=platform,
        user=username,
        status='success',
        details={'platform': platform},
        ip_address=ip_address
    )


def audit_credential_deleted(platform: str, ip_address: Optional[str] = None):
    """Audit log for credential deletion."""
    audit_log(
        action='credential_deleted',
        resource=platform,
        user='system',
        status='success',
        details={'platform': platform},
        ip_address=ip_address
    )


def audit_report_submitted(report_id: int, platform: str, ip_address: Optional[str] = None):
    """Audit log for report submission."""
    audit_log(
        action='report_submitted',
        resource=f'report_{report_id}',
        user='system',
        status='success',
        details={'report_id': report_id, 'platform': platform},
        ip_address=ip_address
    )


def audit_report_rejected(report_id: int, ip_address: Optional[str] = None):
    """Audit log for report rejection."""
    audit_log(
        action='report_rejected',
        resource=f'report_{report_id}',
        user='system',
        status='success',
        details={'report_id': report_id},
        ip_address=ip_address
    )


def audit_failed_validation(action: str, reason: str, ip_address: Optional[str] = None):
    """Audit log for failed validation (potential security issue)."""
    audit_log(
        action=action,
        resource='validation',
        user='unknown',
        status='failure',
        details={'reason': reason},
        ip_address=ip_address
    )


def audit_system_start(user: str = 'system'):
    """Audit log for system start."""
    audit_log(
        action='system_started',
        resource='orchestrator',
        user=user,
        status='success'
    )


def audit_system_stop(user: str = 'system'):
    """Audit log for system stop."""
    audit_log(
        action='system_stopped',
        resource='orchestrator',
        user=user,
        status='success'
    )
