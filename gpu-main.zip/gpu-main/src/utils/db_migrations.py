"""
Database migration utilities to ensure schema compatibility.
"""

import sqlite3
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def ensure_reports_table_compatibility(db_path='data/bounty_hunter.db'):
    """
    Ensure reports table has all required columns with proper defaults.
    """
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Check if submitted column exists
        cursor.execute("PRAGMA table_info(reports)")
        columns = {row[1]: row for row in cursor.fetchall()}

        # Add submitted column if missing
        if 'submitted' not in columns:
            logger.info("Adding 'submitted' column to reports table")
            cursor.execute("""
                ALTER TABLE reports
                ADD COLUMN submitted INTEGER DEFAULT 0
            """)

        # Add submission_result column if missing
        if 'submission_result' not in columns:
            logger.info("Adding 'submission_result' column to reports table")
            cursor.execute("""
                ALTER TABLE reports
                ADD COLUMN submission_result TEXT
            """)

        # Ensure all existing reports have submitted=0 if NULL
        cursor.execute("""
            UPDATE reports
            SET submitted = 0
            WHERE submitted IS NULL
        """)

        conn.commit()
        conn.close()

        logger.info("Reports table schema verification complete")
        return True

    except Exception as e:
        logger.error(f"Error ensuring reports table compatibility: {e}")
        return False


def ensure_programs_rewards_column(db_path='data/bounty_hunter.db'):
    """
    Ensure programs table has rewards column for bounty information.
    """
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Check if rewards column exists
        cursor.execute("PRAGMA table_info(programs)")
        columns = {row[1]: row for row in cursor.fetchall()}

        # Add rewards column if missing
        if 'rewards' not in columns:
            logger.info("Adding 'rewards' column to programs table")
            cursor.execute("""
                ALTER TABLE programs
                ADD COLUMN rewards TEXT
            """)

        conn.commit()
        conn.close()

        logger.info("Programs table schema verification complete")
        return True

    except Exception as e:
        logger.error(f"Error ensuring programs table compatibility: {e}")
        return False


def add_composite_indexes(db_path='data/bounty_hunter.db'):
    """
    Add composite indexes for common query patterns.
    """
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Composite indexes for better query performance
        indexes = [
            # Reports: submitted + platform (for pending reports by platform)
            "CREATE INDEX IF NOT EXISTS idx_reports_submitted_platform ON reports(submitted, platform)",

            # Vulnerabilities: program + created_at (for recent vulns by program)
            "CREATE INDEX IF NOT EXISTS idx_vulnerabilities_program_created ON vulnerabilities(program_name, created_at DESC)",

            # Reports: submitted + generated_at (for pending reports chronologically)
            "CREATE INDEX IF NOT EXISTS idx_reports_submitted_generated ON reports(submitted, generated_at DESC)",

            # Programs: platform + last_scanned (for active programs by platform)
            "CREATE INDEX IF NOT EXISTS idx_programs_platform_scanned ON programs(platform, last_scanned DESC)",
        ]

        for index_sql in indexes:
            try:
                cursor.execute(index_sql)
                logger.info(f"Created index: {index_sql.split('idx_')[1].split(' ON')[0]}")
            except Exception as e:
                logger.warning(f"Index creation skipped (may already exist): {e}")

        conn.commit()
        conn.close()

        logger.info("Composite indexes added successfully")
        return True

    except Exception as e:
        logger.error(f"Error adding composite indexes: {e}")
        return False


def add_unique_constraints(db_path='data/bounty_hunter.db'):
    """
    Add unique constraints to prevent duplicate records.
    """
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Check if unique index already exists
        cursor.execute("""
            SELECT name FROM sqlite_master
            WHERE type='index' AND name='idx_programs_unique'
        """)

        if not cursor.fetchone():
            logger.info("Adding unique constraint on programs(name, platform)")
            cursor.execute("""
                CREATE UNIQUE INDEX idx_programs_unique
                ON programs(name, platform)
            """)
        else:
            logger.info("Unique constraint on programs already exists")

        conn.commit()
        conn.close()

        logger.info("Unique constraints verified")
        return True

    except Exception as e:
        logger.error(f"Error adding unique constraints: {e}")
        return False


def run_all_migrations(db_path='data/bounty_hunter.db'):
    """
    Run all database migrations to ensure compatibility.
    """
    logger.info("Running database migrations...")

    # Ensure database directory exists
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)

    migrations = [
        ensure_reports_table_compatibility,
        ensure_programs_rewards_column,
        add_composite_indexes,
        add_unique_constraints
    ]

    success = True
    for migration in migrations:
        if not migration(db_path):
            success = False
            logger.error(f"Migration {migration.__name__} failed")

    if success:
        logger.info("All database migrations completed successfully")
    else:
        logger.warning("Some database migrations failed")

    return success
