"""Database management utilities."""

import sqlite3
import json
import logging
from typing import List, Dict, Optional
from datetime import datetime

logger = logging.getLogger(__name__)


class Database:
    """SQLite database manager."""

    def __init__(self, db_path: str):
        self.db_path = db_path
        self.conn = None
        self._init_database()

    def _init_database(self):
        """Initialize database schema."""
        self.conn = sqlite3.connect(self.db_path)
        self.conn.row_factory = sqlite3.Row

        cursor = self.conn.cursor()

        # Programs table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS programs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                platform TEXT NOT NULL,
                url TEXT NOT NULL,
                scope TEXT,
                out_of_scope TEXT,
                rewards TEXT,
                discovered_at TIMESTAMP,
                last_updated TIMESTAMP,
                last_scanned TIMESTAMP
            )
        """)

        # Assets table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS assets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                hostname TEXT NOT NULL,
                ip_addresses TEXT,
                ports TEXT,
                technologies TEXT,
                web_servers TEXT,
                status_code INTEGER,
                title TEXT,
                discovered_at TIMESTAMP
            )
        """)

        # Vulnerabilities table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS vulnerabilities (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                program_name TEXT,
                name TEXT NOT NULL,
                severity TEXT NOT NULL,
                category TEXT NOT NULL,
                url TEXT NOT NULL,
                parameters TEXT,
                description TEXT,
                proof_of_concept TEXT,
                remediation TEXT,
                cvss_score REAL,
                cve_id TEXT,
                references TEXT,
                discovered_at TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Exploits table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS exploits (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                vulnerability_id INTEGER,
                poc_code TEXT,
                impact_assessment TEXT,
                verified BOOLEAN,
                created_at TIMESTAMP,
                FOREIGN KEY (vulnerability_id) REFERENCES vulnerabilities (id)
            )
        """)

        # Reports table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS reports (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                vulnerability_id INTEGER,
                report_content TEXT,
                platform TEXT,
                program_name TEXT,
                submitted BOOLEAN,
                submission_result TEXT,
                generated_at TIMESTAMP,
                FOREIGN KEY (vulnerability_id) REFERENCES vulnerabilities (id)
            )
        """)

        # Leaderboard stats table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS leaderboard_stats (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                platform TEXT NOT NULL,
                username TEXT,
                rank INTEGER,
                points INTEGER,
                bounties_earned REAL,
                bugs_found INTEGER,
                timestamp TIMESTAMP
            )
        """)

        # Create indexes for performance
        self._create_indexes(cursor)

        self.conn.commit()
        logger.info("Database initialized")

    def _create_indexes(self, cursor):
        """Create database indexes for improved query performance."""
        indexes = [
            # Programs indexes
            "CREATE INDEX IF NOT EXISTS idx_programs_platform ON programs(platform)",
            "CREATE INDEX IF NOT EXISTS idx_programs_name ON programs(name)",
            "CREATE INDEX IF NOT EXISTS idx_programs_last_updated ON programs(last_updated)",

            # Assets indexes
            "CREATE INDEX IF NOT EXISTS idx_assets_hostname ON assets(hostname)",
            "CREATE INDEX IF NOT EXISTS idx_assets_discovered_at ON assets(discovered_at)",

            # Vulnerabilities indexes
            "CREATE INDEX IF NOT EXISTS idx_vulnerabilities_severity ON vulnerabilities(severity)",
            "CREATE INDEX IF NOT EXISTS idx_vulnerabilities_category ON vulnerabilities(category)",
            "CREATE INDEX IF NOT EXISTS idx_vulnerabilities_url ON vulnerabilities(url)",
            "CREATE INDEX IF NOT EXISTS idx_vulnerabilities_discovered_at ON vulnerabilities(discovered_at)",
            "CREATE INDEX IF NOT EXISTS idx_vulnerabilities_severity_category ON vulnerabilities(severity, category)",

            # Exploits indexes
            "CREATE INDEX IF NOT EXISTS idx_exploits_vulnerability_id ON exploits(vulnerability_id)",
            "CREATE INDEX IF NOT EXISTS idx_exploits_verified ON exploits(verified)",

            # Reports indexes
            "CREATE INDEX IF NOT EXISTS idx_reports_vulnerability_id ON reports(vulnerability_id)",
            "CREATE INDEX IF NOT EXISTS idx_reports_platform ON reports(platform)",
            "CREATE INDEX IF NOT EXISTS idx_reports_submitted ON reports(submitted)",
            "CREATE INDEX IF NOT EXISTS idx_reports_generated_at ON reports(generated_at)",

            # Leaderboard indexes
            "CREATE INDEX IF NOT EXISTS idx_leaderboard_platform ON leaderboard_stats(platform)",
            "CREATE INDEX IF NOT EXISTS idx_leaderboard_timestamp ON leaderboard_stats(timestamp)",
            "CREATE INDEX IF NOT EXISTS idx_leaderboard_platform_timestamp ON leaderboard_stats(platform, timestamp)"
        ]

        for index_sql in indexes:
            cursor.execute(index_sql)

        logger.info("Database indexes created")

    def save_program(self, program: Dict):
        """Save program to database."""
        cursor = self.conn.cursor()

        cursor.execute("""
            INSERT INTO programs (name, platform, url, scope, out_of_scope, rewards, discovered_at, last_updated)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            program.get('name'),
            program.get('platform'),
            program.get('url'),
            json.dumps(program.get('scope', [])),
            json.dumps(program.get('out_of_scope', [])),
            json.dumps(program.get('rewards', {})),
            program.get('discovered_at'),
            program.get('last_updated')
        ))

        self.conn.commit()

    def save_vulnerability(self, vuln: Dict) -> int:
        """Save vulnerability to database."""
        cursor = self.conn.cursor()

        cursor.execute("""
            INSERT INTO vulnerabilities (name, severity, category, url, description, proof_of_concept,
                                       remediation, cvss_score, cve_id, references, discovered_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            vuln.get('name'),
            vuln.get('severity'),
            vuln.get('category'),
            vuln.get('url'),
            vuln.get('description'),
            vuln.get('proof_of_concept'),
            vuln.get('remediation'),
            vuln.get('cvss_score'),
            vuln.get('cve_id'),
            json.dumps(vuln.get('references', [])),
            vuln.get('discovered_at')
        ))

        self.conn.commit()
        return cursor.lastrowid

    def get_statistics(self) -> Dict:
        """Get database statistics."""
        cursor = self.conn.cursor()

        stats = {}

        # Count programs
        cursor.execute("SELECT COUNT(*) FROM programs")
        stats['total_programs'] = cursor.fetchone()[0]

        # Count assets
        cursor.execute("SELECT COUNT(*) FROM assets")
        stats['total_assets'] = cursor.fetchone()[0]

        # Count vulnerabilities by severity
        cursor.execute("SELECT severity, COUNT(*) FROM vulnerabilities GROUP BY severity")
        stats['vulnerabilities_by_severity'] = dict(cursor.fetchall())

        # Total vulnerabilities
        cursor.execute("SELECT COUNT(*) FROM vulnerabilities")
        stats['total_vulnerabilities'] = cursor.fetchone()[0]

        # Submitted reports
        cursor.execute("SELECT COUNT(*) FROM reports WHERE submitted = 1")
        stats['submitted_reports'] = cursor.fetchone()[0]

        return stats

    def close(self):
        """Close database connection."""
        if self.conn:
            self.conn.close()
