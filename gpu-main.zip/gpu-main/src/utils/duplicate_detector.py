"""
Smart Duplicate Detector
Checks if vulnerability was already reported before submission.
"""

import logging
import aiohttp
import hashlib
from typing import Dict, List, Optional, Set
from datetime import datetime, timedelta
import json
import os

logger = logging.getLogger(__name__)


class DuplicateDetector:
    """Detects duplicate vulnerabilities before reporting."""

    def __init__(self, db_connection=None):
        """Initialize duplicate detector."""
        self.db = db_connection
        self.known_vulns: Set[str] = set()
        self.disclosed_reports_cache = {}
        self.cache_file = './data/duplicate_cache.json'

        # Load cache
        self._load_cache()

    def _load_cache(self):
        """Load cached duplicate data."""
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'r') as f:
                    data = json.load(f)
                    self.known_vulns = set(data.get('known_vulns', []))
                    self.disclosed_reports_cache = data.get('disclosed_reports', {})
                    logger.info(f"Loaded {len(self.known_vulns)} known vulnerabilities from cache")
            except Exception as e:
                logger.error(f"Error loading cache: {e}")

    def _save_cache(self):
        """Save cache to disk."""
        try:
            os.makedirs(os.path.dirname(self.cache_file), exist_ok=True)
            with open(self.cache_file, 'w') as f:
                json.dump({
                    'known_vulns': list(self.known_vulns),
                    'disclosed_reports': self.disclosed_reports_cache,
                    'last_updated': datetime.now().isoformat()
                }, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving cache: {e}")

    async def is_duplicate(self, vulnerability: Dict) -> Dict:
        """
        Check if vulnerability is a duplicate.

        Returns dict with:
        - is_duplicate: bool
        - confidence: float (0-1)
        - reason: str
        - similar_reports: List[Dict]
        """
        result = {
            'is_duplicate': False,
            'confidence': 0.0,
            'reason': '',
            'similar_reports': []
        }

        # Generate vulnerability signature
        vuln_sig = self._generate_signature(vulnerability)

        # Check 1: Exact match in our database
        if self.db:
            db_match = self._check_own_reports(vuln_sig, vulnerability)
            if db_match:
                result['is_duplicate'] = True
                result['confidence'] = 1.0
                result['reason'] = 'Already reported by you'
                result['similar_reports'] = [db_match]
                return result

        # Check 2: Disclosed HackerOne reports
        h1_match = await self._check_hackerone_disclosed(vulnerability)
        if h1_match:
            result['is_duplicate'] = True
            result['confidence'] = 0.9
            result['reason'] = f"Similar disclosed on HackerOne: {h1_match.get('title')}"
            result['similar_reports'].append(h1_match)
            return result

        # Check 3: Bugcrowd disclosed reports
        bc_match = await self._check_bugcrowd_disclosed(vulnerability)
        if bc_match:
            result['is_duplicate'] = True
            result['confidence'] = 0.9
            result['reason'] = f"Similar disclosed on Bugcrowd: {bc_match.get('title')}"
            result['similar_reports'].append(bc_match)
            return result

        # Check 4: CVE database
        cve_match = await self._check_cve_database(vulnerability)
        if cve_match:
            result['is_duplicate'] = True
            result['confidence'] = 0.8
            result['reason'] = f"Known CVE: {cve_match.get('cve_id')}"
            result['similar_reports'].append(cve_match)
            return result

        # Check 5: GitHub Security Advisories
        ghsa_match = await self._check_github_advisories(vulnerability)
        if ghsa_match:
            result['is_duplicate'] = True
            result['confidence'] = 0.8
            result['reason'] = f"GitHub Advisory: {ghsa_match.get('ghsa_id')}"
            result['similar_reports'].append(ghsa_match)
            return result

        # Check 6: Pattern similarity with known reports
        similar = await self._find_similar_patterns(vulnerability)
        if similar:
            result['similar_reports'] = similar
            result['confidence'] = 0.5
            result['reason'] = f"Found {len(similar)} similar reports - review recommended"

        # Add to known vulnerabilities
        self.known_vulns.add(vuln_sig)
        self._save_cache()

        return result

    def _generate_signature(self, vuln: Dict) -> str:
        """Generate unique signature for vulnerability."""
        # Normalize URL
        url = vuln.get('url', '').lower().strip()

        # Normalize vulnerability type
        vuln_type = vuln.get('category', '').lower().strip()

        # Extract key parameters (for IDOR, XSS payloads, etc.)
        params = vuln.get('parameters', '')

        # Create signature
        sig_string = f"{url}:{vuln_type}:{params}"
        return hashlib.md5(sig_string.encode()).hexdigest()

    def _check_own_reports(self, signature: str, vuln: Dict) -> Optional[Dict]:
        """Check against our own database of reports."""
        if not self.db:
            return None

        # Check signature cache
        if signature in self.known_vulns:
            return {
                'source': 'own_database',
                'signature': signature,
                'match_type': 'exact'
            }

        # Query database for similar vulnerabilities
        try:
            cursor = self.db.conn.cursor()
            cursor.execute("""
                SELECT * FROM vulnerabilities
                WHERE url = ? AND category = ?
                LIMIT 1
            """, (vuln.get('url'), vuln.get('category')))

            row = cursor.fetchone()
            if row:
                return {
                    'source': 'own_database',
                    'url': vuln.get('url'),
                    'category': vuln.get('category'),
                    'match_type': 'similar'
                }
        except Exception as e:
            logger.error(f"Database check error: {e}")

        return None

    async def _check_hackerone_disclosed(self, vuln: Dict) -> Optional[Dict]:
        """Check HackerOne disclosed reports."""
        try:
            # Extract domain from URL
            from urllib.parse import urlparse
            parsed = urlparse(vuln.get('url', ''))
            domain = parsed.netloc

            # Search disclosed reports
            search_url = "https://hackerone.com/hacktivity"

            # Check cache first (valid for 24 hours)
            cache_key = f"h1_{domain}_{vuln.get('category')}"
            if cache_key in self.disclosed_reports_cache:
                cached = self.disclosed_reports_cache[cache_key]
                cache_time = datetime.fromisoformat(cached['timestamp'])
                if datetime.now() - cache_time < timedelta(hours=24):
                    return cached.get('match')

            # Query HackerOne API (public disclosed reports)
            async with aiohttp.ClientSession() as session:
                params = {
                    'querystring': domain,
                    'filter': 'disclosed'
                }

                async with session.get(search_url, params=params, timeout=10) as response:
                    if response.status == 200:
                        # Parse response for matches
                        text = await response.text()

                        # Look for vulnerability type + domain combination
                        vuln_type = vuln.get('category', '').lower()
                        if vuln_type in text.lower() and domain in text.lower():
                            match = {
                                'source': 'hackerone',
                                'title': f"{vuln_type} on {domain}",
                                'url': search_url
                            }

                            # Cache result
                            self.disclosed_reports_cache[cache_key] = {
                                'timestamp': datetime.now().isoformat(),
                                'match': match
                            }
                            self._save_cache()

                            return match

        except Exception as e:
            logger.debug(f"HackerOne check error: {e}")

        return None

    async def _check_bugcrowd_disclosed(self, vuln: Dict) -> Optional[Dict]:
        """Check Bugcrowd disclosed reports."""
        try:
            from urllib.parse import urlparse
            parsed = urlparse(vuln.get('url', ''))
            domain = parsed.netloc

            # Bugcrowd public disclosures
            url = "https://bugcrowd.com/disclosures"

            cache_key = f"bc_{domain}_{vuln.get('category')}"
            if cache_key in self.disclosed_reports_cache:
                cached = self.disclosed_reports_cache[cache_key]
                cache_time = datetime.fromisoformat(cached['timestamp'])
                if datetime.now() - cache_time < timedelta(hours=24):
                    return cached.get('match')

            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=10) as response:
                    if response.status == 200:
                        text = await response.text()

                        vuln_type = vuln.get('category', '').lower()
                        if vuln_type in text.lower() and domain in text.lower():
                            match = {
                                'source': 'bugcrowd',
                                'title': f"{vuln_type} on {domain}",
                                'url': url
                            }

                            self.disclosed_reports_cache[cache_key] = {
                                'timestamp': datetime.now().isoformat(),
                                'match': match
                            }
                            self._save_cache()

                            return match

        except Exception as e:
            logger.debug(f"Bugcrowd check error: {e}")

        return None

    async def _check_cve_database(self, vuln: Dict) -> Optional[Dict]:
        """Check CVE database for known vulnerabilities."""
        try:
            from urllib.parse import urlparse
            parsed = urlparse(vuln.get('url', ''))
            domain = parsed.netloc

            # Extract product name from domain (e.g., redhat.com -> Red Hat)
            product = domain.split('.')[0].replace('-', ' ').title()

            # NVD API
            url = "https://services.nvd.nist.gov/rest/json/cves/2.0"

            cache_key = f"cve_{product}_{vuln.get('category')}"
            if cache_key in self.disclosed_reports_cache:
                cached = self.disclosed_reports_cache[cache_key]
                cache_time = datetime.fromisoformat(cached['timestamp'])
                if datetime.now() - cache_time < timedelta(days=7):
                    return cached.get('match')

            params = {
                'keywordSearch': f"{product} {vuln.get('category')}",
                'resultsPerPage': 5
            }

            async with aiohttp.ClientSession() as session:
                async with session.get(url, params=params, timeout=10) as response:
                    if response.status == 200:
                        data = await response.json()

                        if data.get('vulnerabilities'):
                            cve = data['vulnerabilities'][0]
                            cve_id = cve.get('cve', {}).get('id')

                            match = {
                                'source': 'nvd',
                                'cve_id': cve_id,
                                'description': cve.get('cve', {}).get('descriptions', [{}])[0].get('value', '')[:200]
                            }

                            self.disclosed_reports_cache[cache_key] = {
                                'timestamp': datetime.now().isoformat(),
                                'match': match
                            }
                            self._save_cache()

                            return match

        except Exception as e:
            logger.debug(f"CVE check error: {e}")

        return None

    async def _check_github_advisories(self, vuln: Dict) -> Optional[Dict]:
        """Check GitHub Security Advisories."""
        try:
            from urllib.parse import urlparse
            parsed = urlparse(vuln.get('url', ''))
            domain = parsed.netloc

            # GitHub Advisory Database API
            url = "https://api.github.com/advisories"

            cache_key = f"ghsa_{domain}_{vuln.get('category')}"
            if cache_key in self.disclosed_reports_cache:
                cached = self.disclosed_reports_cache[cache_key]
                cache_time = datetime.fromisoformat(cached['timestamp'])
                if datetime.now() - cache_time < timedelta(days=7):
                    return cached.get('match')

            params = {
                'per_page': 5
            }

            async with aiohttp.ClientSession() as session:
                headers = {'Accept': 'application/vnd.github+json'}

                async with session.get(url, params=params, headers=headers, timeout=10) as response:
                    if response.status == 200:
                        advisories = await response.json()

                        vuln_type = vuln.get('category', '').lower()
                        for advisory in advisories:
                            summary = advisory.get('summary', '').lower()
                            if vuln_type in summary or domain in summary:
                                match = {
                                    'source': 'github',
                                    'ghsa_id': advisory.get('ghsa_id'),
                                    'summary': advisory.get('summary')[:200],
                                    'url': advisory.get('html_url')
                                }

                                self.disclosed_reports_cache[cache_key] = {
                                    'timestamp': datetime.now().isoformat(),
                                    'match': match
                                }
                                self._save_cache()

                                return match

        except Exception as e:
            logger.debug(f"GitHub Advisory check error: {e}")

        return None

    async def _find_similar_patterns(self, vuln: Dict) -> List[Dict]:
        """Find similar vulnerability patterns."""
        similar = []

        if not self.db:
            return similar

        try:
            cursor = self.db.conn.cursor()

            # Find vulnerabilities with similar characteristics
            cursor.execute("""
                SELECT url, category, severity, name
                FROM vulnerabilities
                WHERE category = ?
                AND url LIKE ?
                LIMIT 5
            """, (
                vuln.get('category'),
                f"%{vuln.get('url', '').split('/')[2]}%"  # Same domain
            ))

            for row in cursor.fetchall():
                similar.append({
                    'url': row[0],
                    'category': row[1],
                    'severity': row[2],
                    'name': row[3],
                    'similarity': 0.7  # Medium similarity
                })

        except Exception as e:
            logger.error(f"Pattern search error: {e}")

        return similar

    async def suggest_alternatives(self, vuln: Dict) -> List[str]:
        """Suggest alternative targets based on duplicate."""
        suggestions = []

        from urllib.parse import urlparse
        parsed = urlparse(vuln.get('url', ''))
        domain = parsed.netloc
        path = parsed.path

        # Suggest similar paths on same domain
        suggestions.append(f"Try similar endpoints: {domain}/api/{path.split('/')[-1]}")
        suggestions.append(f"Try subdomain: dev.{domain}{path}")
        suggestions.append(f"Try different parameter: {vuln.get('url')}?alt_param=test")

        # Suggest related vulnerability types
        vuln_type = vuln.get('category', '')
        related = {
            'xss': ['csrf', 'open_redirect', 'cors_misconfiguration'],
            'sqli': ['idor', 'info_disclosure'],
            'ssrf': ['xxe', 'file_inclusion'],
            'idor': ['broken_auth', 'info_disclosure']
        }

        if vuln_type in related:
            for alt_type in related[vuln_type]:
                suggestions.append(f"Try testing for {alt_type} on same endpoint")

        return suggestions[:5]  # Top 5 suggestions
