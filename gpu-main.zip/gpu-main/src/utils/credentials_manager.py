"""
Credentials Manager
Secure storage and management of bug bounty platform credentials.
"""

import os
import json
import logging
from typing import Dict, Optional
from cryptography.fernet import Fernet
from pathlib import Path

logger = logging.getLogger(__name__)


class CredentialsManager:
    """Manage bug bounty platform credentials securely."""

    def __init__(self, credentials_file: str = './data/credentials.enc'):
        """Initialize credentials manager."""
        self.credentials_file = credentials_file
        self.key_file = './data/.key'

        # Ensure directory exists
        os.makedirs(os.path.dirname(credentials_file), exist_ok=True)

        # Load or generate encryption key
        self.key = self._load_or_generate_key()
        self.cipher = Fernet(self.key)

        # Load credentials
        self.credentials = self._load_credentials()

    def _load_or_generate_key(self) -> bytes:
        """Load existing key or generate new one."""
        if os.path.exists(self.key_file):
            with open(self.key_file, 'rb') as f:
                return f.read()
        else:
            # Generate new key
            key = Fernet.generate_key()
            with open(self.key_file, 'wb') as f:
                f.write(key)

            # Restrict permissions
            os.chmod(self.key_file, 0o600)
            logger.info("Generated new encryption key")
            return key

    def _load_credentials(self) -> Dict:
        """Load and decrypt credentials."""
        if not os.path.exists(self.credentials_file):
            return {}

        try:
            with open(self.credentials_file, 'rb') as f:
                encrypted_data = f.read()

            decrypted_data = self.cipher.decrypt(encrypted_data)
            return json.loads(decrypted_data.decode())
        except Exception as e:
            logger.error(f"Error loading credentials: {e}")
            return {}

    def _save_credentials(self):
        """Encrypt and save credentials."""
        try:
            json_data = json.dumps(self.credentials).encode()
            encrypted_data = self.cipher.encrypt(json_data)

            with open(self.credentials_file, 'wb') as f:
                f.write(encrypted_data)

            # Restrict permissions
            os.chmod(self.credentials_file, 0o600)
            logger.info("Credentials saved securely")
        except Exception as e:
            logger.error(f"Error saving credentials: {e}")

    def add_credential(self, platform: str, username: str, api_token: str,
                       additional_info: Optional[Dict] = None):
        """
        Add or update credentials for a platform.

        Args:
            platform: 'hackerone', 'bugcrowd', 'intigriti', etc.
            username: Username or email
            api_token: API token/key
            additional_info: Additional fields (e.g., API secret)
        """
        self.credentials[platform] = {
            'username': username,
            'api_token': api_token,
            'additional_info': additional_info or {},
            'added_at': str(Path(self.credentials_file).stat().st_mtime) if os.path.exists(self.credentials_file) else 'now'
        }

        self._save_credentials()
        logger.info(f"Added credentials for {platform}")

    def get_credential(self, platform: str) -> Optional[Dict]:
        """Get credentials for a platform."""
        return self.credentials.get(platform)

    def remove_credential(self, platform: str):
        """Remove credentials for a platform."""
        if platform in self.credentials:
            del self.credentials[platform]
            self._save_credentials()
            logger.info(f"Removed credentials for {platform}")

    def list_platforms(self) -> list:
        """List all platforms with stored credentials."""
        return list(self.credentials.keys())

    def has_credentials(self, platform: str) -> bool:
        """Check if credentials exist for a platform."""
        return platform in self.credentials

    def get_all_masked(self) -> Dict:
        """Get all credentials with API tokens masked."""
        masked = {}
        for platform, creds in self.credentials.items():
            token = creds.get('api_token', '')
            masked_token = token[:8] + '*' * (len(token) - 12) + token[-4:] if len(token) > 12 else '***'

            masked[platform] = {
                'username': creds.get('username'),
                'api_token': masked_token,
                'has_credentials': True
            }

        return masked

    def validate_credential(self, platform: str) -> bool:
        """Validate that credential exists and has required fields."""
        creds = self.get_credential(platform)
        if not creds:
            return False

        return bool(creds.get('username') and creds.get('api_token'))

    def export_to_env(self):
        """Export credentials to environment variables (for legacy compatibility)."""
        env_mapping = {
            'hackerone': {
                'username': 'HACKERONE_USERNAME',
                'api_token': 'HACKERONE_API_TOKEN'
            },
            'bugcrowd': {
                'username': 'BUGCROWD_USERNAME',
                'api_token': 'BUGCROWD_API_TOKEN'
            }
        }

        for platform, creds in self.credentials.items():
            if platform in env_mapping:
                mapping = env_mapping[platform]
                os.environ[mapping['username']] = creds.get('username', '')
                os.environ[mapping['api_token']] = creds.get('api_token', '')

    def get_hackerone_credentials(self) -> Optional[tuple]:
        """Get HackerOne credentials as tuple (username, token)."""
        creds = self.get_credential('hackerone')
        if creds:
            return (creds.get('username'), creds.get('api_token'))
        return None

    def get_bugcrowd_credentials(self) -> Optional[tuple]:
        """Get Bugcrowd credentials as tuple (username, token)."""
        creds = self.get_credential('bugcrowd')
        if creds:
            return (creds.get('username'), creds.get('api_token'))
        return None
