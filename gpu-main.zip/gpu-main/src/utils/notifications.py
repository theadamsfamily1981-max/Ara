"""Notification utilities."""

import aiohttp
import logging
from typing import Dict

logger = logging.getLogger(__name__)


class NotificationManager:
    """Manages notifications via various channels."""

    def __init__(self, config: Dict):
        self.config = config
        self.slack_webhook = config.get('notifications', {}).get('slack_webhook')
        self.email = config.get('notifications', {}).get('email')
        self.notify_on = config.get('notifications', {}).get('notify_on', [])

    async def notify(self, event_type: str, message: str, details: Dict = None):
        """Send notification."""
        if event_type not in self.notify_on:
            return

        logger.info(f"Notification [{event_type}]: {message}")

        # Send to Slack
        if self.slack_webhook:
            await self._send_slack(event_type, message, details)

    async def _send_slack(self, event_type: str, message: str, details: Dict = None):
        """Send Slack notification."""
        try:
            emoji_map = {
                'critical_finding': ':rotating_light:',
                'high_finding': ':warning:',
                'bounty_awarded': ':moneybag:',
                'ranking_change': ':chart_with_upwards_trend:'
            }

            emoji = emoji_map.get(event_type, ':bell:')

            payload = {
                'text': f"{emoji} *{event_type.replace('_', ' ').title()}*",
                'attachments': [{
                    'text': message,
                    'color': 'good' if event_type == 'bounty_awarded' else 'danger'
                }]
            }

            if details:
                payload['attachments'][0]['fields'] = [
                    {'title': k, 'value': str(v), 'short': True}
                    for k, v in details.items()
                ]

            async with aiohttp.ClientSession() as session:
                async with session.post(self.slack_webhook, json=payload) as response:
                    if response.status != 200:
                        logger.error(f"Slack notification failed: {response.status}")

        except Exception as e:
            logger.error(f"Slack notification error: {e}")
