"""
AI-Powered Report Quality Optimizer
Analyzes and improves report quality for higher acceptance rates.
"""

import logging
from typing import Dict, List
import re

logger = logging.getLogger(__name__)


class ReportOptimizer:
    """Optimize bug reports for maximum acceptance rate."""

    def __init__(self):
        """Initialize report optimizer."""
        self.quality_checklist = {
            'has_clear_title': False,
            'has_summary': False,
            'has_steps_to_reproduce': False,
            'has_impact_section': False,
            'has_poc': False,
            'has_remediation': False,
            'has_references': False,
            'proper_formatting': False,
            'no_typos': False,
            'appropriate_severity': False
        }

    def analyze_report(self, report: Dict) -> Dict:
        """
        Analyze report quality and provide improvement suggestions.

        Returns: Dict with score, issues, and suggestions
        """
        score = 0
        issues = []
        suggestions = []

        # Check title
        title = report.get('title', '')
        if not title or len(title) < 10:
            issues.append("Title is missing or too short")
            suggestions.append("Add a clear, descriptive title (e.g., 'XSS in User Profile Page')")
        elif len(title) > 100:
            issues.append("Title is too long")
            suggestions.append("Shorten title to under 100 characters")
        else:
            score += 10

        # Check summary
        summary = report.get('summary', '')
        if not summary or len(summary) < 50:
            issues.append("Summary is missing or too brief")
            suggestions.append("Add a detailed summary explaining what the vulnerability is and why it matters")
        else:
            score += 15

        # Check steps to reproduce
        steps = report.get('steps_to_reproduce', '')
        if not steps or len(steps) < 100:
            issues.append("Steps to reproduce are insufficient")
            suggestions.append("Provide clear, numbered steps that anyone can follow to reproduce the issue")
        else:
            # Check if steps are numbered
            if re.search(r'^\d+\.', steps, re.MULTILINE):
                score += 20
            else:
                score += 10
                suggestions.append("Format steps as numbered list (1., 2., 3., etc.)")

        # Check impact section
        impact = report.get('impact', '')
        if not impact:
            issues.append("Impact section is missing")
            suggestions.append("Add an impact section explaining the real-world consequences of this vulnerability")
        else:
            score += 15

        # Check proof of concept
        poc = report.get('proof_of_concept', '')
        if not poc:
            issues.append("Missing proof of concept")
            suggestions.append("Include PoC code, screenshots, or video demonstrating the vulnerability")
        else:
            # Check if PoC has code blocks
            if '```' in poc or '<script>' in poc or 'curl' in poc:
                score += 20
            else:
                score += 10
                suggestions.append("Format PoC with code blocks or specific examples")

        # Check remediation
        remediation = report.get('remediation', '')
        if not remediation:
            issues.append("Missing remediation advice")
            suggestions.append("Suggest how to fix the vulnerability (shows you understand the issue)")
        else:
            score += 10

        # Check references
        references = report.get('references', [])
        if not references or len(references) == 0:
            suggestions.append("Consider adding references to CWE, OWASP, or similar resources")
        else:
            score += 5

        # Check severity
        severity = report.get('severity', '').lower()
        if severity not in ['low', 'medium', 'high', 'critical']:
            issues.append("Invalid or missing severity")
            suggestions.append("Specify severity: Critical, High, Medium, or Low")
        else:
            # Check if severity matches the vulnerability
            if self._verify_severity(report):
                score += 5
            else:
                issues.append("Severity may be incorrect for this vulnerability type")
                suggestions.append(f"Suggested severity: {self._calculate_appropriate_severity(report)}")

        return {
            'score': min(score, 100),
            'grade': self._score_to_grade(score),
            'issues': issues,
            'suggestions': suggestions,
            'acceptance_likelihood': self._estimate_acceptance(score)
        }

    def improve_report(self, report: Dict) -> Dict:
        """
        Automatically improve report quality.

        Returns: Improved report dict
        """
        improved = report.copy()

        # Improve title
        improved['title'] = self._improve_title(improved)

        # Enhance summary
        improved['summary'] = self._enhance_summary(improved)

        # Format steps to reproduce
        improved['steps_to_reproduce'] = self._format_steps(improved)

        # Add impact if missing
        if not improved.get('impact'):
            improved['impact'] = self._generate_impact(improved)

        # Format PoC
        improved['proof_of_concept'] = self._format_poc(improved)

        # Add remediation if missing
        if not improved.get('remediation'):
            improved['remediation'] = self._generate_remediation(improved)

        # Add references
        improved['references'] = self._add_references(improved)

        # Verify severity
        improved['severity'] = self._calculate_appropriate_severity(improved)

        return improved

    def _improve_title(self, report: Dict) -> str:
        """Improve report title."""
        title = report.get('title', '')

        # If title is too short, construct from category and location
        if len(title) < 10:
            category = report.get('category', 'vulnerability')
            url = report.get('url', '')

            if url:
                # Extract path
                from urllib.parse import urlparse
                parsed = urlparse(url)
                path = parsed.path.strip('/').split('/')[-1] or 'endpoint'

                title = f"{category.upper()} in {path}"
            else:
                title = f"{category.upper()} vulnerability"

        # Capitalize properly
        title = title[0].upper() + title[1:] if title else title

        # Ensure title ends without period
        title = title.rstrip('.')

        return title

    def _enhance_summary(self, report: Dict) -> str:
        """Enhance summary section."""
        summary = report.get('summary', '')

        if summary and len(summary) > 50:
            return summary

        # Generate basic summary
        category = report.get('category', 'vulnerability')
        url = report.get('url', 'the application')
        severity = report.get('severity', 'medium')

        template = f"""A {severity} severity {category} vulnerability was discovered in {url}.

This vulnerability allows an attacker to {self._get_attack_description(category)} by exploiting insufficient {self._get_weakness_description(category)}.

This could lead to {self._get_impact_description(category)}, posing a significant security risk."""

        return template

    def _format_steps(self, report: Dict) -> str:
        """Format steps to reproduce."""
        steps = report.get('steps_to_reproduce', '')

        if not steps:
            # Generate basic steps
            url = report.get('url', 'https://target.com')
            category = report.get('category', 'vulnerability')

            steps = f"""1. Navigate to {url}
2. {self._get_exploitation_step(category)}
3. Observe the vulnerability being triggered

Expected: The application should {self._get_expected_behavior(category)}
Actual: The vulnerability is successfully exploited"""

        # Ensure steps are numbered
        if not re.search(r'^\d+\.', steps, re.MULTILINE):
            # Split by newlines and number them
            lines = [line.strip() for line in steps.split('\n') if line.strip()]
            steps = '\n'.join([f"{i+1}. {line}" for i, line in enumerate(lines)])

        return steps

    def _generate_impact(self, report: Dict) -> str:
        """Generate impact section."""
        category = report.get('category', 'vulnerability')
        severity = report.get('severity', 'medium')

        impacts = {
            'xss': "An attacker could execute arbitrary JavaScript in the context of victim users, potentially stealing session tokens, performing actions on their behalf, or redirecting them to malicious sites.",
            'sqli': "An attacker could extract sensitive data from the database, modify or delete records, and potentially gain access to the underlying operating system.",
            'ssrf': "An attacker could access internal services, scan internal networks, and potentially access sensitive data or systems not exposed to the internet.",
            'rce': "An attacker could execute arbitrary commands on the server, potentially leading to complete system compromise, data theft, or service disruption.",
            'idor': "An attacker could access or modify other users' data by manipulating object references, leading to unauthorized data access or modification.",
            'csrf': "An attacker could trick authenticated users into performing unwanted actions, potentially changing passwords, transferring funds, or modifying critical data.",
            'lfi': "An attacker could read sensitive files from the server, including configuration files, source code, or credentials, potentially leading to further compromise.",
            'auth_bypass': "An attacker could gain unauthorized access to protected resources or functionality, potentially accessing sensitive data or administrative functions.",
            'info_disclosure': "Sensitive information is exposed to unauthorized parties, which could be used to facilitate further attacks or compromise user privacy."
        }

        impact = impacts.get(category, "This vulnerability could be exploited by an attacker to compromise the security of the application.")

        # Add business impact based on severity
        if severity in ['critical', 'high']:
            impact += "\n\n**Business Impact:**\n"
            impact += "- Potential data breach affecting user privacy\n"
            impact += "- Reputational damage\n"
            impact += "- Possible regulatory compliance violations\n"
            impact += "- Financial loss from incident response and remediation"

        return impact

    def _format_poc(self, report: Dict) -> str:
        """Format proof of concept."""
        poc = report.get('proof_of_concept', '')

        if not poc:
            return "PoC to be provided upon request for security reasons."

        # Ensure code blocks are formatted
        if '```' not in poc and any(keyword in poc for keyword in ['<script>', 'curl', 'POST', 'GET', 'python']):
            # Wrap in code block
            poc = f"```\n{poc}\n```"

        return poc

    def _generate_remediation(self, report: Dict) -> str:
        """Generate remediation advice."""
        category = report.get('category', 'vulnerability')

        remediations = {
            'xss': "1. Implement proper output encoding/escaping for all user input\n2. Use Content Security Policy (CSP) headers\n3. Validate and sanitize all input on the server side\n4. Use framework-provided XSS protection mechanisms",
            'sqli': "1. Use parameterized queries/prepared statements\n2. Implement input validation with whitelisting\n3. Apply principle of least privilege for database accounts\n4. Use ORM frameworks properly",
            'ssrf': "1. Implement URL whitelist validation\n2. Disable unnecessary protocols (file://, gopher://, etc.)\n3. Use network segmentation\n4. Validate and sanitize all user-supplied URLs",
            'rce': "1. Never execute user input directly\n2. Use safe APIs and avoid shell execution\n3. Implement input validation and sanitization\n4. Run applications with minimal privileges",
            'idor': "1. Implement proper authorization checks\n2. Use indirect object references\n3. Validate user permissions for each request\n4. Implement access control lists (ACLs)",
            'csrf': "1. Implement anti-CSRF tokens\n2. Use SameSite cookie attribute\n3. Validate Origin and Referer headers\n4. Require re-authentication for sensitive actions"
        }

        return remediations.get(category, "1. Review and fix the vulnerable code\n2. Implement proper security controls\n3. Conduct security testing to verify the fix")

    def _add_references(self, report: Dict) -> List[str]:
        """Add relevant references."""
        category = report.get('category', '')
        references = report.get('references', [])

        if references:
            return references

        # Add relevant references
        ref_map = {
            'xss': ['https://owasp.org/www-community/attacks/xss/', 'https://cwe.mitre.org/data/definitions/79.html'],
            'sqli': ['https://owasp.org/www-community/attacks/SQL_Injection', 'https://cwe.mitre.org/data/definitions/89.html'],
            'ssrf': ['https://owasp.org/www-community/attacks/Server_Side_Request_Forgery', 'https://cwe.mitre.org/data/definitions/918.html'],
            'rce': ['https://owasp.org/www-community/attacks/Command_Injection', 'https://cwe.mitre.org/data/definitions/78.html'],
            'idor': ['https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/05-Authorization_Testing/04-Testing_for_Insecure_Direct_Object_References'],
            'csrf': ['https://owasp.org/www-community/attacks/csrf', 'https://cwe.mitre.org/data/definitions/352.html']
        }

        return ref_map.get(category, ['https://owasp.org/www-project-top-ten/'])

    def _calculate_appropriate_severity(self, report: Dict) -> str:
        """Calculate appropriate severity based on vulnerability type and context."""
        category = report.get('category', '').lower()
        url = report.get('url', '')

        # Base severity by category
        severity_map = {
            'rce': 'critical',
            'sqli': 'critical',
            'auth_bypass': 'critical',
            'ssrf': 'high',
            'xxe': 'high',
            'idor': 'high',
            'xss': 'medium',
            'csrf': 'medium',
            'lfi': 'high',
            'open_redirect': 'low',
            'info_disclosure': 'low'
        }

        base_severity = severity_map.get(category, 'medium')

        # Upgrade if authenticated required is bypassed
        if 'auth' in report.get('description', '').lower():
            if base_severity == 'medium':
                base_severity = 'high'

        # Downgrade if only affects low-value endpoint
        if any(keyword in url for keyword in ['/test', '/debug', '/dev', '/staging']):
            if base_severity == 'critical':
                base_severity = 'high'
            elif base_severity == 'high':
                base_severity = 'medium'

        return base_severity

    def _verify_severity(self, report: Dict) -> bool:
        """Verify if reported severity matches vulnerability."""
        reported = report.get('severity', '').lower()
        calculated = self._calculate_appropriate_severity(report)

        return reported == calculated

    def _score_to_grade(self, score: int) -> str:
        """Convert score to letter grade."""
        if score >= 90:
            return 'A'
        elif score >= 80:
            return 'B'
        elif score >= 70:
            return 'C'
        elif score >= 60:
            return 'D'
        else:
            return 'F'

    def _estimate_acceptance(self, score: int) -> str:
        """Estimate acceptance likelihood."""
        if score >= 90:
            return 'Very High (90%+)'
        elif score >= 80:
            return 'High (75-90%)'
        elif score >= 70:
            return 'Medium (60-75%)'
        elif score >= 60:
            return 'Low (40-60%)'
        else:
            return 'Very Low (<40%)'

    # Helper methods for text generation
    def _get_attack_description(self, category: str) -> str:
        descriptions = {
            'xss': 'execute arbitrary JavaScript code',
            'sqli': 'execute arbitrary SQL queries',
            'ssrf': 'access internal systems',
            'rce': 'execute arbitrary system commands',
            'idor': 'access unauthorized resources',
            'csrf': 'perform unauthorized actions'
        }
        return descriptions.get(category, 'exploit the vulnerability')

    def _get_weakness_description(self, category: str) -> str:
        descriptions = {
            'xss': 'output encoding',
            'sqli': 'input validation',
            'ssrf': 'URL validation',
            'rce': 'command execution controls',
            'idor': 'authorization checks',
            'csrf': 'request verification'
        }
        return descriptions.get(category, 'security controls')

    def _get_impact_description(self, category: str) -> str:
        descriptions = {
            'xss': 'session hijacking, phishing, and data theft',
            'sqli': 'complete database compromise',
            'ssrf': 'internal network reconnaissance',
            'rce': 'complete system compromise',
            'idor': 'unauthorized data access',
            'csrf': 'unauthorized actions on behalf of users'
        }
        return descriptions.get(category, 'security compromise')

    def _get_exploitation_step(self, category: str) -> str:
        steps = {
            'xss': 'Inject the payload into the vulnerable parameter',
            'sqli': 'Submit a SQL injection payload in the vulnerable field',
            'ssrf': 'Provide a URL pointing to an internal resource',
            'idor': 'Modify the object ID to access another user\'s data',
            'csrf': 'Trick an authenticated user into visiting the crafted URL'
        }
        return steps.get(category, 'Exploit the vulnerability as described')

    def _get_expected_behavior(self, category: str) -> str:
        behaviors = {
            'xss': 'sanitize or encode the input',
            'sqli': 'use parameterized queries',
            'ssrf': 'validate the URL whitelist',
            'idor': 'verify user authorization',
            'csrf': 'require a valid anti-CSRF token'
        }
        return behaviors.get(category, 'implement proper security controls')
