"""
Smart Target Prioritization System
Uses ML-based scoring to prioritize highest-value targets first.
"""

import logging
from typing import Dict, List, Tuple
from datetime import datetime, timedelta
import json

logger = logging.getLogger(__name__)


class TargetPrioritizer:
    """Intelligent target prioritization based on multiple factors."""

    def __init__(self, db_connection=None):
        """Initialize target prioritizer."""
        self.db = db_connection

        # Scoring weights (tune these based on results)
        self.weights = {
            'bounty_amount': 0.30,      # Higher bounties = higher priority
            'response_time': 0.15,       # Faster triage = better
            'acceptance_rate': 0.20,     # Higher acceptance = reliable
            'asset_count': 0.10,         # More assets = more opportunities
            'last_scanned': 0.10,        # Older scans = higher priority
            'difficulty': 0.10,          # Lower competition = better
            'reputation': 0.05           # Program reputation
        }

    async def prioritize_programs(self, programs: List[Dict]) -> List[Tuple[Dict, float]]:
        """
        Score and prioritize programs for maximum ROI.

        Returns: List of (program, score) tuples sorted by score descending
        """
        scored_programs = []

        for program in programs:
            score = await self._calculate_score(program)
            scored_programs.append((program, score))

        # Sort by score descending
        scored_programs.sort(key=lambda x: x[1], reverse=True)

        logger.info(f"Prioritized {len(scored_programs)} programs")
        self._log_top_programs(scored_programs[:5])

        return scored_programs

    async def _calculate_score(self, program: Dict) -> float:
        """Calculate priority score for a program."""
        score = 0.0

        # 1. Bounty Amount Score (0-100)
        bounty_score = self._score_bounty_amount(program)
        score += bounty_score * self.weights['bounty_amount']

        # 2. Response Time Score (0-100)
        response_score = self._score_response_time(program)
        score += response_score * self.weights['response_time']

        # 3. Acceptance Rate Score (0-100)
        acceptance_score = self._score_acceptance_rate(program)
        score += acceptance_score * self.weights['acceptance_rate']

        # 4. Asset Count Score (0-100)
        asset_score = self._score_asset_count(program)
        score += asset_score * self.weights['asset_count']

        # 5. Last Scanned Score (0-100)
        freshness_score = self._score_freshness(program)
        score += freshness_score * self.weights['last_scanned']

        # 6. Difficulty Score (0-100)
        difficulty_score = self._score_difficulty(program)
        score += difficulty_score * self.weights['difficulty']

        # 7. Reputation Score (0-100)
        reputation_score = self._score_reputation(program)
        score += reputation_score * self.weights['reputation']

        return round(score, 2)

    def _score_bounty_amount(self, program: Dict) -> float:
        """Score based on bounty amounts (higher is better)."""
        rewards = program.get('rewards', {})

        # Get critical bounty amount
        critical_bounty = 0
        if isinstance(rewards, dict):
            critical_bounty = rewards.get('critical', 0)

        # Scale: $0 = 0, $5000 = 50, $10000+ = 100
        if critical_bounty >= 10000:
            return 100.0
        elif critical_bounty >= 5000:
            return 50 + (critical_bounty - 5000) / 100
        elif critical_bounty > 0:
            return critical_bounty / 100
        else:
            # No public bounty info, assume medium
            return 50.0

    def _score_response_time(self, program: Dict) -> float:
        """Score based on average response time (faster is better)."""
        # If we have historical data from database
        if self.db:
            avg_response = self._get_avg_response_time(program.get('name'))
            if avg_response:
                # Scale: <1 day = 100, 7 days = 50, 30+ days = 0
                if avg_response <= 1:
                    return 100.0
                elif avg_response <= 7:
                    return 100 - (avg_response - 1) * 8.33
                elif avg_response <= 30:
                    return 50 - (avg_response - 7) * 2.17
                else:
                    return 0.0

        # Default: assume medium response time
        return 60.0

    def _score_acceptance_rate(self, program: Dict) -> float:
        """Score based on report acceptance rate (higher is better)."""
        if self.db:
            rate = self._get_acceptance_rate(program.get('name'))
            if rate is not None:
                return rate  # Already 0-100

        # Default: assume decent acceptance rate
        return 70.0

    def _score_asset_count(self, program: Dict) -> float:
        """Score based on number of in-scope assets (more is better)."""
        scope = program.get('scope', [])

        if isinstance(scope, list):
            count = len(scope)
        else:
            count = 0

        # Scale: 0 assets = 0, 10 assets = 50, 50+ assets = 100
        if count >= 50:
            return 100.0
        elif count >= 10:
            return 50 + (count - 10) * 1.25
        elif count > 0:
            return count * 5
        else:
            return 30.0  # Unknown scope

    def _score_freshness(self, program: Dict) -> float:
        """Score based on when last scanned (older is higher priority)."""
        last_scanned = program.get('last_scanned')

        if not last_scanned:
            return 100.0  # Never scanned = highest priority

        try:
            if isinstance(last_scanned, str):
                last_scan_time = datetime.fromisoformat(last_scanned)
            else:
                last_scan_time = last_scanned

            days_ago = (datetime.now() - last_scan_time).days

            # Scale: 7+ days = 100, 3 days = 60, <1 day = 20
            if days_ago >= 7:
                return 100.0
            elif days_ago >= 3:
                return 60 + (days_ago - 3) * 10
            elif days_ago >= 1:
                return 20 + (days_ago - 1) * 20
            else:
                return 20.0
        except:
            return 100.0  # Can't parse, assume needs scan

    def _score_difficulty(self, program: Dict) -> float:
        """Score based on difficulty/competition (easier is better)."""
        # Indicators of difficulty:
        # - Public vs private
        # - Number of researchers
        # - Average bounty / reports ratio

        if program.get('platform') == 'private':
            return 100.0  # Private programs = less competition

        # Check if program has many researchers (more competition)
        # This would need API data, so we'll estimate

        # For now, check program maturity
        discovered_at = program.get('discovered_at')
        if discovered_at:
            try:
                if isinstance(discovered_at, str):
                    discovered_time = datetime.fromisoformat(discovered_at)
                else:
                    discovered_time = discovered_at

                days_old = (datetime.now() - discovered_time).days

                # Newer programs = easier (less picked over)
                if days_old <= 30:
                    return 100.0  # Brand new
                elif days_old <= 90:
                    return 80.0
                elif days_old <= 180:
                    return 60.0
                elif days_old <= 365:
                    return 40.0
                else:
                    return 30.0  # Very mature
            except:
                pass

        return 50.0  # Unknown difficulty

    def _score_reputation(self, program: Dict) -> float:
        """Score based on program reputation (pays fairly, good triage, etc)."""
        # Known good programs get boost
        good_programs = [
            'google', 'microsoft', 'apple', 'facebook', 'tesla',
            'paypal', 'shopify', 'twitter', 'github', 'gitlab',
            'red hat', 'redhat', 'ibm', 'intel', 'amazon', 'netflix'
        ]

        program_name = program.get('name', '').lower()

        for good in good_programs:
            if good in program_name:
                return 100.0

        # Default reputation
        return 70.0

    def _get_avg_response_time(self, program_name: str) -> float:
        """Get average response time from database."""
        if not self.db:
            return None

        try:
            cursor = self.db.conn.cursor()
            # This is hypothetical - would need actual response time tracking
            # For now, return None
            return None
        except:
            return None

    def _get_acceptance_rate(self, program_name: str) -> float:
        """Get report acceptance rate from database."""
        if not self.db:
            return None

        try:
            cursor = self.db.conn.cursor()
            cursor.execute("""
                SELECT
                    COUNT(*) as total,
                    SUM(CASE WHEN submitted = 1 THEN 1 ELSE 0 END) as accepted
                FROM reports
                WHERE program_name = ?
            """, (program_name,))

            row = cursor.fetchone()
            if row and row[0] > 0:
                return (row[1] / row[0]) * 100

            return None
        except:
            return None

    def _log_top_programs(self, top_programs: List[Tuple[Dict, float]]):
        """Log top priority programs."""
        logger.info("=" * 60)
        logger.info("TOP 5 PRIORITY TARGETS")
        logger.info("=" * 60)

        for i, (program, score) in enumerate(top_programs[:5], 1):
            logger.info(f"{i}. {program.get('name')} - Score: {score:.2f}")
            logger.info(f"   Platform: {program.get('platform')}")
            logger.info(f"   Scope items: {len(program.get('scope', []))}")

        logger.info("=" * 60)

    async def suggest_next_target(self, programs: List[Dict]) -> Dict:
        """Suggest the single best target to scan next."""
        prioritized = await self.prioritize_programs(programs)

        if prioritized:
            best_program, best_score = prioritized[0]

            logger.info(f"🎯 RECOMMENDED TARGET: {best_program.get('name')} (Score: {best_score:.2f})")

            return {
                'program': best_program,
                'score': best_score,
                'reason': self._explain_score(best_program, best_score)
            }

        return None

    def _explain_score(self, program: Dict, score: float) -> str:
        """Explain why this program was scored highly."""
        reasons = []

        bounty_score = self._score_bounty_amount(program)
        if bounty_score >= 80:
            reasons.append(f"High bounties (${program.get('rewards', {}).get('critical', 'N/A')})")

        asset_score = self._score_asset_count(program)
        if asset_score >= 80:
            reasons.append(f"Large attack surface ({len(program.get('scope', []))} assets)")

        freshness_score = self._score_freshness(program)
        if freshness_score >= 80:
            reasons.append("Haven't scanned recently")

        difficulty_score = self._score_difficulty(program)
        if difficulty_score >= 80:
            reasons.append("Low competition")

        if not reasons:
            reasons.append("Good overall balance")

        return ", ".join(reasons)

    def get_scoring_breakdown(self, program: Dict) -> Dict:
        """Get detailed scoring breakdown for analysis."""
        return {
            'bounty_amount': self._score_bounty_amount(program),
            'response_time': self._score_response_time(program),
            'acceptance_rate': self._score_acceptance_rate(program),
            'asset_count': self._score_asset_count(program),
            'freshness': self._score_freshness(program),
            'difficulty': self._score_difficulty(program),
            'reputation': self._score_reputation(program),
            'total_score': sum([
                self._score_bounty_amount(program) * self.weights['bounty_amount'],
                self._score_response_time(program) * self.weights['response_time'],
                self._score_acceptance_rate(program) * self.weights['acceptance_rate'],
                self._score_asset_count(program) * self.weights['asset_count'],
                self._score_freshness(program) * self.weights['last_scanned'],
                self._score_difficulty(program) * self.weights['difficulty'],
                self._score_reputation(program) * self.weights['reputation']
            ])
        }

    def tune_weights(self, historical_data: List[Dict]):
        """Tune scoring weights based on historical success."""
        # This would implement ML-based weight optimization
        # For now, using expert-tuned weights
        logger.info("Weight tuning would require historical success data")
        pass
