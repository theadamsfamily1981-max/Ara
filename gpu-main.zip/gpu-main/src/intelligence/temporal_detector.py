"""
Temporal Pattern Detector - Time-Based Vulnerability Discovery

Detects vulnerabilities that only manifest:
- At specific times of day (backup windows, maintenance windows)
- After specific sequences over days/weeks
- After N operations (threshold-based bugs)
- After state accumulation
- During scheduled job execution

The unfair advantage: Humans test "now". We monitor 24/7 over weeks to find
temporal patterns and time-window vulnerabilities impossible for humans to catch.

Finds:
- Time-window vulnerabilities (auth disabled during backups)
- Sequence-dependent bugs (11th edit bypasses auth)
- State accumulation vulnerabilities (counter overflow after 1000 actions)
- Token expiration races (expired tokens with side effects)
- Scheduled job vulnerabilities (cron job exposes admin API)
- Time-of-day behavior changes (different auth at 3 AM)

Expected impact: 10-15 findings/month @ $12K-$25K = $120K-$375K/month
"""

import asyncio
import aiohttp
import time
from typing import Dict, List, Set, Tuple, Optional, Any
from dataclasses import dataclass, field
from collections import defaultdict
from datetime import datetime, timedelta
from enum import Enum
import json


class TemporalPattern(Enum):
    """Types of temporal patterns"""
    TIME_WINDOW = "time_window"  # Behavior changes at specific times
    SEQUENCE_DEPENDENT = "sequence_dependent"  # After N operations
    STATE_ACCUMULATION = "state_accumulation"  # After accumulating state
    TOKEN_EXPIRATION = "token_expiration"  # Expired token behavior
    SCHEDULED_JOB = "scheduled_job"  # During cron/scheduled tasks
    RATE_LIMIT_RESET = "rate_limit_reset"  # After rate limit resets


@dataclass
class TemporalBehavior:
    """Observed behavior at a specific time"""
    timestamp: float
    endpoint: str
    method: str
    response_status: int
    response_time_ms: float
    response_body: str
    auth_required: bool
    succeeded: bool
    hour_of_day: int
    day_of_week: int
    sequence_number: int  # Nth request in sequence


@dataclass
class TemporalVulnerability:
    """A time-based vulnerability"""
    vuln_id: str
    pattern_type: TemporalPattern
    title: str
    severity: str
    cvss_score: float
    description: str
    time_conditions: str  # When this vulnerability is exploitable
    evidence: List[TemporalBehavior]
    exploitation_steps: List[str]
    impact: str
    confidence: float


class TemporalDetector:
    """
    Detects temporal patterns and time-based vulnerabilities
    """

    def __init__(self):
        self.behaviors: List[TemporalBehavior] = []
        self.vulnerabilities: List[TemporalVulnerability] = []

        # Track behavior over time
        self.hourly_behavior: Dict[int, List[TemporalBehavior]] = defaultdict(list)
        self.sequence_tracking: Dict[str, List[TemporalBehavior]] = defaultdict(list)

    async def monitor_over_time(
        self,
        target_url: str,
        endpoints: List[str],
        duration_hours: int = 24,
        check_interval_minutes: int = 30
    ):
        """
        Monitors endpoints over extended time period to detect temporal patterns

        Args:
            target_url: Base URL to monitor
            endpoints: List of endpoints to check
            duration_hours: How long to monitor (24 = one day, 168 = one week)
            check_interval_minutes: How often to check
        """

        print(f"[*] Starting temporal monitoring for {duration_hours} hours...")
        print(f"    Checking every {check_interval_minutes} minutes")
        print(f"    Total checks: {int(duration_hours * 60 / check_interval_minutes)}")

        start_time = time.time()
        end_time = start_time + (duration_hours * 3600)
        check_count = 0

        while time.time() < end_time:
            current_time = datetime.now()
            hour = current_time.hour
            day_of_week = current_time.weekday()

            print(f"[*] Check #{check_count + 1} at {current_time.strftime('%Y-%m-%d %H:%M:%S')}")

            # Test all endpoints
            for endpoint in endpoints:
                behavior = await self._test_endpoint(
                    target_url,
                    endpoint,
                    check_count,
                    hour,
                    day_of_week
                )

                if behavior:
                    self.behaviors.append(behavior)
                    self.hourly_behavior[hour].append(behavior)
                    self.sequence_tracking[endpoint].append(behavior)

            check_count += 1

            # Wait for next check
            await asyncio.sleep(check_interval_minutes * 60)

        print(f"[+] Monitoring complete. Collected {len(self.behaviors)} temporal data points")

    async def _test_endpoint(
        self,
        base_url: str,
        endpoint: str,
        sequence_num: int,
        hour: int,
        day_of_week: int
    ) -> Optional[TemporalBehavior]:
        """
        Tests an endpoint and records temporal behavior
        """

        url = f"{base_url}{endpoint}"
        start_time = time.time()

        try:
            # Test with and without authentication
            behaviors = []

            # Without auth
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url,
                    timeout=aiohttp.ClientTimeout(total=10),
                    ssl=False
                ) as response:
                    response_time_ms = (time.time() - start_time) * 1000
                    body = await response.text()
                    status = response.status

                    return TemporalBehavior(
                        timestamp=time.time(),
                        endpoint=endpoint,
                        method="GET",
                        response_status=status,
                        response_time_ms=response_time_ms,
                        response_body=body[:500],
                        auth_required=False,
                        succeeded=(200 <= status < 300),
                        hour_of_day=hour,
                        day_of_week=day_of_week,
                        sequence_number=sequence_num
                    )

        except Exception as e:
            return None

    async def test_sequence_dependent(
        self,
        target_url: str,
        endpoint: str,
        max_sequence: int = 100
    ):
        """
        Tests for sequence-dependent vulnerabilities (bugs after N operations)
        """

        print(f"[*] Testing sequence-dependent behavior on {endpoint}")
        print(f"    Testing up to {max_sequence} sequential operations")

        for i in range(1, max_sequence + 1):
            behavior = await self._perform_operation(target_url, endpoint, i)

            if behavior:
                self.behaviors.append(behavior)
                self.sequence_tracking[endpoint].append(behavior)

                # Check for behavior change
                if i > 1:
                    prev_behavior = self.sequence_tracking[endpoint][-2]

                    # Detect if behavior changed at this sequence number
                    if behavior.succeeded != prev_behavior.succeeded:
                        print(f"[!] Behavior change detected at sequence {i}")

            # Small delay between operations
            await asyncio.sleep(0.1)

        print(f"[+] Sequence testing complete: {len(self.sequence_tracking[endpoint])} operations")

    async def _perform_operation(
        self,
        base_url: str,
        endpoint: str,
        sequence_num: int
    ) -> Optional[TemporalBehavior]:
        """
        Performs a single operation in a sequence
        """

        url = f"{base_url}{endpoint}"

        try:
            async with aiohttp.ClientSession() as session:
                # POST operation to trigger sequence behavior
                async with session.post(
                    url,
                    json={"sequence": sequence_num, "action": "test"},
                    timeout=aiohttp.ClientTimeout(total=10),
                    ssl=False
                ) as response:
                    body = await response.text()
                    status = response.status

                    return TemporalBehavior(
                        timestamp=time.time(),
                        endpoint=endpoint,
                        method="POST",
                        response_status=status,
                        response_time_ms=0,
                        response_body=body[:500],
                        auth_required=False,
                        succeeded=(200 <= status < 300),
                        hour_of_day=datetime.now().hour,
                        day_of_week=datetime.now().weekday(),
                        sequence_number=sequence_num
                    )

        except:
            return None

    async def test_state_accumulation(
        self,
        target_url: str,
        endpoint: str,
        accumulation_actions: List[Dict[str, Any]]
    ):
        """
        Tests for state accumulation vulnerabilities
        (e.g., counter overflow after 1000 likes)
        """

        print(f"[*] Testing state accumulation on {endpoint}")
        print(f"    Performing {len(accumulation_actions)} actions")

        for i, action in enumerate(accumulation_actions):
            url = f"{base_url}{endpoint}"

            try:
                async with aiohttp.ClientSession() as session:
                    async with session.post(
                        url,
                        json=action,
                        timeout=aiohttp.ClientTimeout(total=10),
                        ssl=False
                    ) as response:
                        body = await response.text()
                        status = response.status

                        behavior = TemporalBehavior(
                            timestamp=time.time(),
                            endpoint=endpoint,
                            method="POST",
                            response_status=status,
                            response_time_ms=0,
                            response_body=body[:500],
                            auth_required=False,
                            succeeded=(200 <= status < 300),
                            hour_of_day=datetime.now().hour,
                            day_of_week=datetime.now().weekday(),
                            sequence_number=i + 1
                        )

                        self.behaviors.append(behavior)

                        # Check for overflow/accumulation effects
                        if "overflow" in body.lower() or "negative" in body.lower():
                            print(f"[!] Potential accumulation bug at action {i + 1}")

            except:
                pass

            await asyncio.sleep(0.05)

    async def analyze_vulnerabilities(self) -> List[TemporalVulnerability]:
        """
        Analyzes collected temporal data for vulnerabilities
        """

        print(f"[*] Analyzing temporal patterns...")

        vulns = []
        vulns.extend(self._find_time_window_vulnerabilities())
        vulns.extend(self._find_sequence_dependent_vulnerabilities())
        vulns.extend(self._find_state_accumulation_vulnerabilities())
        vulns.extend(self._find_scheduled_job_vulnerabilities())

        self.vulnerabilities = vulns

        print(f"[+] Found {len(vulns)} temporal vulnerabilities")

        return vulns

    def _find_time_window_vulnerabilities(self) -> List[TemporalVulnerability]:
        """
        Finds vulnerabilities that only exist during specific time windows
        """

        vulns = []

        # Group behaviors by hour
        for hour, behaviors in self.hourly_behavior.items():
            # Check if this hour has different behavior than other hours
            success_rate_this_hour = sum(1 for b in behaviors if b.succeeded) / len(behaviors) if behaviors else 0

            # Compare with other hours
            other_hours_behaviors = [b for h, bl in self.hourly_behavior.items() if h != hour for b in bl]
            success_rate_other_hours = sum(1 for b in other_hours_behaviors if b.succeeded) / len(other_hours_behaviors) if other_hours_behaviors else 0

            # If success rate significantly different
            if abs(success_rate_this_hour - success_rate_other_hours) > 0.3:
                # Potential time window vulnerability
                if success_rate_this_hour > success_rate_other_hours:
                    vulns.append(TemporalVulnerability(
                        vuln_id=f"time_window_{hour}",
                        pattern_type=TemporalPattern.TIME_WINDOW,
                        title=f"Authentication Bypass During Hour {hour}:00",
                        severity="high",
                        cvss_score=8.0,
                        description=(
                            f"Endpoints show significantly different behavior at hour {hour}:00. "
                            f"Success rate: {success_rate_this_hour*100:.1f}% (vs {success_rate_other_hours*100:.1f}% normally). "
                            "This may indicate backup/maintenance window with disabled security."
                        ),
                        time_conditions=f"Exploitable during hour {hour}:00-{(hour+1)%24}:00",
                        evidence=behaviors[:5],
                        exploitation_steps=[
                            f"1. Wait for time window: {hour}:00-{(hour+1)%24}:00",
                            "2. Send requests during this window",
                            "3. Security controls are weakened/disabled",
                            "4. Unauthorized access succeeds"
                        ],
                        impact="Time-based authentication bypass",
                        confidence=0.85
                    ))

        return vulns

    def _find_sequence_dependent_vulnerabilities(self) -> List[TemporalVulnerability]:
        """
        Finds bugs that appear after N operations
        """

        vulns = []

        # Check each endpoint's sequence
        for endpoint, behaviors in self.sequence_tracking.items():
            if len(behaviors) < 10:
                continue

            # Look for behavior changes at specific sequence numbers
            for i in range(1, len(behaviors)):
                curr = behaviors[i]
                prev = behaviors[i - 1]

                # If behavior changed from denied to allowed
                if not prev.succeeded and curr.succeeded:
                    # Check if auth status changed
                    if not prev.auth_required and curr.succeeded:
                        vulns.append(TemporalVulnerability(
                            vuln_id=f"sequence_{endpoint}_{i}",
                            pattern_type=TemporalPattern.SEQUENCE_DEPENDENT,
                            title=f"Sequence-Dependent Auth Bypass After {i} Operations",
                            severity="high",
                            cvss_score=7.5,
                            description=(
                                f"After {i} operations on {endpoint}, authentication check is bypassed. "
                                f"Operations 1-{i-1} correctly enforce auth, but operation {i}+ do not. "
                                "This suggests caching/threshold bug."
                            ),
                            time_conditions=f"After {i} operations on same endpoint",
                            evidence=[prev, curr],
                            exploitation_steps=[
                                f"1. Perform {i-1} legitimate operations",
                                f"2. On operation {i}, authentication is not checked",
                                "3. Exploit with unauthorized access",
                                f"4. All subsequent operations bypass auth"
                            ],
                            impact="Authentication bypass after sequence threshold",
                            confidence=0.8
                        ))

        return vulns

    def _find_state_accumulation_vulnerabilities(self) -> List[TemporalVulnerability]:
        """
        Finds vulnerabilities from state accumulation (e.g., counter overflow)
        """

        vulns = []

        # Look for overflow indicators in responses
        for i, behavior in enumerate(self.behaviors):
            body_lower = behavior.response_body.lower()

            # Check for overflow indicators
            overflow_indicators = [
                "overflow",
                "negative",
                "too many",
                "limit exceeded",
                "-2147483648",  # INT_MIN
                "2147483647"    # INT_MAX
            ]

            if any(indicator in body_lower for indicator in overflow_indicators):
                # Check if this is after many operations
                endpoint_behaviors = self.sequence_tracking.get(behavior.endpoint, [])

                if behavior.sequence_number > 100:
                    vulns.append(TemporalVulnerability(
                        vuln_id=f"accumulation_{behavior.endpoint}_{behavior.sequence_number}",
                        pattern_type=TemporalPattern.STATE_ACCUMULATION,
                        title=f"State Accumulation Bug After {behavior.sequence_number} Operations",
                        severity="medium",
                        cvss_score=6.0,
                        description=(
                            f"After {behavior.sequence_number} operations, state accumulation causes "
                            "unexpected behavior (overflow/underflow). This may lead to privilege escalation "
                            "or business logic bypass."
                        ),
                        time_conditions=f"After approximately {behavior.sequence_number} operations",
                        evidence=[behavior],
                        exploitation_steps=[
                            f"1. Perform {behavior.sequence_number} operations",
                            "2. Counter/state overflows or underflows",
                            "3. Exploit unexpected state for privilege escalation",
                            "4. Example: Negative balance allows unlimited withdrawals"
                        ],
                        impact="Business logic bypass via state accumulation",
                        confidence=0.7
                    ))

        return vulns

    def _find_scheduled_job_vulnerabilities(self) -> List[TemporalVulnerability]:
        """
        Finds vulnerabilities related to scheduled jobs/cron tasks
        """

        vulns = []

        # Look for patterns that suggest scheduled job execution
        # Common times: midnight (0), 2 AM (2), 3 AM (3)
        suspicious_hours = [0, 2, 3, 4]

        for hour in suspicious_hours:
            if hour not in self.hourly_behavior:
                continue

            behaviors = self.hourly_behavior[hour]

            # Check for unusual patterns during these hours
            for behavior in behaviors:
                # Look for admin/debug endpoints being accessible
                if any(keyword in behavior.endpoint.lower() for keyword in ['admin', 'debug', 'internal', 'cron', 'job']):
                    if behavior.succeeded:
                        vulns.append(TemporalVulnerability(
                            vuln_id=f"scheduled_job_{hour}_{behavior.endpoint}",
                            pattern_type=TemporalPattern.SCHEDULED_JOB,
                            title=f"Scheduled Job Exposes Privileged Endpoint at {hour}:00",
                            severity="high",
                            cvss_score=7.8,
                            description=(
                                f"Privileged endpoint {behavior.endpoint} is accessible at {hour}:00. "
                                "This may be exposed during scheduled job execution (cron/backup). "
                                "Normal security controls appear disabled during this time."
                            ),
                            time_conditions=f"During scheduled job execution (~{hour}:00)",
                            evidence=[behavior],
                            exploitation_steps=[
                                f"1. Monitor for scheduled job execution (~{hour}:00)",
                                f"2. Access {behavior.endpoint} during this window",
                                "3. Security controls disabled for job execution",
                                "4. Gain privileged access"
                            ],
                            impact="Privilege escalation via scheduled job window",
                            confidence=0.75
                        ))

        return vulns

    def generate_report(self) -> str:
        """Generates markdown report of temporal analysis"""

        report = ["# Temporal Pattern Analysis Report", ""]
        report.append(f"**Analysis Date:** {datetime.now().isoformat()}")
        report.append(f"**Monitoring Duration:** {len(set(b.hour_of_day for b in self.behaviors))} unique hours")
        report.append(f"**Data Points Collected:** {len(self.behaviors)}")
        report.append(f"**Vulnerabilities Found:** {len(self.vulnerabilities)}")
        report.append("")

        # Temporal coverage
        hours_covered = sorted(set(b.hour_of_day for b in self.behaviors))
        report.append("## Temporal Coverage")
        report.append(f"**Hours monitored:** {', '.join(map(str, hours_covered))}")
        report.append("")

        # Group by pattern type
        by_pattern = defaultdict(list)
        for vuln in self.vulnerabilities:
            by_pattern[vuln.pattern_type].append(vuln)

        report.append("## Vulnerability Patterns")
        for pattern, vulns in by_pattern.items():
            report.append(f"- {pattern.value}: {len(vulns)}")
        report.append("")

        # Group by severity
        by_severity = defaultdict(list)
        for vuln in self.vulnerabilities:
            by_severity[vuln.severity].append(vuln)

        for severity in ['critical', 'high', 'medium', 'low']:
            if severity in by_severity:
                report.append(f"## {severity.upper()} Severity ({len(by_severity[severity])})")
                report.append("")

                for vuln in by_severity[severity]:
                    report.append(f"### {vuln.title}")
                    report.append(f"**Pattern:** {vuln.pattern_type.value} | **CVSS:** {vuln.cvss_score} | **Confidence:** {vuln.confidence*100:.0f}%")
                    report.append(f"**Time Conditions:** {vuln.time_conditions}")
                    report.append("")
                    report.append(f"**Description:**")
                    report.append(vuln.description)
                    report.append("")
                    report.append(f"**Impact:** {vuln.impact}")
                    report.append("")
                    report.append(f"**Exploitation Steps:**")
                    for step in vuln.exploitation_steps:
                        report.append(f"{step}")
                    report.append("")
                    report.append("---")
                    report.append("")

        return "\n".join(report)


# Example usage
async def detect_temporal_patterns(target_url: str):
    """
    Main entry point for temporal pattern detection
    """

    detector = TemporalDetector()

    # Example 1: Monitor over 24 hours
    await detector.monitor_over_time(
        target_url=target_url,
        endpoints=["/api/admin", "/api/users", "/api/backup"],
        duration_hours=24,
        check_interval_minutes=30
    )

    # Example 2: Test sequence-dependent behavior
    await detector.test_sequence_dependent(
        target_url=target_url,
        endpoint="/api/comments",
        max_sequence=50
    )

    # Analyze for vulnerabilities
    vulns = await detector.analyze_vulnerabilities()

    # Generate report
    report = detector.generate_report()

    return vulns, report


if __name__ == "__main__":
    vulns, report = asyncio.run(detect_temporal_patterns("https://example.com"))

    print("\n" + "="*60)
    print(report)
    print("="*60)

    print(f"\nFound {len(vulns)} temporal vulnerabilities!")
