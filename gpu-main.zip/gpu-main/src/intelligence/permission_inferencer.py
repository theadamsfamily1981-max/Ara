"""
Permission Model Inferencer - Exhaustive Access Control Testing

Builds complete permission model through exhaustive testing of all
user × resource × action combinations.

The unfair advantage: Humans test a few combinations. We test THOUSANDS
systematically to find inconsistencies in the permission model.

Finds:
- IDORs (Insecure Direct Object References)
- Horizontal privilege escalation (access other users' resources)
- Vertical privilege escalation (low-priv user gains admin)
- Permission leakage patterns (even IDs vulnerable, odd IDs protected)
- Role confusion (user with multiple roles gets wrong permissions)
- Permission inheritance bugs (parent permissions leak to children)

Expected impact: 12-20 findings/month @ $8K-$15K = $96K-$300K/month
"""

import asyncio
import aiohttp
import itertools
from typing import Dict, List, Set, Tuple, Optional, Any
from dataclasses import dataclass, field
from collections import defaultdict
from enum import Enum
from datetime import datetime


class Action(Enum):
    """Possible actions on resources"""
    READ = "read"
    WRITE = "write"
    DELETE = "delete"
    ADMIN = "admin"
    EXECUTE = "execute"


class PermissionResult(Enum):
    """Result of permission test"""
    ALLOWED = "allowed"
    DENIED = "denied"
    ERROR = "error"


@dataclass
class User:
    """Represents a user with roles"""
    user_id: str
    username: str
    roles: List[str]
    token: str


@dataclass
class Resource:
    """Represents a resource with ownership"""
    resource_type: str
    resource_id: str
    owner_id: str
    parent_id: Optional[str] = None  # For hierarchical resources


@dataclass
class PermissionTest:
    """Single permission test result"""
    user: User
    resource: Resource
    action: Action
    result: PermissionResult
    http_status: int
    response_time_ms: float
    response_body: str


@dataclass
class PermissionVulnerability:
    """A permission vulnerability"""
    vuln_id: str
    vuln_type: str  # idor, horizontal_privesc, vertical_privesc, etc.
    title: str
    severity: str
    cvss_score: float
    description: str
    evidence: List[PermissionTest]
    exploitation_steps: List[str]
    impact: str
    confidence: float


class PermissionInferencer:
    """
    Infers complete permission model through exhaustive testing
    """

    def __init__(self):
        self.users: List[User] = []
        self.resources: List[Resource] = []
        self.tests: List[PermissionTest] = []
        self.vulnerabilities: List[PermissionVulnerability] = []

        # Permission matrix: (user_id, resource_id, action) -> result
        self.permission_matrix: Dict[Tuple[str, str, Action], PermissionResult] = {}

    def add_user(self, user: User):
        """Adds a user to test with"""
        self.users.append(user)

    def add_resource(self, resource: Resource):
        """Adds a resource to test"""
        self.resources.append(resource)

    async def build_permission_matrix(
        self,
        target_url: str,
        endpoint_template: str = "/api/{resource_type}/{resource_id}"
    ):
        """
        Builds complete permission matrix by testing all combinations

        Args:
            target_url: Base URL
            endpoint_template: Template for resource endpoints
        """

        print(f"[*] Building permission matrix...")
        print(f"    Users: {len(self.users)}")
        print(f"    Resources: {len(self.resources)}")
        print(f"    Actions: {len(Action)}")
        print(f"    Total tests: {len(self.users) * len(self.resources) * len(Action)}")

        # Test all combinations
        tasks = []
        for user in self.users:
            for resource in self.resources:
                for action in Action:
                    task = self._test_permission(
                        target_url,
                        endpoint_template,
                        user,
                        resource,
                        action
                    )
                    tasks.append(task)

        # Execute tests concurrently (batch to avoid overwhelming server)
        batch_size = 10
        for i in range(0, len(tasks), batch_size):
            batch = tasks[i:i+batch_size]
            results = await asyncio.gather(*batch)
            self.tests.extend([r for r in results if r is not None])

            # Small delay between batches
            await asyncio.sleep(0.1)

        # Build matrix
        for test in self.tests:
            key = (test.user.user_id, test.resource.resource_id, test.action)
            self.permission_matrix[key] = test.result

        print(f"[+] Completed {len(self.tests)} permission tests")

    async def _test_permission(
        self,
        base_url: str,
        endpoint_template: str,
        user: User,
        resource: Resource,
        action: Action
    ) -> Optional[PermissionTest]:
        """
        Tests a single permission combination
        """

        # Build endpoint URL
        endpoint = endpoint_template.format(
            resource_type=resource.resource_type,
            resource_id=resource.resource_id
        )
        url = f"{base_url}{endpoint}"

        # Map action to HTTP method
        method_map = {
            Action.READ: "GET",
            Action.WRITE: "PUT",
            Action.DELETE: "DELETE",
            Action.ADMIN: "PATCH",
            Action.EXECUTE: "POST"
        }

        method = method_map.get(action, "GET")

        # Headers with user's token
        headers = {
            "Authorization": f"Bearer {user.token}"
        }

        start_time = asyncio.get_event_loop().time()

        try:
            async with aiohttp.ClientSession() as session:
                async with session.request(
                    method=method,
                    url=url,
                    headers=headers,
                    timeout=aiohttp.ClientTimeout(total=10),
                    ssl=False
                ) as response:
                    response_time_ms = (asyncio.get_event_loop().time() - start_time) * 1000
                    body = await response.text()
                    status = response.status

                    # Determine result
                    if status == 200:
                        result = PermissionResult.ALLOWED
                    elif status in [401, 403, 404]:
                        result = PermissionResult.DENIED
                    else:
                        result = PermissionResult.ERROR

                    return PermissionTest(
                        user=user,
                        resource=resource,
                        action=action,
                        result=result,
                        http_status=status,
                        response_time_ms=response_time_ms,
                        response_body=body[:1000]  # Limit body size
                    )

        except Exception as e:
            return PermissionTest(
                user=user,
                resource=resource,
                action=action,
                result=PermissionResult.ERROR,
                http_status=0,
                response_time_ms=0,
                response_body=str(e)
            )

    async def analyze_vulnerabilities(self) -> List[PermissionVulnerability]:
        """
        Analyzes permission matrix to find vulnerabilities
        """

        print("[*] Analyzing permission matrix for vulnerabilities...")

        # Run different analysis methods
        vulns = []
        vulns.extend(self._find_idor_vulnerabilities())
        vulns.extend(self._find_horizontal_privilege_escalation())
        vulns.extend(self._find_vertical_privilege_escalation())
        vulns.extend(self._find_permission_leakage_patterns())
        vulns.extend(self._find_role_confusion())
        vulns.extend(self._find_permission_inheritance_bugs())

        self.vulnerabilities = vulns

        print(f"[+] Found {len(vulns)} permission vulnerabilities")

        return vulns

    def _find_idor_vulnerabilities(self) -> List[PermissionVulnerability]:
        """
        Finds IDOR (Insecure Direct Object Reference) vulnerabilities
        """

        vulns = []

        # Group resources by type
        by_type = defaultdict(list)
        for resource in self.resources:
            by_type[resource.resource_type].append(resource)

        # For each resource type
        for resource_type, resources in by_type.items():
            # For each user
            for user in self.users:
                # Find resources NOT owned by this user
                other_resources = [r for r in resources if r.owner_id != user.user_id]

                # Check if user can access other users' resources
                for resource in other_resources:
                    for action in [Action.READ, Action.WRITE, Action.DELETE]:
                        key = (user.user_id, resource.resource_id, action)
                        result = self.permission_matrix.get(key)

                        if result == PermissionResult.ALLOWED:
                            # IDOR found!
                            test = next(t for t in self.tests if
                                       t.user.user_id == user.user_id and
                                       t.resource.resource_id == resource.resource_id and
                                       t.action == action)

                            vulns.append(PermissionVulnerability(
                                vuln_id=f"idor_{resource_type}_{resource.resource_id}_{action.value}",
                                vuln_type="idor",
                                title=f"IDOR on {resource_type}: {action.value}",
                                severity="high",
                                cvss_score=8.0,
                                description=(
                                    f"User {user.username} (ID: {user.user_id}) can {action.value} "
                                    f"{resource_type} resource {resource.resource_id} owned by "
                                    f"user {resource.owner_id}. Insecure Direct Object Reference allows "
                                    f"unauthorized access to other users' resources."
                                ),
                                evidence=[test],
                                exploitation_steps=[
                                    f"1. Authenticate as {user.username}",
                                    f"2. Send {test.http_status} request to /api/{resource_type}/{resource.resource_id}",
                                    f"3. Successfully {action.value} resource owned by different user",
                                    "4. Access or modify other users' resources"
                                ],
                                impact="Unauthorized access to other users' data",
                                confidence=0.95
                            ))

        return vulns

    def _find_horizontal_privilege_escalation(self) -> List[PermissionVulnerability]:
        """
        Finds horizontal privilege escalation (same role, different users)
        """

        vulns = []

        # Find users with same roles
        by_role = defaultdict(list)
        for user in self.users:
            for role in user.roles:
                by_role[role].append(user)

        # For each role with multiple users
        for role, users in by_role.items():
            if len(users) < 2:
                continue

            # Check if users can access each other's resources
            for i, user1 in enumerate(users):
                for user2 in users[i+1:]:
                    # Find resources owned by user2
                    user2_resources = [r for r in self.resources if r.owner_id == user2.user_id]

                    for resource in user2_resources:
                        for action in Action:
                            key = (user1.user_id, resource.resource_id, action)
                            result = self.permission_matrix.get(key)

                            if result == PermissionResult.ALLOWED:
                                test = next((t for t in self.tests if
                                           t.user.user_id == user1.user_id and
                                           t.resource.resource_id == resource.resource_id and
                                           t.action == action), None)

                                if test:
                                    vulns.append(PermissionVulnerability(
                                        vuln_id=f"horizontal_{user1.user_id}_{resource.resource_id}",
                                        vuln_type="horizontal_privilege_escalation",
                                        title=f"Horizontal Privilege Escalation: {role} role",
                                        severity="high",
                                        cvss_score=7.5,
                                        description=(
                                            f"User {user1.username} ({role}) can access resources owned by "
                                            f"user {user2.username} (same role). Users with same role should not "
                                            f"be able to access each other's resources."
                                        ),
                                        evidence=[test],
                                        exploitation_steps=[
                                            f"1. Authenticate as {user1.username} ({role})",
                                            f"2. Enumerate resource IDs",
                                            f"3. Access resource {resource.resource_id} owned by {user2.username}",
                                            "4. Access all resources of other users with same role"
                                        ],
                                        impact="Access to peer users' data",
                                        confidence=0.9
                                    ))

        return vulns

    def _find_vertical_privilege_escalation(self) -> List[PermissionVulnerability]:
        """
        Finds vertical privilege escalation (lower role accessing higher role resources)
        """

        vulns = []

        # Define role hierarchy (lower to higher)
        role_hierarchy = ['guest', 'user', 'moderator', 'admin', 'superadmin']
        role_levels = {role: i for i, role in enumerate(role_hierarchy)}

        # For each user
        for user in self.users:
            user_level = max([role_levels.get(r, 0) for r in user.roles])

            # Find resources owned by higher-privilege users
            for resource in self.resources:
                owner = next((u for u in self.users if u.user_id == resource.owner_id), None)
                if not owner:
                    continue

                owner_level = max([role_levels.get(r, 0) for r in owner.roles])

                # If user has lower privilege than owner
                if user_level < owner_level:
                    # Check if user can access resource
                    for action in Action:
                        key = (user.user_id, resource.resource_id, action)
                        result = self.permission_matrix.get(key)

                        if result == PermissionResult.ALLOWED:
                            test = next((t for t in self.tests if
                                       t.user.user_id == user.user_id and
                                       t.resource.resource_id == resource.resource_id and
                                       t.action == action), None)

                            if test:
                                vulns.append(PermissionVulnerability(
                                    vuln_id=f"vertical_{user.user_id}_{resource.resource_id}",
                                    vuln_type="vertical_privilege_escalation",
                                    title=f"Vertical Privilege Escalation: {user.roles} → {owner.roles}",
                                    severity="critical",
                                    cvss_score=9.0,
                                    description=(
                                        f"Low-privilege user {user.username} ({user.roles}) can {action.value} "
                                        f"resources owned by higher-privilege user {owner.username} ({owner.roles}). "
                                        f"This is vertical privilege escalation."
                                    ),
                                    evidence=[test],
                                    exploitation_steps=[
                                        f"1. Authenticate as low-privilege user ({user.roles})",
                                        f"2. Identify admin/high-privilege resource IDs",
                                        f"3. Access resource {resource.resource_id}",
                                        "4. Gain access to privileged functionality"
                                    ],
                                    impact="Full privilege escalation to admin",
                                    confidence=0.95
                                ))

        return vulns

    def _find_permission_leakage_patterns(self) -> List[PermissionVulnerability]:
        """
        Finds patterns in permission leakage (e.g., even IDs vulnerable, odd IDs protected)
        """

        vulns = []

        # Group by resource type
        by_type = defaultdict(list)
        for test in self.tests:
            by_type[test.resource.resource_type].append(test)

        # Look for patterns
        for resource_type, type_tests in by_type.items():
            # Check for numeric ID patterns
            vulnerable_ids = []
            protected_ids = []

            for test in type_tests:
                # Only check if user doesn't own resource
                if test.user.user_id != test.resource.owner_id:
                    if test.result == PermissionResult.ALLOWED:
                        vulnerable_ids.append(test.resource.resource_id)
                    else:
                        protected_ids.append(test.resource.resource_id)

            if vulnerable_ids and protected_ids:
                # Try to find patterns
                # Check if even/odd pattern
                try:
                    vuln_nums = [int(id) for id in vulnerable_ids if id.isdigit()]
                    prot_nums = [int(id) for id in protected_ids if id.isdigit()]

                    vuln_even = sum(1 for n in vuln_nums if n % 2 == 0)
                    vuln_odd = len(vuln_nums) - vuln_even

                    # If >80% of vulnerable IDs are even
                    if vuln_even > 0.8 * len(vuln_nums):
                        vulns.append(PermissionVulnerability(
                            vuln_id=f"pattern_{resource_type}_even",
                            vuln_type="permission_leakage_pattern",
                            title=f"Permission Leakage Pattern: Even {resource_type} IDs",
                            severity="high",
                            cvss_score=7.8,
                            description=(
                                f"Even-numbered {resource_type} IDs have weak permission checks. "
                                f"{vuln_even}/{len(vuln_nums)} vulnerable IDs are even. "
                                "This suggests inconsistent permission implementation."
                            ),
                            evidence=type_tests[:5],
                            exploitation_steps=[
                                f"1. Enumerate {resource_type} IDs",
                                "2. Target even-numbered IDs",
                                "3. Access resources without authorization",
                                f"4. ~{vuln_even/len(vuln_nums)*100:.0f}% success rate"
                            ],
                            impact="Systematic IDOR on subset of resources",
                            confidence=0.85
                        ))
                except:
                    pass

        return vulns

    def _find_role_confusion(self) -> List[PermissionVulnerability]:
        """
        Finds role confusion vulnerabilities
        """

        vulns = []

        # Find users with multiple roles
        multi_role_users = [u for u in self.users if len(u.roles) > 1]

        for user in multi_role_users:
            # Check if having multiple roles grants unexpected permissions
            # Compare with users who have only one of those roles

            for resource in self.resources:
                if resource.owner_id == user.user_id:
                    continue  # Skip own resources

                for action in Action:
                    key = (user.user_id, resource.resource_id, action)
                    result = self.permission_matrix.get(key)

                    if result == PermissionResult.ALLOWED:
                        # Check if single-role users can do this
                        single_role_can = False
                        for single_role in user.roles:
                            single_role_users = [u for u in self.users if u.roles == [single_role]]
                            for sr_user in single_role_users:
                                sr_key = (sr_user.user_id, resource.resource_id, action)
                                if self.permission_matrix.get(sr_key) == PermissionResult.ALLOWED:
                                    single_role_can = True

                        if not single_role_can:
                            # Multi-role user can do something single-role users can't
                            test = next((t for t in self.tests if
                                       t.user.user_id == user.user_id and
                                       t.resource.resource_id == resource.resource_id and
                                       t.action == action), None)

                            if test:
                                vulns.append(PermissionVulnerability(
                                    vuln_id=f"role_confusion_{user.user_id}_{resource.resource_id}",
                                    vuln_type="role_confusion",
                                    title=f"Role Confusion: Multiple Roles Grant Unexpected Access",
                                    severity="medium",
                                    cvss_score=6.5,
                                    description=(
                                        f"User {user.username} with roles {user.roles} can {action.value} "
                                        f"resource {resource.resource_id}, but users with individual roles cannot. "
                                        "Having multiple roles grants unexpected permissions."
                                    ),
                                    evidence=[test],
                                    exploitation_steps=[
                                        "1. Create account with multiple roles",
                                        "2. Permission logic checks ANY role instead of ALL roles",
                                        "3. Gain elevated permissions",
                                        "4. Access resources single-role users cannot"
                                    ],
                                    impact="Privilege escalation via role combination",
                                    confidence=0.75
                                ))

        return vulns

    def _find_permission_inheritance_bugs(self) -> List[PermissionVulnerability]:
        """
        Finds permission inheritance bugs in hierarchical resources
        """

        vulns = []

        # Find hierarchical resources (those with parent_id)
        hierarchical = [r for r in self.resources if r.parent_id]

        for resource in hierarchical:
            # Find parent resource
            parent = next((r for r in self.resources if r.resource_id == resource.parent_id), None)
            if not parent:
                continue

            # For each user
            for user in self.users:
                # Check permissions on parent vs child
                for action in Action:
                    parent_key = (user.user_id, parent.resource_id, action)
                    child_key = (user.user_id, resource.resource_id, action)

                    parent_result = self.permission_matrix.get(parent_key)
                    child_result = self.permission_matrix.get(child_key)

                    # If user has permission on parent, should they have it on child?
                    # Check for unexpected inheritance
                    if parent_result == PermissionResult.ALLOWED and child_result == PermissionResult.ALLOWED:
                        # If user doesn't own either
                        if user.user_id != parent.owner_id and user.user_id != resource.owner_id:
                            test = next((t for t in self.tests if
                                       t.user.user_id == user.user_id and
                                       t.resource.resource_id == resource.resource_id and
                                       t.action == action), None)

                            if test:
                                vulns.append(PermissionVulnerability(
                                    vuln_id=f"inheritance_{resource.resource_id}_{action.value}",
                                    vuln_type="permission_inheritance",
                                    title=f"Permission Inheritance Bug: Parent → Child",
                                    severity="medium",
                                    cvss_score=6.0,
                                    description=(
                                        f"User {user.username} has {action.value} permission on parent resource "
                                        f"{parent.resource_id}, which incorrectly grants permission on child "
                                        f"resource {resource.resource_id}. Permissions inherited too broadly."
                                    ),
                                    evidence=[test],
                                    exploitation_steps=[
                                        f"1. Gain access to parent resource {parent.resource_id}",
                                        f"2. Permission inherited to all child resources",
                                        f"3. Access child resource {resource.resource_id}",
                                        "4. Access entire resource hierarchy"
                                    ],
                                    impact="Excessive permission inheritance",
                                    confidence=0.7
                                ))

        return vulns

    def generate_report(self) -> str:
        """Generates markdown report of permission analysis"""

        report = ["# Permission Model Analysis Report", ""]
        report.append(f"**Analysis Date:** {datetime.now().isoformat()}")
        report.append(f"**Users Tested:** {len(self.users)}")
        report.append(f"**Resources Tested:** {len(self.resources)}")
        report.append(f"**Permission Tests:** {len(self.tests)}")
        report.append(f"**Vulnerabilities Found:** {len(self.vulnerabilities)}")
        report.append("")

        # Permission matrix statistics
        total_tests = len(self.tests)
        allowed = sum(1 for t in self.tests if t.result == PermissionResult.ALLOWED)
        denied = sum(1 for t in self.tests if t.result == PermissionResult.DENIED)

        report.append("## Permission Matrix Statistics")
        report.append(f"- Total tests: {total_tests}")
        report.append(f"- Allowed: {allowed} ({allowed/total_tests*100:.1f}%)")
        report.append(f"- Denied: {denied} ({denied/total_tests*100:.1f}%)")
        report.append("")

        # Group by vulnerability type
        by_type = defaultdict(list)
        for vuln in self.vulnerabilities:
            by_type[vuln.vuln_type].append(vuln)

        report.append("## Vulnerability Types")
        for vuln_type, vulns in by_type.items():
            report.append(f"- {vuln_type}: {len(vulns)}")
        report.append("")

        # Group by severity
        by_severity = defaultdict(list)
        for vuln in self.vulnerabilities:
            by_severity[vuln.severity].append(vuln)

        for severity in ['critical', 'high', 'medium', 'low']:
            if severity in by_severity:
                report.append(f"## {severity.upper()} Severity ({len(by_severity[severity])})")
                report.append("")

                for vuln in by_severity[severity]:
                    report.append(f"### {vuln.title}")
                    report.append(f"**Type:** {vuln.vuln_type} | **CVSS:** {vuln.cvss_score} | **Confidence:** {vuln.confidence*100:.0f}%")
                    report.append("")
                    report.append(f"**Description:**")
                    report.append(vuln.description)
                    report.append("")
                    report.append(f"**Impact:** {vuln.impact}")
                    report.append("")
                    report.append(f"**Exploitation Steps:**")
                    for step in vuln.exploitation_steps:
                        report.append(f"{step}")
                    report.append("")
                    report.append("---")
                    report.append("")

        return "\n".join(report)


# Example usage
async def infer_permission_model(target_url: str):
    """
    Main entry point for permission model inference
    """

    inferencer = PermissionInferencer()

    # Add test users with different roles
    inferencer.add_user(User("1", "alice", ["user"], "token_alice"))
    inferencer.add_user(User("2", "bob", ["user"], "token_bob"))
    inferencer.add_user(User("3", "charlie", ["moderator"], "token_charlie"))
    inferencer.add_user(User("4", "admin", ["admin"], "token_admin"))

    # Add test resources
    for i in range(10):
        inferencer.add_resource(Resource(
            resource_type="post",
            resource_id=str(i),
            owner_id=str((i % 2) + 1)  # Alternate between user 1 and 2
        ))

    # Build permission matrix
    await inferencer.build_permission_matrix(target_url)

    # Analyze for vulnerabilities
    vulns = await inferencer.analyze_vulnerabilities()

    # Generate report
    report = inferencer.generate_report()

    return vulns, report


if __name__ == "__main__":
    vulns, report = asyncio.run(infer_permission_model("https://example.com"))

    print("\n" + "="*60)
    print(report)
    print("="*60)

    print(f"\nFound {len(vulns)} permission vulnerabilities!")
