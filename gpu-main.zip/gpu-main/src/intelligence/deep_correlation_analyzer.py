"""
Deep Correlation Analyzer - AI-Level Vulnerability Discovery

This module leverages the ability to hold massive context and correlate patterns
across hundreds of API requests to find vulnerabilities that humans would miss.

Finds:
- Cross-endpoint state leakage
- Information aggregation attacks
- Permission bypass chains
- Cache poisoning vulnerabilities
- Timing-based information disclosure
- Second-order effects
- Protocol confusion
"""

import asyncio
import aiohttp
import time
import statistics
import hashlib
import re
from typing import Dict, List, Tuple, Optional, Any
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import json


@dataclass
class RequestCapture:
    """Captures complete request/response context"""
    request_id: str
    timestamp: float
    method: str
    url: str
    headers: Dict[str, str]
    body: Optional[str]
    response_status: int
    response_headers: Dict[str, str]
    response_body: str
    response_time_ms: float
    user_context: str  # Which user/session made this request

    def __hash__(self):
        return hash(self.request_id)


@dataclass
class CorrelationFinding:
    """Represents a vulnerability found via correlation"""
    finding_id: str
    category: str
    title: str
    severity: str  # critical, high, medium, low
    description: str
    evidence: List[str]
    requests_involved: List[str]
    exploitation_steps: List[str]
    cvss_score: float
    confidence: float  # 0.0 to 1.0


class DeepCorrelationAnalyzer:
    """
    Analyzes API traffic to find vulnerabilities requiring correlation
    across multiple requests, users, and time windows.
    """

    def __init__(self):
        self.captures: List[RequestCapture] = []
        self.findings: List[CorrelationFinding] = []
        self.endpoint_patterns: Dict[str, List[RequestCapture]] = defaultdict(list)
        self.user_contexts: Dict[str, List[RequestCapture]] = defaultdict(list)
        self.timing_data: Dict[str, List[float]] = defaultdict(list)

    async def capture_request(
        self,
        method: str,
        url: str,
        headers: Dict[str, str],
        body: Optional[str],
        user_context: str
    ) -> RequestCapture:
        """
        Captures a single request with full context
        """
        request_id = hashlib.sha256(
            f"{time.time()}{url}{user_context}".encode()
        ).hexdigest()[:16]

        start_time = time.time()

        try:
            async with aiohttp.ClientSession() as session:
                async with session.request(
                    method=method,
                    url=url,
                    headers=headers,
                    data=body,
                    timeout=aiohttp.ClientTimeout(total=30),
                    ssl=False
                ) as response:
                    response_time_ms = (time.time() - start_time) * 1000
                    response_body = await response.text()

                    capture = RequestCapture(
                        request_id=request_id,
                        timestamp=start_time,
                        method=method,
                        url=url,
                        headers=headers,
                        body=body,
                        response_status=response.status,
                        response_headers=dict(response.headers),
                        response_body=response_body,
                        response_time_ms=response_time_ms,
                        user_context=user_context
                    )

                    self.captures.append(capture)

                    # Index by endpoint pattern
                    endpoint_pattern = self._extract_endpoint_pattern(url)
                    self.endpoint_patterns[endpoint_pattern].append(capture)

                    # Index by user context
                    self.user_contexts[user_context].append(capture)

                    # Store timing data
                    self.timing_data[endpoint_pattern].append(response_time_ms)

                    return capture

        except Exception as e:
            # Still capture failed requests
            capture = RequestCapture(
                request_id=request_id,
                timestamp=start_time,
                method=method,
                url=url,
                headers=headers,
                body=body,
                response_status=0,
                response_headers={},
                response_body=str(e),
                response_time_ms=(time.time() - start_time) * 1000,
                user_context=user_context
            )

            self.captures.append(capture)
            return capture

    def _extract_endpoint_pattern(self, url: str) -> str:
        """
        Extracts endpoint pattern by replacing IDs with placeholders
        Example: /api/users/123/posts/456 -> /api/users/{id}/posts/{id}
        """
        # Replace UUIDs
        pattern = re.sub(
            r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',
            '{uuid}',
            url,
            flags=re.IGNORECASE
        )

        # Replace numeric IDs
        pattern = re.sub(r'/\d+/', '/{id}/', pattern)
        pattern = re.sub(r'/\d+$', '/{id}', pattern)

        return pattern

    async def analyze_all(self) -> List[CorrelationFinding]:
        """
        Runs all correlation analyses and returns findings
        """
        print(f"[*] Deep Correlation Analyzer: Analyzing {len(self.captures)} captured requests...")

        # Run all analysis modules
        await asyncio.gather(
            self._analyze_cross_user_state_leakage(),
            self._analyze_information_aggregation(),
            self._analyze_permission_bypass_chains(),
            self._analyze_cache_poisoning(),
            self._analyze_timing_based_disclosure(),
            self._analyze_error_state_leakage(),
            self._analyze_second_order_effects(),
            self._analyze_protocol_confusion(),
            self._analyze_response_consistency(),
            self._analyze_authentication_bypass_chains()
        )

        # Sort by severity and confidence
        self.findings.sort(
            key=lambda f: (
                {"critical": 4, "high": 3, "medium": 2, "low": 1}[f.severity],
                f.confidence
            ),
            reverse=True
        )

        print(f"[+] Found {len(self.findings)} correlation-based vulnerabilities")
        return self.findings

    async def _analyze_cross_user_state_leakage(self):
        """
        Finds state leakage across different user contexts

        Example:
        User A creates resource X
        User B can see resource X in their list
        """
        print("[*] Analyzing cross-user state leakage...")

        # Group requests by endpoint pattern
        for pattern, requests in self.endpoint_patterns.items():
            # Group by user context
            user_responses = defaultdict(list)
            for req in requests:
                user_responses[req.user_context].append(req)

            # Need at least 2 users
            if len(user_responses) < 2:
                continue

            # Compare responses across users
            users = list(user_responses.keys())
            for i, user1 in enumerate(users):
                for user2 in users[i+1:]:
                    # Look for data from user1 appearing in user2's response
                    user1_data = self._extract_identifiers(user_responses[user1])
                    user2_responses = [r.response_body for r in user_responses[user2]]

                    leaks = []
                    for identifier in user1_data:
                        for response in user2_responses:
                            if identifier in response:
                                leaks.append(identifier)

                    if leaks:
                        self.findings.append(CorrelationFinding(
                            finding_id=f"leak_{pattern}_{user1}_{user2}",
                            category="state_leakage",
                            title=f"Cross-User State Leakage in {pattern}",
                            severity="high",
                            description=(
                                f"Data from user context '{user1}' is leaking into "
                                f"responses for user context '{user2}'. This indicates "
                                f"improper isolation between user sessions or accounts."
                            ),
                            evidence=[
                                f"Leaked identifiers: {', '.join(leaks[:5])}",
                                f"Endpoint pattern: {pattern}",
                                f"User 1: {user1}",
                                f"User 2: {user2}"
                            ],
                            requests_involved=[
                                req.request_id for req in user_responses[user1][:3]
                            ] + [
                                req.request_id for req in user_responses[user2][:3]
                            ],
                            exploitation_steps=[
                                f"1. Authenticate as {user1}",
                                f"2. Perform actions on {pattern}",
                                f"3. Authenticate as {user2}",
                                f"4. Access {pattern}",
                                f"5. Observe data from {user1} in responses"
                            ],
                            cvss_score=7.5,
                            confidence=0.9
                        ))

    def _extract_identifiers(self, requests: List[RequestCapture]) -> List[str]:
        """Extracts potential identifiers from requests"""
        identifiers = set()

        for req in requests:
            # Extract from request bodies
            if req.body:
                identifiers.update(self._find_ids_in_text(req.body))

            # Extract from response bodies
            identifiers.update(self._find_ids_in_text(req.response_body))

        return list(identifiers)

    def _find_ids_in_text(self, text: str) -> List[str]:
        """Finds potential identifiers in text"""
        ids = []

        # UUIDs
        ids.extend(re.findall(
            r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',
            text,
            re.IGNORECASE
        ))

        # Numeric IDs (in common patterns)
        ids.extend(re.findall(r'"id":\s*(\d+)', text))
        ids.extend(re.findall(r'"user_id":\s*(\d+)', text))
        ids.extend(re.findall(r'"resource_id":\s*"([^"]+)"', text))

        return ids[:20]  # Limit to avoid overwhelming

    async def _analyze_information_aggregation(self):
        """
        Finds vulnerabilities where aggregating information across
        multiple endpoints reveals sensitive data.

        Example:
        Endpoint A leaks user existence (timing difference)
        Endpoint B leaks user email format (error message)
        Endpoint C leaks user role (different response structure)
        Combined: Full user enumeration
        """
        print("[*] Analyzing information aggregation attacks...")

        # Group endpoints that might leak related information
        for pattern, requests in self.endpoint_patterns.items():
            info_leaks = []

            # Check for timing-based leaks
            if self._has_timing_leak(requests):
                info_leaks.append("Timing difference reveals existence")

            # Check for error message leaks
            error_leaks = self._analyze_error_messages(requests)
            if error_leaks:
                info_leaks.extend(error_leaks)

            # Check for structure-based leaks
            if self._has_structure_leak(requests):
                info_leaks.append("Response structure reveals internal state")

            # If multiple information leaks, this is a finding
            if len(info_leaks) >= 2:
                self.findings.append(CorrelationFinding(
                    finding_id=f"aggr_{pattern}",
                    category="information_aggregation",
                    title=f"Information Aggregation Attack on {pattern}",
                    severity="medium",
                    description=(
                        f"Multiple information leaks can be aggregated to reveal "
                        f"sensitive data. Each leak alone is minor, but combined "
                        f"they provide significant information disclosure."
                    ),
                    evidence=info_leaks,
                    requests_involved=[req.request_id for req in requests[:5]],
                    exploitation_steps=[
                        "1. Collect responses from multiple requests",
                        "2. Aggregate information from timing, errors, and structure",
                        "3. Correlate to build complete picture",
                        "4. Use aggregated data for further attacks"
                    ],
                    cvss_score=5.5,
                    confidence=0.75
                ))

    def _has_timing_leak(self, requests: List[RequestCapture]) -> bool:
        """Detects timing-based information leakage"""
        if len(requests) < 10:
            return False

        # Group by response status
        success_times = [r.response_time_ms for r in requests if 200 <= r.response_status < 300]
        error_times = [r.response_time_ms for r in requests if r.response_status >= 400]

        if len(success_times) < 5 or len(error_times) < 5:
            return False

        # Statistical test for timing difference
        avg_success = statistics.mean(success_times)
        avg_error = statistics.mean(error_times)

        # If difference > 30% and significant
        if abs(avg_success - avg_error) / max(avg_success, avg_error) > 0.3:
            return True

        return False

    def _analyze_error_messages(self, requests: List[RequestCapture]) -> List[str]:
        """Analyzes error messages for information leakage"""
        leaks = []

        for req in requests:
            if req.response_status >= 400:
                body = req.response_body.lower()

                # Check for various leaks
                if any(db in body for db in ['mysql', 'postgres', 'mongodb', 'redis']):
                    leaks.append(f"Error reveals database type: {req.request_id}")

                if 'stack trace' in body or 'line' in body:
                    leaks.append(f"Error reveals stack trace: {req.request_id}")

                if any(path in body for path in ['/usr/', '/var/', '/home/', 'c:\\']):
                    leaks.append(f"Error reveals file paths: {req.request_id}")

                if 'does not exist' in body or 'not found' in body:
                    leaks.append(f"Error reveals existence check: {req.request_id}")

        return leaks[:3]  # Limit to avoid spam

    def _has_structure_leak(self, requests: List[RequestCapture]) -> bool:
        """Detects structure-based information leakage"""
        # Group responses by length
        length_groups = defaultdict(list)
        for req in requests:
            length_groups[len(req.response_body)].append(req)

        # If we have distinct length groups, might be leaking info
        return len(length_groups) >= 3

    async def _analyze_permission_bypass_chains(self):
        """
        Finds permission bypass via chaining multiple endpoints

        Example:
        Endpoint A: Low-priv user can modify resource metadata
        Endpoint B: Uses metadata for access control
        Chain: Low-priv modifies metadata to gain high-priv access
        """
        print("[*] Analyzing permission bypass chains...")

        # Find write operations
        write_ops = [r for r in self.captures if r.method in ['POST', 'PUT', 'PATCH']]

        # Find read operations
        read_ops = [r for r in self.captures if r.method == 'GET']

        # Look for chains where write affects read
        for write_req in write_ops:
            # Extract what was written
            write_data = self._extract_written_data(write_req)

            # Find subsequent reads that might use this data
            for read_req in read_ops:
                if read_req.timestamp > write_req.timestamp:
                    # Check if written data appears in read response
                    for key, value in write_data.items():
                        if str(value) in read_req.response_body:
                            # Potential chain if different user contexts
                            if write_req.user_context != read_req.user_context:
                                self.findings.append(CorrelationFinding(
                                    finding_id=f"chain_{write_req.request_id}_{read_req.request_id}",
                                    category="permission_bypass_chain",
                                    title="Permission Bypass via Endpoint Chain",
                                    severity="high",
                                    description=(
                                        f"Data written by user '{write_req.user_context}' "
                                        f"affects access control for user '{read_req.user_context}'. "
                                        f"This could allow privilege escalation by manipulating "
                                        f"access control data."
                                    ),
                                    evidence=[
                                        f"Write endpoint: {write_req.url}",
                                        f"Read endpoint: {read_req.url}",
                                        f"Written data: {key}={value}",
                                        f"Data appears in read response"
                                    ],
                                    requests_involved=[write_req.request_id, read_req.request_id],
                                    exploitation_steps=[
                                        f"1. Authenticate as low-privilege user",
                                        f"2. POST to {write_req.url}",
                                        f"3. Modify {key} to desired value",
                                        f"4. Access {read_req.url}",
                                        f"5. Observe elevated access"
                                    ],
                                    cvss_score=8.0,
                                    confidence=0.6
                                ))
                                break  # Only report once per chain

    def _extract_written_data(self, request: RequestCapture) -> Dict[str, Any]:
        """Extracts data that was written in a request"""
        data = {}

        if request.body:
            try:
                parsed = json.loads(request.body)
                if isinstance(parsed, dict):
                    data = parsed
            except:
                # Try to extract key=value pairs
                for match in re.finditer(r'(\w+)[:=]([^&\s,]+)', request.body):
                    data[match.group(1)] = match.group(2)

        return data

    async def _analyze_cache_poisoning(self):
        """
        Finds cache poisoning vulnerabilities via correlation

        Example:
        Request with admin cookie gets cached
        Subsequent request without cookie gets admin response from cache
        """
        print("[*] Analyzing cache poisoning vulnerabilities...")

        # Group by endpoint
        for pattern, requests in self.endpoint_patterns.items():
            # Look for identical URLs with different responses
            url_responses = defaultdict(list)
            for req in requests:
                # Normalize URL (remove query params that might not be in cache key)
                base_url = req.url.split('?')[0]
                url_responses[base_url].append(req)

            for url, reqs in url_responses.items():
                if len(reqs) < 2:
                    continue

                # Check if responses differ based on headers
                high_priv = [r for r in reqs if 'admin' in r.headers.get('Cookie', '').lower()]
                low_priv = [r for r in reqs if 'admin' not in r.headers.get('Cookie', '').lower()]

                if high_priv and low_priv:
                    # Check if low-priv got high-priv response
                    high_response_sig = self._response_signature(high_priv[0])

                    for low_req in low_priv:
                        if self._response_signature(low_req) == high_response_sig:
                            self.findings.append(CorrelationFinding(
                                finding_id=f"cache_{url}",
                                category="cache_poisoning",
                                title=f"Potential Cache Poisoning on {pattern}",
                                severity="high",
                                description=(
                                    "Responses that should differ based on authentication "
                                    "are identical, suggesting cache poisoning. Low-privilege "
                                    "users may receive cached responses intended for high-privilege users."
                                ),
                                evidence=[
                                    f"URL: {url}",
                                    f"High-priv request: {high_priv[0].request_id}",
                                    f"Low-priv request: {low_req.request_id}",
                                    "Identical response signatures"
                                ],
                                requests_involved=[high_priv[0].request_id, low_req.request_id],
                                exploitation_steps=[
                                    "1. Wait for admin to access endpoint",
                                    "2. Response gets cached",
                                    "3. Access same endpoint as low-priv user",
                                    "4. Receive cached admin response"
                                ],
                                cvss_score=7.8,
                                confidence=0.7
                            ))

    def _response_signature(self, request: RequestCapture) -> str:
        """Creates a signature of response for comparison"""
        # Hash response body and key headers
        sig_parts = [
            request.response_body[:1000],  # First 1000 chars
            str(request.response_status),
            request.response_headers.get('Content-Type', ''),
            str(len(request.response_body))
        ]
        return hashlib.md5('|'.join(sig_parts).encode()).hexdigest()

    async def _analyze_timing_based_disclosure(self):
        """
        Finds timing-based information disclosure across endpoints
        """
        print("[*] Analyzing timing-based information disclosure...")

        for pattern, times in self.timing_data.items():
            if len(times) < 20:
                continue

            # Statistical analysis
            mean_time = statistics.mean(times)
            stdev = statistics.stdev(times) if len(times) > 1 else 0

            # Find outliers (> 2 standard deviations)
            outliers = [t for t in times if abs(t - mean_time) > 2 * stdev]

            if len(outliers) > len(times) * 0.1:  # More than 10% outliers
                # Get requests with outlier times
                outlier_requests = [
                    r for r in self.endpoint_patterns[pattern]
                    if r.response_time_ms in outliers
                ]

                self.findings.append(CorrelationFinding(
                    finding_id=f"timing_{pattern}",
                    category="timing_disclosure",
                    title=f"Timing-Based Information Disclosure on {pattern}",
                    severity="medium",
                    description=(
                        f"Significant timing variations detected ({len(outliers)} outliers "
                        f"out of {len(times)} requests). Timing differences may leak "
                        f"information about internal state, data existence, or processing paths."
                    ),
                    evidence=[
                        f"Mean response time: {mean_time:.2f}ms",
                        f"Standard deviation: {stdev:.2f}ms",
                        f"Outlier count: {len(outliers)}",
                        f"Outlier percentage: {len(outliers)/len(times)*100:.1f}%"
                    ],
                    requests_involved=[r.request_id for r in outlier_requests[:5]],
                    exploitation_steps=[
                        "1. Send multiple requests to endpoint",
                        "2. Measure response times",
                        "3. Identify timing patterns",
                        "4. Correlate timing with internal state",
                        "5. Use timing oracle for enumeration or guessing"
                    ],
                    cvss_score=4.5,
                    confidence=0.65
                ))

    async def _analyze_error_state_leakage(self):
        """Analyzes error states for information leakage"""
        print("[*] Analyzing error state leakage...")

        error_requests = [r for r in self.captures if r.response_status >= 400]

        # Group by endpoint
        error_by_endpoint = defaultdict(list)
        for req in error_requests:
            pattern = self._extract_endpoint_pattern(req.url)
            error_by_endpoint[pattern].append(req)

        for pattern, errors in error_by_endpoint.items():
            leaks = []

            for error_req in errors:
                body = error_req.response_body

                # Check for various information leaks
                if re.search(r'/[a-z]+/[a-z0-9/_]+\.(py|js|java|rb|php)', body, re.I):
                    leaks.append("File paths leaked in error message")

                if re.search(r'line \d+', body, re.I):
                    leaks.append("Stack trace with line numbers leaked")

                if re.search(r'(mysql|postgres|mongodb|sqlite|oracle)', body, re.I):
                    leaks.append("Database type revealed in error")

                if re.search(r'(django|rails|express|flask|spring)', body, re.I):
                    leaks.append("Framework revealed in error")

                if re.search(r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b', body):
                    leaks.append("Internal IP address leaked")

            if leaks:
                self.findings.append(CorrelationFinding(
                    finding_id=f"error_{pattern}",
                    category="error_state_leakage",
                    title=f"Information Leakage in Error States for {pattern}",
                    severity="low",
                    description=(
                        "Error messages reveal internal implementation details "
                        "that could aid attackers in crafting more targeted attacks."
                    ),
                    evidence=list(set(leaks))[:5],
                    requests_involved=[r.request_id for r in errors[:3]],
                    exploitation_steps=[
                        "1. Trigger error conditions",
                        "2. Analyze error messages",
                        "3. Extract internal details",
                        "4. Use details for targeted attacks"
                    ],
                    cvss_score=3.5,
                    confidence=0.9
                ))

    async def _analyze_second_order_effects(self):
        """Finds second-order vulnerabilities"""
        print("[*] Analyzing second-order effects...")
        # TODO: Implement tracking data through transformations
        # This requires more sophisticated data flow analysis
        pass

    async def _analyze_protocol_confusion(self):
        """Finds protocol confusion vulnerabilities"""
        print("[*] Analyzing protocol confusion...")
        # TODO: Implement protocol layer analysis
        pass

    async def _analyze_response_consistency(self):
        """Analyzes response consistency across similar requests"""
        print("[*] Analyzing response consistency...")
        # TODO: Implement consistency checking
        pass

    async def _analyze_authentication_bypass_chains(self):
        """Finds authentication bypass via request chaining"""
        print("[*] Analyzing authentication bypass chains...")

        # Find unauthenticated requests that succeeded
        unauth_success = [
            r for r in self.captures
            if not r.headers.get('Authorization')
            and 200 <= r.response_status < 300
        ]

        # Find authenticated requests to same endpoints
        for unauth_req in unauth_success:
            pattern = self._extract_endpoint_pattern(unauth_req.url)

            # Check if there are authenticated requests to same endpoint
            auth_requests = [
                r for r in self.endpoint_patterns[pattern]
                if r.headers.get('Authorization')
            ]

            if auth_requests and 'api' in pattern.lower():
                self.findings.append(CorrelationFinding(
                    finding_id=f"auth_bypass_{pattern}",
                    category="authentication_bypass",
                    title=f"Potential Authentication Bypass on {pattern}",
                    severity="critical",
                    description=(
                        "Endpoint that normally requires authentication can be "
                        "accessed without credentials. This may indicate broken "
                        "authentication or authorization."
                    ),
                    evidence=[
                        f"Unauthenticated request succeeded: {unauth_req.request_id}",
                        f"Status: {unauth_req.response_status}",
                        f"Endpoint: {pattern}"
                    ],
                    requests_involved=[unauth_req.request_id],
                    exploitation_steps=[
                        f"1. Send request to {pattern}",
                        "2. Omit Authorization header",
                        "3. Observe successful response",
                        "4. Access protected resources"
                    ],
                    cvss_score=9.5,
                    confidence=0.8
                ))

    def generate_report(self) -> str:
        """Generates markdown report of all findings"""
        report = ["# Deep Correlation Analysis Report", ""]
        report.append(f"**Total Requests Analyzed:** {len(self.captures)}")
        report.append(f"**Findings:** {len(self.findings)}")
        report.append(f"**Analysis Date:** {datetime.now().isoformat()}")
        report.append("")

        # Group by severity
        by_severity = defaultdict(list)
        for finding in self.findings:
            by_severity[finding.severity].append(finding)

        for severity in ['critical', 'high', 'medium', 'low']:
            if severity in by_severity:
                report.append(f"## {severity.upper()} Severity ({len(by_severity[severity])})")
                report.append("")

                for finding in by_severity[severity]:
                    report.append(f"### {finding.title}")
                    report.append(f"**Category:** {finding.category}")
                    report.append(f"**CVSS Score:** {finding.cvss_score}")
                    report.append(f"**Confidence:** {finding.confidence*100:.0f}%")
                    report.append("")
                    report.append(f"**Description:**")
                    report.append(finding.description)
                    report.append("")
                    report.append(f"**Evidence:**")
                    for evidence in finding.evidence:
                        report.append(f"- {evidence}")
                    report.append("")
                    report.append(f"**Exploitation Steps:**")
                    for step in finding.exploitation_steps:
                        report.append(f"{step}")
                    report.append("")
                    report.append("---")
                    report.append("")

        return "\n".join(report)


async def run_correlation_analysis(target_url: str, num_requests: int = 100):
    """
    Runs deep correlation analysis on a target

    Args:
        target_url: Base URL of target
        num_requests: Number of requests to generate for analysis
    """
    analyzer = DeepCorrelationAnalyzer()

    print(f"[*] Starting Deep Correlation Analysis on {target_url}")
    print(f"[*] Generating {num_requests} requests with multiple user contexts...")

    # Simulate multiple user contexts
    user_contexts = ['admin', 'user1', 'user2', 'guest', 'anonymous']

    # Generate requests to discover endpoints
    common_endpoints = [
        '/api/users',
        '/api/users/{id}',
        '/api/profile',
        '/api/admin/users',
        '/api/posts',
        '/api/posts/{id}',
        '/api/comments',
        '/api/settings',
        '/api/auth/login',
        '/api/auth/logout'
    ]

    # Capture requests
    tasks = []
    for i in range(num_requests):
        endpoint = common_endpoints[i % len(common_endpoints)]
        endpoint = endpoint.replace('{id}', str(i % 100))
        url = f"{target_url}{endpoint}"
        user_context = user_contexts[i % len(user_contexts)]

        method = 'GET' if i % 3 != 0 else 'POST'
        headers = {}

        if user_context != 'anonymous':
            headers['Authorization'] = f'Bearer {user_context}_token'

        body = None
        if method == 'POST':
            body = json.dumps({'data': f'test_{i}'})

        tasks.append(analyzer.capture_request(method, url, headers, body, user_context))

    # Execute captures concurrently
    await asyncio.gather(*tasks)

    # Run analysis
    findings = await analyzer.analyze_all()

    # Generate report
    report = analyzer.generate_report()

    return findings, report


if __name__ == "__main__":
    # Example usage
    target = "https://example.com"
    findings, report = asyncio.run(run_correlation_analysis(target, num_requests=200))

    print("\n" + "="*60)
    print(report)
    print("="*60)
