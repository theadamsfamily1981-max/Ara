"""
Business Logic Flow Mapper - AI-Level Workflow Analysis

Maps complete business logic flows across applications to find:
- Workflow bypass paths
- Missing authorization checks in state transitions
- Invalid state sequences that succeed
- Logic flaws requiring multi-step analysis
- Race conditions in state machines
- Business rule violations

The unfair advantage: Holding 100+ state transitions and their validation
rules in context simultaneously to find bypass paths humans would never discover.
"""

import asyncio
import aiohttp
import networkx as nx
from typing import Dict, List, Set, Tuple, Optional, Any
from dataclasses import dataclass, field
from collections import defaultdict
import json
import re
from datetime import datetime


@dataclass
class StateTransition:
    """Represents a state transition in the application"""
    from_state: str
    to_state: str
    action: str  # API endpoint + method
    required_role: Optional[str]
    preconditions: List[str]
    postconditions: List[str]
    validation_checks: List[str]
    observed: bool = False  # Was this transition actually tested?


@dataclass
class WorkflowBypass:
    """Represents a workflow bypass vulnerability"""
    bypass_id: str
    title: str
    severity: str
    description: str
    normal_path: List[str]
    bypass_path: List[str]
    skipped_checks: List[str]
    exploitation_steps: List[str]
    cvss_score: float
    impact: str


@dataclass
class Resource:
    """Represents a resource with state"""
    resource_type: str
    resource_id: str
    current_state: str
    properties: Dict[str, Any]
    owner: str
    created_at: float
    modified_at: float


class BusinessLogicMapper:
    """
    Maps complete business logic flows across an application
    to find logical vulnerabilities
    """

    def __init__(self):
        # State machine graph
        self.state_graph = nx.DiGraph()

        # Observed transitions
        self.transitions: List[StateTransition] = []

        # Discovered workflows
        self.workflows: Dict[str, List[StateTransition]] = {}

        # Resources and their states
        self.resources: Dict[str, Resource] = {}

        # Bypass vulnerabilities found
        self.bypasses: List[WorkflowBypass] = []

        # Endpoint to state mapping
        self.endpoint_states: Dict[str, Set[str]] = defaultdict(set)

    async def discover_workflows(self, target_url: str, endpoints: List[str]):
        """
        Discovers workflows by exploring state transitions
        """
        print("[*] Discovering workflows...")

        for endpoint in endpoints:
            await self._explore_endpoint(target_url, endpoint)

        # Build state graph from observations
        self._build_state_graph()

        print(f"[+] Discovered {len(self.workflows)} workflows")
        print(f"[+] Mapped {len(self.state_graph.nodes)} states")
        print(f"[+] Observed {len(self.transitions)} transitions")

    async def _explore_endpoint(self, base_url: str, endpoint: str):
        """Explores an endpoint to understand state transitions"""

        # Try different HTTP methods
        methods = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE']

        for method in methods:
            url = f"{base_url}{endpoint}"

            try:
                async with aiohttp.ClientSession() as session:
                    async with session.request(
                        method=method,
                        url=url,
                        timeout=aiohttp.ClientTimeout(total=10),
                        ssl=False
                    ) as response:
                        # Analyze response for state information
                        body = await response.text()
                        state_info = self._extract_state_info(endpoint, method, response.status, body)

                        if state_info:
                            self.endpoint_states[f"{method} {endpoint}"].update(state_info)

            except:
                pass

    def _extract_state_info(self, endpoint: str, method: str, status: int, body: str) -> Set[str]:
        """Extracts state information from response"""
        states = set()

        # Common state field names
        state_patterns = [
            r'"status":\s*"([^"]+)"',
            r'"state":\s*"([^"]+)"',
            r'"workflow_state":\s*"([^"]+)"',
            r'"order_status":\s*"([^"]+)"',
            r'"approval_state":\s*"([^"]+)"',
        ]

        for pattern in state_patterns:
            matches = re.findall(pattern, body, re.IGNORECASE)
            states.update(matches)

        return states

    def _build_state_graph(self):
        """Builds state transition graph from observations"""

        for transition in self.transitions:
            self.state_graph.add_edge(
                transition.from_state,
                transition.to_state,
                action=transition.action,
                role=transition.required_role,
                checks=transition.validation_checks
            )

        # Infer common workflow patterns
        self._infer_workflows()

    def _infer_workflows(self):
        """Infers common workflow patterns from state graph"""

        # Find all paths from initial states to terminal states
        initial_states = [
            node for node in self.state_graph.nodes()
            if self.state_graph.in_degree(node) == 0
        ]

        terminal_states = [
            node for node in self.state_graph.nodes()
            if self.state_graph.out_degree(node) == 0
        ]

        for initial in initial_states:
            for terminal in terminal_states:
                try:
                    paths = list(nx.all_simple_paths(
                        self.state_graph,
                        initial,
                        terminal,
                        cutoff=10
                    ))

                    for path in paths:
                        workflow_name = f"{initial}_to_{terminal}"
                        if workflow_name not in self.workflows:
                            self.workflows[workflow_name] = []

                        # Convert path to transitions
                        transitions = []
                        for i in range(len(path) - 1):
                            edge_data = self.state_graph[path[i]][path[i+1]]
                            transitions.append(StateTransition(
                                from_state=path[i],
                                to_state=path[i+1],
                                action=edge_data.get('action', 'unknown'),
                                required_role=edge_data.get('role'),
                                preconditions=[],
                                postconditions=[],
                                validation_checks=edge_data.get('checks', []),
                                observed=True
                            ))

                        self.workflows[workflow_name].append(transitions)

                except nx.NetworkXNoPath:
                    pass

    async def analyze_bypasses(self) -> List[WorkflowBypass]:
        """
        Analyzes workflows to find bypass vulnerabilities
        """
        print("[*] Analyzing workflow bypasses...")

        # Check each workflow for bypass opportunities
        for workflow_name, paths in self.workflows.items():
            for path in paths:
                bypasses = self._find_bypasses_in_path(workflow_name, path)
                self.bypasses.extend(bypasses)

        # Find missing state transition validations
        self._find_missing_validations()

        # Find state machine race conditions
        self._find_state_race_conditions()

        # Find privilege escalation via state manipulation
        self._find_privilege_escalation_paths()

        print(f"[+] Found {len(self.bypasses)} workflow bypass vulnerabilities")

        return self.bypasses

    def _find_bypasses_in_path(
        self,
        workflow_name: str,
        path: List[StateTransition]
    ) -> List[WorkflowBypass]:
        """Finds bypass opportunities in a workflow path"""
        bypasses = []

        # Check if we can skip intermediate steps
        if len(path) < 3:
            return bypasses

        # Try to find direct paths from start to end
        start_state = path[0].from_state
        end_state = path[-1].to_state

        # Check if direct transition exists
        if self.state_graph.has_edge(start_state, end_state):
            # Found a shortcut - this is a potential bypass
            normal_path_checks = []
            for transition in path[1:-1]:  # Skip first and last
                normal_path_checks.extend(transition.validation_checks)

            shortcut_checks = self.state_graph[start_state][end_state].get('checks', [])

            skipped_checks = [
                check for check in normal_path_checks
                if check not in shortcut_checks
            ]

            if skipped_checks:
                bypasses.append(WorkflowBypass(
                    bypass_id=f"bypass_{workflow_name}_{start_state}_{end_state}",
                    title=f"Workflow Bypass: {workflow_name}",
                    severity="high",
                    description=(
                        f"Direct transition from {start_state} to {end_state} "
                        f"bypasses {len(skipped_checks)} validation checks."
                    ),
                    normal_path=[t.action for t in path],
                    bypass_path=[f"{start_state} -> {end_state}"],
                    skipped_checks=skipped_checks,
                    exploitation_steps=[
                        f"1. Create resource in state {start_state}",
                        f"2. Directly transition to {end_state}",
                        f"3. Bypass: {', '.join(skipped_checks[:3])}",
                        "4. Achieve unauthorized state transition"
                    ],
                    cvss_score=7.5,
                    impact="Bypass business logic validation"
                ))

        # Check for parallel paths with different checks
        all_paths = list(nx.all_simple_paths(
            self.state_graph,
            start_state,
            end_state,
            cutoff=10
        ))

        if len(all_paths) > 1:
            # Find path with least checks
            path_checks = {}
            for p in all_paths:
                checks = []
                for i in range(len(p) - 1):
                    edge_checks = self.state_graph[p[i]][p[i+1]].get('checks', [])
                    checks.extend(edge_checks)
                path_checks[tuple(p)] = checks

            min_checks_path = min(path_checks.items(), key=lambda x: len(x[1]))
            max_checks_path = max(path_checks.items(), key=lambda x: len(x[1]))

            if len(max_checks_path[1]) > len(min_checks_path[1]):
                skipped = [
                    c for c in max_checks_path[1]
                    if c not in min_checks_path[1]
                ]

                bypasses.append(WorkflowBypass(
                    bypass_id=f"bypass_parallel_{workflow_name}",
                    title=f"Parallel Path Bypass: {workflow_name}",
                    severity="medium",
                    description=(
                        f"Alternative path exists with fewer validation checks. "
                        f"Attacker can choose path with minimal checks."
                    ),
                    normal_path=list(max_checks_path[0]),
                    bypass_path=list(min_checks_path[0]),
                    skipped_checks=skipped,
                    exploitation_steps=[
                        "1. Identify multiple paths to same state",
                        "2. Choose path with minimal checks",
                        "3. Follow alternate workflow",
                        "4. Reach same end state with fewer validations"
                    ],
                    cvss_score=6.0,
                    impact="Reduced validation coverage"
                ))

        return bypasses

    def _find_missing_validations(self):
        """Finds state transitions missing critical validations"""

        # Common validation checks that should be present
        critical_validations = [
            'authorization_check',
            'ownership_verification',
            'permission_check',
            'role_check',
            'approval_required'
        ]

        for edge in self.state_graph.edges(data=True):
            from_state, to_state, data = edge
            checks = data.get('checks', [])

            # Check if critical validations are missing
            missing = []
            for critical in critical_validations:
                if not any(critical in check.lower() for check in checks):
                    missing.append(critical)

            # If transitioning to privileged state without checks
            privileged_states = ['approved', 'published', 'executed', 'admin', 'active']
            if any(priv in to_state.lower() for priv in privileged_states):
                if missing:
                    self.bypasses.append(WorkflowBypass(
                        bypass_id=f"missing_val_{from_state}_{to_state}",
                        title=f"Missing Validation: {from_state} → {to_state}",
                        severity="high",
                        description=(
                            f"Transition to privileged state '{to_state}' lacks "
                            f"critical validation checks."
                        ),
                        normal_path=[f"{from_state} (with checks) → {to_state}"],
                        bypass_path=[f"{from_state} (no checks) → {to_state}"],
                        skipped_checks=missing,
                        exploitation_steps=[
                            f"1. Create resource in {from_state}",
                            f"2. Transition to {to_state}",
                            "3. Missing validations allow unauthorized transition",
                            f"4. Resource reaches {to_state} without proper checks"
                        ],
                        cvss_score=8.0,
                        impact="Unauthorized state escalation"
                    ))

    def _find_state_race_conditions(self):
        """Finds race conditions in state transitions"""

        # Look for TOCTOU patterns
        # Pattern: Check state → Modify state (with time gap)

        for edge in self.state_graph.edges(data=True):
            from_state, to_state, data = edge
            action = data.get('action', '')

            # If action suggests read-then-write pattern
            if any(keyword in action.lower() for keyword in ['check', 'verify', 'validate']):
                # Look for subsequent write actions
                for next_edge in self.state_graph.edges(to_state, data=True):
                    next_state = next_edge[1]
                    next_action = next_edge[2].get('action', '')

                    if any(keyword in next_action.lower() for keyword in ['update', 'modify', 'write']):
                        self.bypasses.append(WorkflowBypass(
                            bypass_id=f"race_{from_state}_{to_state}_{next_state}",
                            title=f"TOCTOU Race Condition: {from_state} → {to_state} → {next_state}",
                            severity="high",
                            description=(
                                "Time-of-check to time-of-use race condition detected. "
                                "State can change between check and use."
                            ),
                            normal_path=[f"{from_state} → {to_state} → {next_state}"],
                            bypass_path=["Parallel request modifies state between check and use"],
                            skipped_checks=["Atomic check-and-set"],
                            exploitation_steps=[
                                f"1. Thread 1: Check state at {from_state}",
                                f"2. Thread 2: Modify state (race)",
                                f"3. Thread 1: Proceed with {next_action} based on stale check",
                                "4. Inconsistent state achieved"
                            ],
                            cvss_score=7.0,
                            impact="State inconsistency, double-spending, unauthorized access"
                        ))

    def _find_privilege_escalation_paths(self):
        """Finds paths that allow privilege escalation"""

        # Define privilege levels
        low_priv_states = ['pending', 'draft', 'requested', 'submitted']
        high_priv_states = ['approved', 'admin', 'published', 'executed', 'verified']

        # Find paths from low to high privilege
        for low_state in low_priv_states:
            if low_state not in self.state_graph:
                continue

            for high_state in high_priv_states:
                if high_state not in self.state_graph:
                    continue

                # Check if path exists
                try:
                    paths = list(nx.all_shortest_paths(
                        self.state_graph,
                        low_state,
                        high_state
                    ))

                    for path in paths:
                        # Check if any edge allows low-privilege user
                        vulnerable = False
                        for i in range(len(path) - 1):
                            edge_data = self.state_graph[path[i]][path[i+1]]
                            required_role = edge_data.get('role')

                            # If no role required or only basic role
                            if not required_role or required_role in ['user', 'authenticated', 'guest']:
                                vulnerable = True
                                break

                        if vulnerable:
                            self.bypasses.append(WorkflowBypass(
                                bypass_id=f"privesc_{low_state}_{high_state}",
                                title=f"Privilege Escalation: {low_state} → {high_state}",
                                severity="critical",
                                description=(
                                    f"Low-privilege user can escalate resource from "
                                    f"{low_state} to {high_state} without proper authorization."
                                ),
                                normal_path=["Admin approval required"],
                                bypass_path=[f"{' → '.join(path)}"],
                                skipped_checks=["Administrative approval", "Privilege verification"],
                                exploitation_steps=[
                                    f"1. Create resource in {low_state} as low-priv user",
                                    f"2. Follow path: {' → '.join(path)}",
                                    "3. No privilege checks enforced",
                                    f"4. Resource reaches {high_state} without authorization"
                                ],
                                cvss_score=9.0,
                                impact="Unauthorized privilege escalation"
                            ))

                except nx.NetworkXNoPath:
                    pass

    def add_observed_transition(
        self,
        from_state: str,
        to_state: str,
        action: str,
        role: Optional[str] = None,
        checks: List[str] = None
    ):
        """Adds an observed state transition"""

        transition = StateTransition(
            from_state=from_state,
            to_state=to_state,
            action=action,
            required_role=role,
            preconditions=[],
            postconditions=[],
            validation_checks=checks or [],
            observed=True
        )

        self.transitions.append(transition)
        self.state_graph.add_edge(
            from_state,
            to_state,
            action=action,
            role=role,
            checks=checks or []
        )

    def generate_report(self) -> str:
        """Generates markdown report of workflow analysis"""

        report = ["# Business Logic Flow Analysis Report", ""]
        report.append(f"**Analysis Date:** {datetime.now().isoformat()}")
        report.append(f"**States Discovered:** {len(self.state_graph.nodes)}")
        report.append(f"**Transitions Mapped:** {len(self.transitions)}")
        report.append(f"**Workflows Identified:** {len(self.workflows)}")
        report.append(f"**Bypasses Found:** {len(self.bypasses)}")
        report.append("")

        # State machine visualization
        report.append("## State Machine Overview")
        report.append("```")
        report.append(f"States: {', '.join(list(self.state_graph.nodes)[:20])}")
        report.append(f"Transitions: {len(self.state_graph.edges)}")
        report.append("```")
        report.append("")

        # Group bypasses by severity
        by_severity = defaultdict(list)
        for bypass in self.bypasses:
            by_severity[bypass.severity].append(bypass)

        for severity in ['critical', 'high', 'medium', 'low']:
            if severity in by_severity:
                report.append(f"## {severity.upper()} Severity Bypasses ({len(by_severity[severity])})")
                report.append("")

                for bypass in by_severity[severity]:
                    report.append(f"### {bypass.title}")
                    report.append(f"**CVSS Score:** {bypass.cvss_score}")
                    report.append(f"**Impact:** {bypass.impact}")
                    report.append("")
                    report.append(f"**Description:**")
                    report.append(bypass.description)
                    report.append("")
                    report.append(f"**Normal Path:**")
                    for step in bypass.normal_path:
                        report.append(f"- {step}")
                    report.append("")
                    report.append(f"**Bypass Path:**")
                    for step in bypass.bypass_path:
                        report.append(f"- {step}")
                    report.append("")
                    report.append(f"**Skipped Checks:**")
                    for check in bypass.skipped_checks:
                        report.append(f"- {check}")
                    report.append("")
                    report.append(f"**Exploitation:**")
                    for step in bypass.exploitation_steps:
                        report.append(f"{step}")
                    report.append("")
                    report.append("---")
                    report.append("")

        return "\n".join(report)


# Example workflow patterns to look for
COMMON_WORKFLOWS = {
    "order_processing": {
        "states": ["cart", "pending", "paid", "shipped", "delivered", "completed"],
        "critical_transitions": [
            ("cart", "paid", "payment_verification"),
            ("paid", "shipped", "inventory_check"),
            ("shipped", "delivered", "tracking_confirmation")
        ]
    },
    "approval_workflow": {
        "states": ["draft", "submitted", "review", "approved", "published"],
        "critical_transitions": [
            ("submitted", "review", "authorization_check"),
            ("review", "approved", "admin_approval"),
            ("approved", "published", "final_validation")
        ]
    },
    "account_management": {
        "states": ["registered", "verified", "active", "suspended", "deleted"],
        "critical_transitions": [
            ("registered", "verified", "email_verification"),
            ("verified", "active", "kyc_check"),
            ("active", "suspended", "admin_action")
        ]
    }
}


async def analyze_business_logic(target_url: str):
    """
    Main entry point for business logic analysis
    """
    mapper = BusinessLogicMapper()

    # Example: Add observed transitions (in real usage, these come from crawling)
    # Order workflow
    mapper.add_observed_transition("cart", "pending", "POST /api/orders", "user", ["user_authenticated"])
    mapper.add_observed_transition("pending", "paid", "POST /api/orders/{id}/pay", "user", ["payment_valid"])
    mapper.add_observed_transition("paid", "shipped", "POST /api/orders/{id}/ship", "admin", ["admin_role", "inventory_available"])
    mapper.add_observed_transition("shipped", "delivered", "POST /api/orders/{id}/deliver", "courier", ["tracking_confirmed"])

    # Bypass path (missing check!)
    mapper.add_observed_transition("pending", "shipped", "POST /api/orders/{id}/ship", "user", [])  # NO CHECKS!

    # Approval workflow
    mapper.add_observed_transition("draft", "submitted", "POST /api/articles", "user", ["user_authenticated"])
    mapper.add_observed_transition("submitted", "approved", "POST /api/articles/{id}/approve", "admin", ["admin_role"])
    mapper.add_observed_transition("approved", "published", "POST /api/articles/{id}/publish", "admin", ["admin_role"])

    # Bypass path
    mapper.add_observed_transition("draft", "published", "PATCH /api/articles/{id}", "user", [])  # Direct publish!

    # Analyze for bypasses
    bypasses = await mapper.analyze_bypasses()

    # Generate report
    report = mapper.generate_report()

    return bypasses, report


if __name__ == "__main__":
    bypasses, report = asyncio.run(analyze_business_logic("https://example.com"))

    print("\n" + "="*60)
    print(report)
    print("="*60)

    print(f"\nFound {len(bypasses)} workflow bypass vulnerabilities!")
