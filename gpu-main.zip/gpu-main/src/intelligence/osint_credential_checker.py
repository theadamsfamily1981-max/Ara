"""
OSINT Credential Checker
Checks for leaked credentials and exposed sensitive information using OSINT sources.
"""

import asyncio
import aiohttp
import logging
from typing import List, Dict, Optional, Set
from datetime import datetime
import hashlib
import re
import base64

logger = logging.getLogger(__name__)


class OSINTCredentialChecker:
    """Check for leaked credentials using OSINT sources."""

    def __init__(self, config: Dict):
        self.config = config
        self.found_leaks = []

    async def check_domain(self, domain: str) -> Dict:
        """
        Comprehensive OSINT credential check for a domain.

        Checks:
        - Have I Been Pwned (HIBP)
        - Paste sites (Pastebin, GitHub Gists)
        - Public data breaches
        - Exposed .git repositories
        - Exposed environment files
        - Cloud storage buckets
        """
        results = {
            'domain': domain,
            'emails_found': [],
            'leaked_credentials': [],
            'exposed_repositories': [],
            'exposed_files': [],
            'cloud_buckets': [],
            'paste_leaks': []
        }

        logger.info(f"Starting OSINT check for {domain}")

        # Run all checks concurrently
        tasks = [
            self._check_exposed_git(domain),
            self._check_exposed_env_files(domain),
            self._check_cloud_buckets(domain),
            self._discover_emails(domain),
            self._check_paste_sites(domain),
            self._check_github_leaks(domain)
        ]

        check_results = await asyncio.gather(*tasks, return_exceptions=True)

        # Process results
        for result in check_results:
            if isinstance(result, dict):
                if 'exposed_git' in result:
                    results['exposed_repositories'].extend(result['exposed_git'])
                if 'env_files' in result:
                    results['exposed_files'].extend(result['env_files'])
                if 'buckets' in result:
                    results['cloud_buckets'].extend(result['buckets'])
                if 'emails' in result:
                    results['emails_found'].extend(result['emails'])
                if 'pastes' in result:
                    results['paste_leaks'].extend(result['pastes'])
                if 'github_leaks' in result:
                    results['leaked_credentials'].extend(result['github_leaks'])

        # Check HIBP for discovered emails
        if results['emails_found']:
            for email in results['emails_found'][:10]:  # Limit to avoid rate limiting
                breaches = await self._check_hibp(email)
                if breaches:
                    results['leaked_credentials'].append({
                        'email': email,
                        'breaches': breaches,
                        'source': 'Have I Been Pwned'
                    })

        logger.info(f"OSINT check complete for {domain}: "
                   f"{len(results['emails_found'])} emails, "
                   f"{len(results['leaked_credentials'])} leaks found")

        return results

    async def _check_exposed_git(self, domain: str) -> Dict:
        """Check for exposed .git repositories."""
        exposed_git = []

        # Common .git exposure URLs
        git_paths = [
            '/.git/config',
            '/.git/HEAD',
            '/.git/index',
            '/.git/logs/HEAD',
            '/.git/refs/heads/master',
            '/.git/refs/heads/main'
        ]

        try:
            async with aiohttp.ClientSession() as session:
                for path in git_paths:
                    url = f"https://{domain}{path}"

                    try:
                        async with session.get(
                            url,
                            timeout=aiohttp.ClientTimeout(total=10),
                            ssl=False
                        ) as response:
                            if response.status == 200:
                                text = await response.text()

                                # Verify it's actually a git file
                                if 'ref:' in text or '[core]' in text or '\x00' in text:
                                    exposed_git.append({
                                        'url': url,
                                        'type': 'git_repository',
                                        'severity': 'critical',
                                        'description': 'Exposed .git repository allows downloading entire source code',
                                        'discovered_at': datetime.now().isoformat()
                                    })
                                    logger.warning(f"Found exposed .git: {url}")
                                    break  # One is enough

                    except Exception as e:
                        logger.debug(f"Git check error for {url}: {e}")
                        continue

        except Exception as e:
            logger.error(f"Git check error: {e}")

        return {'exposed_git': exposed_git}

    async def _check_exposed_env_files(self, domain: str) -> Dict:
        """Check for exposed environment and configuration files."""
        exposed_files = []

        # Common exposed files
        sensitive_files = [
            '/.env',
            '/.env.backup',
            '/.env.old',
            '/.env.prod',
            '/.env.production',
            '/.env.local',
            '/config.yml',
            '/config.yaml',
            '/configuration.yml',
            '/database.yml',
            '/credentials.json',
            '/secrets.json',
            '/aws.json',
            '/.aws/credentials',
            '/.aws/config',
            '/composer.json',
            '/package.json',
            '/yarn.lock',
            '/Gemfile',
            '/requirements.txt',
            '/.htpasswd',
            '/.npmrc',
            '/.dockerenv',
            '/docker-compose.yml',
            '/.DS_Store',
            '/backup.sql',
            '/database.sql',
            '/dump.sql',
            '/web.config',
            '/phpinfo.php',
            '/info.php'
        ]

        try:
            async with aiohttp.ClientSession() as session:
                for file_path in sensitive_files:
                    url = f"https://{domain}{file_path}"

                    try:
                        async with session.get(
                            url,
                            timeout=aiohttp.ClientTimeout(total=10),
                            ssl=False
                        ) as response:
                            if response.status == 200:
                                text = await response.text()

                                # Check if file contains sensitive information
                                sensitive_keywords = [
                                    'API_KEY', 'SECRET', 'PASSWORD', 'TOKEN', 'PRIVATE_KEY',
                                    'DATABASE', 'DB_PASSWORD', 'AWS_ACCESS_KEY', 'AWS_SECRET',
                                    'mongodb://', 'postgres://', 'mysql://', 'redis://'
                                ]

                                if any(keyword in text.upper() for keyword in sensitive_keywords):
                                    exposed_files.append({
                                        'url': url,
                                        'type': 'exposed_config',
                                        'severity': 'critical',
                                        'description': f'Exposed sensitive configuration file: {file_path}',
                                        'preview': text[:200] if len(text) < 200 else text[:200] + '...',
                                        'discovered_at': datetime.now().isoformat()
                                    })
                                    logger.warning(f"Found exposed sensitive file: {url}")

                    except Exception as e:
                        logger.debug(f"File check error for {url}: {e}")
                        continue

        except Exception as e:
            logger.error(f"Env file check error: {e}")

        return {'env_files': exposed_files}

    async def _check_cloud_buckets(self, domain: str) -> Dict:
        """Check for exposed cloud storage buckets."""
        buckets = []

        # Generate potential bucket names
        company_name = domain.split('.')[0]
        bucket_names = [
            company_name,
            f"{company_name}-backups",
            f"{company_name}-backup",
            f"{company_name}-data",
            f"{company_name}-assets",
            f"{company_name}-media",
            f"{company_name}-files",
            f"{company_name}-uploads",
            f"{company_name}-dev",
            f"{company_name}-prod",
            f"{company_name}-production",
            f"{company_name}-staging",
            f"{company_name}-test",
            f"{company_name}-logs",
            f"{company_name}-archive"
        ]

        # Check AWS S3
        for bucket_name in bucket_names:
            s3_url = f"https://{bucket_name}.s3.amazonaws.com"

            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(
                        s3_url,
                        timeout=aiohttp.ClientTimeout(total=5),
                        ssl=False
                    ) as response:
                        if response.status == 200:
                            text = await response.text()

                            if '<ListBucketResult' in text or '<Contents>' in text:
                                buckets.append({
                                    'url': s3_url,
                                    'type': 'aws_s3',
                                    'bucket_name': bucket_name,
                                    'severity': 'high',
                                    'description': 'Publicly accessible S3 bucket',
                                    'discovered_at': datetime.now().isoformat()
                                })
                                logger.warning(f"Found exposed S3 bucket: {s3_url}")

            except Exception as e:
                logger.debug(f"S3 check error for {bucket_name}: {e}")

        return {'buckets': buckets}

    async def _discover_emails(self, domain: str) -> Dict:
        """Discover email addresses associated with domain."""
        emails = set()

        # Try Hunter.io-style patterns
        common_patterns = [
            f"admin@{domain}",
            f"info@{domain}",
            f"contact@{domain}",
            f"support@{domain}",
            f"security@{domain}",
            f"dev@{domain}",
            f"api@{domain}",
            f"noreply@{domain}"
        ]

        emails.update(common_patterns)

        # Try to scrape from main website
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"https://{domain}",
                    timeout=aiohttp.ClientTimeout(total=10),
                    ssl=False
                ) as response:
                    if response.status == 200:
                        html = await response.text()

                        # Extract email addresses from HTML
                        email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
                        found_emails = re.findall(email_pattern, html)

                        # Filter to only emails from this domain
                        for email in found_emails:
                            if domain in email:
                                emails.add(email)

        except Exception as e:
            logger.debug(f"Email discovery error: {e}")

        return {'emails': list(emails)}

    async def _check_hibp(self, email: str) -> List[str]:
        """Check Have I Been Pwned for email breaches."""
        try:
            # Use HIBP API v3
            api_url = f"https://haveibeenpwned.com/api/v3/breachedaccount/{email}"

            headers = {
                'User-Agent': 'Bug-Bounty-Hunter-OSINT-Check'
            }

            # Note: HIBP requires API key for rate limiting
            # In production, add API key from config
            if 'hibp_api_key' in self.config:
                headers['hibp-api-key'] = self.config['hibp_api_key']

            async with aiohttp.ClientSession() as session:
                async with session.get(
                    api_url,
                    headers=headers,
                    timeout=aiohttp.ClientTimeout(total=10)
                ) as response:
                    if response.status == 200:
                        breaches = await response.json()
                        return [breach['Name'] for breach in breaches]
                    elif response.status == 404:
                        # No breaches found - good!
                        return []
                    elif response.status == 429:
                        logger.warning("HIBP rate limit reached")
                        return []

        except Exception as e:
            logger.debug(f"HIBP check error for {email}: {e}")

        return []

    async def _check_paste_sites(self, domain: str) -> Dict:
        """Check paste sites for domain leaks."""
        pastes = []

        # Note: In production, implement actual paste site scraping
        # This would require: 1) Pastebin scraping API, 2) Psbdmp API, 3) Telegram channel monitoring

        # For now, return structure for future implementation
        logger.info(f"Paste site checking for {domain} - implement actual scraping")

        return {'pastes': pastes}

    async def _check_github_leaks(self, domain: str) -> Dict:
        """Check GitHub for leaked credentials."""
        leaks = []

        # Note: This would use GitHub Code Search API
        # Search for: domain + sensitive keywords in code

        logger.info(f"GitHub leak checking for {domain} - requires GitHub API token")

        # In production, implement GitHub dorking:
        # - Search for API keys, passwords, tokens
        # - Check public repositories
        # - Check commit history

        return {'github_leaks': leaks}


async def check_domain_osint(domain: str, config: Dict) -> Dict:
    """Convenience function to run OSINT checks on a domain."""
    checker = OSINTCredentialChecker(config)
    return await checker.check_domain(domain)
