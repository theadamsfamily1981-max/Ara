"""
Cloud Asset Discovery Module
Find AWS, GCP, Azure, and other cloud resources belonging to targets.
"""

import logging
import aiohttp
import asyncio
from typing import Dict, List, Set
import re

logger = logging.getLogger(__name__)


class CloudHunter:
    """Discover cloud assets for bug bounty targets."""

    def __init__(self):
        """Initialize cloud hunter."""
        self.discovered_assets = []

        # Cloud patterns
        self.aws_patterns = [
            r'([a-z0-9.-]+)\.s3\.amazonaws\.com',
            r'([a-z0-9.-]+)\.s3-([a-z0-9-]+)\.amazonaws\.com',
            r's3\.amazonaws\.com/([a-z0-9.-]+)',
            r'([a-z0-9.-]+)\.cloudfront\.net',
            r'([a-z0-9.-]+)\.execute-api\.([a-z0-9-]+)\.amazonaws\.com',
            r'([a-z0-9.-]+)\.lambda-url\.([a-z0-9-]+)\.on\.aws',
            r'([a-z0-9.-]+)\.elasticbeanstalk\.com',
            r'([a-z0-9.-]+)\.elb\.([a-z0-9-]+)\.amazonaws\.com'
        ]

        self.azure_patterns = [
            r'([a-z0-9.-]+)\.azurewebsites\.net',
            r'([a-z0-9.-]+)\.blob\.core\.windows\.net',
            r'([a-z0-9.-]+)\.queue\.core\.windows\.net',
            r'([a-z0-9.-]+)\.table\.core\.windows\.net',
            r'([a-z0-9.-]+)\.file\.core\.windows\.net',
            r'([a-z0-9.-]+)\.cloudapp\.azure\.com',
            r'([a-z0-9.-]+)\.azurefd\.net',
            r'([a-z0-9.-]+)\.azure-api\.net'
        ]

        self.gcp_patterns = [
            r'([a-z0-9.-]+)\.appspot\.com',
            r'([a-z0-9.-]+)\.cloudfunctions\.net',
            r'([a-z0-9.-]+)\.run\.app',
            r'([a-z0-9.-]+)\.storage\.googleapis\.com',
            r'storage\.googleapis\.com/([a-z0-9.-]+)',
            r'([a-z0-9.-]+)\.cloudendpointsapis\.com'
        ]

        self.other_patterns = [
            r'([a-z0-9.-]+)\.herokuapp\.com',
            r'([a-z0-9.-]+)\.vercel\.app',
            r'([a-z0-9.-]+)\.netlify\.app',
            r'([a-z0-9.-]+)\.digitaloceanspaces\.com',
            r'([a-z0-9.-]+)\.railway\.app',
            r'([a-z0-9.-]+)\.fly\.dev'
        ]

    async def discover_cloud_assets(self, domain: str, scope: List[str]) -> List[Dict]:
        """
        Discover cloud assets for a given domain and scope.

        Returns: List of cloud asset dictionaries
        """
        logger.info(f"🔍 Hunting for cloud assets related to {domain}")

        assets = []

        # Run discovery methods in parallel
        tasks = [
            self._discover_s3_buckets(domain, scope),
            self._discover_azure_storage(domain, scope),
            self._discover_gcp_storage(domain, scope),
            self._discover_cloudfront_distributions(domain),
            self._discover_elastic_ips(domain),
            self._discover_paas_apps(domain, scope)
        ]

        results = await asyncio.gather(*tasks, return_exceptions=True)

        for result in results:
            if isinstance(result, list):
                assets.extend(result)

        # Deduplicate
        unique_assets = []
        seen = set()
        for asset in assets:
            key = (asset.get('type'), asset.get('url'))
            if key not in seen:
                seen.add(key)
                unique_assets.append(asset)

        logger.info(f"Found {len(unique_assets)} cloud assets")
        return unique_assets

    async def _discover_s3_buckets(self, domain: str, scope: List[str]) -> List[Dict]:
        """Discover AWS S3 buckets."""
        logger.info("Searching for S3 buckets...")

        buckets = []
        potential_names = self._generate_bucket_names(domain, scope)

        # Test each potential bucket name
        tasks = [self._check_s3_bucket(name) for name in potential_names[:100]]  # Limit to 100
        results = await asyncio.gather(*tasks)

        for result in results:
            if result:
                buckets.append(result)

        logger.info(f"Found {len(buckets)} S3 buckets")
        return buckets

    def _generate_bucket_names(self, domain: str, scope: List[str]) -> List[str]:
        """Generate potential bucket names."""
        base_names = []

        # Extract domain parts
        parts = domain.replace('.', '-').split('-')
        base_names.append(domain.replace('.', '-'))
        base_names.append(domain.replace('.', ''))

        # Add company name variations
        if len(parts) > 1:
            base_names.append(parts[0])  # First part

        # Add scope domains
        for url in scope:
            if isinstance(url, str):
                # Extract domain from URL
                clean = url.replace('https://', '').replace('http://', '').split('/')[0]
                base_names.append(clean.replace('.', '-'))
                base_names.append(clean.replace('.', ''))

        # Common variations
        suffixes = ['', '-prod', '-dev', '-staging', '-test', '-backup', '-static',
                   '-assets', '-images', '-media', '-files', '-uploads', '-public',
                   '-private', '-logs', '-data', '-api', '-web', '-app']

        prefixes = ['', 'www-', 'api-', 'app-', 'prod-', 'staging-', 'dev-']

        variations = []
        for base in set(base_names):
            for prefix in prefixes:
                for suffix in suffixes:
                    variations.append(f"{prefix}{base}{suffix}")

        return list(set(variations))[:100]  # Limit to 100

    async def _check_s3_bucket(self, bucket_name: str) -> Dict:
        """Check if S3 bucket exists and is accessible."""
        urls = [
            f"https://{bucket_name}.s3.amazonaws.com",
            f"https://s3.amazonaws.com/{bucket_name}"
        ]

        for url in urls:
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.head(url, timeout=5, allow_redirects=False) as response:
                        if response.status in [200, 403, 301]:
                            # Bucket exists!
                            public = response.status == 200

                            logger.info(f"✅ Found S3 bucket: {bucket_name} ({'PUBLIC' if public else 'Private'})")

                            return {
                                'type': 's3_bucket',
                                'name': bucket_name,
                                'url': url,
                                'public': public,
                                'status': response.status,
                                'cloud_provider': 'AWS',
                                'severity': 'critical' if public else 'low'
                            }

            except:
                pass

        return None

    async def _discover_azure_storage(self, domain: str, scope: List[str]) -> List[Dict]:
        """Discover Azure storage accounts."""
        logger.info("Searching for Azure storage accounts...")

        accounts = []
        potential_names = self._generate_azure_names(domain)

        for name in potential_names[:50]:
            url = f"https://{name}.blob.core.windows.net"

            try:
                async with aiohttp.ClientSession() as session:
                    async with session.head(url, timeout=5) as response:
                        if response.status in [200, 403, 404]:
                            # Account exists
                            public = response.status == 200

                            if response.status != 404:
                                logger.info(f"✅ Found Azure storage: {name}")

                                accounts.append({
                                    'type': 'azure_storage',
                                    'name': name,
                                    'url': url,
                                    'public': public,
                                    'cloud_provider': 'Azure',
                                    'severity': 'high' if public else 'low'
                                })

            except:
                pass

        logger.info(f"Found {len(accounts)} Azure storage accounts")
        return accounts

    def _generate_azure_names(self, domain: str) -> List[str]:
        """Generate potential Azure storage account names."""
        # Azure storage names: 3-24 chars, lowercase letters and numbers only
        base = domain.replace('.', '').replace('-', '').lower()[:20]

        variations = [base]
        for suffix in ['prod', 'dev', 'staging', 'backup', 'data', 'files']:
            if len(base + suffix) <= 24:
                variations.append(base + suffix)

        return variations

    async def _discover_gcp_storage(self, domain: str, scope: List[str]) -> List[Dict]:
        """Discover GCP storage buckets."""
        logger.info("Searching for GCP storage buckets...")

        buckets = []
        potential_names = self._generate_bucket_names(domain, scope)

        for name in potential_names[:50]:
            url = f"https://storage.googleapis.com/{name}"

            try:
                async with aiohttp.ClientSession() as session:
                    async with session.head(url, timeout=5) as response:
                        if response.status in [200, 403]:
                            public = response.status == 200

                            logger.info(f"✅ Found GCP bucket: {name}")

                            buckets.append({
                                'type': 'gcp_bucket',
                                'name': name,
                                'url': url,
                                'public': public,
                                'cloud_provider': 'GCP',
                                'severity': 'critical' if public else 'low'
                            })

            except:
                pass

        logger.info(f"Found {len(buckets)} GCP buckets")
        return buckets

    async def _discover_cloudfront_distributions(self, domain: str) -> List[Dict]:
        """Discover CloudFront distributions."""
        # This would require DNS enumeration to find cloudfront domains
        # For now, return empty list
        return []

    async def _discover_elastic_ips(self, domain: str) -> List[Dict]:
        """Discover AWS Elastic IPs."""
        # This would require IP range scanning
        # For now, return empty list
        return []

    async def _discover_paas_apps(self, domain: str, scope: List[str]) -> List[Dict]:
        """Discover PaaS applications (Heroku, Vercel, etc)."""
        logger.info("Searching for PaaS applications...")

        apps = []
        base_names = self._generate_app_names(domain)

        # Check Heroku
        for name in base_names[:30]:
            url = f"https://{name}.herokuapp.com"

            try:
                async with aiohttp.ClientSession() as session:
                    async with session.head(url, timeout=5) as response:
                        if response.status != 404:
                            logger.info(f"✅ Found Heroku app: {name}")

                            apps.append({
                                'type': 'heroku_app',
                                'name': name,
                                'url': url,
                                'cloud_provider': 'Heroku',
                                'severity': 'low'
                            })

            except:
                pass

        # Check Vercel
        for name in base_names[:30]:
            url = f"https://{name}.vercel.app"

            try:
                async with aiohttp.ClientSession() as session:
                    async with session.head(url, timeout=5) as response:
                        if response.status != 404:
                            logger.info(f"✅ Found Vercel app: {name}")

                            apps.append({
                                'type': 'vercel_app',
                                'name': name,
                                'url': url,
                                'cloud_provider': 'Vercel',
                                'severity': 'low'
                            })

            except:
                pass

        logger.info(f"Found {len(apps)} PaaS applications")
        return apps

    def _generate_app_names(self, domain: str) -> List[str]:
        """Generate potential app names."""
        base = domain.replace('.', '-')
        parts = domain.split('.')

        variations = [base, parts[0]]

        for suffix in ['-prod', '-staging', '-dev', '-api', '-web', '-app']:
            variations.append(base + suffix)
            variations.append(parts[0] + suffix)

        return variations

    async def check_misconfigurations(self, asset: Dict) -> List[Dict]:
        """Check for misconfigurations in discovered cloud assets."""
        issues = []

        asset_type = asset.get('type')
        url = asset.get('url')

        if asset_type == 's3_bucket' and asset.get('public'):
            # Public S3 bucket
            issues.append({
                'severity': 'critical',
                'title': 'Publicly Accessible S3 Bucket',
                'description': f"S3 bucket {asset.get('name')} is publicly accessible",
                'url': url,
                'impact': 'Anyone can list and potentially download files from this bucket',
                'remediation': 'Remove public access permissions from the S3 bucket'
            })

            # Try to list contents
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(url, timeout=10) as response:
                        if response.status == 200:
                            text = await response.text()

                            # Check for sensitive files
                            sensitive_patterns = [
                                r'\.env', r'config', r'secret', r'key',
                                r'password', r'credential', r'backup',
                                r'\.sql', r'\.db', r'\.log'
                            ]

                            for pattern in sensitive_patterns:
                                if re.search(pattern, text, re.IGNORECASE):
                                    issues.append({
                                        'severity': 'critical',
                                        'title': 'Sensitive Files in Public S3 Bucket',
                                        'description': f"Public S3 bucket contains files matching pattern: {pattern}",
                                        'url': url,
                                        'impact': 'Sensitive information may be exposed to unauthorized parties'
                                    })
                                    break

            except:
                pass

        elif asset_type == 'azure_storage' and asset.get('public'):
            issues.append({
                'severity': 'high',
                'title': 'Publicly Accessible Azure Storage',
                'description': f"Azure storage account {asset.get('name')} allows public access",
                'url': url,
                'impact': 'Unauthorized access to stored data',
                'remediation': 'Configure appropriate access controls on Azure storage'
            })

        return issues

    def generate_cloud_report(self, assets: List[Dict], issues: List[Dict]) -> str:
        """Generate report for cloud asset findings."""
        report = f"""
# Cloud Asset Discovery Report

## Summary
Discovered {len(assets)} cloud assets and {len(issues)} security issues.

## Discovered Assets

"""

        # Group by cloud provider
        by_provider = {}
        for asset in assets:
            provider = asset.get('cloud_provider', 'Unknown')
            if provider not in by_provider:
                by_provider[provider] = []
            by_provider[provider].append(asset)

        for provider, provider_assets in by_provider.items():
            report += f"### {provider}\n\n"
            for asset in provider_assets:
                status = "🔴 PUBLIC" if asset.get('public') else "🟢 Private"
                report += f"- **{asset.get('type')}**: {asset.get('name')} - {status}\n"
                report += f"  - URL: {asset.get('url')}\n\n"

        if issues:
            report += "## Security Issues\n\n"
            for i, issue in enumerate(issues, 1):
                report += f"### {i}. {issue.get('title')}\n\n"
                report += f"**Severity**: {issue.get('severity').upper()}\n\n"
                report += f"**Description**: {issue.get('description')}\n\n"
                report += f"**Impact**: {issue.get('impact')}\n\n"
                if issue.get('remediation'):
                    report += f"**Remediation**: {issue.get('remediation')}\n\n"

        return report
