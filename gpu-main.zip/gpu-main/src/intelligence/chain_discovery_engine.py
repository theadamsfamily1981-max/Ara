"""
Chain Discovery Engine - AI-Level Attack Chain Synthesis

Discovers high-impact attack chains by combining low-severity primitives.

The unfair advantage: Can hold 1000s of vulnerability primitives in context
and test millions of combinations to find chains humans would never discover.

Examples of powerful chains:
1. XSS in profile → Export to CSV → Excel DDE = Admin RCE
2. SSRF in webhook → Internal API call → Admin token leak = Account takeover
3. Path traversal → Config file read → Credential leak → Privilege escalation
4. File upload → Metadata injection → Template include = RCE
5. Cache poisoning → XSS payload → Persistent attack = Mass compromise

Each primitive might be low/medium severity alone, but chained becomes critical.
"""

import asyncio
import itertools
from typing import Dict, List, Set, Tuple, Optional, Any, Callable
from dataclasses import dataclass, field
from collections import defaultdict
from enum import Enum
import json


class PrimitiveType(Enum):
    """Types of vulnerability primitives"""
    # Information disclosure
    INFO_LEAK = "info_leak"
    PATH_TRAVERSAL = "path_traversal"
    DIRECTORY_LISTING = "directory_listing"

    # Injection
    XSS = "xss"
    SQL_INJECTION = "sql_injection"
    COMMAND_INJECTION = "command_injection"
    TEMPLATE_INJECTION = "template_injection"
    SSRF = "ssrf"

    # File operations
    FILE_UPLOAD = "file_upload"
    FILE_INCLUDE = "file_include"
    FILE_WRITE = "file_write"
    FILE_READ = "file_read"

    # Authentication/Authorization
    AUTH_BYPASS = "auth_bypass"
    IDOR = "idor"
    PRIVILEGE_ESCALATION = "privilege_escalation"
    SESSION_FIXATION = "session_fixation"

    # Logic flaws
    RACE_CONDITION = "race_condition"
    BUSINESS_LOGIC = "business_logic"
    WORKFLOW_BYPASS = "workflow_bypass"

    # Data manipulation
    PARAMETER_POLLUTION = "parameter_pollution"
    MASS_ASSIGNMENT = "mass_assignment"
    PROTOTYPE_POLLUTION = "prototype_pollution"

    # Side effects
    CACHE_POISONING = "cache_poisoning"
    CORS_MISCONFIGURATION = "cors"
    WEBHOOK_INJECTION = "webhook_injection"

    # Processing
    CSV_INJECTION = "csv_injection"
    XML_EXTERNAL_ENTITY = "xxe"
    DESERIALIZATION = "deserialization"


@dataclass
class Primitive:
    """A single vulnerability primitive (building block)"""
    id: str
    type: PrimitiveType
    description: str
    endpoint: str
    method: str
    severity: str  # low, medium, high
    cvss_score: float

    # What this primitive can do
    capabilities: List[str]  # e.g., ["read_file", "write_data", "execute_code"]

    # What this primitive requires
    requires: List[str]  # e.g., ["authenticated", "admin_role", "file_path"]

    # What this primitive produces
    produces: List[str]  # e.g., ["credentials", "session_token", "api_key"]

    # Exploitation details
    payload: str
    parameter: str

    def __hash__(self):
        return hash(self.id)


@dataclass
class AttackChain:
    """A chain of primitives that creates high-impact vulnerability"""
    chain_id: str
    primitives: List[Primitive]
    title: str
    description: str
    severity: str  # Elevated severity from chain
    cvss_score: float  # Elevated CVSS from chain

    # Impact
    impact: str
    attack_scenario: str

    # Steps to exploit
    exploitation_steps: List[str]

    # Why this chain is powerful
    amplification_factor: float  # How much more severe than sum of parts

    def __hash__(self):
        return hash(self.chain_id)


class ChainDiscoveryEngine:
    """
    Discovers high-impact attack chains by combining vulnerability primitives
    """

    def __init__(self):
        self.primitives: List[Primitive] = []
        self.chains: List[AttackChain] = []

        # Capability matching rules
        self.chain_rules: List[Callable] = []

        # Initialize built-in chain detection rules
        self._initialize_chain_rules()

    def add_primitive(self, primitive: Primitive):
        """Adds a vulnerability primitive to the catalog"""
        self.primitives.append(primitive)

    def _initialize_chain_rules(self):
        """Initializes rules for detecting valuable chains"""

        # Rule 1: Injection → Export → Processing = RCE
        self.chain_rules.append(self._detect_injection_export_chain)

        # Rule 2: SSRF → Internal API → Credential leak
        self.chain_rules.append(self._detect_ssrf_credential_chain)

        # Rule 3: File operations → Template injection = RCE
        self.chain_rules.append(self._detect_file_template_chain)

        # Rule 4: Information disclosure → Authentication bypass
        self.chain_rules.append(self._detect_info_to_auth_chain)

        # Rule 5: Cache poisoning → Persistent XSS = Mass compromise
        self.chain_rules.append(self._detect_cache_xss_chain)

        # Rule 6: IDOR → Privilege escalation → Admin access
        self.chain_rules.append(self._detect_idor_privesc_chain)

        # Rule 7: Race condition → Business logic bypass
        self.chain_rules.append(self._detect_race_logic_chain)

        # Rule 8: Path traversal → Config read → Credential use
        self.chain_rules.append(self._detect_path_to_cred_chain)

        # Rule 9: Mass assignment → Privilege escalation
        self.chain_rules.append(self._detect_mass_assign_privesc_chain)

        # Rule 10: Prototype pollution → Auth bypass
        self.chain_rules.append(self._detect_prototype_auth_chain)

    async def discover_chains(self, max_chain_length: int = 4) -> List[AttackChain]:
        """
        Discovers attack chains by combining primitives

        Args:
            max_chain_length: Maximum number of primitives in a chain
        """
        print(f"[*] Chain Discovery: Analyzing {len(self.primitives)} primitives...")
        print(f"[*] Testing chains up to length {max_chain_length}...")

        # Generate all possible chains up to max length
        for length in range(2, max_chain_length + 1):
            print(f"[*] Testing {length}-primitive chains...")

            # Generate combinations
            for combo in itertools.combinations(self.primitives, length):
                # Check if this combination forms a valid chain
                chain = await self._evaluate_combination(list(combo))
                if chain:
                    self.chains.append(chain)

        print(f"[+] Discovered {len(self.chains)} attack chains!")

        # Sort by severity and amplification factor
        self.chains.sort(
            key=lambda c: (
                {"critical": 4, "high": 3, "medium": 2, "low": 1}[c.severity],
                c.amplification_factor
            ),
            reverse=True
        )

        return self.chains

    async def _evaluate_combination(self, primitives: List[Primitive]) -> Optional[AttackChain]:
        """
        Evaluates if a combination of primitives forms a valid attack chain
        """

        # Check if primitives can be chained (output of one feeds input of next)
        if not self._primitives_chainable(primitives):
            return None

        # Apply chain detection rules
        for rule in self.chain_rules:
            chain = rule(primitives)
            if chain:
                return chain

        # Generic chaining logic
        return self._build_generic_chain(primitives)

    def _primitives_chainable(self, primitives: List[Primitive]) -> bool:
        """
        Checks if primitives can be chained together
        (output of one provides input for next)
        """

        for i in range(len(primitives) - 1):
            curr = primitives[i]
            next_prim = primitives[i + 1]

            # Check if current produces what next requires
            produces_required = any(
                prod in next_prim.requires
                for prod in curr.produces
            )

            if not produces_required:
                return False

        return True

    def _detect_injection_export_chain(self, primitives: List[Primitive]) -> Optional[AttackChain]:
        """
        Detects: Injection → Export → Processing = RCE

        Example: XSS in profile → Export to CSV → Admin opens in Excel → DDE injection = RCE
        """

        has_injection = any(p.type in [
            PrimitiveType.XSS,
            PrimitiveType.SQL_INJECTION,
            PrimitiveType.CSV_INJECTION
        ] for p in primitives)

        has_export = any("export" in p.capabilities or "download" in p.capabilities for p in primitives)

        has_processing = any("process" in p.capabilities or "render" in p.capabilities for p in primitives)

        if has_injection and has_export:
            injection_prim = next(p for p in primitives if p.type in [
                PrimitiveType.XSS, PrimitiveType.CSV_INJECTION
            ])

            return AttackChain(
                chain_id=f"injection_export_{injection_prim.id}",
                primitives=primitives,
                title="Injection → Export → Processing = RCE",
                description=(
                    f"Inject malicious payload via {injection_prim.endpoint}, "
                    "export data to file format (CSV/PDF/Excel), "
                    "victim processes file resulting in code execution."
                ),
                severity="critical",
                cvss_score=9.5,
                impact="Remote Code Execution on victim machine (typically admin)",
                attack_scenario=(
                    "1. Attacker injects formula/DDE payload in profile field\n"
                    "2. Admin exports user data to CSV\n"
                    "3. Admin opens CSV in Excel\n"
                    "4. Excel executes DDE command\n"
                    "5. Attacker gains RCE on admin machine"
                ),
                exploitation_steps=[
                    f"POST {injection_prim.endpoint}",
                    f"Inject payload: {injection_prim.payload}",
                    "Wait for admin to export data",
                    "Admin opens file → Code execution",
                    "Establish reverse shell"
                ],
                amplification_factor=3.5  # Low severity XSS → Critical RCE
            ))

        return None

    def _detect_ssrf_credential_chain(self, primitives: List[Primitive]) -> Optional[AttackChain]:
        """
        Detects: SSRF → Internal API → Credential leak
        """

        ssrf = next((p for p in primitives if p.type == PrimitiveType.SSRF), None)
        produces_creds = any("credentials" in p.produces or "token" in p.produces for p in primitives)

        if ssrf and produces_creds:
            return AttackChain(
                chain_id=f"ssrf_cred_{ssrf.id}",
                primitives=primitives,
                title="SSRF → Internal API → Credential Leak → Account Takeover",
                description=(
                    "Use SSRF to access internal APIs, extract credentials/tokens, "
                    "use credentials for account takeover."
                ),
                severity="critical",
                cvss_score=9.0,
                impact="Full account takeover including admin accounts",
                attack_scenario=(
                    "1. Exploit SSRF to access internal metadata service\n"
                    "2. Extract AWS credentials / API tokens\n"
                    "3. Use credentials to access cloud resources\n"
                    "4. Escalate to admin access\n"
                    "5. Complete infrastructure compromise"
                ),
                exploitation_steps=[
                    f"POST {ssrf.endpoint}",
                    f"Payload: {ssrf.payload}",
                    "Access http://169.254.169.254/latest/meta-data/",
                    "Extract AWS credentials",
                    "Use credentials for cloud access"
                ],
                amplification_factor=4.0
            ))

        return None

    def _detect_file_template_chain(self, primitives: List[Primitive]) -> Optional[AttackChain]:
        """
        Detects: File upload/write → Template inclusion → RCE
        """

        file_op = next((p for p in primitives if p.type in [
            PrimitiveType.FILE_UPLOAD,
            PrimitiveType.FILE_WRITE
        ]), None)

        template = next((p for p in primitives if p.type == PrimitiveType.TEMPLATE_INJECTION), None)

        if file_op and template:
            return AttackChain(
                chain_id=f"file_template_{file_op.id}_{template.id}",
                primitives=primitives,
                title="File Upload → Template Injection → RCE",
                description=(
                    "Upload malicious template file, trigger template rendering, "
                    "achieve remote code execution."
                ),
                severity="critical",
                cvss_score=9.8,
                impact="Remote Code Execution on application server",
                attack_scenario=(
                    "1. Upload malicious template file (.jinja2, .twig, etc.)\n"
                    "2. File stored in templates directory\n"
                    "3. Trigger template rendering\n"
                    "4. Template engine executes injected code\n"
                    "5. Full server compromise"
                ),
                exploitation_steps=[
                    f"POST {file_op.endpoint}",
                    f"Upload: {file_op.payload}",
                    f"Trigger: {template.endpoint}",
                    "Server executes template",
                    "RCE achieved"
                ],
                amplification_factor=5.0
            ))

        return None

    def _detect_info_to_auth_chain(self, primitives: List[Primitive]) -> Optional[AttackChain]:
        """
        Detects: Information disclosure → Authentication bypass
        """

        info_leak = next((p for p in primitives if p.type == PrimitiveType.INFO_LEAK), None)
        auth_bypass = next((p for p in primitives if p.type == PrimitiveType.AUTH_BYPASS), None)

        if info_leak and auth_bypass:
            return AttackChain(
                chain_id=f"info_auth_{info_leak.id}_{auth_bypass.id}",
                primitives=primitives,
                title="Information Disclosure → Authentication Bypass → Account Takeover",
                description=(
                    "Leak internal information, use it to bypass authentication."
                ),
                severity="high",
                cvss_score=8.5,
                impact="Account takeover without credentials",
                attack_scenario=(
                    "1. Extract internal IDs/tokens via info leak\n"
                    "2. Use leaked data to craft bypass payload\n"
                    "3. Authenticate without password\n"
                    "4. Full account access"
                ),
                exploitation_steps=[
                    f"GET {info_leak.endpoint}",
                    "Extract internal tokens",
                    f"POST {auth_bypass.endpoint}",
                    "Bypass with leaked tokens",
                    "Account compromised"
                ],
                amplification_factor=3.0
            ))

        return None

    def _detect_cache_xss_chain(self, primitives: List[Primitive]) -> Optional[AttackChain]:
        """
        Detects: Cache poisoning → XSS → Persistent mass compromise
        """

        cache = next((p for p in primitives if p.type == PrimitiveType.CACHE_POISONING), None)
        xss = next((p for p in primitives if p.type == PrimitiveType.XSS), None)

        if cache and xss:
            return AttackChain(
                chain_id=f"cache_xss_{cache.id}_{xss.id}",
                primitives=primitives,
                title="Cache Poisoning → XSS → Mass User Compromise",
                description=(
                    "Poison cache with XSS payload, affect all users accessing cached page."
                ),
                severity="critical",
                cvss_score=9.0,
                impact="Mass compromise of all users",
                attack_scenario=(
                    "1. Inject XSS payload in cacheable response\n"
                    "2. Response gets cached by CDN/reverse proxy\n"
                    "3. All users receive poisoned response\n"
                    "4. XSS executes in every user's browser\n"
                    "5. Mass session hijacking"
                ),
                exploitation_steps=[
                    f"GET {cache.endpoint}",
                    "Add cache-busting headers",
                    f"Inject XSS: {xss.payload}",
                    "Response cached with XSS",
                    "All users compromised"
                ],
                amplification_factor=4.5
            ))

        return None

    def _detect_idor_privesc_chain(self, primitives: List[Primitive]) -> Optional[AttackChain]:
        """
        Detects: IDOR → Privilege escalation → Admin access
        """

        idor = next((p for p in primitives if p.type == PrimitiveType.IDOR), None)
        privesc = next((p for p in primitives if p.type == PrimitiveType.PRIVILEGE_ESCALATION), None)

        if idor and privesc:
            return AttackChain(
                chain_id=f"idor_privesc_{idor.id}_{privesc.id}",
                primitives=primitives,
                title="IDOR → Privilege Escalation → Full Admin Access",
                description=(
                    "Access other users' resources via IDOR, modify admin settings, "
                    "escalate to full admin privileges."
                ),
                severity="critical",
                cvss_score=9.5,
                impact="Full administrative access",
                attack_scenario=(
                    "1. Use IDOR to access admin user object\n"
                    "2. Modify admin role/permissions field\n"
                    "3. Elevate own account to admin\n"
                    "4. Full application control"
                ),
                exploitation_steps=[
                    f"GET {idor.endpoint}",
                    "Iterate through user IDs",
                    "Find admin user (ID=1)",
                    f"PATCH {privesc.endpoint}",
                    "Set role=admin on own account"
                ],
                amplification_factor=3.8
            ))

        return None

    def _detect_race_logic_chain(self, primitives: List[Primitive]) -> Optional[AttackChain]:
        """
        Detects: Race condition → Business logic bypass
        """

        race = next((p for p in primitives if p.type == PrimitiveType.RACE_CONDITION), None)
        logic = next((p for p in primitives if p.type == PrimitiveType.BUSINESS_LOGIC), None)

        if race and logic:
            return AttackChain(
                chain_id=f"race_logic_{race.id}_{logic.id}",
                primitives=primitives,
                title="Race Condition → Business Logic Bypass → Financial Fraud",
                description=(
                    "Exploit race condition to bypass business rules, double-spend, "
                    "or duplicate credits."
                ),
                severity="high",
                cvss_score=8.0,
                impact="Financial loss, double-spending, credit duplication",
                attack_scenario=(
                    "1. Initiate payment/transfer\n"
                    "2. Send parallel duplicate requests (race)\n"
                    "3. Balance check passes for both\n"
                    "4. Both transactions execute\n"
                    "5. Double value extracted"
                ),
                exploitation_steps=[
                    f"POST {race.endpoint} (Thread 1)",
                    f"POST {race.endpoint} (Thread 2, simultaneous)",
                    "Both pass balance check",
                    "Both transactions succeed",
                    "Double spending achieved"
                ],
                amplification_factor=3.2
            ))

        return None

    def _detect_path_to_cred_chain(self, primitives: List[Primitive]) -> Optional[AttackChain]:
        """
        Detects: Path traversal → Config/credential file → Credential use
        """

        path_trav = next((p for p in primitives if p.type == PrimitiveType.PATH_TRAVERSAL), None)
        produces_creds = any("credentials" in p.produces for p in primitives)

        if path_trav and produces_creds:
            return AttackChain(
                chain_id=f"path_cred_{path_trav.id}",
                primitives=primitives,
                title="Path Traversal → Credential Extraction → Full Compromise",
                description=(
                    "Use path traversal to read config files, extract credentials, "
                    "use credentials for full system access."
                ),
                severity="critical",
                cvss_score=9.3,
                impact="Full system compromise via stolen credentials",
                attack_scenario=(
                    "1. Exploit path traversal to read /etc/app/config.yml\n"
                    "2. Extract database credentials\n"
                    "3. Connect to database directly\n"
                    "4. Dump all user data\n"
                    "5. Modify admin accounts"
                ),
                exploitation_steps=[
                    f"GET {path_trav.endpoint}",
                    f"Payload: {path_trav.payload}",
                    "Read ../../config/database.yml",
                    "Extract DB credentials",
                    "Direct database access"
                ],
                amplification_factor=4.2
            ))

        return None

    def _detect_mass_assign_privesc_chain(self, primitives: List[Primitive]) -> Optional[AttackChain]:
        """
        Detects: Mass assignment → Privilege escalation
        """

        mass_assign = next((p for p in primitives if p.type == PrimitiveType.MASS_ASSIGNMENT), None)
        has_privesc = any("privilege" in cap for p in primitives for cap in p.capabilities)

        if mass_assign and has_privesc:
            return AttackChain(
                chain_id=f"mass_privesc_{mass_assign.id}",
                primitives=primitives,
                title="Mass Assignment → Privilege Escalation",
                description=(
                    "Use mass assignment to set privileged fields, escalate to admin."
                ),
                severity="high",
                cvss_score=8.5,
                impact="Administrative access via parameter injection",
                attack_scenario=(
                    "1. Register new user account\n"
                    "2. Add 'role=admin' to registration payload\n"
                    "3. Mass assignment allows setting role\n"
                    "4. Account created with admin privileges\n"
                    "5. Immediate admin access"
                ),
                exploitation_steps=[
                    f"POST {mass_assign.endpoint}",
                    'Payload: {{"username":"attacker", "role":"admin"}}',
                    "Mass assignment vulnerability",
                    "Role field not filtered",
                    "Admin account created"
                ],
                amplification_factor=3.5
            ))

        return None

    def _detect_prototype_auth_chain(self, primitives: List[Primitive]) -> Optional[AttackChain]:
        """
        Detects: Prototype pollution → Authentication bypass
        """

        proto_poll = next((p for p in primitives if p.type == PrimitiveType.PROTOTYPE_POLLUTION), None)
        affects_auth = any("authentication" in cap for p in primitives for cap in p.capabilities)

        if proto_poll and affects_auth:
            return AttackChain(
                chain_id=f"proto_auth_{proto_poll.id}",
                primitives=primitives,
                title="Prototype Pollution → Authentication Bypass",
                description=(
                    "Pollute Object.prototype to bypass authentication checks."
                ),
                severity="critical",
                cvss_score=9.0,
                impact="Authentication bypass affecting all users",
                attack_scenario=(
                    "1. Inject __proto__ payload to pollute prototype\n"
                    "2. Set isAdmin = true on Object.prototype\n"
                    "3. All objects inherit isAdmin property\n"
                    "4. Authentication checks pass for all users\n"
                    "5. Universal privilege escalation"
                ),
                exploitation_steps=[
                    f"POST {proto_poll.endpoint}",
                    'Payload: {{"__proto__": {{"isAdmin": true}}}}',
                    "Object.prototype polluted",
                    "All auth checks bypassed",
                    "Full access achieved"
                ],
                amplification_factor=5.0
            ))

        return None

    def _build_generic_chain(self, primitives: List[Primitive]) -> Optional[AttackChain]:
        """
        Builds a generic chain if primitives are chainable but don't match specific rules
        """

        # Calculate combined severity
        max_individual_cvss = max(p.cvss_score for p in primitives)
        combined_cvss = min(max_individual_cvss + len(primitives) * 0.5, 10.0)

        # Determine if chaining creates significant amplification
        amplification = combined_cvss / max_individual_cvss

        if amplification < 1.3:  # Not significant enough
            return None

        severity = "critical" if combined_cvss >= 9.0 else \
                   "high" if combined_cvss >= 7.0 else \
                   "medium" if combined_cvss >= 4.0 else "low"

        return AttackChain(
            chain_id=f"generic_{'_'.join(p.id for p in primitives)}",
            primitives=primitives,
            title=f"Chained Attack: {' → '.join(p.type.value for p in primitives)}",
            description=(
                f"Combining {len(primitives)} vulnerabilities creates higher impact attack."
            ),
            severity=severity,
            cvss_score=combined_cvss,
            impact="Amplified impact through chaining",
            attack_scenario="Execute primitives in sequence for amplified impact",
            exploitation_steps=[
                f"{i+1}. Exploit {p.endpoint} ({p.type.value})"
                for i, p in enumerate(primitives)
            ],
            amplification_factor=amplification
        ))

    def generate_report(self) -> str:
        """Generates markdown report of discovered chains"""

        report = ["# Attack Chain Discovery Report", ""]
        report.append(f"**Primitives Analyzed:** {len(self.primitives)}")
        report.append(f"**Chains Discovered:** {len(self.chains)}")
        report.append(f"**Analysis Date:** {datetime.now().isoformat()}")
        report.append("")

        # Statistics
        by_severity = defaultdict(int)
        total_amplification = 0
        for chain in self.chains:
            by_severity[chain.severity] += 1
            total_amplification += chain.amplification_factor

        report.append("## Statistics")
        report.append(f"- Critical chains: {by_severity['critical']}")
        report.append(f"- High severity chains: {by_severity['high']}")
        report.append(f"- Medium severity chains: {by_severity['medium']}")
        report.append(f"- Average amplification: {total_amplification/len(self.chains):.2f}x")
        report.append("")

        # Top chains
        report.append("## Discovered Attack Chains")
        report.append("")

        for chain in self.chains:
            report.append(f"### {chain.title}")
            report.append(f"**Severity:** {chain.severity.upper()} | **CVSS:** {chain.cvss_score} | **Amplification:** {chain.amplification_factor:.1f}x")
            report.append("")
            report.append(f"**Impact:** {chain.impact}")
            report.append("")
            report.append(f"**Description:**")
            report.append(chain.description)
            report.append("")
            report.append(f"**Attack Scenario:**")
            report.append(chain.attack_scenario)
            report.append("")
            report.append(f"**Exploitation Steps:**")
            for step in chain.exploitation_steps:
                report.append(f"- {step}")
            report.append("")
            report.append(f"**Primitives Used:**")
            for prim in chain.primitives:
                report.append(f"- {prim.type.value}: {prim.endpoint} (CVSS: {prim.cvss_score})")
            report.append("")
            report.append("---")
            report.append("")

        return "\n".join(report)


# Example usage
async def demo_chain_discovery():
    """Demonstrates chain discovery with example primitives"""

    engine = ChainDiscoveryEngine()

    # Add example primitives
    engine.add_primitive(Primitive(
        id="xss_1",
        type=PrimitiveType.XSS,
        description="Stored XSS in profile name",
        endpoint="/api/profile",
        method="POST",
        severity="medium",
        cvss_score=5.5,
        capabilities=["inject_html", "store_data"],
        requires=["authenticated"],
        produces=["stored_payload"],
        payload='<script>alert(1)</script>',
        parameter="name"
    ))

    engine.add_primitive(Primitive(
        id="export_1",
        type=PrimitiveType.CSV_INJECTION,
        description="User data export to CSV",
        endpoint="/admin/export/users",
        method="GET",
        severity="low",
        cvss_score=2.0,
        capabilities=["export", "download"],
        requires=["admin_role", "stored_payload"],
        produces=["csv_file"],
        payload="",
        parameter=""
    ))

    # Discover chains
    chains = await engine.discover_chains(max_chain_length=3)

    # Generate report
    report = engine.generate_report()

    return chains, report


if __name__ == "__main__":
    chains, report = asyncio.run(demo_chain_discovery())

    print("\n" + "="*60)
    print(report)
    print("="*60)

    print(f"\nDiscovered {len(chains)} attack chains with amplification!")
