"""
Semantic Analysis Engine - Finding Spec-Implementation Gaps

This module finds vulnerabilities by comparing INTENDED behavior (documented)
vs ACTUAL behavior (tested).

The unfair advantage: Humans read docs and test individually. We build a complete
semantic model of what the application SHOULD do, then find where reality differs.

Finds:
- Specification-implementation gaps (documented restrictions not enforced)
- Behavioral contradictions (actions that should fail but succeed)
- Semantic permission inconsistencies (implicit assumptions about authorization)
- Undocumented features/parameters (capabilities not in docs)
- API contract violations (promises not kept)

Expected impact: 15-25 findings/month @ $10K-$20K = $150K-$500K/month
"""

import asyncio
import aiohttp
import re
import json
from typing import Dict, List, Set, Tuple, Optional, Any
from dataclasses import dataclass, field
from collections import defaultdict
from datetime import datetime
import yaml


@dataclass
class APISpecification:
    """Represents what the API is SUPPOSED to do"""
    endpoint: str
    method: str
    description: str
    required_params: List[str]
    optional_params: List[str]
    allowed_values: Dict[str, List[str]]  # param -> [allowed values]
    requires_auth: bool
    requires_role: Optional[str]
    response_schema: Dict[str, Any]
    constraints: List[str]  # Documented constraints
    examples: List[Dict[str, Any]]


@dataclass
class APIBehavior:
    """Represents what the API ACTUALLY does"""
    endpoint: str
    method: str
    tested_with: Dict[str, Any]  # Parameters used
    response_status: int
    response_body: str
    auth_used: bool
    succeeded: bool
    constraints_violated: List[str]  # Which documented constraints were violated
    unexpected_success: bool  # Should have failed but succeeded


@dataclass
class SemanticGap:
    """Represents a gap between specification and implementation"""
    gap_id: str
    gap_type: str  # spec_violation, undocumented_feature, permission_gap, etc.
    title: str
    severity: str
    cvss_score: float
    description: str
    specification: str  # What docs say
    reality: str  # What actually happens
    evidence: List[str]
    exploitation_steps: List[str]
    impact: str
    confidence: float


class SemanticAnalyzer:
    """
    Analyzes semantic gaps between API specifications and actual behavior
    """

    def __init__(self):
        self.specifications: Dict[str, APISpecification] = {}
        self.behaviors: List[APIBehavior] = []
        self.gaps: List[SemanticGap] = []

    async def load_specification(self, spec_source: str, spec_type: str = "openapi"):
        """
        Loads API specification from various sources

        Args:
            spec_source: URL or file path to specification
            spec_type: openapi, swagger, wadl, raml, or manual
        """

        print(f"[*] Loading API specification from {spec_source}")

        if spec_type == "openapi":
            await self._load_openapi(spec_source)
        elif spec_type == "swagger":
            await self._load_swagger(spec_source)
        elif spec_type == "documentation":
            await self._parse_documentation(spec_source)
        elif spec_type == "manual":
            # Manual specification (from analysis)
            pass

        print(f"[+] Loaded {len(self.specifications)} endpoint specifications")

    async def _load_openapi(self, url: str):
        """Loads OpenAPI/Swagger specification"""

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as response:
                    if response.status == 200:
                        content = await response.text()

                        # Try JSON first
                        try:
                            spec = json.loads(content)
                        except:
                            # Try YAML
                            spec = yaml.safe_load(content)

                        # Parse OpenAPI spec
                        self._parse_openapi_spec(spec)

        except Exception as e:
            print(f"[!] Error loading OpenAPI spec: {e}")

    def _parse_openapi_spec(self, spec: Dict):
        """Parses OpenAPI specification into our format"""

        base_path = spec.get('basePath', '')
        paths = spec.get('paths', {})

        for path, path_spec in paths.items():
            for method, method_spec in path_spec.items():
                if method.upper() not in ['GET', 'POST', 'PUT', 'PATCH', 'DELETE']:
                    continue

                # Extract parameters
                params = method_spec.get('parameters', [])
                required_params = []
                optional_params = []
                allowed_values = {}

                for param in params:
                    param_name = param.get('name')
                    param_required = param.get('required', False)

                    if param_required:
                        required_params.append(param_name)
                    else:
                        optional_params.append(param_name)

                    # Extract enum values (allowed values)
                    if 'enum' in param:
                        allowed_values[param_name] = param['enum']

                # Extract security requirements
                requires_auth = 'security' in method_spec or 'security' in spec
                requires_role = None

                if 'security' in method_spec:
                    # Try to extract required role/scope
                    security = method_spec['security']
                    if security and len(security) > 0:
                        first_sec = security[0]
                        for key, scopes in first_sec.items():
                            if scopes:
                                requires_role = scopes[0]

                # Extract constraints from description
                description = method_spec.get('description', '')
                constraints = self._extract_constraints(description)

                # Create specification
                endpoint_key = f"{method.upper()} {base_path}{path}"
                self.specifications[endpoint_key] = APISpecification(
                    endpoint=f"{base_path}{path}",
                    method=method.upper(),
                    description=description,
                    required_params=required_params,
                    optional_params=optional_params,
                    allowed_values=allowed_values,
                    requires_auth=requires_auth,
                    requires_role=requires_role,
                    response_schema=method_spec.get('responses', {}).get('200', {}).get('schema', {}),
                    constraints=constraints,
                    examples=method_spec.get('examples', [])
                )

    def _extract_constraints(self, description: str) -> List[str]:
        """Extracts constraints from API description"""

        constraints = []

        # Common constraint patterns
        patterns = [
            r"must be ([\w\s]+)",
            r"cannot be ([\w\s]+)",
            r"only ([\w\s]+) can",
            r"requires? ([\w\s]+)",
            r"([\w\s]+) is required",
            r"after ([\w\s]+)",
            r"before ([\w\s]+)",
            r"when ([\w\s]+)",
        ]

        for pattern in patterns:
            matches = re.findall(pattern, description, re.IGNORECASE)
            constraints.extend(matches)

        return constraints

    async def _load_swagger(self, url: str):
        """Loads Swagger specification (wrapper for OpenAPI)"""
        await self._load_openapi(url)

    async def _parse_documentation(self, url: str):
        """Parses human-readable documentation to extract specifications"""

        # This would use NLP/pattern matching to extract specs from docs
        # For now, placeholder
        print("[*] Documentation parsing not yet implemented")
        pass

    async def test_actual_behavior(
        self,
        base_url: str,
        auth_tokens: Dict[str, str] = None
    ):
        """
        Tests actual API behavior to compare with specifications
        """

        print(f"[*] Testing actual behavior of {len(self.specifications)} endpoints...")

        for spec_key, spec in self.specifications.items():
            # Test multiple scenarios
            scenarios = self._generate_test_scenarios(spec)

            for scenario in scenarios:
                behavior = await self._test_scenario(base_url, spec, scenario, auth_tokens)
                self.behaviors.append(behavior)

        print(f"[+] Collected {len(self.behaviors)} behavior samples")

    def _generate_test_scenarios(self, spec: APISpecification) -> List[Dict[str, Any]]:
        """
        Generates test scenarios to explore specification boundaries
        """

        scenarios = []

        # Scenario 1: Happy path (all required params, valid values)
        happy_path = {}
        for param in spec.required_params:
            if param in spec.allowed_values:
                happy_path[param] = spec.allowed_values[param][0]
            else:
                happy_path[param] = "test_value"

        scenarios.append({
            'name': 'happy_path',
            'params': happy_path,
            'use_auth': spec.requires_auth,
            'expected_success': True
        })

        # Scenario 2: Missing required param
        if spec.required_params:
            missing_param = {}
            for param in spec.required_params[:-1]:  # Skip last one
                if param in spec.allowed_values:
                    missing_param[param] = spec.allowed_values[param][0]
                else:
                    missing_param[param] = "test_value"

            scenarios.append({
                'name': 'missing_required_param',
                'params': missing_param,
                'use_auth': spec.requires_auth,
                'expected_success': False
            })

        # Scenario 3: Invalid enum value
        for param, values in spec.allowed_values.items():
            invalid_value = {}
            for p in spec.required_params:
                if p == param:
                    invalid_value[p] = "INVALID_VALUE_NOT_IN_ENUM"
                elif p in spec.allowed_values:
                    invalid_value[p] = spec.allowed_values[p][0]
                else:
                    invalid_value[p] = "test_value"

            scenarios.append({
                'name': f'invalid_{param}_value',
                'params': invalid_value,
                'use_auth': spec.requires_auth,
                'expected_success': False
            })

        # Scenario 4: Without authentication (if auth required)
        if spec.requires_auth:
            scenarios.append({
                'name': 'no_auth',
                'params': happy_path.copy(),
                'use_auth': False,
                'expected_success': False
            })

        # Scenario 5: Undocumented parameters
        test_undocumented = happy_path.copy()
        test_undocumented['admin'] = 'true'
        test_undocumented['debug'] = 'true'
        test_undocumented['role'] = 'admin'

        scenarios.append({
            'name': 'undocumented_params',
            'params': test_undocumented,
            'use_auth': spec.requires_auth,
            'expected_success': True  # Should ignore unknown params
        })

        return scenarios

    async def _test_scenario(
        self,
        base_url: str,
        spec: APISpecification,
        scenario: Dict[str, Any],
        auth_tokens: Dict[str, str]
    ) -> APIBehavior:
        """
        Tests a single scenario
        """

        url = f"{base_url}{spec.endpoint}"
        params = scenario['params']
        use_auth = scenario['use_auth']
        expected_success = scenario['expected_success']

        headers = {}
        if use_auth and auth_tokens:
            headers['Authorization'] = f"Bearer {auth_tokens.get('default', '')}"

        try:
            async with aiohttp.ClientSession() as session:
                async with session.request(
                    method=spec.method,
                    url=url,
                    json=params if spec.method in ['POST', 'PUT', 'PATCH'] else None,
                    params=params if spec.method == 'GET' else None,
                    headers=headers,
                    timeout=aiohttp.ClientTimeout(total=10),
                    ssl=False
                ) as response:
                    body = await response.text()
                    status = response.status

                    succeeded = 200 <= status < 300
                    unexpected_success = succeeded and not expected_success

                    # Check constraint violations
                    violations = []
                    if unexpected_success:
                        violations.append(f"Expected failure but got {status}")

                    return APIBehavior(
                        endpoint=spec.endpoint,
                        method=spec.method,
                        tested_with=params,
                        response_status=status,
                        response_body=body,
                        auth_used=use_auth,
                        succeeded=succeeded,
                        constraints_violated=violations,
                        unexpected_success=unexpected_success
                    )

        except Exception as e:
            return APIBehavior(
                endpoint=spec.endpoint,
                method=spec.method,
                tested_with=params,
                response_status=0,
                response_body=str(e),
                auth_used=use_auth,
                succeeded=False,
                constraints_violated=[],
                unexpected_success=False
            )

    async def analyze_gaps(self) -> List[SemanticGap]:
        """
        Analyzes all specifications vs behaviors to find semantic gaps
        """

        print("[*] Analyzing semantic gaps...")

        for spec_key, spec in self.specifications.items():
            # Get behaviors for this endpoint
            endpoint_behaviors = [
                b for b in self.behaviors
                if b.endpoint == spec.endpoint and b.method == spec.method
            ]

            # Analyze different gap types
            gaps = []
            gaps.extend(self._find_specification_violations(spec, endpoint_behaviors))
            gaps.extend(self._find_auth_gaps(spec, endpoint_behaviors))
            gaps.extend(self._find_undocumented_features(spec, endpoint_behaviors))
            gaps.extend(self._find_constraint_violations(spec, endpoint_behaviors))

            self.gaps.extend(gaps)

        print(f"[+] Found {len(self.gaps)} semantic gaps")

        return self.gaps

    def _find_specification_violations(
        self,
        spec: APISpecification,
        behaviors: List[APIBehavior]
    ) -> List[SemanticGap]:
        """
        Finds cases where documented restrictions are not enforced
        """

        gaps = []

        # Find behaviors that violated documented constraints
        for behavior in behaviors:
            if behavior.unexpected_success:
                # Check if this violated enum constraints
                for param, value in behavior.tested_with.items():
                    if param in spec.allowed_values:
                        if value not in spec.allowed_values[param]:
                            gaps.append(SemanticGap(
                                gap_id=f"spec_violation_{spec.endpoint}_{param}",
                                gap_type="specification_violation",
                                title=f"Undocumented Value Accepted: {param}",
                                severity="medium",
                                cvss_score=5.5,
                                description=(
                                    f"Documentation specifies {param} must be one of "
                                    f"{spec.allowed_values[param]}, but server accepts "
                                    f"undocumented value '{value}'."
                                ),
                                specification=f"{param} ∈ {spec.allowed_values[param]}",
                                reality=f"Server accepts {param} = '{value}'",
                                evidence=[
                                    f"Documented values: {spec.allowed_values[param]}",
                                    f"Tested value: {value}",
                                    f"Response status: {behavior.response_status}",
                                    "Request succeeded despite using undocumented value"
                                ],
                                exploitation_steps=[
                                    f"1. Read documentation for {spec.endpoint}",
                                    f"2. Note {param} is restricted to {spec.allowed_values[param]}",
                                    f"3. Send request with {param}='{value}'",
                                    "4. Request succeeds, bypassing documented restrictions",
                                    "5. Explore other undocumented values for privilege escalation"
                                ],
                                impact="Bypass documented restrictions, potential privilege escalation",
                                confidence=0.9
                            ))

        return gaps

    def _find_auth_gaps(
        self,
        spec: APISpecification,
        behaviors: List[APIBehavior]
    ) -> List[SemanticGap]:
        """
        Finds authentication/authorization gaps
        """

        gaps = []

        # Find requests that succeeded without auth when auth was documented as required
        if spec.requires_auth:
            unauth_successes = [
                b for b in behaviors
                if not b.auth_used and b.succeeded
            ]

            if unauth_successes:
                gaps.append(SemanticGap(
                    gap_id=f"auth_gap_{spec.endpoint}",
                    gap_type="authentication_gap",
                    title=f"Authentication Not Enforced on {spec.endpoint}",
                    severity="high",
                    cvss_score=8.0,
                    description=(
                        f"Documentation states authentication is required, "
                        f"but endpoint accepts unauthenticated requests."
                    ),
                    specification="Authentication required",
                    reality="Endpoint accessible without authentication",
                    evidence=[
                        f"Documentation: requires_auth = {spec.requires_auth}",
                        f"Tested without auth: {len(unauth_successes)} successful requests",
                        f"Response status: {unauth_successes[0].response_status}"
                    ],
                    exploitation_steps=[
                        f"1. Remove Authorization header",
                        f"2. Send request to {spec.method} {spec.endpoint}",
                        "3. Request succeeds without authentication",
                        "4. Access protected resources anonymously"
                    ],
                    impact="Unauthorized access to protected endpoints",
                    confidence=0.95
                ))

        return gaps

    def _find_undocumented_features(
        self,
        spec: APISpecification,
        behaviors: List[APIBehavior]
    ) -> List[SemanticGap]:
        """
        Finds undocumented parameters or features that work
        """

        gaps = []

        # Look for behaviors that used undocumented parameters and succeeded
        documented_params = set(spec.required_params + spec.optional_params)

        for behavior in behaviors:
            if behavior.succeeded:
                undocumented_params = set(behavior.tested_with.keys()) - documented_params

                if undocumented_params:
                    gaps.append(SemanticGap(
                        gap_id=f"undocumented_{spec.endpoint}_{'_'.join(undocumented_params)}",
                        gap_type="undocumented_feature",
                        title=f"Undocumented Parameters Accepted: {', '.join(undocumented_params)}",
                        severity="medium",
                        cvss_score=6.0,
                        description=(
                            f"Endpoint accepts undocumented parameters: {', '.join(undocumented_params)}. "
                            "These may provide hidden functionality or privilege escalation."
                        ),
                        specification=f"Documented params: {documented_params}",
                        reality=f"Also accepts: {undocumented_params}",
                        evidence=[
                            f"Documented parameters: {documented_params}",
                            f"Undocumented parameters found: {undocumented_params}",
                            f"Request succeeded with undocumented params"
                        ],
                        exploitation_steps=[
                            f"1. Send request with undocumented param: {list(undocumented_params)[0]}",
                            "2. Server accepts and processes parameter",
                            "3. Test various values (admin=true, role=admin, debug=true)",
                            "4. Look for privilege escalation or information disclosure"
                        ],
                        impact="Hidden functionality, potential privilege escalation",
                        confidence=0.75
                    ))

        return gaps

    def _find_constraint_violations(
        self,
        spec: APISpecification,
        behaviors: List[APIBehavior]
    ) -> List[SemanticGap]:
        """
        Finds violations of documented constraints
        """

        gaps = []

        # Check if behaviors violated documented constraints
        for constraint in spec.constraints:
            constraint_lower = constraint.lower()

            # Check different constraint types
            if "after" in constraint_lower or "before" in constraint_lower:
                # Temporal constraint
                # TODO: Implement temporal constraint checking
                pass

            elif "only" in constraint_lower and "can" in constraint_lower:
                # Permission constraint (e.g., "only admin can delete")
                # Check if non-admin succeeded
                # TODO: Implement role-based constraint checking
                pass

        return gaps

    def generate_report(self) -> str:
        """Generates markdown report of semantic analysis"""

        report = ["# Semantic Analysis Report", ""]
        report.append(f"**Analysis Date:** {datetime.now().isoformat()}")
        report.append(f"**Endpoints Analyzed:** {len(self.specifications)}")
        report.append(f"**Behaviors Tested:** {len(self.behaviors)}")
        report.append(f"**Semantic Gaps Found:** {len(self.gaps)}")
        report.append("")

        # Group by gap type
        by_type = defaultdict(list)
        for gap in self.gaps:
            by_type[gap.gap_type].append(gap)

        report.append("## Gap Types")
        for gap_type, gaps in by_type.items():
            report.append(f"- {gap_type}: {len(gaps)}")
        report.append("")

        # Group by severity
        by_severity = defaultdict(list)
        for gap in self.gaps:
            by_severity[gap.severity].append(gap)

        for severity in ['critical', 'high', 'medium', 'low']:
            if severity in by_severity:
                report.append(f"## {severity.upper()} Severity ({len(by_severity[severity])})")
                report.append("")

                for gap in by_severity[severity]:
                    report.append(f"### {gap.title}")
                    report.append(f"**Type:** {gap.gap_type} | **CVSS:** {gap.cvss_score} | **Confidence:** {gap.confidence*100:.0f}%")
                    report.append("")
                    report.append(f"**Description:**")
                    report.append(gap.description)
                    report.append("")
                    report.append(f"**Specification says:** {gap.specification}")
                    report.append(f"**Reality is:** {gap.reality}")
                    report.append("")
                    report.append(f"**Impact:** {gap.impact}")
                    report.append("")
                    report.append(f"**Evidence:**")
                    for evidence in gap.evidence:
                        report.append(f"- {evidence}")
                    report.append("")
                    report.append(f"**Exploitation Steps:**")
                    for step in gap.exploitation_steps:
                        report.append(f"{step}")
                    report.append("")
                    report.append("---")
                    report.append("")

        return "\n".join(report)


# Example usage
async def analyze_api_semantics(target_url: str, spec_url: str):
    """
    Main entry point for semantic analysis
    """

    analyzer = SemanticAnalyzer()

    # Load specification
    await analyzer.load_specification(spec_url, spec_type="openapi")

    # Test actual behavior
    await analyzer.test_actual_behavior(
        base_url=target_url,
        auth_tokens={"default": "test_token_123"}
    )

    # Analyze gaps
    gaps = await analyzer.analyze_gaps()

    # Generate report
    report = analyzer.generate_report()

    return gaps, report


if __name__ == "__main__":
    gaps, report = asyncio.run(analyze_api_semantics(
        target_url="https://api.example.com",
        spec_url="https://api.example.com/openapi.json"
    ))

    print("\n" + "="*60)
    print(report)
    print("="*60)

    print(f"\nFound {len(gaps)} semantic gaps!")
