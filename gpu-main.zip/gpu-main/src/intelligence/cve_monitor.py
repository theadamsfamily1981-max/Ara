"""
CVE Monitoring and Auto-Exploitation System
Monitors new CVEs and automatically checks if targets are vulnerable.
"""

import logging
import aiohttp
import asyncio
from typing import Dict, List, Optional
from datetime import datetime, timedelta
import json
import re

logger = logging.getLogger(__name__)


class CVEMonitor:
    """Monitor CVEs and automatically test targets."""

    def __init__(self, db_connection=None):
        """Initialize CVE monitor."""
        self.db = db_connection
        self.known_cves = set()
        self.cve_cache_file = './data/cve_cache.json'

        # Technology to CVE keywords mapping
        self.tech_keywords = {
            'wordpress': ['wordpress', 'wp-', 'woocommerce'],
            'drupal': ['drupal'],
            'joomla': ['joomla'],
            'apache': ['apache', 'httpd'],
            'nginx': ['nginx'],
            'tomcat': ['tomcat'],
            'jenkins': ['jenkins'],
            'gitlab': ['gitlab'],
            'grafana': ['grafana'],
            'confluence': ['confluence', 'atlassian'],
            'jira': ['jira', 'atlassian'],
            'elastic': ['elasticsearch', 'kibana', 'logstash'],
            'redis': ['redis'],
            'mongodb': ['mongodb', 'mongo'],
            'postgresql': ['postgresql', 'postgres'],
            'mysql': ['mysql', 'mariadb']
        }

        self._load_cache()

    def _load_cache(self):
        """Load known CVEs from cache."""
        try:
            with open(self.cve_cache_file, 'r') as f:
                data = json.load(f)
                self.known_cves = set(data.get('known_cves', []))
                logger.info(f"Loaded {len(self.known_cves)} known CVEs from cache")
        except:
            logger.info("No CVE cache found, starting fresh")

    def _save_cache(self):
        """Save known CVEs to cache."""
        try:
            import os
            os.makedirs(os.path.dirname(self.cve_cache_file), exist_ok=True)
            with open(self.cve_cache_file, 'w') as f:
                json.dump({
                    'known_cves': list(self.known_cves),
                    'last_updated': datetime.now().isoformat()
                }, f)
        except Exception as e:
            logger.error(f"Error saving CVE cache: {e}")

    async def check_new_cves(self, days_back: int = 7) -> List[Dict]:
        """
        Check for new CVEs in the last N days.

        Returns: List of new CVE dictionaries
        """
        logger.info(f"Checking for CVEs from last {days_back} days...")

        new_cves = []

        # Check multiple CVE sources
        sources = [
            self._check_nvd_api(days_back),
            self._check_cve_trends(days_back),
            self._check_github_advisories(days_back)
        ]

        results = await asyncio.gather(*sources, return_exceptions=True)

        for result in results:
            if isinstance(result, list):
                new_cves.extend(result)

        # Deduplicate by CVE ID
        seen = set()
        unique_cves = []
        for cve in new_cves:
            cve_id = cve.get('cve_id')
            if cve_id and cve_id not in seen:
                seen.add(cve_id)
                unique_cves.append(cve)

                # Add to known CVEs
                if cve_id not in self.known_cves:
                    self.known_cves.add(cve_id)

        self._save_cache()

        logger.info(f"Found {len(unique_cves)} new/updated CVEs")
        return unique_cves

    async def _check_nvd_api(self, days_back: int) -> List[Dict]:
        """Check NVD API for recent CVEs."""
        try:
            start_date = (datetime.now() - timedelta(days=days_back)).strftime('%Y-%m-%dT00:00:00.000')
            url = f"https://services.nvd.nist.gov/rest/json/cves/2.0"

            params = {
                'pubStartDate': start_date,
                'resultsPerPage': 100
            }

            async with aiohttp.ClientSession() as session:
                async with session.get(url, params=params, timeout=30) as response:
                    if response.status == 200:
                        data = await response.json()

                        cves = []
                        for vuln in data.get('vulnerabilities', []):
                            cve_data = vuln.get('cve', {})

                            cve_id = cve_data.get('id')
                            descriptions = cve_data.get('descriptions', [])
                            description = descriptions[0].get('value', '') if descriptions else ''

                            # Get CVSS score
                            metrics = cve_data.get('metrics', {})
                            cvss_v3 = metrics.get('cvssMetricV31', [{}])[0] if 'cvssMetricV31' in metrics else {}
                            cvss_data = cvss_v3.get('cvssData', {})
                            cvss_score = cvss_data.get('baseScore', 0)
                            severity = cvss_data.get('baseSeverity', 'UNKNOWN')

                            # Only include high/critical
                            if cvss_score >= 7.0:
                                cves.append({
                                    'cve_id': cve_id,
                                    'description': description,
                                    'cvss_score': cvss_score,
                                    'severity': severity,
                                    'published': cve_data.get('published'),
                                    'source': 'NVD'
                                })

                        logger.info(f"Found {len(cves)} high/critical CVEs from NVD")
                        return cves

        except Exception as e:
            logger.error(f"Error checking NVD API: {e}")

        return []

    async def _check_cve_trends(self, days_back: int) -> List[Dict]:
        """Check CVETrends for trending CVEs."""
        try:
            url = "https://cvetrends.com/api/cves/24hrs"

            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=15) as response:
                    if response.status == 200:
                        data = await response.json()

                        cves = []
                        for item in data.get('data', [])[:50]:  # Top 50 trending
                            cves.append({
                                'cve_id': item.get('cve'),
                                'description': item.get('summary', ''),
                                'cvss_score': float(item.get('cvss', 0)),
                                'severity': self._cvss_to_severity(float(item.get('cvss', 0))),
                                'trending': True,
                                'source': 'CVETrends'
                            })

                        logger.info(f"Found {len(cves)} trending CVEs")
                        return cves

        except Exception as e:
            logger.debug(f"Error checking CVETrends: {e}")

        return []

    async def _check_github_advisories(self, days_back: int) -> List[Dict]:
        """Check GitHub Security Advisories."""
        try:
            url = "https://api.github.com/advisories"

            params = {
                'per_page': 50,
                'sort': 'published',
                'direction': 'desc'
            }

            headers = {'Accept': 'application/vnd.github+json'}

            async with aiohttp.ClientSession() as session:
                async with session.get(url, params=params, headers=headers, timeout=15) as response:
                    if response.status == 200:
                        data = await response.json()

                        cves = []
                        for advisory in data:
                            cve_id = advisory.get('cve_id')
                            if not cve_id:
                                continue

                            severity = advisory.get('severity', 'unknown').upper()
                            if severity in ['HIGH', 'CRITICAL']:
                                cves.append({
                                    'cve_id': cve_id,
                                    'description': advisory.get('summary', ''),
                                    'cvss_score': self._severity_to_cvss(severity),
                                    'severity': severity,
                                    'published': advisory.get('published_at'),
                                    'source': 'GitHub'
                                })

                        logger.info(f"Found {len(cves)} CVEs from GitHub Advisories")
                        return cves

        except Exception as e:
            logger.debug(f"Error checking GitHub Advisories: {e}")

        return []

    def _cvss_to_severity(self, score: float) -> str:
        """Convert CVSS score to severity."""
        if score >= 9.0:
            return 'CRITICAL'
        elif score >= 7.0:
            return 'HIGH'
        elif score >= 4.0:
            return 'MEDIUM'
        else:
            return 'LOW'

    def _severity_to_cvss(self, severity: str) -> float:
        """Convert severity to approximate CVSS score."""
        severity_map = {
            'CRITICAL': 9.5,
            'HIGH': 8.0,
            'MEDIUM': 6.0,
            'LOW': 3.0
        }
        return severity_map.get(severity.upper(), 5.0)

    async def match_cves_to_targets(self, cves: List[Dict], assets: List[Dict]) -> List[Dict]:
        """
        Match CVEs to discovered assets based on technology.

        Returns: List of potential matches with asset and CVE info
        """
        matches = []

        for cve in cves:
            cve_desc = cve.get('description', '').lower()
            cve_id = cve.get('cve_id', '')

            # Find which technology this CVE affects
            affected_tech = []
            for tech, keywords in self.tech_keywords.items():
                for keyword in keywords:
                    if keyword in cve_desc:
                        affected_tech.append(tech)
                        break

            if not affected_tech:
                continue

            # Match against assets with those technologies
            for asset in assets:
                asset_tech = asset.get('technologies', [])
                if isinstance(asset_tech, str):
                    asset_tech = [asset_tech]

                for tech in affected_tech:
                    for asset_t in asset_tech:
                        if tech in asset_t.lower():
                            matches.append({
                                'cve': cve,
                                'asset': asset,
                                'technology': tech,
                                'match_confidence': 'high'
                            })
                            break

        logger.info(f"Matched {len(matches)} CVEs to assets")
        return matches

    async def auto_exploit_cve(self, match: Dict) -> Optional[Dict]:
        """
        Automatically attempt to exploit a CVE on a target.

        Returns: Vulnerability dict if successful, None otherwise
        """
        cve = match.get('cve', {})
        asset = match.get('asset', {})

        cve_id = cve.get('cve_id')
        url = asset.get('url') or f"https://{asset.get('hostname')}"

        logger.info(f"Attempting auto-exploit of {cve_id} on {url}")

        # Try to find public exploits
        exploits = await self._find_public_exploits(cve_id)

        if not exploits:
            logger.info(f"No public exploits found for {cve_id}")
            return None

        # Try each exploit
        for exploit in exploits[:3]:  # Try top 3
            result = await self._test_exploit(exploit, url, asset)

            if result and result.get('vulnerable'):
                logger.info(f"✅ CONFIRMED: {url} is vulnerable to {cve_id}")

                return {
                    'name': f"{cve_id} - {cve.get('description', '')[:100]}",
                    'severity': cve.get('severity', 'HIGH').lower(),
                    'category': 'cve_exploitation',
                    'url': url,
                    'description': cve.get('description', ''),
                    'proof_of_concept': result.get('proof'),
                    'cvss_score': cve.get('cvss_score'),
                    'cve_id': cve_id,
                    'technology': match.get('technology'),
                    'exploit_source': exploit.get('source'),
                    'auto_discovered': True
                }

        logger.info(f"No successful exploits for {cve_id} on {url}")
        return None

    async def _find_public_exploits(self, cve_id: str) -> List[Dict]:
        """Find public exploits for a CVE."""
        exploits = []

        # Check Exploit-DB
        try:
            url = f"https://www.exploit-db.com/search?cve={cve_id}"

            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=10) as response:
                    if response.status == 200:
                        text = await response.text()

                        # Parse exploit links (simplified)
                        pattern = r'/exploits/(\d+)'
                        matches = re.findall(pattern, text)

                        for exploit_id in matches[:5]:
                            exploits.append({
                                'source': 'exploit-db',
                                'id': exploit_id,
                                'url': f'https://www.exploit-db.com/exploits/{exploit_id}'
                            })

        except Exception as e:
            logger.debug(f"Error checking Exploit-DB: {e}")

        # Check GitHub for PoCs
        try:
            search_url = f"https://api.github.com/search/repositories?q={cve_id}+poc&sort=stars"

            headers = {'Accept': 'application/vnd.github+json'}

            async with aiohttp.ClientSession() as session:
                async with session.get(search_url, headers=headers, timeout=10) as response:
                    if response.status == 200:
                        data = await response.json()

                        for repo in data.get('items', [])[:3]:
                            exploits.append({
                                'source': 'github',
                                'id': repo.get('full_name'),
                                'url': repo.get('html_url'),
                                'stars': repo.get('stargazers_count', 0)
                            })

        except Exception as e:
            logger.debug(f"Error checking GitHub: {e}")

        logger.info(f"Found {len(exploits)} potential exploits for {cve_id}")
        return exploits

    async def _test_exploit(self, exploit: Dict, target_url: str, asset: Dict) -> Optional[Dict]:
        """Test an exploit against a target."""
        # This is a simplified version - real implementation would:
        # 1. Download exploit code
        # 2. Run it safely in sandbox
        # 3. Verify vulnerability

        # For now, just check if version is vulnerable
        try:
            # Simple version detection (example)
            async with aiohttp.ClientSession() as session:
                async with session.get(target_url, timeout=10) as response:
                    headers = response.headers
                    server = headers.get('Server', '')

                    # Check if vulnerable version
                    # This would need real exploit logic
                    logger.debug(f"Tested exploit on {target_url}, server: {server}")

                    # Placeholder - would implement real exploit testing
                    return None

        except Exception as e:
            logger.debug(f"Exploit test error: {e}")

        return None

    async def generate_cve_report(self, vulnerability: Dict) -> str:
        """Generate report for CVE-based vulnerability."""
        cve_id = vulnerability.get('cve_id')

        report = f"""
# {cve_id} Detected

## Summary
A known CVE ({cve_id}) was detected on your infrastructure.

## Details
- **URL**: {vulnerability.get('url')}
- **CVE ID**: {cve_id}
- **CVSS Score**: {vulnerability.get('cvss_score')}
- **Severity**: {vulnerability.get('severity').upper()}
- **Technology**: {vulnerability.get('technology')}

## Description
{vulnerability.get('description')}

## Proof of Concept
{vulnerability.get('proof_of_concept')}

## Impact
This vulnerability could allow an attacker to:
- Gain unauthorized access
- Execute arbitrary code
- Exfiltrate sensitive data
- Disrupt service availability

## Remediation
1. Update {vulnerability.get('technology')} to the latest patched version
2. Implement WAF rules to block known exploit patterns
3. Monitor logs for exploitation attempts
4. Review security advisories for additional context

## References
- https://nvd.nist.gov/vuln/detail/{cve_id}
- {vulnerability.get('exploit_source', 'N/A')}

**This vulnerability was automatically discovered by our CVE monitoring system.**
"""

        return report
