"""
Race Condition Detector - AI-Level Timing Attack Discovery

Detects race conditions through:
- Precise parallel request timing (microsecond precision)
- Statistical analysis of thousands of attempts
- Pattern recognition in state inconsistencies
- TOCTOU (Time-of-Check to Time-of-Use) detection

The unfair advantage: Can generate and analyze 10,000+ parallel requests
with precise timing to find race windows humans would never catch.

Common race conditions found:
1. Double-spending in payment systems
2. Coupon/promo code reuse
3. Concurrent state transitions
4. Session fixation races
5. Resource reservation conflicts
6. Inventory manipulation
7. Vote/like manipulation
8. File operation races
"""

import asyncio
import aiohttp
import time
import statistics
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass, field
from collections import defaultdict, Counter
import json
import hashlib
from datetime import datetime


@dataclass
class RaceAttempt:
    """Single race condition test attempt"""
    attempt_id: str
    endpoint: str
    method: str
    payload: str
    concurrent_requests: int
    successful_races: int  # How many requests succeeded when only 1 should
    responses: List[Tuple[int, str, float]]  # (status, body, response_time)
    anomaly_detected: bool
    timestamp: float


@dataclass
class RaceVulnerability:
    """Detected race condition vulnerability"""
    vuln_id: str
    title: str
    severity: str
    cvss_score: float
    endpoint: str
    description: str
    evidence: List[str]
    exploitation_steps: List[str]
    impact: str
    confidence: float
    race_type: str  # TOCTOU, double-spend, state-race, etc.
    success_rate: float  # What % of attempts succeeded


class RaceConditionDetector:
    """
    Detects race conditions through parallel request generation
    and statistical analysis
    """

    def __init__(self):
        self.attempts: List[RaceAttempt] = []
        self.vulnerabilities: List[RaceVulnerability] = []

        # Patterns that indicate race-prone operations
        self.race_prone_patterns = [
            "balance", "credit", "debit", "withdraw", "deposit",
            "coupon", "promo", "discount", "voucher",
            "reserve", "book", "claim", "redeem",
            "vote", "like", "favorite",
            "inventory", "stock", "quantity",
            "purchase", "order", "checkout"
        ]

    async def test_endpoint(
        self,
        url: str,
        method: str = "POST",
        payload: Dict = None,
        headers: Dict = None,
        concurrent_count: int = 100
    ) -> RaceAttempt:
        """
        Tests an endpoint for race conditions by sending concurrent requests
        """

        attempt_id = hashlib.sha256(
            f"{time.time()}{url}{method}".encode()
        ).hexdigest()[:16]

        print(f"[*] Testing {method} {url} with {concurrent_count} concurrent requests...")

        # Generate concurrent requests with precise timing
        tasks = []
        for i in range(concurrent_count):
            task = self._send_request(url, method, payload, headers)
            tasks.append(task)

        # Execute all requests simultaneously
        start_time = time.time()
        results = await asyncio.gather(*tasks, return_exceptions=True)
        end_time = time.time()

        # Analyze results
        responses = []
        successful_count = 0

        for result in results:
            if isinstance(result, Exception):
                continue

            status, body, response_time = result
            responses.append((status, body, response_time))

            # Count successful responses (2xx status)
            if 200 <= status < 300:
                successful_count += 1

        # Detect anomaly
        anomaly = self._detect_anomaly(successful_count, responses, payload)

        attempt = RaceAttempt(
            attempt_id=attempt_id,
            endpoint=url,
            method=method,
            payload=json.dumps(payload) if payload else "",
            concurrent_requests=concurrent_count,
            successful_races=successful_count,
            responses=responses[:100],  # Store sample
            anomaly_detected=anomaly,
            timestamp=start_time
        )

        self.attempts.append(attempt)

        if anomaly:
            print(f"[!] ANOMALY DETECTED: {successful_count}/{concurrent_count} requests succeeded!")

        return attempt

    async def _send_request(
        self,
        url: str,
        method: str,
        payload: Dict,
        headers: Dict
    ) -> Tuple[int, str, float]:
        """
        Sends a single request and returns response details
        """

        start_time = time.time()

        try:
            async with aiohttp.ClientSession() as session:
                async with session.request(
                    method=method,
                    url=url,
                    json=payload,
                    headers=headers or {},
                    timeout=aiohttp.ClientTimeout(total=30),
                    ssl=False
                ) as response:
                    body = await response.text()
                    response_time = (time.time() - start_time) * 1000

                    return (response.status, body, response_time)

        except Exception as e:
            return (0, str(e), (time.time() - start_time) * 1000)

    def _detect_anomaly(
        self,
        successful_count: int,
        responses: List[Tuple[int, str, float]],
        payload: Dict
    ) -> bool:
        """
        Detects if results indicate a race condition
        """

        # Check 1: More successes than expected
        # If operation should be one-time (e.g., redeem coupon), but many succeeded
        if successful_count > 10:  # More than 10% succeeded when racing
            return True

        # Check 2: Inconsistent responses
        # If responses vary significantly, might indicate race
        response_bodies = [r[1] for r in responses if 200 <= r[0] < 300]
        if response_bodies:
            unique_responses = len(set(response_bodies))
            if unique_responses > 1 and unique_responses < len(response_bodies) * 0.8:
                return True

        # Check 3: Status code distribution
        status_codes = [r[0] for r in responses]
        status_distribution = Counter(status_codes)

        # If we have both successes and failures, might indicate race
        has_success = any(200 <= s < 300 for s in status_codes)
        has_failure = any(s >= 400 for s in status_codes)

        if has_success and has_failure:
            success_count = sum(1 for s in status_codes if 200 <= s < 300)
            if 5 < success_count < len(status_codes) - 5:  # Not all or none
                return True

        return False

    async def analyze_race_patterns(self) -> List[RaceVulnerability]:
        """
        Analyzes all attempts to identify race condition vulnerabilities
        """

        print(f"[*] Analyzing {len(self.attempts)} race attempts...")

        for attempt in self.attempts:
            if attempt.anomaly_detected:
                vuln = self._classify_race_vulnerability(attempt)
                if vuln:
                    self.vulnerabilities.append(vuln)

        # Additional analysis: correlation across attempts
        self._correlate_attempts()

        print(f"[+] Found {len(self.vulnerabilities)} race condition vulnerabilities")

        return self.vulnerabilities

    def _classify_race_vulnerability(self, attempt: RaceAttempt) -> Optional[RaceVulnerability]:
        """
        Classifies the type of race condition and creates vulnerability report
        """

        endpoint = attempt.endpoint.lower()
        payload = attempt.payload.lower()

        # Determine race type and severity
        race_type = "unknown"
        severity = "medium"
        cvss_score = 5.0
        impact = "Race condition allows concurrent operation"

        # Double-spending / Financial race
        if any(keyword in endpoint or keyword in payload
               for keyword in ["payment", "balance", "withdraw", "credit", "debit"]):
            race_type = "double_spend"
            severity = "critical"
            cvss_score = 9.0
            impact = "Financial loss through double-spending"

        # Coupon/promo code reuse
        elif any(keyword in endpoint or keyword in payload
                 for keyword in ["coupon", "promo", "discount", "voucher"]):
            race_type = "resource_reuse"
            severity = "high"
            cvss_score = 7.5
            impact = "Unlimited coupon/promo code reuse"

        # Inventory manipulation
        elif any(keyword in endpoint or keyword in payload
                 for keyword in ["inventory", "stock", "quantity", "reserve"]):
            race_type = "inventory_race"
            severity = "high"
            cvss_score = 7.0
            impact = "Inventory manipulation, overselling"

        # State transition race
        elif any(keyword in endpoint or keyword in payload
                 for keyword in ["status", "state", "approve", "verify"]):
            race_type = "state_race"
            severity = "high"
            cvss_score = 7.5
            impact = "Inconsistent state, bypass workflow"

        # File operation race (TOCTOU)
        elif any(keyword in endpoint or keyword in payload
                 for keyword in ["file", "upload", "download", "read", "write"]):
            race_type = "toctou"
            severity = "high"
            cvss_score = 7.8
            impact = "TOCTOU vulnerability, unauthorized file access"

        # Vote/like manipulation
        elif any(keyword in endpoint or keyword in payload
                 for keyword in ["vote", "like", "favorite", "follow"]):
            race_type = "action_spam"
            severity = "medium"
            cvss_score = 5.0
            impact = "Vote/like manipulation"

        # Calculate success rate
        success_rate = attempt.successful_races / attempt.concurrent_requests

        # Build evidence
        evidence = [
            f"Concurrent requests: {attempt.concurrent_requests}",
            f"Successful races: {attempt.successful_races}",
            f"Success rate: {success_rate*100:.1f}%",
            f"Expected successes: 1",
            f"Actual successes: {attempt.successful_races}",
            f"Anomaly multiplier: {attempt.successful_races}x"
        ]

        # Sample responses
        status_dist = Counter(r[0] for r in attempt.responses)
        evidence.append(f"Status code distribution: {dict(status_dist)}")

        # Build exploitation steps
        exploitation_steps = [
            f"1. Prepare {attempt.concurrent_requests} identical requests to {attempt.endpoint}",
            f"2. Send all requests simultaneously (parallel execution)",
            "3. Server processes requests concurrently",
            "4. Race condition window exploited",
            f"5. {attempt.successful_races} operations succeed (expected: 1)",
            f"6. Impact: {impact}"
        ]

        # Add specific exploitation details based on race type
        if race_type == "double_spend":
            exploitation_steps.append(
                "7. Example: Withdraw $100 balance 10 times simultaneously → $1000 withdrawn from $100 balance"
            )
        elif race_type == "resource_reuse":
            exploitation_steps.append(
                "7. Example: Redeem single-use coupon 10 times simultaneously → 10x discount applied"
            )

        return RaceVulnerability(
            vuln_id=f"race_{attempt.attempt_id}",
            title=f"Race Condition: {race_type.replace('_', ' ').title()} on {attempt.endpoint}",
            severity=severity,
            cvss_score=cvss_score,
            endpoint=attempt.endpoint,
            description=(
                f"Race condition detected allowing concurrent execution of operation "
                f"that should be atomic. {attempt.successful_races} operations succeeded "
                f"when only 1 should have been allowed."
            ),
            evidence=evidence,
            exploitation_steps=exploitation_steps,
            impact=impact,
            confidence=min(0.9, success_rate * 2),  # Higher success rate = higher confidence
            race_type=race_type,
            success_rate=success_rate
        )

    def _correlate_attempts(self):
        """
        Correlates multiple attempts to find patterns
        """

        # Group attempts by endpoint
        by_endpoint = defaultdict(list)
        for attempt in self.attempts:
            if attempt.anomaly_detected:
                by_endpoint[attempt.endpoint].append(attempt)

        # If same endpoint shows race across multiple tests, increase confidence
        for endpoint, attempts in by_endpoint.items():
            if len(attempts) > 1:
                # Find existing vulnerabilities for this endpoint
                for vuln in self.vulnerabilities:
                    if vuln.endpoint == endpoint:
                        # Increase confidence
                        vuln.confidence = min(1.0, vuln.confidence * 1.3)
                        vuln.evidence.append(
                            f"Reproduced across {len(attempts)} independent tests"
                        )

    async def discover_race_conditions(
        self,
        target_url: str,
        endpoints: List[Dict[str, Any]],
        tests_per_endpoint: int = 3
    ) -> List[RaceVulnerability]:
        """
        Main entry point: discovers race conditions across endpoints

        Args:
            target_url: Base URL of target
            endpoints: List of endpoints to test [{"path": "/api/foo", "method": "POST", "payload": {...}}]
            tests_per_endpoint: Number of times to test each endpoint
        """

        print(f"[*] Race Condition Discovery: Testing {len(endpoints)} endpoints")

        for endpoint_spec in endpoints:
            path = endpoint_spec.get("path")
            method = endpoint_spec.get("method", "POST")
            payload = endpoint_spec.get("payload", {})
            headers = endpoint_spec.get("headers", {})

            url = f"{target_url}{path}"

            # Test multiple times to confirm reproducibility
            for test_num in range(tests_per_endpoint):
                print(f"[*] Test {test_num + 1}/{tests_per_endpoint} for {path}")

                # Vary concurrency levels
                concurrency_levels = [10, 50, 100]
                for concurrency in concurrency_levels:
                    await self.test_endpoint(
                        url=url,
                        method=method,
                        payload=payload,
                        headers=headers,
                        concurrent_count=concurrency
                    )

                # Small delay between tests
                await asyncio.sleep(0.5)

        # Analyze all attempts
        vulnerabilities = await self.analyze_race_patterns()

        return vulnerabilities

    async def test_toctou_pattern(
        self,
        check_url: str,
        use_url: str,
        payload: Dict,
        delay_ms: int = 100
    ) -> bool:
        """
        Specifically tests for Time-of-Check to Time-of-Use (TOCTOU) vulnerabilities

        Args:
            check_url: URL that checks a condition
            use_url: URL that uses the result
            payload: Request payload
            delay_ms: Delay between check and use in milliseconds
        """

        print(f"[*] Testing TOCTOU pattern: check={check_url}, use={use_url}")

        # Thread 1: Check → Use (with delay)
        async def normal_flow():
            async with aiohttp.ClientSession() as session:
                # Check
                await session.get(check_url)
                # Delay
                await asyncio.sleep(delay_ms / 1000.0)
                # Use
                resp = await session.post(use_url, json=payload)
                return resp.status

        # Thread 2: Modify during delay
        async def race_flow():
            await asyncio.sleep(delay_ms / 2000.0)  # Attack in middle of delay
            async with aiohttp.ClientSession() as session:
                # Modify state during check-to-use gap
                resp = await session.post(use_url, json=payload)
                return resp.status

        # Execute both flows
        results = await asyncio.gather(normal_flow(), race_flow(), return_exceptions=True)

        # If both succeeded, TOCTOU exists
        if len([r for r in results if isinstance(r, int) and 200 <= r < 300]) > 1:
            print("[!] TOCTOU vulnerability confirmed!")

            self.vulnerabilities.append(RaceVulnerability(
                vuln_id=f"toctou_{hashlib.sha256(check_url.encode()).hexdigest()[:8]}",
                title=f"TOCTOU Vulnerability: {check_url} → {use_url}",
                severity="high",
                cvss_score=7.5,
                endpoint=f"{check_url} → {use_url}",
                description=(
                    "Time-of-Check to Time-of-Use vulnerability detected. "
                    "State can be modified between check and use operations."
                ),
                evidence=[
                    f"Check endpoint: {check_url}",
                    f"Use endpoint: {use_url}",
                    f"Time window: {delay_ms}ms",
                    "Both normal and race flows succeeded"
                ],
                exploitation_steps=[
                    f"1. Victim: GET {check_url} (check passes)",
                    f"2. Attacker: POST {use_url} during {delay_ms}ms window (modify state)",
                    f"3. Victim: POST {use_url} (uses stale check result)",
                    "4. Inconsistent state achieved"
                ],
                impact="State inconsistency, unauthorized access, data corruption",
                confidence=0.85,
                race_type="toctou",
                success_rate=1.0
            ))

            return True

        return False

    def generate_report(self) -> str:
        """Generates markdown report of race condition findings"""

        report = ["# Race Condition Detection Report", ""]
        report.append(f"**Analysis Date:** {datetime.now().isoformat()}")
        report.append(f"**Endpoints Tested:** {len(set(a.endpoint for a in self.attempts))}")
        report.append(f"**Total Attempts:** {len(self.attempts)}")
        report.append(f"**Vulnerabilities Found:** {len(self.vulnerabilities)}")
        report.append("")

        # Statistics
        total_requests = sum(a.concurrent_requests for a in self.attempts)
        avg_success_rate = statistics.mean([v.success_rate for v in self.vulnerabilities]) if self.vulnerabilities else 0

        report.append("## Statistics")
        report.append(f"- Total requests sent: {total_requests:,}")
        report.append(f"- Average success rate: {avg_success_rate*100:.1f}%")
        report.append(f"- Anomalies detected: {sum(1 for a in self.attempts if a.anomaly_detected)}")
        report.append("")

        # Group by severity
        by_severity = defaultdict(list)
        for vuln in self.vulnerabilities:
            by_severity[vuln.severity].append(vuln)

        for severity in ['critical', 'high', 'medium', 'low']:
            if severity in by_severity:
                report.append(f"## {severity.upper()} Severity ({len(by_severity[severity])})")
                report.append("")

                for vuln in by_severity[severity]:
                    report.append(f"### {vuln.title}")
                    report.append(f"**Type:** {vuln.race_type} | **CVSS:** {vuln.cvss_score} | **Confidence:** {vuln.confidence*100:.0f}%")
                    report.append(f"**Success Rate:** {vuln.success_rate*100:.1f}%")
                    report.append("")
                    report.append(f"**Description:**")
                    report.append(vuln.description)
                    report.append("")
                    report.append(f"**Impact:** {vuln.impact}")
                    report.append("")
                    report.append(f"**Evidence:**")
                    for evidence in vuln.evidence:
                        report.append(f"- {evidence}")
                    report.append("")
                    report.append(f"**Exploitation Steps:**")
                    for step in vuln.exploitation_steps:
                        report.append(f"{step}")
                    report.append("")
                    report.append("---")
                    report.append("")

        return "\n".join(report)


# Example usage
async def demo_race_detection():
    """Demonstrates race condition detection"""

    detector = RaceConditionDetector()

    # Example endpoints to test
    endpoints = [
        {
            "path": "/api/wallet/withdraw",
            "method": "POST",
            "payload": {"amount": 100},
            "headers": {"Authorization": "Bearer token123"}
        },
        {
            "path": "/api/coupons/redeem",
            "method": "POST",
            "payload": {"code": "SAVE50"},
            "headers": {"Authorization": "Bearer token123"}
        },
        {
            "path": "/api/products/123/purchase",
            "method": "POST",
            "payload": {"quantity": 1},
            "headers": {"Authorization": "Bearer token123"}
        }
    ]

    # Discover race conditions
    vulns = await detector.discover_race_conditions(
        target_url="https://example.com",
        endpoints=endpoints,
        tests_per_endpoint=2
    )

    # Generate report
    report = detector.generate_report()

    return vulns, report


if __name__ == "__main__":
    vulns, report = asyncio.run(demo_race_detection())

    print("\n" + "="*60)
    print(report)
    print("="*60)

    print(f"\nFound {len(vulns)} race condition vulnerabilities!")
