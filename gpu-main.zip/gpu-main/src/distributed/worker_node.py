"""
Distributed Scanning Architecture - Worker Node

Enables horizontal scaling by distributing work across multiple workers.

Architecture:
- Master node coordinates work
- Worker nodes execute scans
- Results aggregated at master
- Fault tolerance and load balancing

Benefits:
- Scale to 100+ workers
- Geographic distribution
- Bypass rate limits via IP diversity
- Fault tolerance
"""

import asyncio
import logging
import json
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
from datetime import datetime
import aiohttp
from enum import Enum
import socket
import os


class WorkerStatus(Enum):
    """Worker status"""
    IDLE = "idle"
    BUSY = "busy"
    ERROR = "error"
    OFFLINE = "offline"


@dataclass
class WorkTask:
    """A unit of work for a worker"""
    task_id: str
    task_type: str  # scan_endpoint, run_analyzer, etc.
    target_url: str
    analyzer_name: Optional[str] = None
    parameters: Dict[str, Any] = field(default_factory=dict)
    priority: int = 0
    created_at: datetime = field(default_factory=datetime.now)


@dataclass
class WorkResult:
    """Result from a worker"""
    task_id: str
    worker_id: str
    success: bool
    findings: List[Dict[str, Any]] = field(default_factory=list)
    error: Optional[str] = None
    duration_seconds: float = 0.0
    completed_at: datetime = field(default_factory=datetime.now)


class WorkerNode:
    """
    Worker node for distributed scanning

    Receives tasks from master, executes scans, returns results.
    """

    def __init__(
        self,
        worker_id: Optional[str] = None,
        master_url: str = "http://localhost:8080",
        max_concurrent_tasks: int = 5
    ):
        """
        Initialize worker node

        Args:
            worker_id: Unique worker ID (auto-generated if None)
            master_url: URL of master coordinator
            max_concurrent_tasks: Max concurrent tasks
        """
        self.worker_id = worker_id or self._generate_worker_id()
        self.master_url = master_url
        self.max_concurrent_tasks = max_concurrent_tasks

        self.status = WorkerStatus.IDLE
        self.current_tasks: List[WorkTask] = []
        self.completed_tasks = 0
        self.failed_tasks = 0

        self.logger = logging.getLogger(f"worker.{self.worker_id}")
        self.running = False

    def _generate_worker_id(self) -> str:
        """Generate unique worker ID"""
        hostname = socket.gethostname()
        pid = os.getpid()
        return f"worker-{hostname}-{pid}"

    async def start(self):
        """Start worker and register with master"""
        self.logger.info(f"Starting worker {self.worker_id}")
        self.running = True

        # Register with master
        await self._register_with_master()

        # Start work loop
        asyncio.create_task(self._work_loop())

        # Start heartbeat
        asyncio.create_task(self._heartbeat_loop())

    async def stop(self):
        """Stop worker gracefully"""
        self.logger.info(f"Stopping worker {self.worker_id}")
        self.running = False

        # Deregister from master
        await self._deregister_from_master()

    async def _register_with_master(self):
        """Register this worker with the master node"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self.master_url}/api/workers/register",
                    json={
                        'worker_id': self.worker_id,
                        'max_concurrent_tasks': self.max_concurrent_tasks,
                        'capabilities': self._get_capabilities()
                    },
                    timeout=aiohttp.ClientTimeout(total=10)
                ) as response:
                    if response.status == 200:
                        self.logger.info("Successfully registered with master")
                    else:
                        self.logger.error(f"Registration failed: {response.status}")

        except Exception as e:
            self.logger.error(f"Error registering with master: {e}")

    async def _deregister_from_master(self):
        """Deregister from master"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self.master_url}/api/workers/deregister",
                    json={'worker_id': self.worker_id},
                    timeout=aiohttp.ClientTimeout(total=10)
                ) as response:
                    if response.status == 200:
                        self.logger.info("Successfully deregistered from master")

        except Exception as e:
            self.logger.error(f"Error deregistering: {e}")

    async def _heartbeat_loop(self):
        """Send periodic heartbeats to master"""
        while self.running:
            try:
                await self._send_heartbeat()
                await asyncio.sleep(30)  # Every 30 seconds

            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Heartbeat error: {e}")
                await asyncio.sleep(30)

    async def _send_heartbeat(self):
        """Send heartbeat to master"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self.master_url}/api/workers/heartbeat",
                    json={
                        'worker_id': self.worker_id,
                        'status': self.status.value,
                        'current_tasks': len(self.current_tasks),
                        'completed_tasks': self.completed_tasks,
                        'failed_tasks': self.failed_tasks
                    },
                    timeout=aiohttp.ClientTimeout(total=5)
                ) as response:
                    pass  # Just need to send it

        except Exception as e:
            self.logger.error(f"Error sending heartbeat: {e}")

    async def _work_loop(self):
        """Main work loop - fetch and execute tasks"""
        while self.running:
            try:
                # Check if we can take more work
                if len(self.current_tasks) < self.max_concurrent_tasks:
                    # Fetch task from master
                    task = await self._fetch_task()

                    if task:
                        # Execute task in background
                        asyncio.create_task(self._execute_task(task))
                    else:
                        # No work available, wait a bit
                        await asyncio.sleep(5)
                else:
                    # At capacity, wait
                    await asyncio.sleep(1)

            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Work loop error: {e}")
                await asyncio.sleep(5)

    async def _fetch_task(self) -> Optional[WorkTask]:
        """Fetch a task from master"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"{self.master_url}/api/tasks/next",
                    params={'worker_id': self.worker_id},
                    timeout=aiohttp.ClientTimeout(total=10)
                ) as response:
                    if response.status == 200:
                        data = await response.json()

                        task = WorkTask(
                            task_id=data['task_id'],
                            task_type=data['task_type'],
                            target_url=data['target_url'],
                            analyzer_name=data.get('analyzer_name'),
                            parameters=data.get('parameters', {}),
                            priority=data.get('priority', 0)
                        )

                        return task

                    elif response.status == 204:
                        # No tasks available
                        return None

        except Exception as e:
            self.logger.error(f"Error fetching task: {e}")

        return None

    async def _execute_task(self, task: WorkTask):
        """
        Execute a task

        Args:
            task: Task to execute
        """
        self.current_tasks.append(task)
        self.status = WorkerStatus.BUSY

        self.logger.info(f"Executing task {task.task_id}: {task.task_type} on {task.target_url}")

        start_time = asyncio.get_event_loop().time()
        findings = []
        error = None
        success = True

        try:
            # Execute based on task type
            if task.task_type == 'scan_endpoint':
                findings = await self._scan_endpoint(task)

            elif task.task_type == 'run_analyzer':
                findings = await self._run_analyzer(task)

            else:
                raise ValueError(f"Unknown task type: {task.task_type}")

        except Exception as e:
            self.logger.error(f"Task {task.task_id} failed: {e}", exc_info=True)
            error = str(e)
            success = False
            self.failed_tasks += 1

        else:
            self.completed_tasks += 1

        finally:
            duration = asyncio.get_event_loop().time() - start_time

            # Create result
            result = WorkResult(
                task_id=task.task_id,
                worker_id=self.worker_id,
                success=success,
                findings=findings,
                error=error,
                duration_seconds=duration
            )

            # Send result to master
            await self._send_result(result)

            # Remove from current tasks
            self.current_tasks.remove(task)

            if not self.current_tasks:
                self.status = WorkerStatus.IDLE

    async def _scan_endpoint(self, task: WorkTask) -> List[Dict[str, Any]]:
        """
        Scan an endpoint

        Args:
            task: Task details

        Returns:
            List of findings
        """
        # Placeholder - would integrate with actual analyzers
        findings = []

        # Simulated scan
        await asyncio.sleep(1)

        return findings

    async def _run_analyzer(self, task: WorkTask) -> List[Dict[str, Any]]:
        """
        Run specific analyzer

        Args:
            task: Task details

        Returns:
            List of findings
        """
        # Placeholder - would integrate with actual analyzers
        findings = []

        # Simulated analyzer run
        await asyncio.sleep(2)

        return findings

    async def _send_result(self, result: WorkResult):
        """
        Send result back to master

        Args:
            result: Work result
        """
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self.master_url}/api/tasks/result",
                    json={
                        'task_id': result.task_id,
                        'worker_id': result.worker_id,
                        'success': result.success,
                        'findings': result.findings,
                        'error': result.error,
                        'duration_seconds': result.duration_seconds
                    },
                    timeout=aiohttp.ClientTimeout(total=30)
                ) as response:
                    if response.status == 200:
                        self.logger.info(f"Result for task {result.task_id} sent successfully")
                    else:
                        self.logger.error(f"Failed to send result: {response.status}")

        except Exception as e:
            self.logger.error(f"Error sending result: {e}")

    def _get_capabilities(self) -> Dict[str, Any]:
        """Get worker capabilities"""
        return {
            'analyzers': [
                'deep_correlation',
                'business_logic',
                'chain_discovery',
                'race_condition',
                'semantic_analysis',
                'transformation',
                'permission',
                'temporal',
                'crypto',
                'pattern_learning'
            ],
            'max_concurrent_tasks': self.max_concurrent_tasks,
            'platform': os.name,
            'hostname': socket.gethostname()
        }

    def get_stats(self) -> Dict[str, Any]:
        """Get worker statistics"""
        return {
            'worker_id': self.worker_id,
            'status': self.status.value,
            'current_tasks': len(self.current_tasks),
            'completed_tasks': self.completed_tasks,
            'failed_tasks': self.failed_tasks,
            'success_rate': (
                self.completed_tasks / (self.completed_tasks + self.failed_tasks)
                if (self.completed_tasks + self.failed_tasks) > 0 else 0.0
            )
        }


async def main():
    """Main entry point for worker node"""
    import argparse

    parser = argparse.ArgumentParser(description='Distributed Worker Node')
    parser.add_argument('--master', default='http://localhost:8080', help='Master node URL')
    parser.add_argument('--workers', type=int, default=5, help='Max concurrent tasks')
    parser.add_argument('--worker-id', help='Worker ID (auto-generated if not provided)')

    args = parser.parse_args()

    # Create and start worker
    worker = WorkerNode(
        worker_id=args.worker_id,
        master_url=args.master,
        max_concurrent_tasks=args.workers
    )

    try:
        await worker.start()

        # Run until interrupted
        while worker.running:
            await asyncio.sleep(1)

    except KeyboardInterrupt:
        logging.info("Shutting down...")

    finally:
        await worker.stop()


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    asyncio.run(main())
