"""
Red Hat Bug Bounty Automation System
A comprehensive automated security research platform for Red Hat bug bounty programs.
"""

__version__ = "1.0.0"
__author__ = "Automated Bug Bounty Hunter"
