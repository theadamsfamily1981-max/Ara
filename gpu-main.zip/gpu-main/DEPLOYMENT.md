# Production Deployment Guide

This guide covers deploying the Bug Bounty Automation System to production with optimal configuration for security, performance, and reliability.

---

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [System Requirements](#system-requirements)
3. [Installation](#installation)
4. [Configuration](#configuration)
5. [Deployment Options](#deployment-options)
6. [Security Hardening](#security-hardening)
7. [Performance Tuning](#performance-tuning)
8. [Monitoring](#monitoring)
9. [Backup and Recovery](#backup-and-recovery)
10. [Troubleshooting](#troubleshooting)

---

## Prerequisites

### Required

- **Operating System**: Ubuntu 20.04+ / CentOS 8+ / RHEL 8+
- **Python**: 3.10 or higher
- **RAM**: Minimum 8GB (16GB+ recommended)
- **CPU**: 4+ cores recommended
- **Disk**: 50GB+ free space
- **Network**: Stable internet connection

### Optional but Recommended

- **Redis**: For distributed caching (6.0+)
- **PostgreSQL**: For persistent storage (12+)
- **Docker**: For containerized deployment (20.10+)
- **Nginx**: For reverse proxy and load balancing
- **Prometheus**: For metrics collection
- **Grafana**: For visualization

---

## System Requirements

### Minimum Requirements

```
CPU: 2 cores
RAM: 8GB
Disk: 20GB SSD
Network: 100 Mbps
```

### Recommended Production Requirements

```
CPU: 8+ cores
RAM: 32GB
Disk: 100GB+ NVMe SSD
Network: 1 Gbps
```

### Performance Scaling

- **Small deployment** (1-5 concurrent targets): 4 cores, 16GB RAM
- **Medium deployment** (5-20 targets): 8 cores, 32GB RAM
- **Large deployment** (20+ targets): 16+ cores, 64GB+ RAM

---

## Installation

### Option 1: Standard Installation

```bash
# Clone repository
git clone https://github.com/yourusername/bug-bounty-automation.git
cd bug-bounty-automation

# Run production installer
chmod +x install.sh
./install.sh --environment production

# Activate environment
source venv/bin/activate

# Verify installation
python -c "import sys; print(sys.version)"
python -m pip list | grep -E "aiohttp|uvloop|orjson"
```

### Option 2: Docker Deployment

```bash
# Build production image
docker-compose -f docker-compose.prod.yml build

# Start services
docker-compose -f docker-compose.prod.yml up -d

# Check status
docker-compose -f docker-compose.prod.yml ps
```

### Option 3: Kubernetes Deployment

```bash
# Apply configurations
kubectl apply -f k8s/namespace.yaml
kubectl apply -f k8s/configmap.yaml
kubectl apply -f k8s/secrets.yaml
kubectl apply -f k8s/deployment.yaml
kubectl apply -f k8s/service.yaml

# Check status
kubectl get pods -n bounty-hunter
```

---

## Configuration

### Environment Variables

Create `.env` file in project root:

```bash
# Environment
ANALYZER_ENV=production

# Configuration File
ANALYZER_CONFIG_FILE=config/production.yaml

# Redis
REDIS_ENABLED=true
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=your_redis_password_here
REDIS_SSL=false

# SSL
SSL_VERIFY=true

# Rate Limiting
RATE_LIMIT_REQUESTS=1000
RATE_LIMIT_WINDOW_SECONDS=3600

# Logging
LOG_LEVEL=WARNING
LOG_TO_FILE=true

# Security
SANITIZE_LOGS=true
ENCRYPT_STORAGE=true
AUDIT_LOG_ENABLED=true

# Database (if using persistent storage)
DATABASE_URL=postgresql://user:pass@localhost/bounty_db

# API Keys (for bug bounty platforms)
BUGCROWD_API_KEY=your_key_here
HACKERONE_API_KEY=your_key_here
```

### Configuration File

Edit `config/production.yaml`:

```yaml
# See config/production.yaml for full configuration
# Key settings to review:

max_concurrent_connections: 100  # Adjust based on system resources
rate_limit_requests: 1000        # Adjust based on target policies
ssl_verify: true                 # NEVER set to false in production
redis_enabled: true              # Enable for distributed caching
log_level: WARNING               # Less verbose in production
```

### Security Configuration

**CRITICAL**: Review these security settings:

```yaml
# config/production.yaml

# SSL Verification - ALWAYS TRUE in production
ssl_verify: true

# Data Security
sanitize_logs: true      # Remove sensitive data from logs
encrypt_storage: true    # Encrypt stored credentials/tokens
audit_log_enabled: true  # Track all security-relevant actions

# Rate Limiting
rate_limit_requests: 1000  # Prevent IP bans
```

---

## Deployment Options

### Option A: Standalone Server

#### 1. Install System Service

```bash
sudo cp deploy/bounty-hunter.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable bounty-hunter
sudo systemctl start bounty-hunter
```

#### 2. Verify Service

```bash
sudo systemctl status bounty-hunter
sudo journalctl -u bounty-hunter -f
```

### Option B: Docker Compose

#### 1. Production Docker Compose

```yaml
# docker-compose.prod.yml
version: '3.8'

services:
  bounty-hunter:
    build:
      context: .
      dockerfile: Dockerfile
      args:
        ENVIRONMENT: production
    environment:
      - ANALYZER_ENV=production
      - REDIS_ENABLED=true
      - REDIS_HOST=redis
    ports:
      - "5000:5000"
    volumes:
      - ./data:/app/data
      - ./logs:/app/logs
      - ./config:/app/config:ro
    depends_on:
      - redis
      - postgresql
    restart: unless-stopped
    deploy:
      resources:
        limits:
          cpus: '4'
          memory: 16G

  redis:
    image: redis:7-alpine
    command: redis-server --requirepass ${REDIS_PASSWORD}
    volumes:
      - redis_data:/data
    restart: unless-stopped

  postgresql:
    image: postgres:15-alpine
    environment:
      - POSTGRES_PASSWORD=${DB_PASSWORD}
      - POSTGRES_DB=bounty_db
    volumes:
      - postgres_data:/var/lib/postgresql/data
    restart: unless-stopped

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf:ro
      - ./nginx/ssl:/etc/nginx/ssl:ro
    depends_on:
      - bounty-hunter
    restart: unless-stopped

volumes:
  redis_data:
  postgres_data:
```

#### 2. Deploy

```bash
docker-compose -f docker-compose.prod.yml up -d
docker-compose -f docker-compose.prod.yml logs -f
```

### Option C: Kubernetes

#### 1. Deploy with Helm

```bash
helm install bounty-hunter ./helm-chart \
  --namespace bounty-hunter \
  --create-namespace \
  --values helm-chart/values-production.yaml
```

#### 2. Scale Deployment

```bash
kubectl scale deployment bounty-hunter \
  --replicas=5 \
  -n bounty-hunter
```

---

## Security Hardening

### 1. SSL/TLS Configuration

```bash
# Generate SSL certificates (or use Let's Encrypt)
openssl req -x509 -nodes -days 365 -newkey rsa:4096 \
  -keyout nginx/ssl/server.key \
  -out nginx/ssl/server.crt
```

### 2. Firewall Configuration

```bash
# Allow only necessary ports
sudo ufw enable
sudo ufw allow 22/tcp    # SSH
sudo ufw allow 80/tcp    # HTTP
sudo ufw allow 443/tcp   # HTTPS
sudo ufw deny 5000/tcp   # Block direct access to app
```

### 3. User Permissions

```bash
# Run as non-root user
sudo useradd -r -s /bin/false bounty-hunter
sudo chown -R bounty-hunter:bounty-hunter /opt/bounty-hunter
```

### 4. Environment Variables

```bash
# Never commit .env file
echo ".env" >> .gitignore

# Set restrictive permissions
chmod 600 .env
```

### 5. API Key Management

```bash
# Use a secrets manager (recommended)
# - AWS Secrets Manager
# - HashiCorp Vault
# - Azure Key Vault

# Or encrypted environment variables
# Install SOPS
curl -LO https://github.com/mozilla/sops/releases/download/v3.7.3/sops-v3.7.3.linux
chmod +x sops-v3.7.3.linux
sudo mv sops-v3.7.3.linux /usr/local/bin/sops

# Encrypt secrets
sops -e secrets.yaml > secrets.enc.yaml
```

---

## Performance Tuning

### 1. Install Performance Dependencies

```bash
pip install -r requirements-optimized.txt
```

This includes:
- **uvloop**: 2-4x faster async event loop
- **orjson**: 5-10x faster JSON parsing
- **aiodns**: Faster DNS resolution
- **cchardet**: Faster charset detection

### 2. System Tuning

```bash
# Increase file descriptor limits
echo "* soft nofile 65536" | sudo tee -a /etc/security/limits.conf
echo "* hard nofile 65536" | sudo tee -a /etc/security/limits.conf

# Increase network buffer sizes
sudo sysctl -w net.core.rmem_max=134217728
sudo sysctl -w net.core.wmem_max=134217728
sudo sysctl -w net.ipv4.tcp_rmem='4096 87380 67108864'
sudo sysctl -w net.ipv4.tcp_wmem='4096 65536 67108864'

# Make permanent
sudo tee -a /etc/sysctl.conf <<EOF
net.core.rmem_max=134217728
net.core.wmem_max=134217728
net.ipv4.tcp_rmem=4096 87380 67108864
net.ipv4.tcp_wmem=4096 65536 67108864
EOF
```

### 3. Redis Tuning

```bash
# Edit /etc/redis/redis.conf
maxmemory 4gb
maxmemory-policy allkeys-lru
tcp-backlog 511
timeout 0
tcp-keepalive 300
```

### 4. Application Configuration

```yaml
# config/production.yaml

# Optimize connection pooling
max_concurrent_connections: 200  # Increase if you have resources
max_connections_per_host: 50

# Enable performance features
use_uvloop: true
use_orjson: true

# Caching
cache_enabled: true
redis_enabled: true
cache_max_size: 50000  # Increase cache size
```

---

## Monitoring

### 1. Application Metrics

The system exposes metrics at `/metrics` endpoint:

```bash
curl http://localhost:5000/metrics
```

### 2. Prometheus Configuration

```yaml
# prometheus.yml
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'bounty-hunter'
    static_configs:
      - targets: ['localhost:5000']
```

### 3. Grafana Dashboards

Import the provided dashboard:

```bash
# grafana/dashboards/bounty-hunter.json
```

### 4. Health Checks

```bash
# Application health
curl http://localhost:5000/health

# Expected response:
# {"status": "healthy", "analyzers": 10, "uptime": 3600}
```

### 5. Log Monitoring

```bash
# Tail logs
tail -f logs/analyzer.log

# Search for errors
grep ERROR logs/analyzer.log

# Monitor with lnav
lnav logs/analyzer.log
```

---

## Backup and Recovery

### 1. Database Backup

```bash
#!/bin/bash
# backup.sh

DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/backup"

# Backup PostgreSQL
pg_dump bounty_db | gzip > $BACKUP_DIR/db_$DATE.sql.gz

# Backup Redis
redis-cli --rdb $BACKUP_DIR/redis_$DATE.rdb

# Backup knowledge base
tar -czf $BACKUP_DIR/knowledge_$DATE.tar.gz data/knowledge_base/

# Retain last 30 days
find $BACKUP_DIR -name "*.gz" -mtime +30 -delete
```

### 2. Automated Backups

```bash
# Add to crontab
crontab -e

# Daily backup at 2 AM
0 2 * * * /opt/bounty-hunter/backup.sh
```

### 3. Recovery

```bash
# Restore database
gunzip < db_20231120_020000.sql.gz | psql bounty_db

# Restore Redis
redis-cli --rdb redis_20231120_020000.rdb

# Restore knowledge base
tar -xzf knowledge_20231120_020000.tar.gz -C data/
```

---

## Troubleshooting

### Common Issues

#### 1. High Memory Usage

```bash
# Check memory
free -h

# Reduce connection pool size
# Edit config/production.yaml
max_concurrent_connections: 50  # Reduce from 100
```

#### 2. Connection Timeouts

```bash
# Increase timeouts
# Edit config/production.yaml
request_timeout_seconds: 60  # Increase from 30
```

#### 3. Rate Limiting Issues

```bash
# Check rate limiter stats
curl http://localhost:5000/api/stats

# Adjust rate limits
# Edit config/production.yaml
rate_limit_requests: 500  # Reduce if getting banned
```

#### 4. Redis Connection Errors

```bash
# Check Redis status
redis-cli ping

# Check Redis logs
tail -f /var/log/redis/redis-server.log

# Test connection
redis-cli -h localhost -p 6379 -a your_password ping
```

#### 5. SSL Certificate Errors

```bash
# Verify certificate
openssl s_client -connect target.com:443

# If self-signed cert needed for testing only
# Edit config/development.yaml (NEVER production!)
ssl_verify: false
```

### Performance Debugging

```bash
# Profile application
python -m cProfile -o profile.stats main.py

# View profile
python -c "import pstats; p = pstats.Stats('profile.stats'); p.sort_stats('cumulative'); p.print_stats(20)"

# Memory profiling
python -m memory_profiler main.py
```

### Log Analysis

```bash
# Error summary
grep ERROR logs/analyzer.log | sort | uniq -c | sort -rn

# Request statistics
grep "duration_ms" logs/analyzer.log | awk '{print $NF}' | \
  awk '{sum+=$1; count++} END {print "Avg:", sum/count, "Count:", count}'
```

---

## Production Checklist

Before going live:

### Configuration
- [ ] SSL verification enabled (`ssl_verify: true`)
- [ ] Secure passwords set for Redis/PostgreSQL
- [ ] Rate limiting configured appropriately
- [ ] Log sanitization enabled
- [ ] Storage encryption enabled
- [ ] Audit logging enabled

### Security
- [ ] Firewall rules configured
- [ ] Running as non-root user
- [ ] SSL/TLS certificates installed
- [ ] Environment variables secured
- [ ] API keys stored securely
- [ ] Sensitive data not in logs

### Performance
- [ ] Performance dependencies installed (uvloop, orjson)
- [ ] System limits increased (file descriptors, network buffers)
- [ ] Redis configured and running
- [ ] Connection pooling optimized
- [ ] Caching enabled

### Monitoring
- [ ] Prometheus exporter configured
- [ ] Grafana dashboards imported
- [ ] Health checks working
- [ ] Log rotation configured
- [ ] Alerting rules set up

### Backup
- [ ] Automated backup script created
- [ ] Backup cron job scheduled
- [ ] Recovery procedure tested
- [ ] Backup retention policy set

### Testing
- [ ] All unit tests passing
- [ ] Integration tests completed
- [ ] Load testing performed
- [ ] Failover tested
- [ ] Recovery tested

---

## Support

For issues and support:

- **GitHub Issues**: https://github.com/yourusername/bug-bounty-automation/issues
- **Documentation**: https://docs.yoursite.com
- **Community**: https://discord.gg/yourserver

---

## License

This system is for authorized security testing only. Ensure you have proper authorization before testing any systems.
