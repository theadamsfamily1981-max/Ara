"""
Unit tests for Cache Manager

Tests LRU cache, Redis cache, and multi-tier caching.
"""

import pytest
import asyncio
import time

import sys
sys.path.insert(0, '/home/user/gpu/src')

from core.cache_manager import LRUCache, CacheManager, CacheEntry


@pytest.mark.asyncio
async def test_lru_cache_basic():
    """Test basic LRU cache operations"""
    cache = LRUCache(max_size=10)

    # Set and get
    await cache.set('key1', 'value1')
    value = await cache.get('key1')

    assert value == 'value1'
    assert cache.hits == 1
    assert cache.misses == 0


@pytest.mark.asyncio
async def test_lru_cache_miss():
    """Test cache miss"""
    cache = LRUCache(max_size=10)

    value = await cache.get('nonexistent')

    assert value is None
    assert cache.hits == 0
    assert cache.misses == 1


@pytest.mark.asyncio
async def test_lru_cache_eviction():
    """Test LRU eviction"""
    cache = LRUCache(max_size=3)

    # Fill cache
    await cache.set('key1', 'value1')
    await cache.set('key2', 'value2')
    await cache.set('key3', 'value3')

    # Add one more (should evict key1)
    await cache.set('key4', 'value4')

    assert await cache.get('key1') is None  # Evicted
    assert await cache.get('key2') == 'value2'
    assert await cache.get('key3') == 'value3'
    assert await cache.get('key4') == 'value4'

    assert cache.evictions == 1


@pytest.mark.asyncio
async def test_lru_cache_ordering():
    """Test LRU ordering"""
    cache = LRUCache(max_size=3)

    await cache.set('key1', 'value1')
    await cache.set('key2', 'value2')
    await cache.set('key3', 'value3')

    # Access key1 (makes it most recently used)
    await cache.get('key1')

    # Add key4 (should evict key2, not key1)
    await cache.set('key4', 'value4')

    assert await cache.get('key1') == 'value1'  # Still there
    assert await cache.get('key2') is None  # Evicted
    assert await cache.get('key3') == 'value3'
    assert await cache.get('key4') == 'value4'


@pytest.mark.asyncio
async def test_lru_cache_ttl():
    """Test TTL expiration"""
    cache = LRUCache(max_size=10)

    # Set with short TTL
    await cache.set('key1', 'value1', ttl=1)

    # Should be available immediately
    value = await cache.get('key1')
    assert value == 'value1'

    # Wait for expiration
    await asyncio.sleep(1.1)

    # Should be expired
    value = await cache.get('key1')
    assert value is None


@pytest.mark.asyncio
async def test_lru_cache_delete():
    """Test manual deletion"""
    cache = LRUCache(max_size=10)

    await cache.set('key1', 'value1')
    assert await cache.get('key1') == 'value1'

    await cache.delete('key1')
    assert await cache.get('key1') is None


@pytest.mark.asyncio
async def test_lru_cache_clear():
    """Test clearing cache"""
    cache = LRUCache(max_size=10)

    await cache.set('key1', 'value1')
    await cache.set('key2', 'value2')

    await cache.clear()

    assert await cache.get('key1') is None
    assert await cache.get('key2') is None
    assert len(cache.cache) == 0


@pytest.mark.asyncio
async def test_lru_cache_cleanup():
    """Test cleanup of expired entries"""
    cache = LRUCache(max_size=10)

    # Add entries with short TTL
    await cache.set('key1', 'value1', ttl=1)
    await cache.set('key2', 'value2', ttl=1)
    await cache.set('key3', 'value3', ttl=0)  # No expiration

    assert len(cache.cache) == 3

    # Wait for expiration
    await asyncio.sleep(1.1)

    # Cleanup
    await cache.cleanup_expired()

    assert len(cache.cache) == 1  # Only key3 remains
    assert await cache.get('key3') == 'value3'


@pytest.mark.asyncio
async def test_lru_cache_stats():
    """Test cache statistics"""
    cache = LRUCache(max_size=5)

    # Make some requests
    await cache.set('key1', 'value1')
    await cache.get('key1')  # Hit
    await cache.get('key2')  # Miss

    stats = cache.get_stats()

    assert stats['size'] == 1
    assert stats['max_size'] == 5
    assert stats['hits'] == 1
    assert stats['misses'] == 1
    assert '50.00%' in stats['hit_rate']


@pytest.mark.asyncio
async def test_cache_manager_memory_only():
    """Test cache manager with memory cache only"""
    manager = CacheManager(
        enable_memory_cache=True,
        enable_redis_cache=False
    )
    await manager.connect()

    await manager.set('test_key', 'test_value')
    value = await manager.get('test_key')

    assert value == 'test_value'

    await manager.disconnect()


@pytest.mark.asyncio
async def test_cache_manager_key_generation():
    """Test cache key generation"""
    manager = CacheManager(enable_memory_cache=True)

    # Same inputs should generate same key
    key1 = manager.make_cache_key('url', {'param': 'value'})
    key2 = manager.make_cache_key('url', {'param': 'value'})
    assert key1 == key2

    # Different inputs should generate different keys
    key3 = manager.make_cache_key('url', {'param': 'different'})
    assert key1 != key3


@pytest.mark.asyncio
async def test_cache_manager_ttl():
    """Test TTL in cache manager"""
    manager = CacheManager(enable_memory_cache=True)
    await manager.connect()

    await manager.set('key1', 'value1', ttl=1)

    # Should exist immediately
    value = await manager.get('key1')
    assert value == 'value1'

    # Wait for expiration
    await asyncio.sleep(1.1)

    # Should be expired
    value = await manager.get('key1')
    assert value is None

    await manager.disconnect()


@pytest.mark.asyncio
async def test_cache_manager_delete():
    """Test deletion from cache manager"""
    manager = CacheManager(enable_memory_cache=True)
    await manager.connect()

    await manager.set('key1', 'value1')
    assert await manager.get('key1') == 'value1'

    await manager.delete('key1')
    assert await manager.get('key1') is None

    await manager.disconnect()


@pytest.mark.asyncio
async def test_cache_manager_clear():
    """Test clearing cache manager"""
    manager = CacheManager(enable_memory_cache=True)
    await manager.connect()

    await manager.set('key1', 'value1')
    await manager.set('key2', 'value2')

    await manager.clear()

    assert await manager.get('key1') is None
    assert await manager.get('key2') is None

    await manager.disconnect()


@pytest.mark.asyncio
async def test_cache_manager_stats():
    """Test cache manager statistics"""
    manager = CacheManager(enable_memory_cache=True)
    await manager.connect()

    await manager.set('key1', 'value1')
    await manager.get('key1')  # Hit
    await manager.get('key2')  # Miss

    stats = manager.get_stats()

    assert stats['memory_cache_enabled'] == True
    assert 'memory_cache' in stats
    assert stats['memory_cache']['hits'] == 1
    assert stats['memory_cache']['misses'] == 1

    await manager.disconnect()


@pytest.mark.asyncio
async def test_cache_entry_expiration():
    """Test CacheEntry expiration check"""
    # Not expired
    entry1 = CacheEntry(
        key='key1',
        value='value1',
        timestamp=time.time(),
        ttl=10
    )
    assert entry1.is_expired() == False

    # Expired
    entry2 = CacheEntry(
        key='key2',
        value='value2',
        timestamp=time.time() - 20,
        ttl=10
    )
    assert entry2.is_expired() == True

    # No expiration (ttl=0)
    entry3 = CacheEntry(
        key='key3',
        value='value3',
        timestamp=time.time() - 1000,
        ttl=0
    )
    assert entry3.is_expired() == False


@pytest.mark.asyncio
async def test_concurrent_cache_access():
    """Test concurrent cache access"""
    cache = LRUCache(max_size=100)

    async def worker(worker_id):
        for i in range(50):
            key = f'key_{worker_id}_{i}'
            await cache.set(key, f'value_{worker_id}_{i}')
            value = await cache.get(key)
            assert value == f'value_{worker_id}_{i}'

    # Run 10 workers concurrently
    tasks = [worker(i) for i in range(10)]
    await asyncio.gather(*tasks)

    assert cache.hits == 500  # 10 workers * 50 gets
    assert len(cache.cache) <= 100  # Respects max size


@pytest.mark.asyncio
async def test_cache_with_complex_values():
    """Test caching complex data structures"""
    manager = CacheManager(enable_memory_cache=True)
    await manager.connect()

    # Test dict
    await manager.set('dict', {'key': 'value', 'nested': {'a': 1}})
    value = await manager.get('dict')
    assert value == {'key': 'value', 'nested': {'a': 1}}

    # Test list
    await manager.set('list', [1, 2, 3, {'a': 'b'}])
    value = await manager.get('list')
    assert value == [1, 2, 3, {'a': 'b'}]

    await manager.disconnect()


@pytest.mark.asyncio
async def test_cache_hit_tracking():
    """Test cache hit tracking"""
    cache = LRUCache(max_size=10)

    await cache.set('key1', 'value1')

    # Make multiple hits
    for i in range(5):
        await cache.get('key1')

    # Check entry hits
    entry = cache.cache['key1']
    assert entry.hits == 5


@pytest.mark.asyncio
async def test_cache_manager_warmup():
    """Test cache warming from L2 to L1"""
    manager = CacheManager(enable_memory_cache=True)
    await manager.connect()

    # Set in cache
    await manager.set('key1', 'value1', ttl=60)

    # Clear L1 (simulate cold start)
    if manager.memory_cache:
        await manager.memory_cache.clear()

    # Get should warm L1 from L2 (in this case, L2 is also memory)
    value = await manager.get('key1')
    # In our implementation, we only have L1, so this just tests basic get

    await manager.disconnect()


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
