"""
Unit tests for Duplicate Detector
"""

import pytest
import asyncio
from unittest.mock import Mock, patch, MagicMock
from src.utils.duplicate_detector import DuplicateDetector


class TestDuplicateDetector:
    """Test suite for duplicate detection functionality."""

    @pytest.fixture
    def detector(self):
        """Create detector instance for testing."""
        mock_db = Mock()
        mock_db.conn = Mock()
        return DuplicateDetector(db_connection=mock_db)

    @pytest.fixture
    def sample_vulnerability(self):
        """Sample vulnerability for testing."""
        return {
            'url': 'https://example.com/api/users',
            'category': 'idor',
            'parameters': 'id=123',
            'name': 'IDOR in User API'
        }

    def test_signature_generation(self, detector, sample_vulnerability):
        """Test vulnerability signature generation."""
        sig = detector._generate_signature(sample_vulnerability)

        assert sig is not None
        assert isinstance(sig, str)
        assert len(sig) == 32  # MD5 hash length

        # Same vulnerability should generate same signature
        sig2 = detector._generate_signature(sample_vulnerability)
        assert sig == sig2

    def test_signature_uniqueness(self, detector):
        """Test that different vulnerabilities generate different signatures."""
        vuln1 = {'url': 'https://example.com/api/users', 'category': 'idor', 'parameters': 'id=123'}
        vuln2 = {'url': 'https://example.com/api/posts', 'category': 'idor', 'parameters': 'id=123'}

        sig1 = detector._generate_signature(vuln1)
        sig2 = detector._generate_signature(vuln2)

        assert sig1 != sig2

    @pytest.mark.asyncio
    async def test_is_duplicate_own_database(self, detector, sample_vulnerability):
        """Test duplicate detection from own database."""
        # Mock database response
        detector.known_vulns.add(detector._generate_signature(sample_vulnerability))

        result = await detector.is_duplicate(sample_vulnerability)

        assert result['is_duplicate'] is True
        assert result['confidence'] == 1.0
        assert 'own_database' in result['reason'].lower()

    @pytest.mark.asyncio
    async def test_is_unique(self, detector, sample_vulnerability):
        """Test that unique vulnerabilities are identified correctly."""
        result = await detector.is_duplicate(sample_vulnerability)

        assert result['is_duplicate'] is False
        assert result['confidence'] == 0.0

    @pytest.mark.asyncio
    async def test_suggest_alternatives(self, detector, sample_vulnerability):
        """Test alternative suggestion generation."""
        alternatives = await detector.suggest_alternatives(sample_vulnerability)

        assert isinstance(alternatives, list)
        assert len(alternatives) > 0
        assert len(alternatives) <= 5  # Should return max 5 suggestions

        # Check that suggestions are relevant
        for alt in alternatives:
            assert isinstance(alt, str)
            assert len(alt) > 0

    @pytest.mark.asyncio
    async def test_cache_loading(self, detector):
        """Test that cache is properly loaded."""
        # Detector should initialize with empty or loaded cache
        assert isinstance(detector.known_vulns, set)
        assert isinstance(detector.disclosed_reports_cache, dict)

    def test_confidence_scoring(self, detector):
        """Test confidence score calculation."""
        # Own database should be 100%
        own_db_match = {'source': 'own_database'}

        # HackerOne should be 90%
        h1_match = {'source': 'hackerone', 'title': 'Test'}

        # Pattern match should be 50%
        pattern_match = {'similarity': 0.7}

        # These are tested implicitly in the is_duplicate method


class TestDuplicateDetectorIntegration:
    """Integration tests for duplicate detector."""

    @pytest.mark.asyncio
    async def test_full_duplicate_check_workflow(self):
        """Test complete duplicate checking workflow."""
        detector = DuplicateDetector(db_connection=None)

        vuln = {
            'url': 'https://example.com/test',
            'category': 'xss',
            'parameters': 'param=test'
        }

        # First check - should be unique
        result1 = await detector.is_duplicate(vuln)
        assert result1['is_duplicate'] is False

        # Second check - should detect as duplicate
        result2 = await detector.is_duplicate(vuln)
        assert result2['is_duplicate'] is True
        assert result2['confidence'] == 1.0

    @pytest.mark.asyncio
    async def test_alternative_suggestions_quality(self):
        """Test that alternative suggestions are relevant."""
        detector = DuplicateDetector(db_connection=None)

        vuln = {
            'url': 'https://example.com/api/users?id=123',
            'category': 'idor',
            'parameters': 'id=123'
        }

        alternatives = await detector.suggest_alternatives(vuln)

        # Should suggest similar endpoints
        assert any('api' in alt.lower() for alt in alternatives)

        # Should suggest related vulnerability types
        assert any('idor' in alt.lower() or 'auth' in alt.lower() for alt in alternatives)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
