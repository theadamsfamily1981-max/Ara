"""
Integration tests for complete workflow
"""

import pytest
import asyncio
from unittest.mock import Mock, patch, AsyncMock
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestWorkflowIntegration:
    """Integration tests for complete bug bounty workflow."""

    @pytest.mark.asyncio
    async def test_config_loading(self):
        """Test configuration loading."""
        from main import BugBountyOrchestrator

        # Should load config without errors
        with patch('main.load_dotenv'):
            with patch('os.makedirs'):
                with patch('src.utils.database.Database'):
                    orchestrator = BugBountyOrchestrator()
                    assert orchestrator.config is not None

    @pytest.mark.asyncio
    async def test_database_initialization(self):
        """Test database initialization."""
        from src.utils.database import Database

        # Create in-memory database for testing
        db = Database(':memory:')

        # Check tables exist
        cursor = db.conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in cursor.fetchall()]

        assert 'programs' in tables
        assert 'assets' in tables
        assert 'vulnerabilities' in tables
        assert 'reports' in tables

    @pytest.mark.asyncio
    async def test_vulnerability_to_report_flow(self):
        """Test flow from vulnerability discovery to report generation."""
        from src.utils.duplicate_detector import DuplicateDetector

        detector = DuplicateDetector(db_connection=None)

        # Simulate finding a vulnerability
        vuln = {
            'url': 'https://example.com/api/test',
            'category': 'xss',
            'severity': 'high',
            'name': 'XSS in Test Endpoint',
            'parameters': 'param=<script>'
        }

        # Check for duplicates
        dup_result = await detector.is_duplicate(vuln)

        # Should be unique first time
        assert dup_result['is_duplicate'] is False

        # Would proceed to reporting here in real workflow

    @pytest.mark.asyncio
    async def test_exploit_chain_detection_flow(self):
        """Test exploit chain detection in workflow."""
        from src.exploits.exploit_chainer import ExploitChainer

        chainer = ExploitChainer()

        # Simulate multiple vulnerabilities found
        vulnerabilities = [
            {'category': 'csrf', 'url': 'https://example.com/api/1', 'severity': 'medium', 'name': 'CSRF 1'},
            {'category': 'xss', 'url': 'https://example.com/api/2', 'severity': 'medium', 'name': 'XSS 1'},
        ]

        # Find chains
        chains = await chainer.find_chains(vulnerabilities)

        # Should find chain
        assert len(chains) > 0

        # Calculate bounty increase
        for chain in chains:
            bounty_info = chainer.calculate_bounty_increase(chain)
            assert bounty_info['increase'] > 0


class TestErrorHandling:
    """Test error handling across system."""

    @pytest.mark.asyncio
    async def test_duplicate_detector_api_failure(self):
        """Test duplicate detector handles API failures gracefully."""
        from src.utils.duplicate_detector import DuplicateDetector

        detector = DuplicateDetector(db_connection=None)

        vuln = {
            'url': 'https://invalid-domain-12345.com/test',
            'category': 'xss',
            'parameters': 'test'
        }

        # Should not crash even if external APIs fail
        result = await detector.is_duplicate(vuln)

        assert isinstance(result, dict)
        assert 'is_duplicate' in result
        assert 'confidence' in result

    def test_database_connection_error_handling(self):
        """Test database error handling."""
        from src.utils.database import Database

        # Try to create database in invalid location
        try:
            db = Database('/invalid/path/database.db')
            # Should handle gracefully or create in alternative location
        except Exception as e:
            # Should provide useful error message
            assert str(e)


class TestPerformance:
    """Performance tests."""

    @pytest.mark.asyncio
    async def test_duplicate_detection_speed(self):
        """Test that duplicate detection is fast enough."""
        from src.utils.duplicate_detector import DuplicateDetector
        import time

        detector = DuplicateDetector(db_connection=None)

        vuln = {
            'url': 'https://example.com/test',
            'category': 'xss',
            'parameters': 'test'
        }

        start = time.time()
        await detector.is_duplicate(vuln)
        duration = time.time() - start

        # Should complete in under 3 seconds (with network calls)
        assert duration < 3.0

    @pytest.mark.asyncio
    async def test_exploit_chain_detection_speed(self):
        """Test that exploit chain detection is fast."""
        from src.exploits.exploit_chainer import ExploitChainer
        import time

        chainer = ExploitChainer()

        # Create 50 vulnerabilities
        vulnerabilities = [
            {'category': 'xss', 'url': f'https://example.com/api/{i}', 'severity': 'medium', 'name': f'Vuln {i}'}
            for i in range(50)
        ]

        start = time.time()
        chains = await chainer.find_chains(vulnerabilities)
        duration = time.time() - start

        # Should complete in under 2 seconds
        assert duration < 2.0


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
