"""
Unit tests for Rate Limiter

Tests token bucket, sliding window, and adaptive rate limiting.
"""

import pytest
import asyncio
import time

import sys
sys.path.insert(0, '/home/user/gpu/src')

from core.rate_limiter import (
    TokenBucketRateLimiter,
    SlidingWindowRateLimiter,
    RateLimiter,
    AdaptiveRateLimiter
)


@pytest.mark.asyncio
async def test_token_bucket_basic():
    """Test basic token bucket functionality"""
    limiter = TokenBucketRateLimiter(rate=10, capacity=10)

    # Should be able to acquire immediately (bucket is full)
    assert await limiter.acquire(1) == True
    assert await limiter.acquire(5) == True

    # Bucket now has 4 tokens
    assert await limiter.acquire(4) == True

    # Bucket is empty, should fail
    assert await limiter.acquire(1) == False


@pytest.mark.asyncio
async def test_token_bucket_refill():
    """Test token bucket refill over time"""
    limiter = TokenBucketRateLimiter(rate=10, capacity=10)

    # Empty the bucket
    await limiter.acquire(10)

    # Wait for refill (0.5 seconds = 5 tokens)
    await asyncio.sleep(0.5)

    # Should have ~5 tokens
    assert await limiter.acquire(4) == True
    assert await limiter.acquire(2) == False  # Not enough tokens


@pytest.mark.asyncio
async def test_token_bucket_wait():
    """Test waiting for tokens"""
    limiter = TokenBucketRateLimiter(rate=100, capacity=10)

    # Empty the bucket
    await limiter.acquire(10)

    # Wait for 1 token (should take ~0.01s)
    start = time.time()
    await limiter.wait_for_token(1)
    elapsed = time.time() - start

    assert elapsed >= 0.01
    assert elapsed < 0.1  # Should be quick


@pytest.mark.asyncio
async def test_sliding_window_basic():
    """Test basic sliding window functionality"""
    limiter = SlidingWindowRateLimiter(max_requests=5, time_window=1)

    # Should allow up to max_requests
    for i in range(5):
        assert await limiter.acquire() == True

    # Should reject 6th request
    assert await limiter.acquire() == False


@pytest.mark.asyncio
async def test_sliding_window_expiration():
    """Test sliding window expiration"""
    limiter = SlidingWindowRateLimiter(max_requests=3, time_window=1)

    # Use all slots
    assert await limiter.acquire() == True
    assert await limiter.acquire() == True
    assert await limiter.acquire() == True
    assert await limiter.acquire() == False

    # Wait for window to expire
    await asyncio.sleep(1.1)

    # Should have slots again
    assert await limiter.acquire() == True


@pytest.mark.asyncio
async def test_sliding_window_wait():
    """Test waiting for slot"""
    limiter = SlidingWindowRateLimiter(max_requests=2, time_window=1)

    # Fill slots
    await limiter.acquire()
    await limiter.acquire()

    # Wait for slot (should wait ~1 second)
    start = time.time()
    await limiter.wait_for_slot()
    elapsed = time.time() - start

    assert elapsed >= 0.9


@pytest.mark.asyncio
async def test_sliding_window_current_rate():
    """Test current rate calculation"""
    limiter = SlidingWindowRateLimiter(max_requests=10, time_window=1)

    # Make some requests
    for i in range(5):
        await limiter.acquire()
        await asyncio.sleep(0.1)

    rate = limiter.get_current_rate()
    assert rate > 0
    assert rate <= 10


@pytest.mark.asyncio
async def test_rate_limiter_global():
    """Test global rate limiting"""
    limiter = RateLimiter(max_requests=10, time_window=1)

    # Make requests up to limit
    for i in range(10):
        await limiter.acquire()

    # Next request should wait
    start = time.time()
    await limiter.acquire()
    elapsed = time.time() - start

    assert elapsed > 0  # Some waiting occurred


@pytest.mark.asyncio
async def test_rate_limiter_per_host():
    """Test per-host rate limiting"""
    limiter = RateLimiter(
        max_requests=1000,
        time_window=60,
        per_host_limit=5
    )

    # Should allow up to per_host_limit for same host
    for i in range(5):
        await limiter.acquire(host='example.com')

    # 6th request to same host should wait
    result = await limiter.try_acquire(host='example.com')
    assert result == False

    # Different host should be independent
    result = await limiter.try_acquire(host='other.com')
    assert result == True


@pytest.mark.asyncio
async def test_rate_limiter_try_acquire():
    """Test non-blocking acquire"""
    limiter = RateLimiter(max_requests=5, time_window=1)

    # Should succeed up to limit
    for i in range(5):
        assert await limiter.try_acquire() == True

    # Should fail when limit reached
    assert await limiter.try_acquire() == False


@pytest.mark.asyncio
async def test_rate_limiter_stats():
    """Test rate limiter statistics"""
    limiter = RateLimiter(max_requests=5, time_window=1)

    # Make some requests
    for i in range(3):
        await limiter.acquire()

    # Try to exceed limit
    for i in range(3):
        await limiter.try_acquire()

    stats = limiter.get_stats()

    assert stats['total_requests'] == 6
    assert stats['blocked_requests'] > 0
    assert 'block_rate' in stats
    assert 'average_wait_time_ms' in stats


@pytest.mark.asyncio
async def test_rate_limiter_reset():
    """Test rate limiter reset"""
    limiter = RateLimiter(max_requests=3, time_window=1)

    # Fill up
    for i in range(3):
        await limiter.acquire()

    # Reset
    await limiter.reset()

    # Should be able to make requests again
    assert await limiter.try_acquire() == True


@pytest.mark.asyncio
async def test_adaptive_rate_limiter_backoff():
    """Test adaptive rate limiter backoff on 429"""
    limiter = AdaptiveRateLimiter(max_requests=100, time_window=1)

    initial_multiplier = limiter.current_multiplier

    # Simulate 429 response
    await limiter.record_response(429)

    # Should have backed off
    assert limiter.current_multiplier < initial_multiplier


@pytest.mark.asyncio
async def test_adaptive_rate_limiter_recovery():
    """Test adaptive rate limiter rate increase on success"""
    limiter = AdaptiveRateLimiter(max_requests=100, time_window=1)

    # Back off first
    await limiter.record_response(429)
    backed_off_multiplier = limiter.current_multiplier

    # Simulate successful responses
    for i in range(15):
        await limiter.record_response(200)

    # Should have increased rate
    assert limiter.current_multiplier > backed_off_multiplier


@pytest.mark.asyncio
async def test_adaptive_rate_limiter_circuit_breaker():
    """Test circuit breaker activation"""
    limiter = AdaptiveRateLimiter(max_requests=100, time_window=1)

    # Trigger circuit breaker with repeated 429s
    for i in range(12):
        await limiter.record_response(429)

    assert limiter.circuit_breaker_active == True
    assert limiter.circuit_breaker_reset_time is not None


@pytest.mark.asyncio
async def test_concurrent_rate_limiting():
    """Test rate limiting under concurrent load"""
    limiter = RateLimiter(max_requests=20, time_window=1)

    # Make 100 concurrent requests
    async def make_request():
        await limiter.acquire()

    tasks = [make_request() for _ in range(100)]

    start = time.time()
    await asyncio.gather(*tasks)
    elapsed = time.time() - start

    # Should take multiple seconds due to rate limiting
    assert elapsed >= 4  # 100 requests / 20 per second = 5 seconds minimum


@pytest.mark.asyncio
async def test_burst_handling():
    """Test burst traffic handling"""
    limiter = RateLimiter(
        max_requests=10,
        time_window=1,
        burst_size=20
    )

    # Should handle burst quickly
    start = time.time()

    for i in range(20):
        await limiter.acquire()

    elapsed = time.time() - start

    # Burst should be fast (under 1 second)
    assert elapsed < 2


@pytest.mark.asyncio
async def test_multiple_hosts():
    """Test rate limiting across multiple hosts"""
    limiter = RateLimiter(
        max_requests=1000,
        time_window=60,
        per_host_limit=3
    )

    hosts = ['host1.com', 'host2.com', 'host3.com']

    # Each host should have independent limit
    for host in hosts:
        for i in range(3):
            result = await limiter.try_acquire(host=host)
            assert result == True

        # 4th request should fail
        result = await limiter.try_acquire(host=host)
        assert result == False


@pytest.mark.asyncio
async def test_rate_limiter_accuracy():
    """Test rate limiter accuracy over time"""
    limiter = RateLimiter(max_requests=10, time_window=1)

    start = time.time()
    request_times = []

    # Make 30 requests
    for i in range(30):
        await limiter.acquire()
        request_times.append(time.time() - start)

    elapsed = time.time() - start

    # Should take ~3 seconds (30 requests / 10 per second)
    assert 2.5 <= elapsed <= 3.5

    # Check that requests are spread out
    # First 10 should be fast, then spacing increases
    assert request_times[9] < 0.5
    assert request_times[20] > 2.0


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
