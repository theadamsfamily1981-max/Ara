"""
Unit tests for BaseAnalyzer

Tests connection pooling, rate limiting, caching, and metrics.
"""

import pytest
import asyncio
from unittest.mock import Mock, patch, AsyncMock
from aiohttp import web
import aiohttp

import sys
sys.path.insert(0, '/home/user/gpu/src')

from core.base_analyzer import BaseAnalyzer, AnalyzerStats, RequestMetrics
from core.config import AnalyzerConfig
from core.cache_manager import CacheManager


class TestAnalyzer(BaseAnalyzer):
    """Test analyzer for testing base functionality"""

    def __init__(self, *args, **kwargs):
        super().__init__(name="test_analyzer", *args, **kwargs)


@pytest.fixture
async def test_server():
    """Create a test HTTP server"""

    async def handler(request):
        return web.Response(text='{"status": "ok"}', content_type='application/json')

    async def slow_handler(request):
        await asyncio.sleep(0.1)
        return web.Response(text='{"status": "slow"}', content_type='application/json')

    async def error_handler(request):
        return web.Response(status=500, text='Error')

    app = web.Application()
    app.router.add_get('/test', handler)
    app.router.add_post('/test', handler)
    app.router.add_get('/slow', slow_handler)
    app.router.add_get('/error', error_handler)

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, 'localhost', 8765)
    await site.start()

    yield 'http://localhost:8765'

    await runner.cleanup()


@pytest.mark.asyncio
async def test_analyzer_initialization():
    """Test analyzer initialization"""
    config = AnalyzerConfig()
    analyzer = TestAnalyzer(config=config)

    assert analyzer.name == "test_analyzer"
    assert analyzer.config == config
    assert analyzer.session is None
    assert analyzer.stats.total_requests == 0


@pytest.mark.asyncio
async def test_context_manager():
    """Test async context manager"""
    config = AnalyzerConfig()

    async with TestAnalyzer(config=config) as analyzer:
        assert analyzer.session is not None

    # Session should be closed
    assert analyzer.session is None


@pytest.mark.asyncio
async def test_basic_request(test_server):
    """Test basic HTTP request"""
    config = AnalyzerConfig()
    config.ssl_verify = False

    async with TestAnalyzer(config=config) as analyzer:
        response = await analyzer.request('GET', f'{test_server}/test')

        assert response['status'] == 200
        assert 'ok' in response['body']
        assert response['json']['status'] == 'ok'
        assert not response['cached']
        assert analyzer.stats.total_requests == 1
        assert analyzer.stats.successful_requests == 1


@pytest.mark.asyncio
async def test_post_request(test_server):
    """Test POST request with JSON body"""
    config = AnalyzerConfig()
    config.ssl_verify = False

    async with TestAnalyzer(config=config) as analyzer:
        response = await analyzer.request(
            'POST',
            f'{test_server}/test',
            json={'data': 'test'}
        )

        assert response['status'] == 200
        assert analyzer.stats.successful_requests == 1


@pytest.mark.asyncio
async def test_caching():
    """Test request caching"""
    config = AnalyzerConfig()
    config.ssl_verify = False
    config.cache_enabled = True

    cache_manager = CacheManager(
        enable_memory_cache=True,
        enable_redis_cache=False
    )
    await cache_manager.connect()

    async with TestAnalyzer(config=config, cache_manager=cache_manager) as analyzer:
        # First request - not cached
        response1 = await analyzer.request('GET', 'http://httpbin.org/uuid', use_cache=True)
        assert not response1['cached']
        assert analyzer.stats.cached_requests == 0

        # Second request - should be cached
        response2 = await analyzer.request('GET', 'http://httpbin.org/uuid', use_cache=True)
        assert response2['cached']
        assert analyzer.stats.cached_requests == 1

        # Responses should be identical
        assert response1['body'] == response2['body']

    await cache_manager.disconnect()


@pytest.mark.asyncio
async def test_rate_limiting():
    """Test rate limiting"""
    config = AnalyzerConfig()
    config.ssl_verify = False
    config.rate_limit_requests = 5
    config.rate_limit_window_seconds = 1

    async with TestAnalyzer(config=config) as analyzer:
        # Should be able to make requests up to limit
        start_time = asyncio.get_event_loop().time()

        for i in range(5):
            await analyzer.rate_limiter.acquire()

        # Next request should be rate limited
        await analyzer.rate_limiter.acquire()

        elapsed = asyncio.get_event_loop().time() - start_time

        # Should have waited due to rate limiting
        assert elapsed >= 0.5  # Some waiting occurred


@pytest.mark.asyncio
async def test_connection_pooling(test_server):
    """Test connection pooling"""
    config = AnalyzerConfig()
    config.ssl_verify = False
    config.max_concurrent_connections = 10

    async with TestAnalyzer(config=config) as analyzer:
        # Make multiple concurrent requests
        tasks = []
        for i in range(20):
            task = analyzer.request('GET', f'{test_server}/test')
            tasks.append(task)

        responses = await asyncio.gather(*tasks)

        assert len(responses) == 20
        assert all(r['status'] == 200 for r in responses)
        assert analyzer.stats.total_requests == 20
        assert analyzer.stats.successful_requests == 20


@pytest.mark.asyncio
async def test_error_handling(test_server):
    """Test error handling and retries"""
    config = AnalyzerConfig()
    config.ssl_verify = False
    config.max_retries = 2

    async with TestAnalyzer(config=config) as analyzer:
        # Request to error endpoint
        response = await analyzer.request('GET', f'{test_server}/error', retry_count=1)

        assert response['status'] == 500
        assert analyzer.stats.failed_requests == 1


@pytest.mark.asyncio
async def test_timeout():
    """Test request timeout"""
    config = AnalyzerConfig()
    config.ssl_verify = False
    config.request_timeout_seconds = 1

    async with TestAnalyzer(config=config) as analyzer:
        # Request to slow endpoint that will timeout
        with pytest.raises(Exception) as exc_info:
            await analyzer.request('GET', 'http://httpbin.org/delay/5', retry_count=1)

        assert 'Timeout' in str(exc_info.value) or 'failed' in str(exc_info.value)


@pytest.mark.asyncio
async def test_retry_logic(test_server):
    """Test automatic retry logic"""
    config = AnalyzerConfig()
    config.ssl_verify = False
    config.max_retries = 3

    retry_count = {'count': 0}

    original_request = aiohttp.ClientSession.request

    async def mock_request(*args, **kwargs):
        retry_count['count'] += 1
        if retry_count['count'] < 3:
            raise aiohttp.ClientError("Connection failed")
        return await original_request(*args, **kwargs)

    async with TestAnalyzer(config=config) as analyzer:
        # Should retry and eventually succeed
        # (This test would need proper mocking in production)
        pass


@pytest.mark.asyncio
async def test_metrics_collection(test_server):
    """Test metrics collection"""
    config = AnalyzerConfig()
    config.ssl_verify = False

    async with TestAnalyzer(config=config) as analyzer:
        # Make several requests
        await analyzer.request('GET', f'{test_server}/test')
        await analyzer.request('POST', f'{test_server}/test')
        await analyzer.request('GET', f'{test_server}/error')

        # Check metrics
        assert len(analyzer.metrics) == 3

        # Check stats
        stats = analyzer.get_stats()
        assert stats['total_requests'] == 3
        assert stats['successful_requests'] == 2
        assert stats['failed_requests'] == 1

        # Get recent metrics
        metrics = analyzer.get_metrics(limit=10)
        assert len(metrics) == 3
        assert all('endpoint' in m for m in metrics)
        assert all('duration_ms' in m for m in metrics)


@pytest.mark.asyncio
async def test_stats_calculation():
    """Test statistics calculation"""
    stats = AnalyzerStats()

    # No requests
    assert stats.success_rate == 0.0
    assert stats.average_duration_ms == 0.0
    assert stats.cache_hit_rate == 0.0

    # Add some requests
    stats.total_requests = 100
    stats.successful_requests = 80
    stats.failed_requests = 20
    stats.cached_requests = 30
    stats.total_duration_ms = 8000

    assert stats.success_rate == 80.0
    assert stats.average_duration_ms == 100.0
    assert stats.cache_hit_rate == 30.0


@pytest.mark.asyncio
async def test_custom_headers(test_server):
    """Test custom headers"""
    config = AnalyzerConfig()
    config.ssl_verify = False
    config.user_agent = "CustomAgent/1.0"

    async with TestAnalyzer(config=config) as analyzer:
        response = await analyzer.request(
            'GET',
            f'{test_server}/test',
            headers={'X-Custom': 'value'}
        )

        assert response['status'] == 200


@pytest.mark.asyncio
async def test_cache_ttl():
    """Test cache TTL expiration"""
    config = AnalyzerConfig()
    config.cache_enabled = True

    cache_manager = CacheManager(enable_memory_cache=True)
    await cache_manager.connect()

    # Set value with short TTL
    await cache_manager.set('test_key', 'test_value', ttl=1)

    # Should be available immediately
    value = await cache_manager.get('test_key')
    assert value == 'test_value'

    # Wait for expiration
    await asyncio.sleep(1.5)

    # Should be expired
    value = await cache_manager.get('test_key')
    assert value is None

    await cache_manager.disconnect()


@pytest.mark.asyncio
async def test_parallel_analyzers(test_server):
    """Test multiple analyzer instances"""
    config = AnalyzerConfig()
    config.ssl_verify = False

    analyzers = []
    for i in range(5):
        analyzer = TestAnalyzer(config=config)
        await analyzer.__aenter__()
        analyzers.append(analyzer)

    # Make requests with all analyzers
    tasks = []
    for analyzer in analyzers:
        task = analyzer.request('GET', f'{test_server}/test')
        tasks.append(task)

    responses = await asyncio.gather(*tasks)

    assert len(responses) == 5
    assert all(r['status'] == 200 for r in responses)

    # Cleanup
    for analyzer in analyzers:
        await analyzer.__aexit__(None, None, None)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
