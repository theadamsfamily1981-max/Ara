#!/bin/bash
#
# Bug Bounty Automation System - One-Command Installer
# Supports: Ubuntu/Debian, CentOS/RHEL, macOS
#

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Banner
echo -e "${BLUE}"
cat << "EOF"
╔══════════════════════════════════════════════════════════╗
║                                                          ║
║       🎯 Bug Bounty Automation System Installer 🎯       ║
║                                                          ║
║            Automated Red Hat Bug Bounty Hunter          ║
║                    Version 1.0.0                        ║
║                                                          ║
╚══════════════════════════════════════════════════════════╝
EOF
echo -e "${NC}"

# Functions
print_step() {
    echo -e "\n${BLUE}==>${NC} ${GREEN}$1${NC}"
}

print_info() {
    echo -e "${YELLOW}ℹ${NC}  $1"
}

print_success() {
    echo -e "${GREEN}✓${NC}  $1"
}

print_error() {
    echo -e "${RED}✗${NC}  $1"
}

# Check if running as root
check_root() {
    if [[ $EUID -eq 0 ]]; then
        print_error "This script should NOT be run as root"
        print_info "Please run as a regular user. Sudo will be requested when needed."
        exit 1
    fi
}

# Detect OS
detect_os() {
    print_step "Detecting operating system..."

    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        if [ -f /etc/os-release ]; then
            . /etc/os-release
            OS=$ID
            VER=$VERSION_ID
            print_success "Detected: $PRETTY_NAME"
        else
            print_error "Cannot detect Linux distribution"
            exit 1
        fi
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        OS="macos"
        VER=$(sw_vers -productVersion)
        print_success "Detected: macOS $VER"
    else
        print_error "Unsupported operating system: $OSTYPE"
        exit 1
    fi
}

# Check Python version
check_python() {
    print_step "Checking Python installation..."

    if command -v python3 &> /dev/null; then
        PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
        PYTHON_MAJOR=$(echo $PYTHON_VERSION | cut -d'.' -f1)
        PYTHON_MINOR=$(echo $PYTHON_VERSION | cut -d'.' -f2)

        if [ "$PYTHON_MAJOR" -ge 3 ] && [ "$PYTHON_MINOR" -ge 8 ]; then
            print_success "Python $PYTHON_VERSION found"
        else
            print_error "Python 3.8+ required, found $PYTHON_VERSION"
            print_info "Please install Python 3.8 or newer"
            exit 1
        fi
    else
        print_error "Python 3 not found"
        print_info "Installing Python 3..."
        install_python
    fi
}

# Install system dependencies
install_dependencies() {
    print_step "Installing system dependencies..."

    case $OS in
        ubuntu|debian)
            print_info "Using apt package manager..."
            sudo apt-get update
            sudo apt-get install -y \
                python3-pip python3-dev python3-venv \
                git curl wget \
                build-essential libssl-dev libffi-dev \
                nmap masscan \
                dnsutils netcat \
                jq vim
            ;;
        centos|rhel|fedora)
            print_info "Using yum/dnf package manager..."
            if command -v dnf &> /dev/null; then
                sudo dnf install -y \
                    python3-pip python3-devel \
                    git curl wget \
                    gcc gcc-c++ make openssl-devel \
                    nmap masscan \
                    bind-utils nc \
                    jq vim
            else
                sudo yum install -y \
                    python3-pip python3-devel \
                    git curl wget \
                    gcc gcc-c++ make openssl-devel \
                    nmap masscan \
                    bind-utils nc \
                    jq vim
            fi
            ;;
        macos)
            print_info "Using Homebrew package manager..."
            if ! command -v brew &> /dev/null; then
                print_info "Installing Homebrew..."
                /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
            fi
            brew install python@3.11 git curl wget nmap masscan jq
            ;;
        *)
            print_error "Unsupported OS for automatic dependency installation"
            exit 1
            ;;
    esac

    print_success "System dependencies installed"
}

# Install Go and Go-based security tools
install_go_tools() {
    print_step "Installing Go and security tools..."

    # Check if Go is installed
    if ! command -v go &> /dev/null; then
        print_info "Installing Go..."

        GO_VERSION="1.21.5"
        case $(uname -m) in
            x86_64)
                GO_ARCH="amd64"
                ;;
            aarch64|arm64)
                GO_ARCH="arm64"
                ;;
            *)
                print_error "Unsupported architecture: $(uname -m)"
                exit 1
                ;;
        esac

        wget https://go.dev/dl/go${GO_VERSION}.linux-${GO_ARCH}.tar.gz
        sudo rm -rf /usr/local/go
        sudo tar -C /usr/local -xzf go${GO_VERSION}.linux-${GO_ARCH}.tar.gz
        rm go${GO_VERSION}.linux-${GO_ARCH}.tar.gz

        # Add to PATH
        if ! grep -q "/usr/local/go/bin" ~/.bashrc; then
            echo 'export PATH=$PATH:/usr/local/go/bin:$HOME/go/bin' >> ~/.bashrc
        fi
        export PATH=$PATH:/usr/local/go/bin:$HOME/go/bin

        print_success "Go installed: $(go version)"
    else
        print_success "Go already installed: $(go version)"
    fi

    # Install security tools
    print_info "Installing security tools..."

    go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest
    go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
    go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest
    go install -v github.com/owasp-amass/amass/v4/...@master

    # Update nuclei templates
    ~/go/bin/nuclei -update-templates

    print_success "Security tools installed"
}

# Create virtual environment and install Python packages
install_python_packages() {
    print_step "Setting up Python virtual environment..."

    # Create venv if it doesn't exist
    if [ ! -d "venv" ]; then
        python3 -m venv venv
        print_success "Virtual environment created"
    else
        print_info "Virtual environment already exists"
    fi

    # Activate venv
    source venv/bin/activate

    # Upgrade pip
    print_info "Upgrading pip..."
    pip install --upgrade pip setuptools wheel

    # Install requirements
    print_info "Installing Python packages..."
    pip install -r requirements.txt

    # Install package in development mode
    pip install -e .

    print_success "Python packages installed"
}

# Setup configuration
setup_config() {
    print_step "Setting up configuration..."

    # Create .env from template if it doesn't exist
    if [ ! -f .env ]; then
        if [ -f .env.template ]; then
            cp .env.template .env
            print_success "Created .env from template"
            print_info "Please edit .env file with your API keys and credentials"
        else
            print_error ".env.template not found"
        fi
    else
        print_info ".env file already exists"
    fi

    # Create necessary directories
    print_info "Creating directories..."
    mkdir -p data logs reports screenshots templates/custom

    # Set permissions
    chmod 700 data logs
    chmod 755 reports screenshots

    print_success "Configuration setup complete"
}

# Docker installation (optional)
install_docker() {
    print_step "Checking Docker installation..."

    if command -v docker &> /dev/null; then
        print_success "Docker already installed: $(docker --version)"
    else
        read -p "Docker not found. Install Docker? (y/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            print_info "Installing Docker..."
            curl -fsSL https://get.docker.com -o get-docker.sh
            sudo sh get-docker.sh
            sudo usermod -aG docker $USER
            rm get-docker.sh
            print_success "Docker installed"
            print_info "Please log out and back in for Docker group changes to take effect"
        fi
    fi

    # Check Docker Compose
    if command -v docker-compose &> /dev/null || docker compose version &> /dev/null 2>&1; then
        print_success "Docker Compose available"
    else
        print_info "Docker Compose not found but may not be needed"
    fi
}

# Run database migrations
run_migrations() {
    print_step "Running database migrations..."

    source venv/bin/activate
    python -c "from src.utils.db_migrations import run_all_migrations; run_all_migrations()"

    print_success "Database migrations complete"
}

# Generate secret key
generate_secret_key() {
    if ! grep -q "FLASK_SECRET_KEY=your-secret" .env 2>/dev/null; then
        return
    fi

    print_step "Generating Flask secret key..."

    SECRET_KEY=$(python3 -c "import secrets; print(secrets.token_hex(32))")

    if [[ "$OSTYPE" == "darwin"* ]]; then
        sed -i '' "s/FLASK_SECRET_KEY=.*/FLASK_SECRET_KEY=$SECRET_KEY/" .env
    else
        sed -i "s/FLASK_SECRET_KEY=.*/FLASK_SECRET_KEY=$SECRET_KEY/" .env
    fi

    print_success "Secret key generated"
}

# Final instructions
print_instructions() {
    echo ""
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║                                                          ║${NC}"
    echo -e "${GREEN}║         ✓  Installation Complete!  ✓                    ║${NC}"
    echo -e "${GREEN}║                                                          ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${BLUE}Next Steps:${NC}"
    echo ""
    echo -e "1. ${YELLOW}Configure your credentials:${NC}"
    echo -e "   ${GREEN}vi .env${NC}"
    echo -e "   Add your API tokens for HackerOne, Bugcrowd, etc."
    echo ""
    echo -e "2. ${YELLOW}Start the Web GUI:${NC}"
    echo -e "   ${GREEN}make run${NC}"
    echo -e "   Or: ${GREEN}source venv/bin/activate && python web_gui.py${NC}"
    echo -e "   Access at: ${BLUE}http://localhost:5000${NC}"
    echo ""
    echo -e "3. ${YELLOW}Or use Docker:${NC}"
    echo -e "   ${GREEN}make docker-up${NC}"
    echo -e "   Or: ${GREEN}docker-compose up -d${NC}"
    echo ""
    echo -e "4. ${YELLOW}Run continuous hunting:${NC}"
    echo -e "   ${GREEN}make hunt${NC}"
    echo -e "   Or: ${GREEN}source venv/bin/activate && python main.py --continuous${NC}"
    echo ""
    echo -e "${BLUE}Useful Commands:${NC}"
    echo -e "   ${GREEN}make help${NC}          - Show all available commands"
    echo -e "   ${GREEN}make status${NC}        - Check system status"
    echo -e "   ${GREEN}make test${NC}          - Run tests"
    echo -e "   ${GREEN}make logs${NC}          - View logs"
    echo ""
    echo -e "${BLUE}Documentation:${NC}"
    echo -e "   ${GREEN}cat INSTALL.md${NC}                         - Installation guide"
    echo -e "   ${GREEN}cat USER_GUIDE_CREDENTIALS_REPORTS.md${NC} - Usage guide"
    echo -e "   ${GREEN}cat EFFECTIVENESS_ANALYSIS.md${NC}         - System capabilities"
    echo ""
    echo -e "${YELLOW}⚠  Remember to configure your .env file before running!${NC}"
    echo ""
}

# Main installation flow
main() {
    check_root
    detect_os
    check_python
    install_dependencies
    install_go_tools
    install_python_packages
    setup_config
    generate_secret_key
    run_migrations
    install_docker
    print_instructions
}

# Run main function
main
